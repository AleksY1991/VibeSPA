import { createSignal } from 'solid-js';
import {
  Button, Card, Dialog, LayerPortal, List, Popover, ScrollArea, SplitPanel,
  TabPanel, Tabs, TooltipLayer, constructItem,
  type ButtonState, type SplitPanelState, type TabOption, type TabsState,
} from '@ui-kit/core';

/**
 * @component Card
 * @use Group related content in a shared surface; the parent owns page layout.
 */
export function CardExample() {
  const visible = constructItem('example.card', item => item.constant('visible', true));
  return (
    <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="content">
      <h2>Project details</h2>
      <p>Related content shares one surface.</p>
    </Card.View>
  );
}

/**
 * @component Dialog
 * @use Open a named modal with an owned layer; choose editor only for a bounded editing frame.
 */
export function DialogExample() {
  const [open, setOpen] = createSignal(false);
  const state = constructItem('example.dialog', item => ({
    open: item.observe('open', open),
    action: item.constant<ButtonState>('action', {}),
  }));
  return (
    <>
      <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setOpen(true)}>Open details</Button.View>
      <Dialog.View observable={state.open}
        surface={{ kind: 'own', name: 'example.details', transparent: false, layer: true }} hotkeys={[]}
        recipe="dialog" label="Project details" onOpenChange={setOpen}>
        <p>The dialog owns dismissal, modality and focus restoration.</p>
        <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="outline" onActivate={() => setOpen(false)}>Done</Button.View>
      </Dialog.View>
    </>
  );
}

/**
 * @component Popover
 * @use Disclose secondary commands behind a specifically named trigger; the shared panel owns keyboard focus and dismissal.
 */
export function PopoverExample() {
  const [open, setOpen] = createSignal(false);
  const [lastAction, setLastAction] = createSignal('');
  const state = constructItem('example.popover', item => ({
    open: item.observe('open', open),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: open() })),
    action: item.constant<ButtonState>('action', {}),
  }));
  return (
    <><Popover.View observable={state.open}
      surface={{ kind: 'own', name: 'example.options', transparent: false, layer: true }} hotkeys={[]}
      recipe="actions" onOpenChange={setOpen} aria-label="Project actions"
      trigger={api => (
        <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
          aria-controls={api.contentId} aria-haspopup="dialog" onActivate={api.toggle}>Project actions</Button.View>
      )}>
      {api => (
        <>
          <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="menu-item" onActivate={() => { setLastAction('Export project'); api.close(); }}>Export project</Button.View>
          <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="menu-item" onActivate={() => { setLastAction('Archive project'); api.close(); }}>Archive project</Button.View>
        </>
      )}
    </Popover.View>
    <output aria-live="polite">{lastAction() ? `Selected action: ${lastAction()}` : ''}</output></>
  );
}

/**
 * @component LayerPortal
 * @use Move owned content outside clipping ancestors while keeping its surface lineage.
 */
export function LayerPortalExample() {
  const [visible, setVisible] = createSignal(false);
  const state = constructItem('example.portal', item => ({
    visible: item.observe('visible', visible),
    action: item.constant<ButtonState>('action', {}),
  }));
  return (
    <>
      <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setVisible(value => !value)}>Toggle portaled content</Button.View>
      <LayerPortal.View observable={state.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>
        <p>Portaled content retains its existing owner.</p>
      </LayerPortal.View>
    </>
  );
}

/**
 * @component ScrollArea
 * @use Give bounded content native scrolling and keyboard behavior; set its available space on a parent.
 */
export function ScrollAreaExample() {
  const visible = constructItem('example.scroll', item => item.constant('visible', true));
  return (
    <div style={{ height: '8rem' }}>
      <ScrollArea.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
        fill orientation="vertical" role="region" aria-label="Project notes">
        <p>First note. The browser owns scrolling and text selection.</p>
        <p>Second note. Keyboard users can enter an overflowing region.</p>
        <p>Third note. The parent supplies the available height.</p>
        <p>Fourth note. Content may grow without replacing its owner.</p>
      </ScrollArea.View>
    </div>
  );
}

/**
 * @component TooltipLayer
 * @use Mount one delegated tooltip owner for an active application view; data-tip supplies optional mouse hints.
 */
export function TooltipLayerExample() {
  const state = constructItem('example.tooltip', item => ({
    enabled: item.constant('enabled', true),
    action: item.constant<ButtonState>('action', {}),
  }));
  const [saved, setSaved] = createSignal(false);
  return (
    <>
      <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" data-tip="Save these local edits" onActivate={() => setSaved(true)}>Save</Button.View>
      <p>{saved() ? 'Saved' : 'Unsaved changes'}</p>
      <TooltipLayer.View observable={state.enabled} surface={{ kind: 'inherit' }} hotkeys={[]} />
    </>
  );
}

/**
 * @component List
 * @use Render repeated records by stable key; read each supplied row observable inside reactive JSX.
 */
export function ListExample() {
  const [records, setRecords] = createSignal<readonly { id: string; label: string }[]>([
    { id: 'first', label: 'First record' }, { id: 'second', label: 'Second record' },
  ]);
  const state = constructItem('example.list', item => ({
    rows: item.observe('records', records),
    action: item.constant<ButtonState>('action', {}),
  }));
  return (
    <>
      <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setRecords(rows => [...rows].reverse())}>Reverse order</Button.View>
      <ol>
        <List.View observable={state.rows} surface={{ kind: 'inherit' }} hotkeys={[]}
          keyBy={record => record.id}>
          {row => <li>{row.read().label}</li>}
        </List.View>
      </ol>
    </>
  );
}

/**
 * @component Tabs
 * @use Switch between named panels; keep tab and panel IDs paired and selection in a typed observable.
 */
export function TabsExample() {
  type View = 'overview' | 'history';
  const [selected, setSelected] = createSignal<View>('overview');
  const tabs: readonly TabOption<View>[] = [
    { value: 'overview', label: 'Overview', id: 'example-overview-tab', panelId: 'example-overview-panel' },
    { value: 'history', label: 'History', id: 'example-history-tab', panelId: 'example-history-panel' },
  ];
  const state = constructItem('example.tabs', item => ({
    tabs: item.observe<TabsState<View>>('tabs', () => ({ value: selected(), tabs })),
    overview: item.observe('overview', () => selected() === 'overview'),
    history: item.observe('history', () => selected() === 'history'),
  }));
  return (
    <>
      <Tabs.View observable={state.tabs} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Project views" size="dense" onValueChange={setSelected} />
      <TabPanel.View observable={state.overview} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="example-overview-panel" tabId="example-overview-tab" value="overview">Overview content</TabPanel.View>
      <TabPanel.View observable={state.history} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="example-history-panel" tabId="example-history-tab" value="history">History content</TabPanel.View>
    </>
  );
}

/**
 * @component TabPanel
 * @use Associate retained panel content with its tab; drive visibility from the same selected value as the tablist.
 */
export function TabPanelExample() {
  const [selected, setSelected] = createSignal<'details'>('details');
  const tabs: readonly TabOption<'details'>[] = [
    { value: 'details', label: 'Details', id: 'example-details-tab', panelId: 'example-details-panel' },
  ];
  const state = constructItem('example.tab-panel', item => ({
    tabs: item.observe<TabsState<'details'>>('tabs', () => ({ value: selected(), tabs })),
    active: item.observe('active', () => selected() === 'details'),
  }));
  return (
    <>
      <Tabs.View observable={state.tabs} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Detail views" size="dense" onValueChange={setSelected} />
      <TabPanel.View observable={state.active} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="example-details-panel" tabId="example-details-tab" value="details">
        <p>This panel stays associated with its named tab.</p>
      </TabPanel.View>
    </>
  );
}

/**
 * @component SplitPanel
 * @use Give two related panes one keyboard-accessible resize divider and an explicit size command.
 */
export function SplitPanelExample() {
  const [endSize, setEndSize] = createSignal(256);
  const state = constructItem('example.split-panel', item =>
    item.observe<SplitPanelState>('state', () => ({ endSize: endSize(), collapsed: false })));
  return (
    <SplitPanel.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
      min={160} max={480} step={16} label="Details pane width" onEndSizeChange={setEndSize}
      start={<main><h2>Document</h2><p>Main content</p></main>}
      end={<aside><h2>Details</h2><p>Supporting content</p></aside>} />
  );
}
