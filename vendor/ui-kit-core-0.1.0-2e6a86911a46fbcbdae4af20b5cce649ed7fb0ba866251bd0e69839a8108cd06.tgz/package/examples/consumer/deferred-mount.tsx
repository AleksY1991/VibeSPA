/** @jsxImportSource @solidjs/web */
import { Button, constructItem } from '@ui-kit/core';
import { renderUiRoot, scopedUiMount } from '@ui-kit/core/infrastructure/renderUiRoot';

/** Create once inside the prepared UI owner; call later from a grid/editor callback. */
export function createDeferredActionCells() {
  return scopedUiMount((host: HTMLElement, label: string, activate: () => void) => renderUiRoot(() => {
    const state = constructItem('cell.action', item => item.constant('state', {}));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="cell-action" onActivate={activate}>{label}</Button.View>;
  }, host));
}
