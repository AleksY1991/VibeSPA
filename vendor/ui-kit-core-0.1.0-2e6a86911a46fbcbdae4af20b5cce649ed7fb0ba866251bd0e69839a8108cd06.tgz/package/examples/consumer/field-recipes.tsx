/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { Button, Select, TextField, Textarea, XIcon, constructItem, type ButtonState } from '@ui-kit/core';

/**
 * @component TextField
 * @recipe entry
 * @use Use field-sized text for a prominent single-line entry while retaining the selected canonical control target.
 */
export function TextFieldEntryExample() {
  const [email, setEmail] = createSignal('');
  const value = constructItem('example.entry.email', item => item.observe('value', email));
  return <TextField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="entry" label="Contact email" labelVisible type="email" autocomplete="email"
    onValueChange={next => setEmail(next)} />;
}

/**
 * @component TextField
 * @recipe title
 * @use Edit a document heading with the shared heading typography instead of assigning a custom font size or weight.
 */
export function TextFieldTitleExample() {
  const [title, setTitle] = createSignal('Project summary');
  const value = constructItem('example.title', item => item.observe('value', title));
  return <TextField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="title" label="Document title" placeholder="Untitled document"
    onValueChange={next => setTitle(next)} />;
}

/**
 * @component TextField
 * @recipe search-action
 * @use Reserve the field's fixed trailing action lane when a composition overlays its own clear button.
 */
export function TextFieldSearchActionExample() {
  const [query, setQuery] = createSignal('roadmap');
  const state = constructItem('example.search-action', item => ({
    query: item.observe('query', query),
    clear: item.observe<ButtonState>('clear', () => ({ disabled: query().length === 0 })),
  }));
  return <div style={{ position: 'relative' }}>
    <TextField.View observable={state.query} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="search-action" size="large" label="Search documents" role="searchbox" placeholder="Search documents"
      placement={{ width: '100%' }} onValueChange={next => setQuery(next)} />
    <Button.View observable={state.clear} surface={{ kind: 'inherit' }} hotkeys={[]}
      shape="icon" variant="ghost" size="large" aria-label="Clear document search"
      placement={{ position: 'absolute', 'inset-inline-end': '0', top: '0' }}
      onActivate={() => setQuery('')}><XIcon /></Button.View>
  </div>;
}

/**
 * @component Textarea
 * @recipe entry
 * @use Use field-sized text for multiline entry, with explicit growth bounds instead of independent typography or padding props.
 */
export function TextareaEntryExample() {
  const [description, setDescription] = createSignal('');
  const value = constructItem('example.entry.description', item => item.observe('value', description));
  return <Textarea.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="entry" label="Project description" labelVisible rows={3} resize="auto"
    minHeight={80} maxHeight={240} onValueChange={next => setDescription(next)} />;
}

/**
 * @component Textarea
 * @recipe reading
 * @use Edit long-form text with the shared reading rhythm; the recipe keeps normal weight and adapts to field text on narrow screens.
 */
export function TextareaReadingExample() {
  const [document, setDocument] = createSignal('Start with the reader.\nKeep related ideas together.');
  const value = constructItem('example.reading', item => item.observe('value', document));
  return <Textarea.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="reading" label="Document body" rows={6} resize="auto" maxHeight={400}
    onValueChange={next => setDocument(next)} />;
}

/**
 * @component Textarea
 * @recipe compact-composer
 * @use Compose a short message with actions beside the field; this recipe balances its first line without reserving an overlaid action lane.
 */
export function TextareaCompactComposerExample() {
  const [draft, setDraft] = createSignal('');
  const [sent, setSent] = createSignal('');
  const state = constructItem('example.compact-composer', item => ({
    draft: item.observe('draft', draft),
    send: item.observe<ButtonState>('send', () => ({ disabled: draft().trim().length === 0 })),
  }));
  const send = () => {
    setSent(draft().trim());
    setDraft('');
  };
  return <>
    <div style={{ display: 'flex', gap: '4px', 'align-items': 'end' }}>
      <Textarea.View observable={state.draft} surface={{ kind: 'inherit' }} hotkeys={[]}
        recipe="compact-composer" label="Message" placeholder="Write a message" rows={1}
        resize="auto" maxHeight={160} placement={{ 'flex-grow': '1' }}
        onValueChange={next => setDraft(next)} />
      <Button.View observable={state.send} surface={{ kind: 'inherit' }} hotkeys={[]}
        onActivate={send}>Send</Button.View>
    </div>
    <p>{sent() ? `Sent: ${sent()}` : 'No message sent yet.'}</p>
  </>;
}

/**
 * @component Select
 * @recipe entry
 * @use Match a prominent entry form's field-sized text while keeping selection, option identity and canonical control targets owned by Select.
 */
export function SelectEntryExample() {
  const [language, setLanguage] = createSignal('en');
  const value = constructItem('example.entry.language', item => item.observe('value', language));
  return <Select.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="entry" label="Language" options={[
      { value: 'en', label: 'English' }, { value: 'de', label: 'Deutsch' },
      { value: 'es', label: 'Español' }, { value: 'fr', label: 'Français' },
      { value: 'it', label: 'Italiano' }, { value: 'ja', label: '日本語' },
    ]} onValueChange={next => setLanguage(next)} />;
}
