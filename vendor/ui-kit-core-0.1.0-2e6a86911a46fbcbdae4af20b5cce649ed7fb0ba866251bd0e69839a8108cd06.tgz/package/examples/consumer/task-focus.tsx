/** @jsxImportSource @solidjs/web */
import { createSignal, Show } from 'solid-js';
import { Button, Popover, Textarea, constructItem, type ButtonState } from '@ui-kit/core';

/** A host composition: the shared controls do not decide command frequency. */
export function TaskFocusExample() {
  const initial = 'Customers can download receipts from their billing history.\n\nExisting invoice links remain valid. The rollout starts after support has reviewed the help article.\n\nBefore publishing, confirm the billing export and the customer email.';
  const [draft, setDraft] = createSignal(initial);
  const [saved, setSaved] = createSignal(initial);
  const [optionsOpen, setOptionsOpen] = createSignal(false);
  const [detailsVisible, setDetailsVisible] = createSignal(false);
  const [notice, setNotice] = createSignal('');
  const dirty = () => draft() !== saved();
  const state = constructItem('example.task-focus', item => ({
    draft: item.observe('draft', draft),
    save: item.observe<ButtonState>('save', () => ({ disabled: !dirty() })),
    options: item.observe('options', optionsOpen),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: optionsOpen() })),
    action: item.constant<ButtonState>('action', {}),
    revert: item.observe<ButtonState>('revert', () => ({ disabled: !dirty() })),
  }));

  return <section class="task-focus-workspace" aria-labelledby="task-focus-title">
    <header class="task-focus-header">
      <h1 id="task-focus-title">Release notes</h1>
      <div class="task-focus-actions">
        <Button.View id="task-save" observable={state.save} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="default" onActivate={() => { setSaved(draft()); setNotice('Saved for this session.'); }}>Save</Button.View>
        <Popover.View observable={state.options}
          surface={{ kind: 'own', name: 'example.document-options', transparent: false, layer: true }} hotkeys={[]}
          recipe="actions" aria-label="Document options" onOpenChange={setOptionsOpen}
          trigger={api => <Button.View id="task-options" observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
            aria-haspopup="dialog" aria-controls={api.contentId} onActivate={api.toggle}>Document options</Button.View>}>
          {api => <>
            <Button.View id="task-toggle-details" observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
              recipe="menu-item" onActivate={() => { setDetailsVisible(value => !value); api.close(); }}>
              {detailsVisible() ? 'Hide document details' : 'Show document details'}
            </Button.View>
            <Button.View id="task-revert" observable={state.revert} surface={{ kind: 'inherit' }} hotkeys={[]}
              recipe="menu-item" onActivate={() => { setDraft(saved()); setNotice('Unsaved changes reverted.'); api.close(); }}>Revert unsaved changes</Button.View>
          </>}
        </Popover.View>
      </div>
    </header>
    <div class={`task-focus-content${detailsVisible() ? ' task-focus-with-details' : ''}`}>
      <div class="task-focus-editor">
        <Textarea.View id="task-document" observable={state.draft} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="reading" label="Release notes" rows={12} resize="auto" minHeight={280} maxHeight={640}
          onValueChange={value => { setDraft(value); setNotice(''); }} />
      </div>
      <Show when={detailsVisible()}><aside class="task-focus-details" aria-label="Document details">
        <h2>Document details</h2>
        <dl><div><dt>Characters</dt><dd>{draft().length}</dd></div></dl>
      </aside></Show>
    </div>
    <output class="task-focus-status" aria-live="polite">{notice() || (dirty() ? 'Unsaved changes' : 'Session only')}</output>
  </section>;
}
