/** @jsxImportSource @solidjs/web */
import { createSignal, createUniqueId } from 'solid-js';
import { Checkbox, ChoiceGroup, Field, Input, SearchField, Select, TextField, Textarea, Toggle, constructItem } from '@ui-kit/core';

/**
 * @component Field
 * @use Associate an outer caption, hint or error with a native control. Validation remains owned by the input.
 */
export function FieldExample() {
  const id = createUniqueId();
  const [volume, setVolume] = createSignal('50');
  const caption = constructItem('example.volume.caption', item => item.constant('text', 'Volume'));
  const value = constructItem('example.volume', item => item.observe('value', volume));
  return <Field.View observable={caption} surface={{ kind: 'inherit' }} hotkeys={[]} for={id}
    hint="Choose a volume from zero to one hundred.">
    <Input.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} id={id}
      type="range" min="0" max="100" onValueChange={next => setVolume(next)} />
  </Field.View>;
}

/**
 * @component Input
 * @use Use a browser-native input type that TextField does not expose. Prefer TextField for visible text editing and FilePicker for file selection UI.
 */
export function InputExample() {
  const [time, setTime] = createSignal('09:00');
  const value = constructItem('example.meetingTime', item => item.observe('value', time));
  return <Input.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    type="time" aria-label="Meeting time" onValueChange={next => setTime(next)} />;
}

/**
 * @component TextField
 * @use Edit one line of text with the shared field recipe, accessible label and explicit write command.
 */
export function TextFieldExample() {
  const [name, setName] = createSignal('');
  const value = constructItem('example.name', item => item.observe('value', name));
  return <TextField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Name" labelVisible recipe="form" autocomplete="name"
    onValueChange={next => setName(next)} />;
}

/**
 * @component SearchField
 * @use Edit a picker or list query. SearchField owns its inline recipe, dense size and text input type.
 */
export function SearchFieldExample() {
  const [query, setQuery] = createSignal('');
  const value = constructItem('example.search', item => item.observe('query', query));
  return <SearchField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Search items" placeholder="Search items" onValueChange={next => setQuery(next)} />;
}

/**
 * @component Textarea
 * @use Edit multiline text. Choose a field recipe and bounded auto-height when the document should grow with its content.
 */
export function TextareaExample() {
  const [description, setDescription] = createSignal('');
  const value = constructItem('example.description', item => item.observe('value', description));
  return <Textarea.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Description" labelVisible recipe="form" rows={3} resize="auto" minHeight={80} maxHeight={240}
    onValueChange={next => setDescription(next)} />;
}

/**
 * @component Select
 * @use Select one string value from a longer option set. For fewer than six visible choices, prefer ChoiceGroup.
 */
export function SelectExample() {
  const [language, setLanguage] = createSignal('en');
  const value = constructItem('example.language', item => item.observe('value', language));
  return <Select.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Language" recipe="form" options={[
      { value: 'en', label: 'English' }, { value: 'de', label: 'Deutsch' },
      { value: 'es', label: 'Español' }, { value: 'fr', label: 'Français' },
      { value: 'it', label: 'Italiano' }, { value: 'ja', label: '日本語' },
    ]} onValueChange={next => setLanguage(next)} />;
}

/**
 * @component Checkbox
 * @use Edit a boolean selection with a visible label and native Space behavior.
 */
export function CheckboxExample() {
  const [accepted, setAccepted] = createSignal(false);
  const value = constructItem('example.accepted', item => item.observe('value', accepted));
  return <Checkbox.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Include completed items" onCheckedChange={next => setAccepted(next)} />;
}

/**
 * @component Toggle
 * @use Switch a boolean setting immediately, keeping its current value and write command explicit.
 */
export function ToggleExample() {
  const [enabled, setEnabled] = createSignal(false);
  const value = constructItem('example.notifications', item => item.observe('value', enabled));
  return <Toggle.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Enable notifications" onCheckedChange={next => setEnabled(next)} />;
}

/**
 * @component ChoiceGroup
 * @use Present a small mutually exclusive set as visible choices, with the selected value typed to its options.
 */
export function ChoiceGroupExample() {
  const [view, setView] = createSignal<'list' | 'grid'>('list');
  const value = constructItem('example.view', item => item.observe('value', view));
  return <ChoiceGroup.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="View" options={[{ value: 'list', label: 'List' }, { value: 'grid', label: 'Grid' }]}
    onValueChange={next => setView(next)} />;
}
