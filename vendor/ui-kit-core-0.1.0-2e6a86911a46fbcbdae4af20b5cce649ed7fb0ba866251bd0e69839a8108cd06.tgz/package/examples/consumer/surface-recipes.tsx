/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { Button, Card, Popover, ScrollArea, TextField, constructItem, type ButtonState } from '@ui-kit/core';

/**
 * @component Card
 * @recipe plain
 * @use Bind content visibility and surface lifetime without adding panel chrome; place it through the parent or narrow placement contract.
 */
export function CardPlainExample() {
  const visible = constructItem('example.card.plain', item => item.constant('visible', true));
  return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="plain" attributes={{ role: 'region', 'aria-label': 'Project summary' }}>
    <h2>Project summary</h2>
    <p>The application owns this content and its surrounding page layout.</p>
  </Card.View>;
}

/**
 * @component Card
 * @recipe content
 * @use Group related prose with the shared bordered, padded content surface.
 */
export function CardContentExample() {
  const visible = constructItem('example.card.content', item => item.constant('visible', true));
  return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="content">
    <h2>Delivery notes</h2>
    <p>Keep the current scope small enough to review.</p>
  </Card.View>;
}

/**
 * @component Card
 * @recipe panel
 * @use Fill a parent-bounded panel with a clipped column; use ScrollArea for content that can exceed the available height.
 */
export function CardPanelExample() {
  const visible = constructItem('example.card.panel', item => item.constant('visible', true));
  return <div style={{ height: '12rem' }}>
    <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="panel">
      <h2>Activity</h2>
      <ScrollArea.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
        fill orientation="vertical" role="region" aria-label="Recent project activity">
        <p>The plan was updated.</p>
        <p>A review was requested.</p>
      </ScrollArea.View>
    </Card.View>
  </div>;
}

/**
 * @component Card
 * @recipe popover
 * @use Give an application-owned floating composition an unpadded surface while keeping nested content visible; use Popover when the core should own anchoring and dismissal.
 */
export function CardPopoverExample() {
  const visible = constructItem('example.card.popover', item => item.constant('visible', true));
  return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="popover" placement={{ width: '18rem' }}>
    <p>An enclosing composition owns this surface's placement and interaction.</p>
  </Card.View>;
}

/**
 * @component Card
 * @recipe notice
 * @use Present semantic status with one shared padded notice recipe; tone reports status rather than changing the layout.
 */
export function CardNoticeExample() {
  const visible = constructItem('example.card.notice', item => item.constant('visible', true));
  return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
    recipe="notice" tone="warning" attributes={{ role: 'status' }}>
    <p>Some changes still need review.</p>
  </Card.View>;
}

/**
 * @component Popover
 * @recipe popover
 * @use Show contextual information in the shared padded panel, with the trigger API owning opening and dismissal.
 */
export function PopoverInformationExample() {
  const [open, setOpen] = createSignal(false);
  const state = constructItem('example.popover.information', item => ({
    open: item.observe('open', open),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: open() })),
  }));
  return <Popover.View observable={state.open}
    surface={{ kind: 'own', name: 'example.project-information', transparent: false, layer: true }} hotkeys={[]}
    recipe="popover" onOpenChange={setOpen} role="dialog" aria-label="Project information"
    trigger={api => <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" aria-controls={api.contentId} onActivate={api.toggle}>About this project</Button.View>}>
    {() => <p>Changes are saved as you work. Review the activity panel for recent updates.</p>}
  </Popover.View>;
}

/**
 * @component Popover
 * @recipe picker
 * @use Present a compact grid of immediate choices; the choice command updates state and closes the same popover owner.
 */
export function PopoverPickerExample() {
  const [open, setOpen] = createSignal(false);
  const [order, setOrder] = createSignal<'ascending' | 'descending'>('ascending');
  const state = constructItem('example.popover.picker', item => ({
    open: item.observe('open', open),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: open() })),
    ascending: item.observe<ButtonState>('ascending', () => ({ pressed: order() === 'ascending' })),
    descending: item.observe<ButtonState>('descending', () => ({ pressed: order() === 'descending' })),
  }));
  return <Popover.View observable={state.open}
    surface={{ kind: 'own', name: 'example.sort-order', transparent: false, layer: true }} hotkeys={[]}
    recipe="picker" onOpenChange={setOpen} role="dialog" aria-label="Sort order"
    trigger={api => <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" aria-controls={api.contentId} onActivate={api.toggle}>Sort order</Button.View>}>
    {api => <>
      <Button.View observable={state.ascending} surface={{ kind: 'inherit' }} hotkeys={[]}
        recipe="menu-item" onActivate={() => { setOrder('ascending'); api.close(); }}>Ascending</Button.View>
      <Button.View observable={state.descending} surface={{ kind: 'inherit' }} hotkeys={[]}
        recipe="menu-item" onActivate={() => { setOrder('descending'); api.close(); }}>Descending</Button.View>
    </>}
  </Popover.View>;
}

/**
 * @component Popover
 * @recipe actions
 * @use Keep secondary commands behind a stable labeled trigger. The compact panel fits its commands, focuses the first enabled control, and returns focus after a command closes it; Tab stays native.
 */
export function PopoverActionsExample() {
  const [open, setOpen] = createSignal(false);
  const [result, setResult] = createSignal('');
  const state = constructItem('example.popover.actions', item => ({
    open: item.observe('open', open),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: open() })),
    action: item.constant<ButtonState>('action', {}),
  }));
  return <>
    <Popover.View observable={state.open}
      surface={{ kind: 'own', name: 'example.project-actions', transparent: false, layer: true }} hotkeys={[]}
      recipe="actions" onOpenChange={setOpen} aria-label="Project actions"
      trigger={api => <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="ghost" aria-haspopup="dialog" aria-controls={api.contentId} onActivate={api.toggle}>Project actions</Button.View>}>
      {api => <>
        <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="menu-item" onActivate={() => { setResult('Export requested.'); api.close(); }}>Export project</Button.View>
        <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="menu-item" onActivate={() => { setResult('Duplicate requested.'); api.close(); }}>Duplicate project</Button.View>
      </>}
    </Popover.View>
    <output role="status">{result()}</output>
  </>;
}

/**
 * @component Popover
 * @recipe content
 * @use Host content that already owns its inner spacing; fitContentWidth keeps the trigger as a minimum and the viewport as a limit.
 */
export function PopoverContentExample() {
  const [open, setOpen] = createSignal(false);
  const state = constructItem('example.popover.content', item => ({
    open: item.observe('open', open),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: open() })),
    visible: item.constant('visible', true),
  }));
  return <Popover.View observable={state.open}
    surface={{ kind: 'own', name: 'example.reference-content', transparent: false, layer: true }} hotkeys={[]}
    recipe="content" fitContentWidth onOpenChange={setOpen} role="dialog" aria-label="Reference notes"
    trigger={api => <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" aria-controls={api.contentId} onActivate={api.toggle}>Reference notes</Button.View>}>
    {() => <ScrollArea.View observable={state.visible} surface={{ kind: 'inherit' }} hotkeys={[]}
      orientation="vertical" role="region" aria-label="Reference details">
      <article><h2>Release checklist</h2><p>Review scope, validation and remaining decisions.</p></article>
    </ScrollArea.View>}
  </Popover.View>;
}

/**
 * @component Popover
 * @recipe form
 * @use Stack a short editing form with shared spacing and scroll bounds; native text editing stays with the field.
 */
export function PopoverFormExample() {
  const [open, setOpen] = createSignal(false);
  const [name, setName] = createSignal('Project draft');
  const state = constructItem('example.popover.form', item => ({
    open: item.observe('open', open),
    name: item.observe('name', name),
    trigger: item.observe<ButtonState>('trigger', () => ({ expanded: open() })),
    action: item.constant<ButtonState>('action', {}),
  }));
  return <Popover.View observable={state.open}
    surface={{ kind: 'own', name: 'example.rename-project', transparent: false, layer: true }} hotkeys={[]}
    recipe="form" onOpenChange={setOpen} role="dialog" aria-label="Rename project"
    trigger={api => <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" aria-controls={api.contentId} onActivate={api.toggle}>Rename project</Button.View>}>
    {api => <>
      <TextField.View observable={state.name} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Project name" labelVisible onValueChange={next => setName(next)} />
      <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={api.close}>Done</Button.View>
    </>}
  </Popover.View>;
}
