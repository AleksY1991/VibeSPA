import { createSignal } from 'solid-js';
import {
  Button, CaretInput, ContentEditable, EditorHost, InteractionEvents, InteractionRegion,
  constructItem, type ButtonState, type ContentEditableState, type EditorHostProps,
  type EditorHostState,
} from '@ui-kit/core';

/**
 * @component EditorHost
 * @use Integrate an existing imperative rich-text editor through its mount/update/dispose adapter; use Textarea for ordinary multiline text.
 */
export function EditorHostExample(props: Pick<EditorHostProps, 'mount' | 'onError'>) {
  const state = constructItem('note.editor', item => item.constant<EditorHostState>('state', {
    visible: true, editable: true,
  }));
  return <EditorHost.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Note editor" mount={props.mount} onError={props.onError} />;
}

/**
 * @component InteractionRegion
 * @use Give a composite row pointer selection while retaining independent nested actions; use Button for a single action.
 */
export function InteractionRegionExample() {
  const [selected, setSelected] = createSignal(false);
  const [opened, setOpened] = createSignal(false);
  const bindings = constructItem('result.row', item => ({
    row: item.observe<ButtonState>('row', () => ({ highlighted: selected() })),
    action: item.constant<ButtonState>('action', {}),
  }));
  return <InteractionRegion.View as="article" observable={bindings.row}
    surface={{ kind: 'inherit' }} hotkeys={[]}
    onActivate={activation => { if (!activation.targetIsInteractive) setSelected(true); }}>
    <p>Project proposal</p>
    <Button.View observable={bindings.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="ghost" onActivate={() => setOpened(true)}>Open details</Button.View>
    <output>{opened() ? 'Details opened' : selected() ? 'Row selected' : 'Select a result'}</output>
  </InteractionRegion.View>;
}

/**
 * @component ContentEditable
 * @use Edit a plaintext title in place while preserving browser caret and IME behavior; commit and cancel remain explicit commands.
 */
export function ContentEditableExample() {
  const [saved, setSaved] = createSignal('Project alpha');
  const [draft, setDraft] = createSignal('Project alpha');
  const [editing, setEditing] = createSignal(false);
  const state = constructItem('project.title', item => item.observe<ContentEditableState>('state', () => ({
    text: editing() ? draft() : saved(), editing: editing(),
  })));
  return <ContentEditable.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Project title" focusOnEdit="selectAll"
    onActivate={() => { if (!editing()) { setDraft(saved()); setEditing(true); } }}
    onValueChange={setDraft}
    onCommit={text => { setSaved(text); setEditing(false); }}
    onCancel={() => setEditing(false)} />;
}

/**
 * @component CaretInput
 * @use Supply a canvas renderer's invisible native editing engine; the renderer still owns painted text and caret geometry.
 */
export function CaretInputExample() {
  const [draft, setDraft] = createSignal('Canvas label');
  const [composition, setComposition] = createSignal('idle');
  const bindings = constructItem('canvas.label', item => ({
    engine: item.constant('engine', { disabled: false }),
    action: item.constant<ButtonState>('action', {}),
  }));
  const engine = new CaretInput({
    observable: bindings.engine, surface: { kind: 'inherit' }, hotkeys: [],
    mount: { kind: 'deferred', document }, label: 'Canvas label',
    onSnapshot: snapshot => setDraft(snapshot.value),
    onComposition: (phase, _data, snapshot) => { setComposition(phase); setDraft(snapshot.value); },
    onBlur: snapshot => setDraft(snapshot.value),
  });
  return <section aria-label="Canvas text editing example">
    <div ref={host => engine.handle.attach(host)} />
    <Button.View observable={bindings.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" onActivate={() => {
        const value = draft();
        engine.handle.begin({ value, selectionStart: 0, selectionEnd: value.length });
      }}>Edit canvas label</Button.View>
    <output>{draft()} · composition: {composition()}</output>
  </section>;
}

/**
 * @component InteractionEvents
 * @use Own non-keyboard browser listeners with a control's lifetime; declare keyboard commands through hotkeys instead.
 */
export function InteractionEventsExample() {
  const [width, setWidth] = createSignal(window.innerWidth);
  const active = constructItem('viewport.observer', item => item.constant('active', true));
  new InteractionEvents({
    observable: active, surface: { kind: 'inherit' }, hotkeys: [], target: window,
    events: [{ type: 'resize', handler: () => setWidth(window.innerWidth) }],
  });
  return <output>Viewport width: {width()}px</output>;
}
