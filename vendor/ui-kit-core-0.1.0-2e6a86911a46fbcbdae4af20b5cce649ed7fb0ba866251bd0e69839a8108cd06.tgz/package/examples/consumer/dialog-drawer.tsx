import { createSignal } from 'solid-js';
import { Button, Dialog, Input, constructItem, type ButtonState } from '@ui-kit/core';

/**
 * @component Dialog
 * @recipe drawer
 * @use Keep drawer visibility separate from its live width/expansion model. Change the model through application commands so resizing preserves the same panel and content owner.
 */
export function DialogDrawerExample() {
  const [open, setOpen] = createSignal(false);
  const [width, setWidth] = createSignal(420);
  const [expanded, setExpanded] = createSignal(false);
  const state = constructItem('example.drawer', item => ({
    open: item.observe('open', open),
    drawer: item.observe('drawer', () => ({ width: width(), expanded: expanded() })),
    width: item.observe('width', () => String(width())),
    action: item.constant<ButtonState>('action', {}),
    expansion: item.observe<ButtonState>('expansion', () => ({ pressed: expanded() })),
  }));
  return <>
    <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" onActivate={() => setOpen(true)}>Open inspector</Button.View>
    <Dialog.View observable={state.open} drawer={state.drawer} recipe="drawer"
      surface={{ kind: 'own', name: 'example.inspector', transparent: true, layer: true }} hotkeys={[]}
      modal={false} label="Inspector" onOpenChange={setOpen}>
      <Input.View observable={state.width} surface={{ kind: 'inherit' }} hotkeys={[]}
        type="range" min="280" max="640" step="20" aria-label="Drawer width"
        onValueChange={value => setWidth(Number(value))} />
      <Button.View observable={state.expansion} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setExpanded(value => !value)}>Toggle expanded view</Button.View>
      <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setOpen(false)}>Close inspector</Button.View>
    </Dialog.View>
  </>;
}
