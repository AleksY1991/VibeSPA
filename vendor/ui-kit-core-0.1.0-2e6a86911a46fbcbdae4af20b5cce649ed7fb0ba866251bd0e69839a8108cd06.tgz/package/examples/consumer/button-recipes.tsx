/** @jsxImportSource @solidjs/web */
import { Show, createSignal, createUniqueId } from 'solid-js';
import { Button, FileTextIcon, InteractionRegion, XIcon, constructItem, type ButtonState } from '@ui-kit/core';

/**
 * @component Button
 * @recipe selection-cell
 * @use Select a cell whose composite owns the selection outline. Keep pressed state on the Button; highlight only the outer region so selection paints once.
 */
export function SelectionCellExample() {
  const [selected, setSelected] = createSignal(false);
  const cell = constructItem('example.selection-cell', item => item.observe<ButtonState>('state', () => ({ pressed: selected() })));
  const frame = constructItem('example.selection-frame', item => item.observe<ButtonState>('state', () => ({ highlighted: selected() })));
  return <div style={{ display: 'inline-flex' }}>
    <InteractionRegion.View observable={frame} surface={{ kind: 'inherit' }} hotkeys={[]}>
      <Button.View observable={cell} surface={{ kind: 'inherit' }} hotkeys={[]}
        recipe="selection-cell" aria-label="Select Thursday 12"
        onActivate={() => setSelected(previous => !previous)}>12</Button.View>
    </InteractionRegion.View>
  </div>;
}

/**
 * @component Button
 * @recipe property-row
 * @use Edit a wrapping inspector value. Keep independent trailing actions as siblings rather than nest another action inside the property Button.
 */
export function PropertyRowExample() {
  const [priority, setPriority] = createSignal('Normal');
  const edit = constructItem('example.property-row', item => item.constant<ButtonState>('state', {}));
  const reset = constructItem('example.property-reset', item => item.constant<ButtonState>('state', {}));
  return <div style={{ display: 'flex', 'align-items': 'start' }}>
    <Button.View observable={edit} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="property-row"
      onActivate={() => setPriority(previous => previous === 'Normal' ? 'High' : 'Normal')}>
      <span>Priority: {priority()}</span>
    </Button.View>
    <Button.View observable={reset} surface={{ kind: 'inherit' }} hotkeys={[]}
      shape="icon" variant="ghost" aria-label="Reset priority" onActivate={() => setPriority('Normal')}>
      <XIcon />
    </Button.View>
  </div>;
}

/**
 * @component Button
 * @recipe fill-action
 * @use Fill an already bounded chart or grid cell. The parent supplies both dimensions, including a usable touch target; this recipe has no size or paint knobs.
 */
export function FillActionExample() {
  const [opened, setOpened] = createSignal(0);
  const action = constructItem('example.fill-action', item => item.constant<ButtonState>('state', {}));
  return <>
    <div style={{ width: '44px', height: '44px' }}>
      <Button.View observable={action} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="fill-action"
        aria-label="Open chart cell 4" onActivate={() => setOpened(previous => previous + 1)}>4</Button.View>
    </div>
    <output aria-live="polite">Cell opened {opened()} times</output>
  </>;
}

/**
 * @component Button
 * @recipe overlay-action
 * @use Place a clear glyph over a separate action. The glyph receives pointer hits, the full canonical box remains keyboard-focusable, and an explicit accessible name identifies the action.
 */
export function OverlayActionExample() {
  const [visible, setVisible] = createSignal(true);
  const [opened, setOpened] = createSignal(0);
  const preview = constructItem('example.preview', item => item.constant<ButtonState>('state', {}));
  const clear = constructItem('example.overlay-action', item => item.constant<ButtonState>('state', {}));
  return <>
    <Show when={visible()} fallback={<p>Attachment removed</p>}>
      <div style={{ position: 'relative', width: '160px', height: '96px' }}>
        <Button.View observable={preview} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="fill-action"
          onActivate={() => setOpened(previous => previous + 1)}>Attachment preview</Button.View>
        <Button.View observable={clear} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="overlay-action"
          aria-label="Remove attachment" placement={{ position: 'absolute', top: '0', right: '0' }}
          onActivate={() => setVisible(false)}><XIcon /></Button.View>
      </div>
    </Show>
    <output aria-live="polite">Preview opened {opened()} times</output>
  </>;
}

/**
 * @component Button
 * @recipe cell-action
 * @use Keep a disclosure or grid trigger at the shared fixed control height, even when adjacent row content is taller.
 */
export function CellActionExample() {
  const id = createUniqueId();
  const [expanded, setExpanded] = createSignal(false);
  const action = constructItem('example.cell-action', item => item.observe<ButtonState>('state', () => ({ expanded: expanded() })));
  return <>
    <Button.View observable={action} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="cell-action"
      aria-controls={id} onActivate={() => setExpanded(previous => !previous)}>Project details</Button.View>
    <div id={id} hidden={!expanded()}>The project contains three active tasks.</div>
  </>;
}

/**
 * @component Button
 * @recipe action-row
 * @use Present a multiline action with separate leading decoration. The recipe owns start alignment and spacing; choose an explicit supported paint.
 */
export function ActionRowExample() {
  const [imports, setImports] = createSignal(0);
  const action = constructItem('example.action-row', item => item.constant<ButtonState>('state', {}));
  return <>
    <Button.View observable={action} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="action-row" variant="outline" start={<FileTextIcon />}
      onActivate={() => setImports(previous => previous + 1)}>
      <span><strong>Import document</strong><br />Read a local document into this project</span>
    </Button.View>
    <output aria-live="polite">Import requested {imports()} times</output>
  </>;
}
