import { createSignal, Show } from 'solid-js';
import {
  Avatar, Badge, Divider, Image, Media, MenuSeparator, ProgressBar, Spinner, Tag,
  constructItem, type ImageState, type MediaState,
} from '@ui-kit/core';

/**
 * @component Image
 * @use Display an ordinary responsive image with meaningful alternative text; use an empty alt for decoration.
 */
export function ImageExample(props: { src: string; alt: string }) {
  const source = constructItem('article.image', item =>
    item.observe<ImageState>('source', () => ({ src: props.src })));
  return <Image.View observable={source} surface={{ kind: 'inherit' }} hotkeys={[]}
    alt={props.alt} loading="lazy" decoding="async" />;
}

/**
 * @component Media
 * @use Play audio or video through native browser controls; supply application-owned media URLs and captions.
 */
export function MediaExample(props: { src: string; captions: string }) {
  const source = constructItem('lesson.video', item =>
    item.observe<MediaState>('source', () => ({ src: props.src })));
  return <Media.View observable={source} surface={{ kind: 'inherit' }} hotkeys={[]}
    kind="video" controls preload="metadata" aria-label="Lesson recording">
    <track kind="captions" src={props.captions} srclang="en" label="English" default />
  </Media.View>;
}

/**
 * @component Badge
 * @use Present a short count or status; keep full descriptive text outside the badge.
 */
export function BadgeExample(props: { unread: number }) {
  const count = constructItem('inbox.badge', item =>
    item.observe('count', () => String(props.unread)));
  return <Badge.View observable={count} surface={{ kind: 'inherit' }} hotkeys={[]}
    tone="neutral" label="Unread messages" />;
}

/**
 * @component Avatar
 * @use Present one person's image or initials; the enclosing action owns any selection behavior.
 */
export function AvatarExample() {
  const person = constructItem('person.avatar', item => item.constant('identity', {
    label: 'Alex Morgan', initials: 'AM',
  }));
  return <Avatar.View observable={person} surface={{ kind: 'inherit' }} hotkeys={[]}
    size="compact" />;
}

/**
 * @component Tag
 * @use Show a removable selected value with a contextual, keyboard-accessible remove action.
 */
export function TagExample() {
  const [visible, setVisible] = createSignal(true);
  const tag = constructItem('filter.tag', item => item.constant('value', {
    label: 'Assigned to me', removeLabel: 'Remove Assigned to me filter',
  }));
  return <Show when={visible()} fallback={<span>No assignee filter</span>}>
    <Tag.View observable={tag} surface={{ kind: 'inherit' }} hotkeys={[]}
      onRemove={() => setVisible(false)} />
  </Show>;
}

/**
 * @component Spinner
 * @use Represent work without a measurable total; name the status or explicitly declare it decorative.
 */
export function SpinnerExample(props: { busy: boolean }) {
  const busy = constructItem('search.loading', item => item.observe('busy', () => props.busy));
  return <Spinner.View observable={busy} surface={{ kind: 'inherit' }} hotkeys={[]}
    size="sm" label="Loading search results" />;
}

/**
 * @component ProgressBar
 * @use Report measurable progress in original units; max and the label describe the work.
 */
export function ProgressBarExample(props: { uploaded: number; total: number }) {
  const uploaded = constructItem('upload.progress', item =>
    item.observe('uploaded', () => props.uploaded));
  return <ProgressBar.View observable={uploaded} surface={{ kind: 'inherit' }} hotkeys={[]}
    max={props.total} label="Files uploaded" />;
}

/**
 * @component MenuSeparator
 * @use Separate groups of menu actions without introducing another keyboard action.
 */
export function MenuSeparatorExample() {
  const visible = constructItem('menu.separator', item => item.constant('visible', true));
  return <MenuSeparator.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]} />;
}

/**
 * @component Divider
 * @use Separate content sections with the same noninteractive separator contract as MenuSeparator.
 */
export function DividerExample() {
  const visible = constructItem('section.divider', item => item.constant('visible', true));
  return <Divider.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]} />;
}
