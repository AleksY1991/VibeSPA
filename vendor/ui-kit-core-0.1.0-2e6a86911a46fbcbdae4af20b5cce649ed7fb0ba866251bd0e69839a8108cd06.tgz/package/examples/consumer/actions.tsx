/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { Button, FilePicker, Form, Link, constructItem, type ButtonState, type FormState, type LinkState } from '@ui-kit/core';

/**
 * @component Button
 * @use Trigger a command with quiet default paint. Use variant="default" only for the task's primary action.
 */
export function ButtonExample() {
  const [count, setCount] = createSignal(0);
  const state = constructItem('example.button', item => item.constant<ButtonState>('state', {}));
  return <>
    <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="button" onActivate={() => setCount(previous => previous + 1)}>
      Add item
    </Button.View>
    <output aria-live="polite">{count()} items added</output>
  </>;
}

/**
 * @component Link
 * @use Navigate to a URL with a real anchor, retaining modifier clicks and browser navigation.
 */
export function LinkExample() {
  const destination = constructItem('example.link', item => item.constant<LinkState>('destination', { href: '/settings' }));
  return <Link.View observable={destination} surface={{ kind: 'inherit' }} hotkeys={[]}>
    Settings
  </Link.View>;
}

/**
 * @component Form
 * @use Own native form submission. Prevent the default only when a typed application command handles the intent.
 */
export function FormExample() {
  const [submitted, setSubmitted] = createSignal('');
  const form = constructItem('example.form', item => item.constant<FormState>('state', {}));
  const submit = constructItem('example.form.submit', item => item.constant<ButtonState>('state', {}));
  return <>
    <Form.View observable={form} surface={{ kind: 'inherit' }} hotkeys={[]}
      onSubmit={intent => {
        intent.preventDefault();
        setSubmitted(String(intent.formData().get('intent') ?? ''));
      }}>
      <Button.View observable={submit} surface={{ kind: 'inherit' }} hotkeys={[]}
        type="submit" name="intent" value="save" variant="outline">Save</Button.View>
    </Form.View>
    <output aria-live="polite">{submitted()}</output>
  </>;
}

/**
 * @component FilePicker
 * @use Select one local file and keep its selection in a typed observable. Selection does not upload it.
 */
export function FilePickerExample() {
  const [file, setFile] = createSignal<File | null>(null);
  const selected = constructItem('example.file', item => item.observe('selection', file));
  return <FilePicker.View observable={selected} surface={{ kind: 'inherit' }} hotkeys={[]}
    label="Attachment" accept="image/*" onFileChange={next => setFile(next)} />;
}
