import { createEffect, createMemo, createSignal, getOwner, latest, onCleanup, runWithOwner, untrack, type Accessor } from 'solid-js';

import { surfacePlatform } from './platform';
import { isSurfaceElement } from '../contracts/platform';
import type { Dispose, ElementSurfaceLease, SurfaceAuthority, SurfaceHotkeyHandler } from '../contracts/platform';
import { useHotkeyElementContext, useHotkeyRendererContext, type HotkeyElementContextValue } from './context';
import { observeHotkeyHost, type HotkeyHostLifetime } from './host-lifetime';

interface HotkeysConfigBase {
  /** Stable definition name shown in the live Keyboard registry. */
  readonly name: string;
  /** Exact canonical combinations owned by this DOM subtree. */
  /** False blocks unresolved app shortcuts; true passes them to ancestors. */
  readonly transparent?: boolean;
  /** An open popup/dialog that must arbitrate even while focus is outside it. */
  readonly layer?: boolean | Accessor<boolean>;
  readonly dismissable?: boolean | Accessor<boolean>;
  readonly modal?: boolean | Accessor<boolean>;
  readonly activationRoots?: Accessor<readonly Element[]>;
  /** For kept-mounted UI. Omit when DOM presence is the open state. */
  readonly active?: Accessor<boolean>;
  readonly nativeOverrides?: readonly string[];
  readonly delegate?: readonly string[] | 'all';
  readonly focusKeys?: Readonly<Record<string, SurfaceHotkeyHandler>>;
  /** Same-host public wrappers supply an explicit logical ownership chain. */
  readonly parent?: HotkeyElementContextValue;
}

export interface HotkeyBinding {
  (element: Element): void;
  readonly active: Accessor<boolean>;
  readonly lifetime: Accessor<boolean>;
  readonly authority: () => SurfaceAuthority | undefined;
  readonly canActivate: () => boolean;
  readonly isLive: () => boolean;
  readonly isDisposed: () => boolean;
  readonly attachNonvisual: (target: EventTarget) => void;
  readonly detach: () => void;
  readonly context: HotkeyElementContextValue;
  readonly registerNative: (element: Element) => Dispose;
}

export type HotkeysConfig = HotkeysConfigBase & (
  | {
    readonly keys: readonly string[];
    readonly onKeyDown: SurfaceHotkeyHandler;
  }
  | {
    readonly keys?: Readonly<Record<string, SurfaceHotkeyHandler>>;
    readonly onKeyDown?: never;
  }
);

/**
 * Solid 2 ref factory: DOM mount supplies the element, the owner supplies cleanup.
 * Registration and deregistration cannot be forgotten by the component.
 */
export function hotkeys(config: HotkeysConfig): HotkeyBinding {
  let element: Element | undefined;
  let nonvisual: EventTarget | undefined;
  let release: Dispose | undefined;
  let currentLease: ElementSurfaceLease | undefined;
  let registeredTarget: EventTarget | undefined;
  let registeredParentId: string | null | undefined;
  let releaseNative: Dispose | undefined;
  let releaseHost: HotkeyHostLifetime | undefined;
  let hostPresent = true;
  let currentInstanceId: string | null = null;
  let currentAuthority: SurfaceAuthority | undefined;
  let lastAuthority: SurfaceAuthority | undefined;
  let disposed = false;
  const listeners = new Set<() => void>();
  const nativeOwners = new Map<Element, number>();
  const logicalParent = config.parent ?? useHotkeyElementContext();
  const renderer = useHotkeyRendererContext();
  const parent = logicalParent ?? renderer;
  const handlers: Readonly<Record<string, SurfaceHotkeyHandler>> = Array.isArray(config.keys)
    ? Object.freeze(Object.fromEntries(config.keys.map((key) => [key, config.onKeyDown])))
    : (config.keys ?? {});
  let enabled = untrack(() => config.active?.() ?? true);
  let layer = untrack(() => typeof config.layer === 'function' ? config.layer() : config.layer ?? false);
  let dismissable = untrack(() => typeof config.dismissable === 'function' ? config.dismissable() : config.dismissable ?? false);
  let modal = untrack(() => typeof config.modal === 'function' ? config.modal() : config.modal ?? false);
  let activationRoots = untrack(() => config.activationRoots?.() ?? []);
  const parentActive = () => logicalParent?.peekActive()
    ?? (!renderer || (renderer.instanceId() !== null && (renderer.active?.() ?? true)));
  let currentActive = enabled && untrack(parentActive);
  // Ownership, renderer identities and mounted leases are external lifecycle
  // facts. Logical activity remains a direct derivation within retained scopes.
  const [ownerState, setOwnerState] = createSignal<{ rendererId: string | null } | undefined>(
    { rendererId: untrack(() => renderer?.instanceId() ?? null) }, { ownedWrite: true });
  // Ref-only owners need no activity subscription until a consumer reads it.
  // Observed readers still derive from current intent in the source flush.
  const logicalActive = createMemo(() => (config.active?.() ?? true) && (logicalParent
    ? logicalParent.active()
    : !renderer || (ownerState()?.rendererId !== null && (renderer.active?.() ?? true))), { name: `${config.name}.active`, lazy: true });
  // Read ownership outside the owned memos: escaped readers must still observe
  // disposal after those memos have stopped computing.
  const active = () => ownerState() !== undefined && logicalActive();
  const [mountedLease, setMountedLease] = createSignal<ElementSurfaceLease | undefined>(undefined, { ownedWrite: true });
  const mounted = createMemo(() => mountedLease() !== undefined, { name: `${config.name}.lifetime` });
  const hostActive = () => ownerState() !== undefined && mounted();

  const sync = (): void => {
    if (disposed) return;
    const previousId = currentInstanceId;
    const nextActive = enabled && untrack(parentActive);
    const activeChanged = currentActive !== nextActive;
    currentActive = nextActive;
    if (!logicalParent && renderer) {
      const rendererId = renderer.instanceId();
      setOwnerState(previous => previous?.rendererId === rendererId ? previous : { rendererId });
    }
    const parentId = parent?.instanceId() ?? null;
    const target = element ?? nonvisual;
    const eligible = target && hostPresent && nextActive && (!parent || parentId !== null);
    if (eligible && currentLease && registeredTarget === target && registeredParentId === parentId) {
      currentLease.update({ layer, dismissable, modal, activationRoots, nativeOwners: [...nativeOwners.keys()] });
    } else {
      release?.();
      release = undefined;
      currentLease = undefined;
      currentInstanceId = null;
      currentAuthority = undefined;
      registeredTarget = undefined;
      registeredParentId = undefined;
    }
    if (target && eligible && !currentLease) {
      const lease = element ? surfacePlatform().mountElement({
        name: config.name,
        element,
        transparent: config.transparent ?? false,
        layer,
        dismissable,
        modal,
        activationRoots,
        keys: handlers,
        nativeOverrides: config.nativeOverrides,
        nativeOwners: [...nativeOwners.keys()],
        delegate: config.delegate,
        focusKeys: config.focusKeys,
        parentId,
      }) : surfacePlatform().mountNonvisual({ name: config.name, target, parentId });
      currentLease = lease;
      registeredTarget = target;
      registeredParentId = parentId;
      release = lease.dispose;
      currentInstanceId = lease.instanceId;
      currentAuthority = lease.authority;
      lastAuthority = lease.authority;
    }
    setMountedLease(currentLease);
    if (previousId !== currentInstanceId || activeChanged) {
      for (const listener of listeners) listener();
    }
  };

  if (parent) onCleanup(parent.subscribe(sync));
  if (config.active || config.activationRoots || typeof config.layer === 'function' || typeof config.dismissable === 'function' || typeof config.modal === 'function') {
    createEffect(
      () => [
        config.active?.() ?? true,
        typeof config.layer === 'function' ? config.layer() : config.layer ?? false,
        typeof config.dismissable === 'function' ? config.dismissable() : config.dismissable ?? false,
        typeof config.modal === 'function' ? config.modal() : config.modal ?? false,
        config.activationRoots?.() ?? [],
      ] as const,
      ([nextEnabled, nextLayer, nextDismissable, nextModal, nextActivationRoots]) => {
        if (nextEnabled === enabled && nextLayer === layer && nextDismissable === dismissable && nextModal === modal
          && nextActivationRoots.length === activationRoots.length
          && nextActivationRoots.every((root, index) => root === activationRoots[index])) return;
        enabled = nextEnabled;
        layer = nextLayer;
        dismissable = nextDismissable;
        modal = nextModal;
        activationRoots = nextActivationRoots;
        sync();
      },
    );
  }
  onCleanup(() => {
    disposed = true;
    currentActive = false;
    setOwnerState(undefined);
    setMountedLease(undefined);
    currentInstanceId = null;
    currentAuthority = undefined;
    release?.();
    release = undefined;
    currentLease = undefined;
    registeredTarget = undefined;
    registeredParentId = undefined;
    releaseNative?.();
    releaseNative = undefined;
    releaseHost?.();
    releaseHost = undefined;
    element = undefined;
    nonvisual = undefined;
    for (const listener of listeners) listener();
    listeners.clear();
    nativeOwners.clear();
  });

  const registerNative = (nativeElement: Element): Dispose => {
    if (disposed) return () => {};
    const previous = nativeOwners.get(nativeElement) ?? 0;
    nativeOwners.set(nativeElement, previous + 1);
    if (previous === 0) sync();
    let registered = true;
    return () => {
      if (!registered) return;
      registered = false;
      const count = nativeOwners.get(nativeElement) ?? 0;
      if (count > 1) nativeOwners.set(nativeElement, count - 1);
      else {
        nativeOwners.delete(nativeElement);
        sync();
      }
    };
  };
  const refresh = () => {
    if (disposed) return;
    // A verdict read may register a pending-settlement dependency even while
    // untracked. Admission refresh is imperative bookkeeping and must never
    // cause the caller's render or effect to reconstruct retained descendants.
    runWithOwner(null, () => latest(() => untrack(() => {
      logicalParent?.refresh?.();
      if (releaseHost) hostPresent = releaseHost.current();
      enabled = config.active?.() ?? true;
      layer = typeof config.layer === 'function' ? config.layer() : config.layer ?? false;
      dismissable = typeof config.dismissable === 'function' ? config.dismissable() : config.dismissable ?? false;
      modal = typeof config.modal === 'function' ? config.modal() : config.modal ?? false;
      activationRoots = config.activationRoots?.() ?? [];
      sync();
    })));
  };
  const context: HotkeyElementContextValue = {
    active: hostActive,
    peekActive: () => currentInstanceId !== null,
    instanceId: () => currentInstanceId,
    refresh,
    subscribe(listener) {
      listeners.add(listener);
      return () => { listeners.delete(listener); };
    },
  };
  const detach = () => {
    releaseNative?.();
    releaseNative = undefined;
    releaseHost?.();
    releaseHost = undefined;
    element = undefined;
    nonvisual = undefined;
    sync();
  };
  const attachTarget = (target: EventTarget, nextElement?: Element) => {
    if (disposed) return;
    releaseNative?.();
    releaseNative = undefined;
    releaseHost?.();
    releaseHost = undefined;
    element = nextElement;
    nonvisual = nextElement ? undefined : target;
    hostPresent = true;
    releaseNative = nextElement ? logicalParent?.registerNative?.(nextElement) : undefined;
    sync();
    const observeHost = () => {
      if (disposed || !nextElement || element !== nextElement) return;
      releaseHost = observeHotkeyHost(nextElement, present => { hostPresent = present; sync(); });
    };
    observeHost();
    // A ref may be constructed above a Show/vendor switch and invoked below it.
    // The host's render owner, rather than just the factory owner, owns this lease.
    if (getOwner()) onCleanup(() => {
      if ((element ?? nonvisual) !== target) return;
      detach();
    });
  };
  const attach = (element: Element) => attachTarget(element, element);
  return Object.assign(attach, {
    active,
    lifetime: hostActive,
    context,
    detach,
    registerNative,
    authority: () => currentAuthority ?? lastAuthority,
    isLive: () => { refresh(); return currentInstanceId !== null; },
    isDisposed: () => disposed,
    canActivate: () => { refresh(); return currentInstanceId !== null && (currentAuthority?.canActivate() ?? false); },
    attachNonvisual: (target: EventTarget) => {
      if (isSurfaceElement(target)) throw new TypeError('Element hosts must use the rendered-host attachment');
      if (layer || modal || dismissable) throw new TypeError('Nonvisual hosts cannot own visual layers');
      attachTarget(target);
    },
  });
}
