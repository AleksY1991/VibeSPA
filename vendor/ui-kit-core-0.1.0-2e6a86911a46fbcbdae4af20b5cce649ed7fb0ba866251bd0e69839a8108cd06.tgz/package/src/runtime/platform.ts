import type {
  UiRendererDefinition,
  UiSurfacePlatform,
} from '../contracts/platform';

let installed: UiSurfacePlatform | undefined;
let installationCount = 0;
const definitions = new Map<string, UiRendererDefinition>();

/** Bootstrap supplies the application's sole surface authority before UI mount. */
export function configureSurfacePlatform(platform: UiSurfacePlatform): () => void {
  if (installed && installed !== platform) throw new Error('The UI surface platform is already installed');
  if (!installed) {
    for (const definition of definitions.values()) platform.registerRenderer(definition);
    installed = platform;
  }
  installationCount += 1;
  let active = true;
  return () => {
    if (!active) return;
    active = false;
    installationCount -= 1;
    if (installationCount === 0) installed = undefined;
  };
}

export function surfacePlatform(): UiSurfacePlatform {
  if (!installed) throw new Error('Install the application surface platform before mounting UI');
  return installed;
}

/** Static view declarations can precede bootstrap; mounting can never precede it. */
export function declareRenderer(definition: UiRendererDefinition): void {
  definitions.set(definition.id, definition);
  installed?.registerRenderer(definition);
}
