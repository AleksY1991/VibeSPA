import { describe, expect, it } from 'vitest';
import { configureSurfacePlatform, surfacePlatform } from './platform';

describe('one injected surface authority', () => {
  it('retains the shared platform until every mounted root releases it', () => {
    const platform = surfacePlatform();
    const releaseFirst = configureSurfacePlatform(platform);
    const releaseSecond = configureSurfacePlatform(platform);
    releaseFirst();
    releaseFirst();
    expect(surfacePlatform()).toBe(platform);
    releaseSecond();
    // The application's bootstrap lease remains live independently of these roots.
    expect(surfacePlatform()).toBe(platform);
  });

  it('rejects a second arbiter while an application is mounted', () => {
    const platform = surfacePlatform();
    expect(() => configureSurfacePlatform({ ...platform })).toThrow('already installed');
    expect(surfacePlatform()).toBe(platform);
  });
});
