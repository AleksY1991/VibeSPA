import type { Dispose } from '../contracts/platform';
import { isSurfaceElement, surfaceShadowHost } from '../contracts/platform';

export type HotkeyHostLifetime = Dispose & {
  /** Refresh rendered presence before an imperative activation decision. */
  readonly current: () => boolean;
};

interface HostWatch {
  readonly element: Element;
  root: Node;
  readonly changed: (present: boolean) => void;
  readonly roots: Set<Node>;
  readonly targets: Set<Element>;
  present: boolean;
  disposed: boolean;
}

interface HostObserver {
  readonly observer: MutationObserver;
  readonly watches: Set<HostWatch>;
  readonly targets: Map<Element, Set<HostWatch>>;
  readonly roots: Map<Node, number>;
  readonly pending: Set<HostWatch>;
  refreshQueued: boolean;
  initialQueued: boolean;
}

const documents = new WeakMap<Document, HostObserver>();
const observation: MutationObserverInit = { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden', 'style', 'class', 'inert', 'open'] };

function isVisible(element: Element, visibility: Map<Element, boolean>): boolean {
  const cached = visibility.get(element);
  if (cached !== undefined) return cached;
  if (element.hasAttribute('hidden') || element.hasAttribute('inert')) {
    visibility.set(element, false);
    return false;
  }
  const style = element.ownerDocument.defaultView?.getComputedStyle(element);
  const visible = style?.display !== 'none' && style?.visibility !== 'hidden' && style?.visibility !== 'collapse';
  visibility.set(element, visible);
  return visible;
}

function containsComposed(root: Node, node: Node): boolean {
  for (let current: Node | null = node; current;) {
    if (root.contains(current)) return true;
    const currentRoot = current.getRootNode();
    current = surfaceShadowHost(currentRoot);
  }
  return false;
}

function refreshObservation(shared: HostObserver): void {
  if (shared.refreshQueued) return;
  shared.refreshQueued = true;
  queueMicrotask(() => {
    shared.refreshQueued = false;
    // Disconnect discards queued records. Preserve other hosts' removals while
    // coalescing disposal of many detached construction roots into one rebuild.
    const pending = shared.observer.takeRecords();
    shared.observer.disconnect();
    for (const root of shared.roots.keys()) shared.observer.observe(root, observation);
    publish(shared, pending);
  });
}

function releaseRoot(shared: HostObserver, root: Node): void {
  const references = shared.roots.get(root) ?? 0;
  if (references > 1) shared.roots.set(root, references - 1);
  else {
    shared.roots.delete(root);
    refreshObservation(shared);
  }
}

function track(shared: HostObserver, watch: HostWatch, visibility?: Map<Element, boolean>): boolean {
  const document = watch.element.ownerDocument;
  const currentRoot = watch.element.getRootNode({ composed: true });
  // A ref starts in a construction fragment and may enter a detached test root.
  // Broaden that anchor on insertion, but never adopt a smaller detached subtree
  // as a new rendered root after an established host is removed.
  if (currentRoot === document || containsComposed(currentRoot, watch.root)) watch.root = currentRoot;
  const contained = currentRoot === watch.root;
  const roots = new Set<Node>([document, watch.root]);
  const targets = new Set<Element>([watch.element]);
  let visible = true;
  for (let current: Element | null = watch.element; current;) {
    if (visible && visibility && !isVisible(current, visibility)) visible = false;
    const root = current.getRootNode();
    const shadowHost = surfaceShadowHost(root);
    if (shadowHost) {
      roots.add(root);
      targets.add(shadowHost);
    }
    // Slot ancestry is rendered ancestry, even though the assigned element
    // remains a light-DOM child. Index it without inspecting vendor internals.
    if (current.assignedSlot) targets.add(current.assignedSlot);
    current = current.assignedSlot ?? current.parentElement ?? shadowHost;
  }
  // Keep the previous shadow roots while detached so a later reinsertion into
  // them is observable. Once reattached, drop roots and hosts left by the move.
  if (!contained) {
    for (const root of watch.roots) roots.add(root);
    for (const target of watch.targets) targets.add(target);
  }
  for (const root of watch.roots) {
    if (!roots.has(root)) releaseRoot(shared, root);
  }
  for (const root of roots) {
    if (watch.roots.has(root)) continue;
    const references = shared.roots.get(root) ?? 0;
    shared.roots.set(root, references + 1);
    if (references === 0) shared.observer.observe(root, observation);
  }
  watch.roots.clear();
  for (const root of roots) watch.roots.add(root);
  for (const target of watch.targets) {
    if (targets.has(target)) continue;
    const watches = shared.targets.get(target)!;
    watches.delete(watch);
    if (!watches.size) shared.targets.delete(target);
  }
  for (const target of targets) {
    if (watch.targets.has(target)) continue;
    let watches = shared.targets.get(target);
    if (!watches) shared.targets.set(target, watches = new Set());
    watches.add(watch);
  }
  watch.targets.clear();
  for (const target of targets) watch.targets.add(target);
  return contained && visible;
}

function reconcile(shared: HostObserver, watch: HostWatch, visibility = new Map<Element, boolean>()): void {
  if (watch.disposed) return;
  shared.pending.delete(watch);
  const present = track(shared, watch, visibility);
  if (present === watch.present) return;
  watch.present = present;
  watch.changed(present);
}

function publish(shared: HostObserver, records: readonly MutationRecord[]): void {
  const affected = new Set<HostWatch>();
  const visit = (node: Node) => {
    if (!isSurfaceElement(node)) return;
    for (const watch of shared.targets.get(node) ?? []) affected.add(watch);
    for (const descendant of node.querySelectorAll('*')) {
      for (const watch of shared.targets.get(descendant) ?? []) affected.add(watch);
    }
  };
  for (const record of records) {
    if (record.type === 'attributes') visit(record.target);
    for (const node of record.addedNodes) visit(node);
    for (const node of record.removedNodes) visit(node);
  }
  // Ancestors are shared by many controls. Resolve their computed styles once
  // per publication, while synchronous activation checks always get fresh CSS.
  const visibility = new Map<Element, boolean>();
  for (const watch of affected) reconcile(shared, watch, visibility);
}

function queueInitial(shared: HostObserver, watch: HostWatch): void {
  shared.pending.add(watch);
  if (shared.initialQueued) return;
  shared.initialQueued = true;
  queueMicrotask(() => {
    shared.initialQueued = false;
    const visibility = new Map<Element, boolean>();
    for (const pending of [...shared.pending]) reconcile(shared, pending, visibility);
  });
}

/** One shared observer follows rendered hosts, including detached test roots. */
export function observeHotkeyHost(element: Element, changed: (present: boolean) => void): HotkeyHostLifetime {
  const document = element.ownerDocument;
  let shared = documents.get(document);
  if (!shared) {
    const created: HostObserver = {
      observer: new MutationObserver(records => publish(created, records)),
      watches: new Set(), targets: new Map(), roots: new Map(), pending: new Set(),
      refreshQueued: false, initialQueued: false,
    };
    documents.set(document, shared = created);
  }
  const watch: HostWatch = {
    element, root: element.getRootNode({ composed: true }), changed,
    roots: new Set(), targets: new Set(), present: true, disposed: false,
  };
  shared.watches.add(watch);
  // Index immediately, but defer computed styles until insertion has settled.
  track(shared, watch);
  // Refs run before insertion. One shared reconciliation checks their final
  // render roots and initially hidden ancestors without waiting for a mutation.
  queueInitial(shared, watch);
  const release = () => {
    if (watch.disposed) return;
    watch.disposed = true;
    shared.watches.delete(watch);
    shared.pending.delete(watch);
    for (const target of watch.targets) {
      const watches = shared.targets.get(target)!;
      watches.delete(watch);
      if (!watches.size) shared.targets.delete(target);
    }
    for (const root of watch.roots) releaseRoot(shared, root);
    if (!shared.watches.size) documents.delete(document);
  };
  return Object.assign(release, {
    current: () => {
      reconcile(shared, watch);
      return !watch.disposed && watch.present;
    },
  });
}
