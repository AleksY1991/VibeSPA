// @vitest-environment happy-dom
import { describe, expect, it, vi } from 'vitest';

import { observeHotkeyHost } from './host-lifetime';

// Observer publication can schedule a root refresh, which can itself publish
// records. Drain both turns before checking the externally visible lifetime.
const settle = async () => {
  await new Promise(resolve => setTimeout(resolve, 0));
  await new Promise(resolve => setTimeout(resolve, 0));
};

describe('rendered hotkey host lifetime', () => {
  it('follows a foreign document closed shadow root without global DOM constructors', async () => {
    const frame = document.createElement('iframe');
    document.body.append(frame);
    const foreignDocument = frame.contentDocument!;
    const host = foreignDocument.createElement('div');
    const shadow = host.attachShadow({ mode: 'closed' });
    const control = foreignDocument.createElement('button');
    shadow.append(control);
    foreignDocument.body.append(host);
    const changed = vi.fn();
    vi.stubGlobal('ShadowRoot', undefined);
    vi.stubGlobal('Element', undefined);
    const lifetime = observeHotkeyHost(control, changed);
    try {
      expect(control.ownerDocument).not.toBe(document);
      await settle();
      expect(lifetime.current()).toBe(true);

      host.hidden = true;
      await settle();
      expect(changed.mock.calls).toEqual([[false]]);

      host.hidden = false;
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true]]);

      host.remove();
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true], [false]]);
      expect(lifetime.current()).toBe(false);
    } finally {
      lifetime();
      vi.unstubAllGlobals();
      frame.remove();
      await settle();
    }
  });

  it('reports hiding, removal, and disposal synchronously before observer delivery', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const changed = vi.fn();
    const lifetime = observeHotkeyHost(host, changed);
    try {
      expect(lifetime.current()).toBe(true);
      expect(changed).not.toHaveBeenCalled();

      host.hidden = true;
      expect(lifetime.current()).toBe(false);
      expect(changed.mock.calls).toEqual([[false]]);

      host.hidden = false;
      expect(lifetime.current()).toBe(true);
      host.remove();
      expect(lifetime.current()).toBe(false);
      document.body.append(host);
      expect(lifetime.current()).toBe(true);
      expect(changed.mock.calls).toEqual([[false], [true], [false], [true]]);

      lifetime();
      expect(lifetime.current()).toBe(false);
      host.hidden = true;
      await settle();
      expect(lifetime.current()).toBe(false);
      expect(changed.mock.calls).toEqual([[false], [true], [false], [true]]);
    } finally {
      lifetime();
      host.remove();
      await settle();
    }
  });

  it.each(['hidden', 'display', 'visibility'] as const)(
    'reconciles an already-connected host initially concealed by %s without a later mutation',
    async concealment => {
      const host = document.createElement('div');
      if (concealment === 'hidden') host.hidden = true;
      else if (concealment === 'display') host.style.display = 'none';
      else host.style.visibility = 'hidden';
      document.body.append(host);
      const changed = vi.fn();
      const release = observeHotkeyHost(host, changed);
      try {
        await settle();
        expect(changed).toHaveBeenCalledExactlyOnceWith(false);
      } finally {
        release();
        host.remove();
        await settle();
      }
    },
  );

  it.each(['display: none', 'visibility: hidden', 'visibility: collapse'] as const)(
    'follows a parent class that applies %s',
    async declaration => {
      const stylesheet = document.createElement('style');
      stylesheet.textContent = `.concealed-hotkey-parent { ${declaration}; }`;
      document.head.append(stylesheet);
      const parent = document.createElement('div');
      const host = document.createElement('button');
      parent.append(host);
      document.body.append(parent);
      const changed = vi.fn();
      const release = observeHotkeyHost(host, changed);
      try {
        await settle();
        expect(changed).not.toHaveBeenCalled();

        parent.classList.add('concealed-hotkey-parent');
        await settle();
        expect(changed.mock.calls).toEqual([[false]]);

        parent.classList.remove('concealed-hotkey-parent');
        await settle();
        expect(changed.mock.calls).toEqual([[false], [true]]);
      } finally {
        release();
        parent.remove();
        stylesheet.remove();
        await settle();
      }
    },
  );

  it('suspends a host while its ancestor is inert', async () => {
    const parent = document.createElement('div');
    const host = document.createElement('button');
    parent.append(host);
    document.body.append(parent);
    const changed = vi.fn();
    const release = observeHotkeyHost(host, changed);
    try {
      await settle();
      expect(changed).not.toHaveBeenCalled();

      parent.setAttribute('inert', '');
      await settle();
      expect(changed.mock.calls).toEqual([[false]]);

      parent.removeAttribute('inert');
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true]]);
    } finally {
      release();
      parent.remove();
      await settle();
    }
  });

  it('keeps an aria-hidden host live for both synchronous reads and observer settlement', async () => {
    const parent = document.createElement('div');
    const host = document.createElement('button');
    parent.setAttribute('aria-hidden', 'true');
    parent.append(host);
    document.body.append(parent);
    const changed = vi.fn();
    const lifetime = observeHotkeyHost(host, changed);
    try {
      expect(lifetime.current()).toBe(true);
      await settle();
      expect(changed).not.toHaveBeenCalled();

      parent.setAttribute('aria-hidden', 'false');
      expect(lifetime.current()).toBe(true);
      await settle();
      expect(changed).not.toHaveBeenCalled();

      parent.setAttribute('aria-hidden', 'true');
      expect(lifetime.current()).toBe(true);
      await settle();
      expect(lifetime.current()).toBe(true);
      expect(changed).not.toHaveBeenCalled();
    } finally {
      lifetime();
      parent.remove();
      await settle();
    }
  });

  it('follows the open state of a native dialog while its child stays mounted', async () => {
    const dialog = document.createElement('dialog');
    const host = document.createElement('button');
    dialog.append(host);
    document.body.append(dialog);
    const changed = vi.fn();
    const release = observeHotkeyHost(host, changed);
    try {
      await settle();
      expect(changed.mock.calls).toEqual([[false]]);
      expect(dialog.firstElementChild).toBe(host);

      dialog.open = true;
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true]]);
      expect(dialog.firstElementChild).toBe(host);

      dialog.open = false;
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true], [false]]);
      expect(dialog.firstElementChild).toBe(host);
    } finally {
      release();
      dialog.remove();
      await settle();
    }
  });

  it('adopts a detached render container after a pre-insertion ref and suspends after removal', async () => {
    const host = document.createElement('button');
    const container = document.createElement('div');
    const changed = vi.fn();
    const release = observeHotkeyHost(host, changed);
    container.append(host);
    try {
      await settle();
      expect(changed).not.toHaveBeenCalled();

      host.remove();
      await settle();
      expect(changed.mock.calls).toEqual([[false]]);

      container.append(host);
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true]]);
    } finally {
      release();
      await settle();
    }
  });

  it.each(['open', 'closed'] as const)(
    'follows %s shadow-host hiding, removal, and reinsertion',
    async mode => {
      const host = document.createElement('div');
      const shadow = host.attachShadow({ mode });
      const control = document.createElement('button');
      shadow.append(control);
      document.body.append(host);
      const changed = vi.fn();
      const release = observeHotkeyHost(control, changed);
      try {
        await settle();
        expect(changed).not.toHaveBeenCalled();

        host.hidden = true;
        await settle();
        expect(changed.mock.calls).toEqual([[false]]);

        host.hidden = false;
        await settle();
        expect(changed.mock.calls).toEqual([[false], [true]]);

        host.remove();
        await settle();
        expect(changed.mock.calls).toEqual([[false], [true], [false]]);

        document.body.append(host);
        await settle();
        expect(changed.mock.calls).toEqual([[false], [true], [false], [true]]);
      } finally {
        release();
        host.remove();
        await settle();
      }
    },
  );

  it('follows hidden ancestors across nested closed shadow roots', async () => {
    const outerHost = document.createElement('div');
    const outerShadow = outerHost.attachShadow({ mode: 'closed' });
    const wrapper = document.createElement('section');
    const innerHost = document.createElement('div');
    const innerShadow = innerHost.attachShadow({ mode: 'closed' });
    const control = document.createElement('button');
    innerShadow.append(control);
    wrapper.append(innerHost);
    outerShadow.append(wrapper);
    document.body.append(outerHost);
    const changed = vi.fn();
    const release = observeHotkeyHost(control, changed);
    try {
      await settle();
      expect(changed).not.toHaveBeenCalled();

      wrapper.hidden = true;
      await settle();
      expect(changed.mock.calls).toEqual([[false]]);

      wrapper.hidden = false;
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true]]);

      outerHost.style.display = 'none';
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true], [false]]);

      outerHost.style.display = '';
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true], [false], [true]]);
    } finally {
      release();
      outerHost.remove();
      await settle();
    }
  });

  it('tracks the new host after a watched control moves between shadow roots', async () => {
    const firstHost = document.createElement('div');
    const firstShadow = firstHost.attachShadow({ mode: 'closed' });
    const nextHost = document.createElement('div');
    const nextShadow = nextHost.attachShadow({ mode: 'closed' });
    const control = document.createElement('button');
    firstShadow.append(control);
    document.body.append(firstHost, nextHost);
    const changed = vi.fn();
    const release = observeHotkeyHost(control, changed);
    try {
      await settle();
      nextShadow.append(control);
      await settle();
      expect(changed).not.toHaveBeenCalled();

      firstHost.hidden = true;
      firstHost.remove();
      await settle();
      expect(changed).not.toHaveBeenCalled();

      nextHost.hidden = true;
      await settle();
      expect(changed.mock.calls).toEqual([[false]]);

      nextHost.hidden = false;
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true]]);

      nextHost.remove();
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true], [false]]);

      document.body.append(nextHost);
      await settle();
      expect(changed.mock.calls).toEqual([[false], [true], [false], [true]]);
    } finally {
      release();
      firstHost.remove();
      nextHost.remove();
      await settle();
    }
  });

  it('shares one observer across 3000 hosts and stops publishing after disposal', async () => {
    const NativeMutationObserver = globalThis.MutationObserver;
    let observerCount = 0;
    const disconnect = vi.fn();
    class CountingMutationObserver extends NativeMutationObserver {
      constructor(callback: MutationCallback) {
        super(callback);
        observerCount++;
      }

      override disconnect() {
        disconnect();
        super.disconnect();
      }
    }
    vi.stubGlobal('MutationObserver', CountingMutationObserver);
    const container = document.createElement('div');
    const hosts = Array.from({ length: 3000 }, () => document.createElement('button'));
    container.append(...hosts);
    document.body.append(container);
    const changed = vi.fn();
    const releases = hosts.map(host => observeHotkeyHost(host, changed));
    try {
      await settle();
      expect(observerCount).toBe(1);
      expect(changed).not.toHaveBeenCalled();

      container.hidden = true;
      await settle();
      expect(changed).toHaveBeenCalledTimes(hosts.length);
      expect(changed.mock.calls.every(([present]) => present === false)).toBe(true);

      for (const release of releases.splice(0)) release();
      container.hidden = false;
      container.remove();
      await settle();
      expect(changed).toHaveBeenCalledTimes(hosts.length);
      expect(disconnect).toHaveBeenCalled();
      expect(observerCount).toBe(1);
    } finally {
      for (const release of releases.splice(0)) release();
      container.remove();
      await settle();
      vi.unstubAllGlobals();
    }
  });

  it('preserves another host removal queued before the last detached-root watcher is disposed', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const detachedRoot = document.createElement('label');
    const detachedControl = document.createElement('input');
    detachedRoot.append(detachedControl);
    const changed = vi.fn();
    const releaseHost = observeHotkeyHost(host, changed);
    const releaseOther = observeHotkeyHost(detachedControl, () => {});
    try {
      await settle();
      host.remove();
      releaseOther();
      await settle();
      expect(changed).toHaveBeenCalledExactlyOnceWith(false);
    } finally {
      releaseOther();
      releaseHost();
      host.remove();
      await settle();
    }
  });
});
