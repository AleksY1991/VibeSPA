import { createContext, useContext, type Accessor } from 'solid-js';

export interface HotkeyRendererContextValue {
  /** Optional render intent, used for synchronous event authorization. */
  readonly active?: Accessor<boolean>;
  /** Imperative snapshot; the renderer publishes changes through subscribe. */
  readonly instanceId: () => string | null;
  readonly subscribe: (listener: () => void) => () => void;
}

/** Logical ownership survives portals and retained, hidden children. */
export interface HotkeyElementContextValue extends HotkeyRendererContextValue {
  readonly active: Accessor<boolean>;
  /** Immediate lifetime snapshot, before Solid publishes its reactive signal. */
  readonly peekActive: () => boolean;
  /** Refresh pending policy before authorizing an imperative event callback. */
  readonly refresh?: () => void;
  /** Only composite internals explicitly opt into delegating native ownership. */
  readonly registerNative?: (element: Element) => () => void;
}

export const HotkeyElementContext = createContext<HotkeyElementContextValue | null>(null);

export const useHotkeyElementContext = (): HotkeyElementContextValue | undefined =>
  useContext(HotkeyElementContext) ?? undefined;

export const HotkeyRendererContext = createContext<HotkeyRendererContextValue | null>(null);

export const useHotkeyRendererContext = (): HotkeyRendererContextValue | undefined =>
  useContext(HotkeyRendererContext) ?? undefined;
