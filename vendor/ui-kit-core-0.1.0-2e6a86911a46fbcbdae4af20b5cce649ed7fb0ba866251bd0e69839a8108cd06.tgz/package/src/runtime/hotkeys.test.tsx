/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createComponent, createEffect, createRoot, createSignal, flush, OBSERVE, onCleanup, onSettled, Show, untrack, type Accessor } from 'solid-js';
import { afterEach, expect, it } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { List } from '../solid/list';
import { surfaceRegistry } from '../../tests/surface-host';
import { HotkeyRendererContext } from './context';
import { hotkeys, type HotkeyBinding } from './hotkeys';

const disposers: (() => void)[] = [];
afterEach(() => { for (const dispose of disposers.splice(0).reverse()) dispose(); document.body.replaceChildren(); });

function mountRenderer(active: Accessor<boolean>, content: () => JSX.Element) {
  let instanceId: string | null = null;
  const listeners = new Set<() => void>();
  const publish = (next: string | null) => {
    instanceId = next;
    for (const listener of listeners) listener();
  };
  const context = {
    active, instanceId: () => instanceId,
    subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
  };
  const Lease = () => {
    onSettled(() => {
      const lease = surfaceRegistry.mountRenderer('hotkeys.renderer');
      publish(lease.instanceId);
      return () => { publish(null); lease.dispose(); };
    });
    return null;
  };
  const Renderer = () => {
    onCleanup(() => { publish(null); listeners.clear(); });
    return <HotkeyRendererContext value={context}>
      <Show when={active()}><Lease /></Show>
      {createComponent(content, {})}
    </HotkeyRendererContext>;
  };
  surfaceRegistry.registerRenderer({ id: 'hotkeys.renderer', transparent: true });
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => <Renderer />, host);
  disposers.push(dispose);
  return { dispose, host, listenerCount: () => listeners.size };
}

it('does not subscribe unused activity handles from 3000 mounted keyboard owners', () => {
  const [active, setActive] = createSignal(true, { name: 'hotkeys.renderer.intent' });
  const diagnostics: string[] = [];
  const stop = OBSERVE!.diagnostics.subscribe(event => {
    if (event.code === 'HUGE_FAN_OUT') diagnostics.push(event.message);
  });
  const ids = Array.from({ length: 3000 }, (_, index) => index);
  let constructions = 0;
  const fixture = mountRenderer(active, () => {
    const rows = constructItem('hotkeys.owners', item => item.constant('rows', ids));
    return <List.View observable={rows} surface={{ kind: 'inherit' }} hotkeys={[]} keyBy={id => id}>{row => {
      const id = untrack(row.read);
      constructions++;
      const binding = hotkeys({ name: `hotkeys.owner.${id}`, keys: { Enter: () => {} } });
      return <div ref={binding} />;
    }}</List.View>;
  });
  const owners = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name.startsWith('hotkeys.owner.'));
  try {
    flush(); expect(owners()).toHaveLength(3000);
    setActive(false); flush(); expect(owners()).toHaveLength(0);
    setActive(true); flush(); expect(owners()).toHaveLength(3000);
    expect(constructions).toBe(3000);
    expect(diagnostics).toEqual([]);
  } finally { fixture.dispose(); stop(); }
  expect(owners()).toHaveLength(0);
  expect(fixture.listenerCount()).toBe(0);
});

it('derives observed renderer intent in the source flush and revokes escaped handles on disposal', () => {
  const [active, setActive] = createSignal(true);
  const frames: (readonly boolean[])[] = [];
  let binding!: HotkeyBinding;
  const fixture = mountRenderer(active, () => {
    binding = hotkeys({ name: 'hotkeys.observed' });
    createEffect(() => [active(), binding.active(), binding.lifetime()] as const,
      frame => { frames.push(frame); });
    return <div ref={binding} />;
  });
  flush();
  for (const next of [false, true, false, true]) {
    setActive(next); flush();
    expect(binding.canActivate()).toBe(next);
    expect(binding.isLive()).toBe(next);
  }
  const closingFrames = frames.filter(([intent]) => !intent);
  expect(closingFrames.length).toBeGreaterThan(0);
  expect(closingFrames.every(([, logicalActive]) => !logicalActive)).toBe(true);
  expect(frames.at(-1)).toEqual([true, true, true]);
  const escaped: (readonly boolean[])[] = [];
  const stop = createRoot(dispose => {
    createEffect(() => [binding.active(), binding.lifetime()], frame => { escaped.push(frame); });
    return dispose;
  });
  try {
    flush(); fixture.dispose(); flush();
    expect(escaped).toEqual([[true, true], [false, false]]);
    expect(binding.canActivate()).toBe(false);
    expect(binding.isLive()).toBe(false);
    expect(untrack(binding.active)).toBe(false);
    expect(untrack(binding.lifetime)).toBe(false);
    expect(fixture.listenerCount()).toBe(0);
  } finally { stop(); }
});
