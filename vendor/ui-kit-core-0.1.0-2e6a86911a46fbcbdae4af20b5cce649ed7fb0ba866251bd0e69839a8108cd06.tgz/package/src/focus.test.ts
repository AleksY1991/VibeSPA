// @vitest-environment happy-dom
import { readFileSync } from 'node:fs';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

beforeEach(() => { document.body.setAttribute('data-ui-root', ''); });
afterEach(() => {
  document.body.removeAttribute('data-ui-root');
  document.querySelector('[data-focus-policy-test]')?.remove();
  document.body.replaceChildren();
});

describe('focus appearance', () => {
  it('preserves focus, activation, field editing, and explicit selection without focus decoration', () => {
    const style = document.createElement('style');
    style.dataset.focusPolicyTest = '';
    style.textContent = readFileSync('src/focus.css', 'utf8')
      + '\n[data-selected] { outline: 1px solid black; }';
    document.head.append(style);
    const button = document.createElement('button');
    const input = document.createElement('input');
    document.body.append(button, input);
    let activated = false;
    button.onclick = () => { activated = true; };
    button.focus();
    expect(document.activeElement).toBe(button);
    expect(getComputedStyle(button).outlineStyle).toBe('none');
    expect(getComputedStyle(button).boxShadow).toBe('none');
    button.click();
    expect(activated).toBe(true);
    button.dataset.selected = '';
    expect(getComputedStyle(button).outlineStyle).toBe('solid');
    input.focus();
    input.value = 'Still editable';
    input.setSelectionRange(0, 5);
    expect(document.activeElement).toBe(input);
    expect(input.selectionEnd).toBe(5);
    expect(getComputedStyle(input).outlineStyle).toBe('none');
    expect(getComputedStyle(input).getPropertyValue('--wa-focus-ring')).toBe('none');
  });
});
