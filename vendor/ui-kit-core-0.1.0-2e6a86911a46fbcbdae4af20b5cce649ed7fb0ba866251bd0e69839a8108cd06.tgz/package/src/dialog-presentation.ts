import { cn } from './lib/utils';
import type { ClosedControlPresentation } from './contracts/presentation';
import { assertControlPresentation } from './infrastructure/presentation';
import type { Observable } from './contracts/construction';
import { readObservable } from './infrastructure/construction';

export type DialogRecipe = 'dialog' | 'form' | 'editor' | 'media' | 'drawer' | 'fullscreen' | 'detached';
export type DialogSize = 'default' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
export type DialogPlacement = 'center' | 'start' | 'corner';

/** Resizing and expansion are a live panel model, separate from its visibility. */
export interface DialogDrawerState {
  readonly width: number;
  readonly expanded?: boolean;
}

/** Only bounded dialog frames accept a width scale and an anchored placement. */
type DialogFrame =
  | { readonly recipe?: 'dialog' | 'form' | 'editor'; readonly size?: DialogSize; readonly placement?: DialogPlacement;
      readonly drawer?: never; readonly dock?: never }
  | { readonly recipe: 'media' | 'fullscreen' | 'detached'; readonly size?: never; readonly placement?: never;
      readonly drawer?: never; readonly dock?: never }
  | { readonly recipe: 'drawer'; readonly drawer: Observable<DialogDrawerState>;
      readonly size?: never; readonly placement?: never; readonly dock?: 'end' };

/** Never fields keep wider and imported props objects structurally closed. */
interface DialogPresentationBoundary extends ClosedControlPresentation {
  readonly overlayClass?: never;
  readonly overlayClassName?: never;
  readonly visualStyle?: never;
  readonly variant?: never;
  readonly overflow?: never;
  readonly layout?: never;
  readonly blockStart?: never;
  readonly viewportInset?: never;
  readonly padding?: never;
  readonly gap?: never;
  readonly height?: never;
  readonly backdrop?: never;
}

export type DialogPresentation = DialogFrame & DialogPresentationBoundary;

export interface ResolvedDialogPresentation {
  readonly recipe: DialogRecipe;
  readonly size: DialogSize;
  readonly placement: DialogPlacement;
  readonly variant: 'default' | 'fullscreen' | 'detached';
  readonly overflow: 'visible' | 'hidden';
  readonly layout: 'grid' | 'column' | 'block';
  readonly padding: 'none' | 'md';
  readonly gap: 'none' | 'md';
  readonly height: 'content' | 'viewport';
  readonly backdrop: 'default' | 'transparent';
  readonly panelWidth?: number;
  readonly expanded?: boolean;
  readonly dock?: 'end';
}

/** Recipes own complete frame/content geometry; no partial presentation is merged. */
export function resolveDialogPresentation(props: DialogPresentation): ResolvedDialogPresentation {
  assertControlPresentation('Dialog', props);
  const recipe = props.recipe ?? 'dialog';
  if (!['dialog', 'form', 'editor', 'media', 'drawer', 'fullscreen', 'detached'].includes(recipe)) {
    throw new TypeError('Dialog: unsupported recipe');
  }
  const bounded = recipe === 'dialog' || recipe === 'form' || recipe === 'editor';
  if (!bounded && props.size !== undefined) {
    throw new TypeError(`Dialog: the ${recipe} recipe owns its width`);
  }
  if (!bounded && props.placement !== undefined) {
    throw new TypeError(`Dialog: the ${recipe} recipe owns its placement`);
  }
  const drawer = props.recipe === 'drawer' ? readObservable(props.drawer)() : undefined;
  if (recipe === 'drawer') {
    if (!drawer || typeof drawer.width !== 'number' || !Number.isFinite(drawer.width) || drawer.width <= 0) {
      throw new TypeError('Dialog: drawer width must be a finite positive pixel width');
    }
    if (drawer.expanded !== undefined && typeof drawer.expanded !== 'boolean') throw new TypeError('Dialog: drawer expanded must be a boolean');
  } else if (props.drawer !== undefined) {
    throw new TypeError('Dialog: only the drawer recipe accepts a drawer model');
  }
  if (props.dock !== undefined && (recipe !== 'drawer' || props.dock !== 'end')) {
    throw new TypeError('Dialog: only the drawer recipe accepts end docking');
  }
  const size = props.size ?? 'default';
  const placement = recipe === 'drawer' && !drawer?.expanded ? 'corner' : props.placement ?? 'center';
  if (!['default', 'sm', 'md', 'lg', 'xl', '2xl'].includes(size)) throw new TypeError('Dialog: unsupported size');
  if (!['center', 'start', 'corner'].includes(placement)) throw new TypeError('Dialog: unsupported placement');
  const column = ['form', 'editor', 'drawer', 'fullscreen'].includes(recipe);
  // These compositions correspond to real form, preview and resizable
  // panel layouts. Each owns a complete frame rather than exposing its knobs.
  return {
    recipe, size, placement,
    variant: recipe === 'detached' ? 'detached' : recipe === 'fullscreen' || recipe === 'drawer' && drawer?.expanded ? 'fullscreen' : 'default',
    overflow: column || recipe === 'media' ? 'hidden' : 'visible',
    layout: recipe === 'media' ? 'block' : column ? 'column' : 'grid',
    padding: recipe === 'dialog' || recipe === 'detached' ? 'md' : 'none',
    gap: recipe === 'dialog' || recipe === 'detached' ? 'md' : 'none',
    height: recipe === 'editor' || recipe === 'drawer' ? 'viewport' : 'content',
    backdrop: recipe === 'detached' || recipe === 'drawer' ? 'transparent' : 'default',
    ...(drawer ? { panelWidth: drawer.width, expanded: drawer.expanded === true, dock: props.dock } : {}),
  };
}

export function dialogFrameClass(props: ResolvedDialogPresentation): string {
  return cn('ui-dialog-frame', `ui-dialog-recipe-${props.recipe}`, `ui-dialog-size-${props.size}`,
    `ui-dialog-variant-${props.variant}`, `ui-dialog-height-${props.height}`, `ui-dialog-placement-${props.placement}`,
    props.dock === 'end' && !props.expanded && 'ui-dialog-dock-end');
}

export function dialogContentClass(props: ResolvedDialogPresentation): string {
  return cn('ui-dialog-content', `ui-dialog-layout-${props.layout}`, `ui-dialog-padding-${props.padding}`, `ui-dialog-gap-${props.gap}`);
}
