/** Start independent vendor preparation; wait only for the shared theme, then render stable wrappers. */
export { prepareAppImplementation, controlPreparation } from './vendor/web-awesome/registration';
export type { ControlPreparation } from './vendor/web-awesome/registration';
export type { PreparedImplementation, ControlFamily } from './infrastructure/implementation-context';
