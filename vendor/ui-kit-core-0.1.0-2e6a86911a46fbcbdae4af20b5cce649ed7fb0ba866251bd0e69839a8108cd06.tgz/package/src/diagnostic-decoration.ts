/** Repeating diagnostic underline artwork, owned by the design system rather than editor features. */
export const diagnosticUnderline = (color: string): string =>
  `url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='6' height='3'><path d='m0 3l3-3l3 3' stroke='${encodeURIComponent(color)}' fill='none' stroke-width='1.5'/></svg>")`;
