import type { ControlSize } from './control-size';

export type ButtonSize = ControlSize;
export type ButtonShape = 'icon';
export type ButtonVariant = 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
export type ButtonRecipe = 'button' | 'content' | 'menu-item' | 'navigation' | 'inline-action'
  | 'cell-action' | 'property-row' | 'selection-cell' | 'action-row'
  | 'fill-action' | 'overlay-action';

type NamedIcon = { readonly 'aria-label': string; readonly 'aria-labelledby'?: string }
  | { readonly 'aria-label'?: string; readonly 'aria-labelledby': string };

/** Recipes own inner geometry and paint; unsupported cross-products are absent. */
export type ButtonPresentation =
  | { readonly recipe?: 'button'; readonly shape?: never; readonly variant?: ButtonVariant; readonly size?: ButtonSize }
  | ({ readonly recipe?: 'button'; readonly shape: 'icon'; readonly variant: 'ghost' | 'destructive' | 'outline'; readonly size?: ButtonSize } & NamedIcon)
  | { readonly recipe: 'content'; readonly shape?: never; readonly variant: 'outline' | 'secondary' | 'ghost'; readonly size?: ButtonSize }
  | { readonly recipe: 'menu-item' | 'navigation'; readonly shape?: never; readonly variant?: never; readonly size?: ButtonSize }
  | { readonly recipe: 'cell-action' | 'property-row'; readonly shape?: never; readonly variant?: never; readonly size?: ButtonSize }
  | { readonly recipe: 'action-row'; readonly shape?: never; readonly variant: 'outline' | 'secondary' | 'ghost'; readonly size?: ButtonSize }
  | { readonly recipe: 'selection-cell'; readonly shape?: never; readonly variant?: never; readonly size?: ButtonSize }
  | ({ readonly recipe: 'selection-cell'; readonly shape: 'icon'; readonly variant?: never; readonly size?: ButtonSize } & NamedIcon)
  | ({ readonly recipe: 'overlay-action'; readonly shape?: never; readonly variant?: never; readonly size?: ButtonSize } & NamedIcon)
  | { readonly recipe: 'inline-action' | 'fill-action'; readonly shape?: never; readonly variant?: never; readonly size?: never };
