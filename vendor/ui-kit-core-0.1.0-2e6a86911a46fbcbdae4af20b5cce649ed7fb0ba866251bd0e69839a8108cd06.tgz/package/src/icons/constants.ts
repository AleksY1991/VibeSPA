export const ICON_STROKE_WIDTH = 1.5;
export const ICON_VIEWBOX_SIZE = 24;
