/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { createSignal, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { afterEach, describe, expect, it } from 'vitest';
import * as icons from './index';
import { LockIcon, CircleXIcon, type IconComponent, type IconProps } from './index';

afterEach(() => document.body.replaceChildren());

describe('shared icon rendering', () => {
  it('renders every exported glyph as an SVG with a common stroke and no focus target', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const components = Object.entries(icons).filter(([name]) => name.endsWith('Icon')).map(([, value]) => value as IconComponent);
    const dispose = render(() => components.map(Icon => <Icon />), host);
    try {
      const rendered = [...host.querySelectorAll('svg')];
      expect(rendered).toHaveLength(components.length);
      for (const svg of rendered) {
        expect(svg.getAttribute('stroke-width')).toBe('1.5');
        expect(svg.getAttribute('stroke')).toBe('currentColor');
        expect(svg.getAttribute('aria-hidden')).toBe('true');
        expect(svg.hasAttribute('tabindex')).toBe(false);
        expect(svg.children.length).toBeGreaterThan(0);
        expect([...svg.querySelectorAll('*')].every(shape => shape.namespaceURI === 'http://www.w3.org/2000/svg')).toBe(true);
      }
    } finally { dispose(); }
  });

  it('keeps lock and clear on the same grid and refuses accidental stroke overrides', () => {
    const host = document.createElement('div');
    const invalid = { 'stroke-width': 2, stroke: 'red', viewBox: '0 0 10 10' } as unknown as IconProps;
    const dispose = render(() => <><LockIcon {...invalid} /><CircleXIcon /></>, host);
    try {
      for (const svg of host.querySelectorAll('svg')) {
        expect(svg.getAttribute('width')).toBe('16');
        expect(svg.getAttribute('height')).toBe('16');
        expect(svg.getAttribute('viewBox')).toBe('0 0 24 24');
        expect(svg.getAttribute('stroke-width')).toBe('1.5');
        expect(svg.getAttribute('stroke')).toBe('currentColor');
      }
    } finally { dispose(); }
  });

  it('reactively exposes a label only when the icon conveys standalone meaning', () => {
    const [label, setLabel] = createSignal<string | undefined>('Locked');
    const host = document.createElement('div');
    const dispose = render(() => <LockIcon label={label()} />, host);
    try {
      const svg = host.querySelector('svg')!;
      expect(svg.getAttribute('aria-label')).toBe('Locked');
      expect(svg.getAttribute('role')).toBe('img');
      expect(svg.hasAttribute('aria-hidden')).toBe(false);
      setLabel(undefined);
      flush();
      expect(svg.hasAttribute('aria-label')).toBe(false);
      expect(svg.getAttribute('aria-hidden')).toBe('true');
    } finally { dispose(); }
  });
});
