/** @jsxImportSource @solidjs/web */
import { omit } from 'solid-js';
import { Dynamic, type JSX } from '@solidjs/web';
import * as data from './catalog';
import { ICON_STROKE_WIDTH } from './constants';

export { ICON_STROKE_WIDTH } from './constants';
export type IconProps = Omit<JSX.SvgSVGAttributes<SVGSVGElement>,
  'children' | 'viewBox' | 'stroke' | 'stroke-width' | 'stroke-linecap' | 'stroke-linejoin' | 'fill'> & {
  readonly label?: string;
};
export type IconComponent = (props: IconProps) => JSX.Element;
type Shape = readonly [string, Readonly<Record<string, unknown>>, (readonly Shape[])?];

const renderShape = ([tag, attributes, children]: Shape): JSX.Element => (
  <Dynamic component={tag} {...attributes}>{children?.map(renderShape)}</Dynamic>
);

/**
 * Lucide's framework-neutral data avoids a second Solid runtime. A native SVG
 * preserves synchronous rendering, inherited ink and the existing control sizes;
 * wa-icon's fetched assets cannot provide this local, synchronous icon contract.
 * Icons are decorative presentation inside the owning constructed control, so
 * they add no surface, subscription, keyboard behavior or focus target (DESIGN).
 */
function icon(glyph: { readonly name?: string; readonly size?: number; readonly node: readonly Shape[] }): IconComponent {
  return props => {
    const attributes = omit(props, 'label');
    const label = () => props.label ?? props['aria-label'];
    return <svg width="16" height="16" {...attributes}
      viewBox={`0 0 ${glyph.size ?? 24} ${glyph.size ?? 24}`}
      fill="none" stroke="currentColor" stroke-width={ICON_STROKE_WIDTH}
      stroke-linecap="round" stroke-linejoin="round"
      aria-hidden={label() ? undefined : 'true'} aria-label={label()}
      role={label() ? 'img' : undefined} data-ui-icon={glyph.name}>
      {glyph.node.map(renderShape)}
    </svg>;
  };
}

export const AlertIcon = /* @__PURE__ */ icon(data.CircleAlert);
export const AlertTriangleIcon = /* @__PURE__ */ icon(data.TriangleAlert);
export const ArchiveIcon = /* @__PURE__ */ icon(data.Archive);
export const ArchiveRestoreIcon = /* @__PURE__ */ icon(data.ArchiveRestore);
export const ArrowDownIcon = /* @__PURE__ */ icon(data.ArrowDown);
export const ArrowDownUpIcon = /* @__PURE__ */ icon(data.ArrowDownUp);
export const ArrowIcon = /* @__PURE__ */ icon(data.ArrowRight);
export const ArrowLeftIcon = /* @__PURE__ */ icon(data.ArrowLeft);
export const ArrowUpIcon = /* @__PURE__ */ icon(data.ArrowUp);
export const AudioIcon = /* @__PURE__ */ icon(data.Volume2);
export const AudioLinesIcon = /* @__PURE__ */ icon(data.AudioLines);
export const BackIcon = /* @__PURE__ */ icon(data.ChevronLeft);
export const BlockedIcon = /* @__PURE__ */ icon(data.Ban);
export const BlocksIcon = /* @__PURE__ */ icon(data.Blocks);
export const BoldIcon = /* @__PURE__ */ icon(data.Bold);
export const BookmarkIcon = /* @__PURE__ */ icon(data.Bookmark);
export const BotIcon = /* @__PURE__ */ icon(data.Bot);
export const BugIcon = /* @__PURE__ */ icon(data.Bug);
export const BuildingIcon = /* @__PURE__ */ icon(data.Building);
export const CalendarIcon = /* @__PURE__ */ icon(data.Calendar);
export const CalendarRangeIcon = /* @__PURE__ */ icon(data.CalendarRange);
export const CameraIcon = /* @__PURE__ */ icon(data.Video);
export const ChartIcon = /* @__PURE__ */ icon(data.ChartColumn);
export const CheckCircleIcon = /* @__PURE__ */ icon(data.CircleCheck);
export const CheckIcon = /* @__PURE__ */ icon(data.Check);
export const ChevronDownIcon = /* @__PURE__ */ icon(data.ChevronDown);
export const ChevronIcon = /* @__PURE__ */ icon(data.ChevronRight);
export const ChevronLeftIcon = /* @__PURE__ */ icon(data.ChevronLeft);
export const ChevronRightIcon = /* @__PURE__ */ icon(data.ChevronRight);
export const ChevronUpIcon = /* @__PURE__ */ icon(data.ChevronUp);
export const ChevronsLeftIcon = /* @__PURE__ */ icon(data.ChevronsLeft);
export const ChevronsRightIcon = /* @__PURE__ */ icon(data.ChevronsRight);
export const CircleDashedIcon = /* @__PURE__ */ icon(data.CircleDashed);
export const CircleIcon = /* @__PURE__ */ icon(data.Circle);
export const CircleXIcon = /* @__PURE__ */ icon(data.CircleX);
export const ClockIcon = /* @__PURE__ */ icon(data.Clock);
export const CloseCallIcon = /* @__PURE__ */ icon(data.X);
export const CloseIcon = /* @__PURE__ */ icon(data.X);
export const CloudOffIcon = /* @__PURE__ */ icon(data.CloudOff);
export const CodeIcon = /* @__PURE__ */ icon(data.Code);
export const CopyIcon = /* @__PURE__ */ icon(data.Copy);
export const DatabaseIcon = /* @__PURE__ */ icon(data.Database);
export const SplitIcon = /* @__PURE__ */ icon(data.Split);
export const DownloadIcon = /* @__PURE__ */ icon(data.Download);
export const EditIcon = /* @__PURE__ */ icon(data.Pencil);
export const ExternalIcon = /* @__PURE__ */ icon(data.ExternalLink);
export const ExternalLinkIcon = /* @__PURE__ */ icon(data.ExternalLink);
export const EyeIcon = /* @__PURE__ */ icon(data.Eye);
export const EyeOffIcon = /* @__PURE__ */ icon(data.EyeOff);
export const FileIcon = /* @__PURE__ */ icon(data.File);
export const FileTextIcon = /* @__PURE__ */ icon(data.FileText);
export const FilterIcon = /* @__PURE__ */ icon(data.Filter);
export const FlagBodyIcon = /* @__PURE__ */ icon(data.FlagBody);
export const FlagIcon = /* @__PURE__ */ icon(data.Flag);
export const FlaskIcon = /* @__PURE__ */ icon(data.FlaskConical);
export const FocusIcon = /* @__PURE__ */ icon(data.Focus);
export const FolderIcon = /* @__PURE__ */ icon(data.Folder);
export const FolderOpenIcon = /* @__PURE__ */ icon(data.FolderOpen);
export const FolderTreeIcon = /* @__PURE__ */ icon(data.FolderTree);
export const GaugeIcon = /* @__PURE__ */ icon(data.Gauge);
export const GithubIcon = /* @__PURE__ */ icon(data.Github);
export const GitForkIcon = /* @__PURE__ */ icon(data.GitFork);
export const GlobeIcon = /* @__PURE__ */ icon(data.Globe);
export const GripIcon = /* @__PURE__ */ icon(data.GripVertical);
export const GripVerticalIcon = /* @__PURE__ */ icon(data.GripVertical);
export const PinIcon = /* @__PURE__ */ icon(data.Pin);
export const HammerIcon = /* @__PURE__ */ icon(data.Hammer);
export const HashIcon = /* @__PURE__ */ icon(data.Hash);
export const HistoryClockIcon = /* @__PURE__ */ icon(data.History);
export const HistoryIcon = /* @__PURE__ */ icon(data.History);
export const ImageIcon = /* @__PURE__ */ icon(data.Image);
export const InboxIcon = /* @__PURE__ */ icon(data.Inbox);
export const ItalicIcon = /* @__PURE__ */ icon(data.Italic);
export const KeyIcon = /* @__PURE__ */ icon(data.Key);
export const KeyboardIcon = /* @__PURE__ */ icon(data.Keyboard);
export const LayersIcon = /* @__PURE__ */ icon(data.Layers);
export const LeafIcon = /* @__PURE__ */ icon(data.Leaf);
export const LeaveIcon = /* @__PURE__ */ icon(data.LogOut);
export const LineChartIcon = /* @__PURE__ */ icon(data.ChartLine);
export const LinkIcon = /* @__PURE__ */ icon(data.Link);
export const ListIcon = /* @__PURE__ */ icon(data.List);
export const ListTreeIcon = /* @__PURE__ */ icon(data.ListTree);
export const LockIcon = /* @__PURE__ */ icon(data.Lock);
export const LogOutIcon = /* @__PURE__ */ icon(data.LogOut);
export const MaximizeIcon = /* @__PURE__ */ icon(data.Maximize);
export const MessageIcon = /* @__PURE__ */ icon(data.MessageSquare);
export const MicrophoneIcon = /* @__PURE__ */ icon(data.Mic);
export const MicrophoneOffIcon = /* @__PURE__ */ icon(data.MicOff);
export const MinimizeIcon = /* @__PURE__ */ icon(data.Minimize);
export const MinusIcon = /* @__PURE__ */ icon(data.Minus);
export const MonitorIcon = /* @__PURE__ */ icon(data.Monitor);
export const MonitorOffIcon = /* @__PURE__ */ icon(data.MonitorOff);
export const MoonIcon = /* @__PURE__ */ icon(data.Moon);
export const PaletteIcon = /* @__PURE__ */ icon(data.Palette);
export const PanelIcon = /* @__PURE__ */ icon(data.PanelRight);
export const PaperclipIcon = /* @__PURE__ */ icon(data.Paperclip);
export const PenToolIcon = /* @__PURE__ */ icon(data.PenTool);
export const PencilIcon = /* @__PURE__ */ icon(data.Pencil);
export const PieIcon = /* @__PURE__ */ icon(data.ChartPie);
export const PlayIcon = /* @__PURE__ */ icon(data.Play);
export const PlusIcon = /* @__PURE__ */ icon(data.Plus);
export const PointerIcon = /* @__PURE__ */ icon(data.MousePointer2);
export const QuoteIcon = /* @__PURE__ */ icon(data.Quote);
export const RecycleIcon = /* @__PURE__ */ icon(data.Recycle);
export const RedoIcon = /* @__PURE__ */ icon(data.Redo);
export const RefreshIcon = /* @__PURE__ */ icon(data.RefreshCw);
export const RestoreIcon = /* @__PURE__ */ icon(data.RotateCcw);
export const RetryIcon = /* @__PURE__ */ icon(data.RotateCw);
export const RevealIcon = /* @__PURE__ */ icon(data.Eye);
export const RotateIcon = /* @__PURE__ */ icon(data.RotateCcw);
export const SaveIcon = /* @__PURE__ */ icon(data.Save);
export const ScatterIcon = /* @__PURE__ */ icon(data.ChartScatter);
export const ScreenIcon = /* @__PURE__ */ icon(data.ScreenShare);
export const SearchIcon = /* @__PURE__ */ icon(data.Search);
export const SendIcon = /* @__PURE__ */ icon(data.Send);
export const ServerIcon = /* @__PURE__ */ icon(data.Server);
export const SettingsIcon = /* @__PURE__ */ icon(data.Settings);
export const ShieldCheckIcon = /* @__PURE__ */ icon(data.ShieldCheck);
export const SmileIcon = /* @__PURE__ */ icon(data.Smile);
export const SparklesIcon = /* @__PURE__ */ icon(data.Sparkles);
export const StarIcon = /* @__PURE__ */ icon(data.Star);
export const StopIcon = /* @__PURE__ */ icon(data.Square);
export const StrikeIcon = /* @__PURE__ */ icon(data.Strikethrough);
export const SunIcon = /* @__PURE__ */ icon(data.Sun);
export const TableIcon = /* @__PURE__ */ icon(data.Table);
export const TagIcon = /* @__PURE__ */ icon(data.Tag);
export const TargetIcon = /* @__PURE__ */ icon(data.Target);
export const ListTodoIcon = /* @__PURE__ */ icon(data.ListTodo);
export const TrashIcon = /* @__PURE__ */ icon(data.Trash);
export const TriangleAlertIcon = /* @__PURE__ */ icon(data.TriangleAlert);
export const ShapesIcon = /* @__PURE__ */ icon(data.Shapes);
export const UndoIcon = /* @__PURE__ */ icon(data.Undo);
export const UnlockIcon = /* @__PURE__ */ icon(data.LockOpen);
export const UserIcon = /* @__PURE__ */ icon(data.User);
export const UsersIcon = /* @__PURE__ */ icon(data.Users);
export const LayoutGridIcon = /* @__PURE__ */ icon(data.LayoutGrid);
export const XCircleIcon = /* @__PURE__ */ icon(data.CircleX);
export const XIcon = /* @__PURE__ */ icon(data.X);
export const MegaphoneIcon = /* @__PURE__ */ icon(data.Megaphone);
