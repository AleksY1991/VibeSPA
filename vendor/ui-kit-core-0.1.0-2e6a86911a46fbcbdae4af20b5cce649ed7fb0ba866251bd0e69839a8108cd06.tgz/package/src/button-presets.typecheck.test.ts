/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';

const removedProps = [
  ['visualStyle', "'standard'"], ['gap', "'sm'"], ['padding', "'md'"],
  ['textSize', "'caption'"], ['contentAlign', "'start'"], ['iconSize', "'sm'"],
  ['multiline', 'true'], ['fillLabel', 'true'], ['hitTarget', "'content'"],
  ['selectionPaint', 'false'], ['class', "'custom-paint'"], ['className', "'custom-paint'"],
  ['classList', "{ 'custom-paint': true }"], ['style', "{ width: '100%' }"],
];
const forbiddenAliases = [
  'attr:class', 'attr:className', 'attr:classList', 'attr:style',
  'prop:class', 'prop:className', 'prop:classList', 'prop:style',
  'style:color', 'class:paint', 'dataset', 'prop:dataset',
  'data-ui-recipe', 'data-wa-appearance',
  'attr:data-ui-recipe', 'prop:data-ui-recipe', 'attr:data-wa-appearance', 'prop:data-wa-appearance',
];
const source = `
import { Button, type ButtonProps } from './solid/button';
import type { ControlSize } from './control-size';
declare const construction: Pick<ButtonProps, 'observable' | 'surface' | 'hotkeys'>;
const defaultAction: ButtonProps = { ...construction };
const namedButton: ButtonProps = { ...construction, recipe: 'button' };
const dense: ButtonProps = { ...construction, size: 'dense' };
const compact: ButtonProps = { ...construction, size: 'compact' };
const standard: ButtonProps = { ...construction, size: 'standard' };
const large: ButtonProps = { ...construction, size: 'large' };
const icon: ButtonProps = { ...construction, shape: 'icon', variant: 'ghost', size: 'compact', 'aria-label': 'Open settings' };
const referencedIcon: ButtonProps = { ...construction, shape: 'icon', variant: 'outline', 'aria-labelledby': 'settings-label' };
const content: ButtonProps = { ...construction, recipe: 'content', variant: 'outline', size: 'compact' };
const menu: ButtonProps = { ...construction, recipe: 'menu-item', size: 'standard' };
const navigation: ButtonProps = { ...construction, recipe: 'navigation', size: 'large' };
const inline: ButtonProps = { ...construction, recipe: 'inline-action' };
const cell: ButtonProps = { ...construction, recipe: 'cell-action', size: 'compact' };
const property: ButtonProps = { ...construction, recipe: 'property-row' };
const record: ButtonProps = { ...construction, recipe: 'action-row', variant: 'outline' };
const selection: ButtonProps = { ...construction, recipe: 'selection-cell' };
const selectionIcon: ButtonProps = { ...construction, recipe: 'selection-cell', shape: 'icon', 'aria-label': 'Select row' };
const overlay: ButtonProps = { ...construction, recipe: 'overlay-action', size: 'compact', 'aria-label': 'Clear selection' };
const fill: ButtonProps = { ...construction, recipe: 'fill-action' };
declare const shared: ControlSize;
const actionSize: ButtonProps = { ...construction, size: shared };
const actionVariants = ['default', 'destructive', 'outline', 'secondary', 'ghost', 'link'] as const;
actionVariants.forEach(variant => { const button: ButtonProps = { ...construction, variant }; });
const nativeAndAria: ButtonProps = { ...construction, type: 'submit', name: 'intent', value: 'publish', form: 'external-form',
  'aria-controls': 'panel', 'aria-labelledby': 'name', 'aria-describedby': 'details', tabindex: 0 };
const jsx = <Button.View {...construction} variant="outline" size="compact">Save</Button.View>;

// @ts-expect-error icon actions need an accessible name
const unnamedIcon: ButtonProps = { ...construction, shape: 'icon', variant: 'ghost' };
// @ts-expect-error ordinary primary paint is not an icon recipe combination
const primaryIcon: ButtonProps = { ...construction, shape: 'icon', variant: 'default', 'aria-label': 'Save' };
// @ts-expect-error an icon paint must be deliberately selected during migration
const implicitIconPaint: ButtonProps = { ...construction, shape: 'icon', 'aria-label': 'Save' };
// @ts-expect-error content actions do not support icon-only geometry
const contentIcon: ButtonProps = { ...construction, recipe: 'content', shape: 'icon', 'aria-label': 'Pick file' };
// @ts-expect-error content actions expose only their approved paints
const primaryContent: ButtonProps = { ...construction, recipe: 'content', variant: 'default' };
// @ts-expect-error content paint must be explicit instead of silently replacing a legacy default
const implicitContentPaint: ButtonProps = { ...construction, recipe: 'content' };
// @ts-expect-error menus own their appearance
const paintedMenu: ButtonProps = { ...construction, recipe: 'menu-item', variant: 'ghost' };
// @ts-expect-error navigation owns its label and marker structure
const iconNavigation: ButtonProps = { ...construction, recipe: 'navigation', shape: 'icon', 'aria-label': 'Go' };
// @ts-expect-error inline actions use surrounding text geometry
const sizedInline: ButtonProps = { ...construction, recipe: 'inline-action', size: 'dense' };
// @ts-expect-error inline actions own their paint
const paintedInline: ButtonProps = { ...construction, recipe: 'inline-action', variant: 'link' };
// @ts-expect-error fixed cell actions own their paint
const paintedCell: ButtonProps = { ...construction, recipe: 'cell-action', variant: 'ghost' };
// @ts-expect-error content selection icons retain an explicit accessible name
const unnamedSelection: ButtonProps = { ...construction, recipe: 'selection-cell', shape: 'icon' };
// @ts-expect-error overlapping icon actions retain an explicit accessible name
const unnamedOverlay: ButtonProps = { ...construction, recipe: 'overlay-action' };
// @ts-expect-error a chart cell consumes its parent's existing bounds
const sizedFill: ButtonProps = { ...construction, recipe: 'fill-action', size: 'compact' };
// @ts-expect-error rich content rows require a deliberate supported paint
const unpaintedRecord: ButtonProps = { ...construction, recipe: 'action-row' };
// @ts-expect-error a custom recipe cannot restore independent presentation
const custom: ButtonProps = { ...construction, recipe: 'custom' };
// @ts-expect-error legacy recipes without a supported owning composition require explicit migration
const legacyRecipe: ButtonProps = { ...construction, recipe: 'cell' };
// @ts-expect-error legacy action meant a multiline row and cannot silently become an ordinary button
const legacyAction: ButtonProps = { ...construction, recipe: 'action' };
// @ts-expect-error legacy menu geometry requires an explicit new recipe choice
const legacyMenu: ButtonProps = { ...construction, recipe: 'menu' };
// @ts-expect-error legacy inline hit testing cannot silently acquire label-only pointer behavior
const legacyInline: ButtonProps = { ...construction, recipe: 'inline' };
// @ts-expect-error the public scale has only its four canonical names
const oldSize: ButtonProps = { ...construction, size: 'sm' };
// @ts-expect-error navigation is a recipe, not an independently combinable paint
const oldNavigation: ButtonProps = { ...construction, variant: 'navigation' };

${removedProps.map(([name, value]) => `// @ts-expect-error ${name} is owned by a closed recipe\nconst removed_${name}: ButtonProps = { ...construction, ${name}: ${value} };`).join('\n')}

const importedClass = { class: 'custom-paint' };
const importedClassName = { className: 'custom-paint' };
const importedClassList = { classList: { 'custom-paint': true } };
const importedStyle = { style: { 'background-color': 'red', width: '100%' } };
const importedKnobs = { gap: 'sm' as const, padding: 'md' as const };
// @ts-expect-error imported class objects cannot bypass the control boundary
const spreadClass: ButtonProps = { ...construction, ...importedClass };
// @ts-expect-error imported className objects cannot bypass the control boundary
const spreadClassName: ButtonProps = { ...construction, ...importedClassName };
// @ts-expect-error imported classList objects cannot bypass the control boundary
const spreadClassList: ButtonProps = { ...construction, ...importedClassList };
// @ts-expect-error imported style objects cannot bypass the control boundary
const spreadStyle: ButtonProps = { ...construction, ...importedStyle };
// @ts-expect-error imported typography/spacing objects cannot bypass recipes
const spreadKnobs: ButtonProps = { ...construction, ...importedKnobs };
// @ts-expect-error JSX spread remains checked at the control construction boundary
const jsxClass = <Button.View {...construction} {...importedClass}>Save</Button.View>;
// @ts-expect-error JSX imported inline style remains forbidden
const jsxStyle = <Button.View {...construction} {...importedStyle}>Save</Button.View>;
// TypeScript exempts dashed JSX attributes; lint and runtime guard those paths.
// Structural assignments still reject reserved markers in wider props objects.
${forbiddenAliases.map((key, index) => `
const importedAlias${index} = { ...construction, '${key}': 'overwrite' };
// @ts-expect-error structural assignment rejects owned styling aliases and private markers
const assignedAlias${index}: ButtonProps = importedAlias${index};
${key.includes('data-') ? '' : `// @ts-expect-error JSX spreads preserve the same structural presentation boundary
const jsxAlias${index} = <Button.View {...importedAlias${index}}>Save</Button.View>;`}
`).join('\n')}
`;

describe('button presentation type contract', () => {
  it('permits only approved recipes and rejects direct or spread styling escapes', () => {
    const root = process.cwd();
    const filename = path.join(root, 'src/__button_presets_typecheck__.tsx');
    const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
    const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
    const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
      noUnusedLocals: false, noUnusedParameters: false };
    const host = ts.createCompilerHost(options);
    const read = host.readFile.bind(host);
    const exists = host.fileExists.bind(host);
    host.readFile = file => path.resolve(file) === filename ? source : read(file);
    host.fileExists = file => path.resolve(file) === filename || exists(file);
    const program = ts.createProgram([filename], options, host);
    const fixture = program.getSourceFile(filename)!;
    const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
    expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
  }, 30000);
});
