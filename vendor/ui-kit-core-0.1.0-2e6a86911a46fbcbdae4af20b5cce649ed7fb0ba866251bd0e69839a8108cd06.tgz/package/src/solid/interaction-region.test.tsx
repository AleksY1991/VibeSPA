/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { renderPrepared as render } from '../../tests/prepared';
import { createSignal, flush } from 'solid-js';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { InteractionRegion, type InteractionHandle } from './interaction-region';
import { Form } from './form';
import { TextField } from './text-field';
import { Button } from './button';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { HOTKEY_DELEGATE, HOTKEY_PASS } from '../contracts/platform';
import { authoredStyle, useStyles } from '../../tests/styles';

useStyles('selection.css');

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).forEach(dispose => dispose()); document.body.replaceChildren(); });

function keyboard() {
  disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
    commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
}

function enter(element: Element, init: KeyboardEventInit = {}) {
  const event = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, composed: true, cancelable: true, ...init });
  element.dispatchEvent(event);
  return event;
}

describe('InteractionRegion class', () => {
  it('outlines an explicitly highlighted composite around all independent actions', () => {
    const host = document.createElement('div'); document.body.append(host);
    const [highlighted, setHighlighted] = createSignal(true);
    disposers.push(render(() => {
      const item = constructItem('region.highlight', item => ({
        row: item.observe('row', () => ({ highlighted: highlighted() })),
        action: item.constant('action', {}),
      }));
      return <InteractionRegion.View observable={item.row} surface={{ kind: 'inherit' }} hotkeys={[]} role="option">
        <Button.View observable={item.action} surface={{ kind: 'inherit' }} hotkeys={[]}>Open node</Button.View>
        <Button.View observable={item.action} surface={{ kind: 'inherit' }} hotkeys={[]}>Show in graph</Button.View>
      </InteractionRegion.View>;
    }, host));
    flush();
    const region = host.querySelector('[role="option"]')!;
    expect(region.querySelectorAll('button')).toHaveLength(2);
    expect(authoredStyle(region, 'outline')).toContain('solid');
    expect(authoredStyle(region, 'outline')).toContain('var(--ui-line-width)');
    expect(authoredStyle(region, 'outline')).toContain('hsl(var(--ui-primary))');
    expect(authoredStyle(region, 'outline-offset')).toBe('calc(-1 * var(--ui-line-width))');
    expect(region.querySelector('[data-ui-highlighted]')).toBeNull();
    setHighlighted(false); flush();
    expect(region.hasAttribute('data-ui-highlighted')).toBe(false);
    expect(authoredStyle(region, 'outline')).toBe('');
  });

  it('does not publish a handle or measure a prepared region without a rendered host', () => {
    const host = document.createElement('div');
    const onHandle = vi.fn();
    const onSizeChange = vi.fn();
    disposers.push(render(() => {
      const observable = constructItem('region.deferredHost', item => item.constant('state', {}));
      new InteractionRegion({ observable, surface: { kind: 'inherit' }, hotkeys: [], onHandle, onSizeChange });
      return null;
    }, host));
    flush();
    expect(onHandle).not.toHaveBeenCalled();
    expect(onSizeChange).not.toHaveBeenCalled();
  });

  it('activates a focusable role-button on its own Enter while honoring disabled state and IME', () => {
    keyboard();
    const host = document.createElement('div'); document.body.append(host);
    const [disabled, setDisabled] = createSignal(false);
    const activate = vi.fn();
    disposers.push(render(() => {
      const observable = constructItem('region.enter', item => item.observe('state', () => ({ disabled: disabled() })));
      return <InteractionRegion.View observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]}
        role="button" tabindex={0} onActivate={activate}>Run</InteractionRegion.View>;
    }, host));
    const region = host.firstElementChild as HTMLElement;
    expect(enter(region).defaultPrevented).toBe(true);
    expect(activate).toHaveBeenCalledOnce();
    expect(activate.mock.calls[0][0]).toMatchObject({ ownTarget: true, detail: 0 });
    expect(enter(region, { isComposing: true }).defaultPrevented).toBe(false);
    setDisabled(true); flush();
    enter(region);
    expect(activate).toHaveBeenCalledOnce();
  });

  it.each([
    ['handled', undefined], ['native release', HOTKEY_PASS], ['owner delegation', HOTKEY_DELEGATE],
  ] as const)('preserves an explicit Enter policy: %s', (_name, result) => {
    keyboard();
    const host = document.createElement('div'); document.body.append(host);
    const activate = vi.fn(); const owner = vi.fn(); const explicit = vi.fn(() => result);
    disposers.push(render(() => {
      const observable = constructItem('region.explicitEnter', item => item.constant('state', {}));
      return <InteractionRegion.View observable={observable} surface={{ kind: 'inherit' }} hotkeys={[{ key: 'Enter', handler: owner }]}>
        <InteractionRegion.View observable={observable} surface={{ kind: 'own', name: 'explicit.region', transparent: false }}
          hotkeys={[{ key: 'Enter', handler: explicit }]} role="button" tabindex={0} onActivate={activate}>Run</InteractionRegion.View>
      </InteractionRegion.View>;
    }, host));
    enter(host.querySelector('[role="button"]')!);
    expect(explicit).toHaveBeenCalledOnce();
    expect(activate).not.toHaveBeenCalled();
    expect(owner).toHaveBeenCalledTimes(result === HOTKEY_DELEGATE ? 1 : 0);
  });

  it.each([true, false])('keeps native descendant Enter inside a Form (semantic region: %s)', async semantic => {
    keyboard();
    const host = document.createElement('div'); document.body.append(host);
    const activate = vi.fn(); const submit = vi.fn(intent => intent.preventDefault()); const button = vi.fn(); const outerEnter = vi.fn();
    disposers.push(render(() => {
      const states = constructItem('region.formEnter', item => ({ action: item.constant('action', {}), text: item.constant('text', '') }));
      return <InteractionRegion.View observable={states.action} surface={{ kind: 'inherit' }} hotkeys={[{ key: 'Enter', handler: outerEnter }]}>
        <Form.View observable={states.action} surface={{ kind: 'inherit' }} hotkeys={[]} onSubmit={submit}>
        <InteractionRegion.View observable={states.action} surface={{ kind: 'inherit' }} hotkeys={[]} role={semantic ? 'button' : undefined}
          tabindex={0} onActivate={activate}>
          <TextField.View observable={states.text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Text" onValueChange={() => {}} />
          <Button.View observable={states.action} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={button}>Nested action</Button.View>
        </InteractionRegion.View>
        <Button.View observable={states.action} surface={{ kind: 'inherit' }} hotkeys={[]} type="submit">Submit</Button.View>
        </Form.View>
      </InteractionRegion.View>;
    }, host));
    for (let pass = 0; pass < 36; pass++) { flush(); await Promise.resolve(); }
    const field = host.querySelector('wa-input')!.shadowRoot!.querySelector('input')!;
    expect(enter(field).defaultPrevented).toBe(false);
    expect(enter(host.querySelector('button')!).defaultPrevented).toBe(false);
    expect(activate).not.toHaveBeenCalled(); expect(button).not.toHaveBeenCalled(); expect(submit).not.toHaveBeenCalled();
    expect(outerEnter).not.toHaveBeenCalled();
    const region = host.querySelector('[tabindex="0"]')!;
    expect(enter(region).defaultPrevented).toBe(semantic);
    expect(activate).toHaveBeenCalledTimes(semantic ? 1 : 0);
    expect(submit).not.toHaveBeenCalled();
    expect(outerEnter).not.toHaveBeenCalled();
  });

  it('routes rich native activation and press gestures without adding a button', () => {
    const host = document.createElement('div'); document.body.append(host);
    const click = vi.fn(); const double = vi.fn(); const press = vi.fn(); const moved = vi.fn();
    disposers.push(render(() => {
      const observable = constructItem('region', item => item.constant('state', { ariaDisabled: 'false' as const }));
      return <InteractionRegion.View as="li" observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]}
        onActivate={click} onDoubleActivate={double} onPressStart={press} onPointerMove={moved}><span>Label</span></InteractionRegion.View>;
    }, host));
    const region = host.firstElementChild as HTMLElement;
    expect(region.localName).toBe('li');
    expect(region.hasAttribute('aria-disabled')).toBe(false);
    region.dispatchEvent(new MouseEvent('click', { bubbles: true, clientX: 10, clientY: 20 }));
    region.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, detail: 2, clientX: 30 }));
    region.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 4, clientX: 40 }));
    region.dispatchEvent(new PointerEvent('pointermove', { bubbles: true }));
    expect(click).toHaveBeenCalledOnce(); expect(click.mock.calls[0][0]).toMatchObject({ clientX: 10, clientY: 20, ownTarget: true });
    expect(double).toHaveBeenCalledOnce(); expect(double.mock.calls[0][0]).toMatchObject({ detail: 2, clientX: 30 });
    expect(press).toHaveBeenCalledOnce(); expect(press.mock.calls[0][0]).toMatchObject({ pointerId: 4, clientX: 40 });
    expect(moved).toHaveBeenCalledOnce();
  });

  it('recognizes native, ARIA and shadow controls without treating outer actions as children', () => {
    const host = document.createElement('div'); host.setAttribute('role', 'button'); document.body.append(host);
    const click = vi.fn();
    disposers.push(render(() => {
      const observable = constructItem('region.children', item => item.constant('state', {}));
      return <InteractionRegion.View observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]}
        onActivate={click}><span>Plain content</span></InteractionRegion.View>;
    }, host));
    const region = host.firstElementChild as HTMLElement;
    region.firstElementChild!.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
    expect(click).toHaveBeenLastCalledWith(expect.objectContaining({ targetIsInteractive: false }));
    const choice = document.createElement('div'); choice.setAttribute('role', 'checkbox'); region.append(choice);
    choice.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
    expect(click).toHaveBeenLastCalledWith(expect.objectContaining({ targetIsInteractive: true }));
    const shadowControl = document.createElement('div'); region.append(shadowControl);
    const button = document.createElement('button'); shadowControl.attachShadow({ mode: 'open' }).append(button);
    button.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
    expect(click).toHaveBeenLastCalledWith(expect.objectContaining({ targetIsInteractive: true, ownTarget: false }));
  });

  it('releases gesture capture and revokes retained gesture/region handles on disposal', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const pressed = vi.fn(); const activated = vi.fn();
    let savedHandle: InteractionHandle | undefined;
    const dispose = render(() => {
      const observable = constructItem('region.capture', item => item.constant('state', {}));
      return <InteractionRegion.View observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]}
        onPressStart={pressed} onActivate={activated} onHandle={handle => { if (handle) savedHandle = handle; }} />;
    }, host);
    disposers.push(dispose);
    await Promise.resolve(); flush(); await Promise.resolve();
    const region = host.firstElementChild as HTMLElement;
    const captured = new Set<number>();
    region.setPointerCapture = vi.fn(id => { captured.add(id); });
    region.hasPointerCapture = id => captured.has(id);
    region.releasePointerCapture = vi.fn(id => { captured.delete(id); });
    region.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 8 }));
    const gesture = pressed.mock.calls[0][0];
    gesture.capturePointer(); savedHandle!.capturePointer(9);
    expect(captured).toEqual(new Set([8, 9]));
    dispose();
    expect(captured.size).toBe(0);
    expect(region.releasePointerCapture).toHaveBeenCalledWith(8);
    expect(region.releasePointerCapture).toHaveBeenCalledWith(9);
    expect(() => gesture.capturePointer()).toThrow('disposed');
    expect(() => gesture.measure()).toThrow('disposed');
    expect(() => savedHandle!.capturePointer(10)).toThrow('disposed');
    document.body.append(region);
    region.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    region.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 8 }));
    expect(activated).not.toHaveBeenCalled(); expect(pressed).toHaveBeenCalledOnce();
  });
});
