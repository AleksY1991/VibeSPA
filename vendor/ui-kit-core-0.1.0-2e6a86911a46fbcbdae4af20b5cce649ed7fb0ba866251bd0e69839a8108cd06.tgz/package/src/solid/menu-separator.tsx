/** @jsxImportSource @solidjs/web */
import './menu-separator.css';

import { omit } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { RenderedElement } from '../infrastructure/rendered-element';
import { ElementBinding } from '../infrastructure/element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { cn } from '../lib/utils';
export interface MenuSeparatorProps extends Omit<JSX.HTMLAttributes<HTMLElement>, 'children' | 'ref' | 'hidden' | 'aria-hidden' | 'role' | 'aria-orientation' | 'onKeyDown' | 'onKeyUp' | 'onKeyPress'>, ElementConstruction<boolean> {
  
}

function renderMenuSeparator(props: MenuSeparatorProps) {
  const binding = new ElementBinding('MenuSeparator', props, { activeWhen: visible => visible, nativeKeys: [] });
  const attributes = omit(props, 'observable', 'surface', 'hotkeys', 'class');
  const Implementation = requireControlImplementation('Divider');
  return <Implementation attributes={attributes} class={cn(props.class)} hidden={!binding.value()} onElement={binding.attach} />;
}

export class MenuSeparator extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: MenuSeparatorProps) {
    super('MenuSeparator', props);
    this.element = renderMenuSeparator(this.capture(props));
  }
  static View = (props: MenuSeparatorProps): JSX.Element => new MenuSeparator(props).element;
}

export { MenuSeparator as Divider };
