// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createRoot, createSignal, flush } from 'solid-js';
import { constructItem } from '../infrastructure/construction';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { HOTKEY_PASS } from '../contracts/platform';
import { hotkeys as bindHotkeys } from '../runtime/hotkeys';
import type { ElementHotkey } from '../contracts/construction';
import { CaretInput, type CaretInputState } from './caret-input';

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); flush(); document.body.replaceChildren(); });

function fixture(hotkeys: readonly ElementHotkey[] = []) {
  const mount = document.createElement('div'); document.body.append(mount);
  const onSnapshot = vi.fn(); const onComposition = vi.fn(); const onBlur = vi.fn();
  const [state, setState] = createSignal<CaretInputState>({ disabled: false });
  let stop!: () => void;
  const input = createRoot(dispose => {
    stop = dispose; disposers.push(dispose);
    return constructItem('nativeText.test', item => new CaretInput({
      observable: item.observe('state', state), surface: { kind: 'own', name: 'nativeText.test', transparent: false },
      hotkeys, mount, label: 'Edit node label', onSnapshot, onComposition, onBlur,
    }));
  });
  flush();
  const native = mount.querySelector('textarea')!;
  return { input, native, mount, stop, setState, onSnapshot, onComposition, onBlur };
}

describe('CaretInput', () => {
  it('requires explicit printable overrides and leaves inherited typing to its native buffer', () => {
    expect(() => fixture([{ key: 'Shift+A', handler: vi.fn() }])).toThrow(/native-owned/);
    const parent = document.createElement('div'); document.body.append(parent);
    const typed = vi.fn();
    createRoot(dispose => {
      disposers.push(dispose);
      bindHotkeys({ name: 'caret.ancestor', transparent: false, keys: { A: typed, 'Shift+A': typed, Digit1: typed } })(parent);
      constructItem('caret.printable', item => new CaretInput({
        observable: item.constant('state', { disabled: false }), surface: { kind: 'inherit' }, hotkeys: [],
        mount: parent, label: 'Native text', onSnapshot: vi.fn(), onComposition: vi.fn(), onBlur: vi.fn(),
      }));
    });
    flush();
    disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
      runtime: () => ({ editing: false, keyboardLayer: null }) }));
    const native = parent.querySelector('textarea')!;
    for (const init of [{ key: 'a' }, { key: 'A', shiftKey: true }, { key: '1', code: 'Digit1' }]) {
      const event = new KeyboardEvent('keydown', { ...init, bubbles: true, cancelable: true });
      native.dispatchEvent(event); expect(event.defaultPrevented).toBe(false);
    }
    expect(typed).not.toHaveBeenCalled();
  });

  it('denies focus and session replacement outside the active global focus scope', () => {
    const { input, native, onBlur } = fixture();
    input.handle.begin({ value: 'retained', selectionStart: 0, selectionEnd: 0 });
    const focus = vi.spyOn(native, 'focus'); focus.mockClear();
    const blocker = document.createElement('div'); document.body.append(blocker);
    let dismiss!: () => void;
    createRoot(dispose => {
      dismiss = dispose; disposers.push(dispose);
      bindHotkeys({ name: 'caret.blocker', transparent: false, layer: true, modal: true, keys: {} })(blocker);
    });
    flush();
    expect(input.handle.begin({ value: 'blocked', selectionStart: 0, selectionEnd: 0 })).toBe(false);
    input.handle.focus(); expect(focus).not.toHaveBeenCalled();
    input.handle.blur(); expect(onBlur).toHaveBeenCalledOnce();
    expect(input.handle.snapshot().value).toBe('retained');
    dismiss(); input.handle.focus(); expect(focus).toHaveBeenCalledOnce();
    input.handle.detach(); input.handle.focus(); expect(focus).toHaveBeenCalledOnce();
  });

  it('constructs before the host exists and reuses its native engine through repeated attachment', () => {
    const create = vi.spyOn(document, 'createElement');
    const input = createRoot(dispose => {
      disposers.push(dispose);
      return constructItem('caret.deferred', item => new CaretInput({
        observable: item.constant('state', { disabled: false }), surface: { kind: 'inherit' }, hotkeys: [],
        mount: { kind: 'deferred', document }, label: 'Deferred caret',
        onSnapshot: vi.fn(), onComposition: vi.fn(), onBlur: vi.fn(),
      }));
    });
    expect(document.querySelector('textarea')).toBeNull();
    const host = document.createElement('div'); document.body.append(host);
    input.handle.attach(host);
    const native = host.querySelector('textarea')!;
    input.handle.begin({ value: 'retained draft', selectionStart: 1, selectionEnd: 4 });
    for (let index = 0; index < 100; index++) {
      input.handle.detach(); expect(host.querySelector('textarea')).toBeNull();
      input.handle.attach(host); expect(host.querySelector('textarea')).toBe(native);
    }
    expect(input.handle.snapshot().value).toBe('retained draft');
    expect(create.mock.calls.filter(([tag]) => tag === 'textarea')).toHaveLength(1);
    create.mockRestore();
  });

  it('registers its surface only while the deferred engine is attached, including disabled attachment', () => {
    const input = createRoot(dispose => {
      disposers.push(dispose);
      return constructItem('caret.lease', item => new CaretInput({
        observable: item.constant('state', { disabled: true }),
        surface: { kind: 'own', name: 'caret.lease', transparent: false }, hotkeys: [],
        mount: { kind: 'deferred', document }, label: 'Deferred caret',
        onSnapshot: vi.fn(), onComposition: vi.fn(), onBlur: vi.fn(),
      }));
    });
    const leases = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'caret.lease');
    flush(); expect(leases()).toHaveLength(0);
    const host = document.createElement('div'); document.body.append(host);
    input.handle.attach(host); flush(); expect(leases()).toHaveLength(1);
    input.handle.detach(); flush(); expect(leases()).toHaveLength(0);
    input.handle.attach(host); flush(); expect(leases()).toHaveLength(1);
  });

  it('constructs one invisible native buffer and preserves it through state updates and edit sessions', () => {
    const { input, native, mount, setState } = fixture();
    const focused = vi.spyOn(native, 'focus'); const selected = vi.spyOn(native, 'setSelectionRange');
    expect(input.handle.begin({ value: 'abc', selectionStart: 0, selectionEnd: 2, selectionDirection: 'backward' })).toBe(true);
    expect(focused).toHaveBeenCalledWith({ preventScroll: true });
    expect(focused.mock.invocationCallOrder[0]).toBeLessThan(selected.mock.invocationCallOrder[0]);
    expect(input.handle.snapshot()).toEqual({ value: 'abc', selectionStart: 0, selectionEnd: 2, selectionDirection: 'backward' });
    native.value = 'browser-owned draft';
    const writeValue = vi.spyOn(native, 'value', 'set');
    setState({ disabled: true }); flush();
    expect(native.disabled).toBe(true);
    setState({ disabled: false }); flush();
    expect(native.value).toBe('browser-owned draft'); expect(writeValue).not.toHaveBeenCalled();
    for (let i = 0; i < 100; i++) input.handle.begin({ value: `edit ${i}`, selectionStart: 0, selectionEnd: 1 });
    expect(mount.querySelectorAll('textarea')).toHaveLength(1);
    expect(mount.querySelector('textarea')).toBe(native);
    input.handle.setCaretPosition({ x: 42, y: 81 });
    expect(native.style.left).toBe('42px'); expect(native.style.top).toBe('81px');
    expect(native.style.width).toBe('1px'); expect(native.style.height).toBe('1px');
    expect(native.style.opacity).toBe('0'); expect(native.style.pointerEvents).toBe('none');
    expect(native.style.display).not.toBe('none');
  });

  it('mirrors native events and reads clipboard changes after the browser default action', async () => {
    const { input, native, onSnapshot, onComposition, onBlur } = fixture();
    input.handle.begin({ value: 'a', selectionStart: 1, selectionEnd: 1 });
    onSnapshot.mockClear();
    native.dispatchEvent(new Event('input')); native.dispatchEvent(new Event('keyup')); native.dispatchEvent(new Event('select'));
    expect(onSnapshot.mock.calls.map(call => call[1])).toEqual(['input', 'keyup', 'select']);
    native.dispatchEvent(new Event('paste'));
    native.value = 'pasted'; native.setSelectionRange(6, 6);
    await Promise.resolve();
    expect(onSnapshot).toHaveBeenLastCalledWith(expect.objectContaining({ value: 'pasted', selectionStart: 6 }), 'paste');
    native.dispatchEvent(new Event('cut')); native.value = ''; await Promise.resolve();
    expect(onSnapshot).toHaveBeenLastCalledWith(expect.objectContaining({ value: '' }), 'cut');
    for (const phase of ['start', 'update', 'end']) {
      const event = new CompositionEvent(`composition${phase}`);
      Object.defineProperty(event, 'data', { value: '字' });
      native.dispatchEvent(event);
    }
    expect(onComposition.mock.calls.map(call => [call[0], call[1]])).toEqual([['start', '字'], ['update', '字'], ['end', '字']]);
    input.handle.blur(); expect(onBlur).toHaveBeenCalledOnce();
  });

  it('removes its listeners and cancels pending clipboard delivery when its owner ends', async () => {
    const { input, native, mount, stop, onSnapshot, onComposition, onBlur } = fixture();
    native.dispatchEvent(new Event('paste')); stop();
    native.dispatchEvent(new Event('input')); native.dispatchEvent(new Event('blur'));
    native.dispatchEvent(new CompositionEvent('compositionend'));
    await Promise.resolve();
    expect(mount.querySelector('textarea')).toBeNull();
    expect(onSnapshot).not.toHaveBeenCalled(); expect(onComposition).not.toHaveBeenCalled(); expect(onBlur).not.toHaveBeenCalled();
    expect(input.handle.begin({ value: 'obsolete', selectionStart: 0, selectionEnd: 0 })).toBe(false);
  });

  it('does not deliver an earlier clipboard action into a replacement or detached edit', async () => {
    const { input, native, mount, onSnapshot } = fixture();
    input.handle.begin({ value: 'First task', selectionStart: 0, selectionEnd: 0 });
    native.dispatchEvent(new Event('paste'));
    input.handle.begin({ value: 'Second task', selectionStart: 0, selectionEnd: 0 });
    await Promise.resolve();
    expect(onSnapshot.mock.calls.filter(call => call[1] === 'paste')).toEqual([]);
    native.dispatchEvent(new Event('cut'));
    input.handle.detach(); input.handle.attach(mount);
    await Promise.resolve();
    expect(onSnapshot.mock.calls.filter(call => call[1] === 'cut')).toEqual([]);
    expect(input.handle.snapshot().value).toBe('Second task');
    native.dispatchEvent(new Event('paste')); native.value = 'Current paste';
    await Promise.resolve();
    expect(onSnapshot).toHaveBeenLastCalledWith(expect.objectContaining({ value: 'Current paste' }), 'paste');
  });

  it('reads the latest settled disabled state before focus or session replacement', () => {
    const { input, native, setState } = fixture();
    input.handle.begin({ value: 'kept', selectionStart: 0, selectionEnd: 0 }); input.handle.blur();
    setState({ disabled: true });
    expect(native.disabled).toBe(false);
    flush();
    expect(input.handle.begin({ value: 'discarded', selectionStart: 0, selectionEnd: 0 })).toBe(false);
    input.handle.focus(); expect(document.activeElement).not.toBe(native);
    expect(input.handle.snapshot().value).toBe('kept');
  });

  it('routes declared overrides through the dispatcher while preserving native chords and IME', () => {
    const commit = vi.fn(); const pass = vi.fn(() => HOTKEY_PASS);
    const { input, native } = fixture([
      { key: 'Enter', handler: commit, overrideNative: true },
      { key: 'ArrowUp', handler: pass, overrideNative: true },
    ]);
    disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
      runtime: () => ({ editing: true, keyboardLayer: null }) }));
    input.handle.begin({ value: 'abc', selectionStart: 1, selectionEnd: 1 });
    const press = (key: string, options: KeyboardEventInit = {}) => {
      const event = new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true, ...options });
      native.dispatchEvent(event); return event;
    };
    expect(press('Enter').defaultPrevented).toBe(true); expect(commit).toHaveBeenCalledOnce();
    expect(press('ArrowUp').defaultPrevented).toBe(false); expect(pass).toHaveBeenCalledOnce();
    expect(press('ArrowLeft', { ctrlKey: true }).defaultPrevented).toBe(false);
    expect(press('Enter', { isComposing: true }).defaultPrevented).toBe(false);
    expect(commit).toHaveBeenCalledOnce();
  });
});
