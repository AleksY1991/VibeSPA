/** @jsxImportSource @solidjs/web */
import type { JSX } from '@solidjs/web';
import { XIcon } from '../icons';
import type { ElementConstruction } from '../contracts/construction';
import type { TagControlProps, TagState } from '../contracts/tag';
import { constructItem } from '../infrastructure/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { Button } from './button';
import './tag.css';

export interface TagProps extends Omit<TagControlProps, 'children' | 'onElement'>, ElementConstruction<TagState> {
  
  readonly onRemove: () => void;
}

function renderTag(props: TagProps) {
  const binding = new ElementBinding('Tag', props, { nativeKeys: ['Enter', 'Space'], enabledWhen: state => !state.disabled });
  const remove = constructItem('tag.remove', item => item.observe('state', () => ({ disabled: binding.value().disabled }),
    { equals: (a, b) => a.disabled === b.disabled }));
  const Implementation = requireControlImplementation('Tag');
  // WA 3.12's built-in remove action is tabindex=-1, has no contextual label prop,
  // and forces a system icon. Its public content slot lets the existing Button
  // own focus, Enter/Space, and a named Lucide action. Remove this composition
  // when with-remove exposes that keyboard/name/icon contract.
  return binding.provide(() => <Implementation class={props.class} textSize={props.textSize} onElement={binding.attach}>
    <span data-ui-tag-label="">{binding.value().label}</span>
    <Button.View observable={remove} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="ghost" size="compact" shape="icon" type="button"
      aria-label={binding.value().removeLabel} data-tip={binding.value().removeLabel}
      onActivate={event => { if (allowActivation(binding, event) && !binding.value().disabled) props.onRemove(); }}>
      <XIcon class="ui-tag-remove-icon" />
    </Button.View>
  </Implementation>, { nativeChildren: true });
}

export class Tag extends RenderedElement<TagState> {
  readonly element: JSX.Element;
  constructor(props: TagProps) {
    super('Tag', props);
    this.element = renderTag(this.capture(props));
  }
  static View = (props: TagProps): JSX.Element => new Tag(props).element;
}
