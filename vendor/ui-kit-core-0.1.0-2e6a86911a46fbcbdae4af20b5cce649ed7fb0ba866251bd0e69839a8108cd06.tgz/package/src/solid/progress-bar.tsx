/** @jsxImportSource @solidjs/web */
import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import type { ProgressBarControlProps } from '../contracts/progress';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import './progress-bar.css';

export interface ProgressBarProps extends Omit<ProgressBarControlProps, 'value' | 'onElement'>, ElementConstruction<number> { }

function renderProgressBar(props: ProgressBarProps) {
  const binding = new ElementBinding('ProgressBar', props, { nativeKeys: [] });
  const Implementation = requireControlImplementation('ProgressBar');
  return <Implementation {...props} value={binding.value()} onElement={element => binding.attach(element)} />;
}

export class ProgressBar extends RenderedElement<number> {
  readonly element: JSX.Element;
  constructor(props: ProgressBarProps) {
    super('ProgressBar', props);
    this.element = renderProgressBar(this.capture(props));
  }
  static View = (props: ProgressBarProps): JSX.Element => new ProgressBar(props).element;
}
