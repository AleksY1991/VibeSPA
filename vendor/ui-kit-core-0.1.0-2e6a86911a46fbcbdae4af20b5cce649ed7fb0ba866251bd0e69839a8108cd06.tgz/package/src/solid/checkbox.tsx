/** @jsxImportSource @solidjs/web */
import './checkbox.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { CheckboxControlProps } from '../contracts/checkbox';
import type { FocusHandle } from '../contracts/controls';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle } from '../infrastructure/activation';
import './control-geometry.css';

export interface CheckboxProps extends Omit<CheckboxControlProps, 'checked' | 'onElement'>, ElementConstruction<boolean> { }

function renderCheckbox(props: CheckboxProps) {
  const binding = new ElementBinding('Checkbox', props, {
    nativeKeys: ['Space'], enabledWhen: () => !props.disabled, nativeActivation: true,
  });
  const Implementation = requireControlImplementation('Checkbox');
  const change = (checked: boolean) => { if (allowActivation(binding)) props.onCheckedChange(checked); };
  const onHandle = (handle: FocusHandle | undefined) => props.onHandle?.(handle && guardFocusHandle(binding, handle));
  return <Implementation {...props} checked={binding.value()} onCheckedChange={change} onElement={element => binding.attach(element)} onHandle={onHandle} />;
}

export class Checkbox extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: CheckboxProps) {
    super('Checkbox', props);
    this.element = renderCheckbox(this.capture(props));
  }
  static View = (props: CheckboxProps): JSX.Element => new Checkbox(props).element;
}
