/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { constructItem } from '../infrastructure/construction';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { renderPrepared as render } from '../../tests/prepared';
import type { TextareaElement } from '../vendor/web-awesome/elements';
import { createSignal, flush } from 'solid-js';

import { Button } from './button';
import { Field, Input, Textarea } from './field';
import { ScrollArea } from './scroll-area';
import { authoredStyle, useStyles } from '../../tests/styles';

useStyles('solid/button.css', 'solid/field.css', 'solid/scroll-area.css');

afterEach(() => document.body.replaceChildren());
const settle = async () => { for (let n = 0; n < 36; n++) { flush(); await Promise.resolve(); } };

describe('Solid basic primitives', () => {
  it('keeps native button behavior and outer placement with owned appearance', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const clicked = vi.fn();
    const dispose = render(() => {
const binding0 = constructItem('test.Button', item => item.observe('state', () => ({})));
return ((
      <Button.View observable={binding0} surface={{ kind: 'inherit' }} hotkeys={[]} type="button" id="save-action" placement={{ width: '100%' }} onActivate={clicked}>
        Save
      </Button.View>
    )); }, host);

    const button = document.querySelector<HTMLButtonElement>('button')!;
    button.click();
    expect(clicked).toHaveBeenCalledOnce();
    expect(button.type).toBe('button');
    expect(button.id).toBe('save-action');
    expect(button.style.width).toBe('100%');
    expect(button.classList).toContain('ui-button');
    expect(button.classList).toContain('ui-button-dense');
    expect(button.className).not.toMatch(/focus(?:-visible)?:/);
    expect(button.className).not.toMatch(/hover:(?:bg|text)-/);
    dispose();
  });

  it('keeps icon ink scoped to ghost icon buttons', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
const binding1 = constructItem('test.Button', item => item.observe('state', () => ({})));
const binding2 = constructItem('test.Button', item => item.observe('state', () => ({})));
const binding3 = constructItem('test.Button', item => item.observe('state', () => ({})));
return ((
      <>
        <Button.View observable={binding1} surface={{ kind: 'inherit' }} hotkeys={[]} id="ghost-icon" variant="ghost" size="standard" shape="icon" aria-label="Open settings" />
        <Button.View observable={binding2} surface={{ kind: 'inherit' }} hotkeys={[]} id="ghost-label" variant="ghost">Settings</Button.View>
        <Button.View observable={binding3} surface={{ kind: 'inherit' }} hotkeys={[]} id="destructive-icon" variant="destructive" size="standard" shape="icon" aria-label="Delete" />
      </>
    )); }, host);

    const ink = (id: string) => authoredStyle(document.querySelector(id)!, 'color');
    expect(ink('#ghost-icon')).toBe('hsl(var(--ui-muted-foreground))');
    expect(ink('#ghost-label')).not.toBe(ink('#ghost-icon'));
    expect(ink('#destructive-icon')).not.toBe(ink('#ghost-icon'));
    dispose();
  });

  it('preserves label association, native input attributes, and error semantics', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
const binding4 = constructItem('test.Field', item => item.observe('label', () => ("Start time")));
const binding5 = constructItem('test.Input', item => item.observe('value', () => ('')));
return ((
      <Field.View observable={binding4} surface={{ kind: 'inherit' }} hotkeys={[]}  htmlFor="start-time" required error="Choose a valid time">
        <Input.View observable={binding5} surface={{ kind: 'inherit' }} hotkeys={[]} onValueChange={() => {}} id="start-time" type="time" class="solid-class" className="migration-class" />
      </Field.View>
    )); }, host);

    const input = document.querySelector<HTMLInputElement>('#start-time')!;
    expect(document.querySelector('label')?.htmlFor).toBe('start-time');
    expect(input.type).toBe('time');
    expect(input.classList).toContain('solid-class');
    expect(input.classList).toContain('migration-class');
    expect(input.classList).toContain('ui-native-field');
    expect(authoredStyle(input, 'font-size')).toBe('var(--ui-text-body)');
    expect(input.className).not.toMatch(/focus(?:-visible)?:/);
    expect(input.className).not.toMatch(/ring-/);
    expect(document.querySelector('[role="alert"]')?.textContent).toBe('Choose a valid time');
    dispose();
  });

  it('preserves multiline native editing and controlled values through the textarea facade', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const [value, setValue] = createSignal('Initial note');
    const dispose = render(() => {
const binding6 = constructItem('test.Textarea', item => item.observe('value', () => (value())));
return ((
      <Textarea.View observable={binding6} surface={{ kind: 'inherit' }} hotkeys={[]} id="notes" label="Notes" rows={4}  onValueChange={setValue} />
    )); }, host);

    await settle();
    const control = document.querySelector<TextareaElement>('wa-textarea#notes')!;
    const textarea = control.input;
    expect(control.rows).toBe(4);
    expect(textarea.value).toBe('Initial note');
    expect(textarea.getAttribute('aria-label')).toBe('Notes');
    textarea.value = 'First line\nSecond line';
    textarea.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true }));
    await settle();
    expect(value()).toBe('First line\nSecond line');
    setValue('Restored note'); await settle();
    expect(textarea.value).toBe('Restored note');
    dispose();
  });

  it('uses a native touch-scroll container with the requested semantic element', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const visible = constructItem('test.ScrollArea', item => item.constant('visible', true));
      return <ScrollArea.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
        as="main" orientation="both" fill class="solid-class" className="migration-class">
        Content
      </ScrollArea.View>;
    }, host);

    const area = document.querySelector('main')!;
    expect(getComputedStyle(area).overflow).toBe('auto');
    expect(getComputedStyle(area).minHeight).toBe('0px');
    expect(area.classList).toContain('solid-class');
    expect(area.classList).toContain('migration-class');
    dispose();
  });
});
