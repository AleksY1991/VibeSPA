/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, onCleanup, onSettled } from 'solid-js';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import type { Activation, FocusHandle } from '../contracts/controls';
import { Button } from './button';

const disposers: (() => void)[] = [];
const settle = async () => { flush(); await Promise.resolve(); flush(); };
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  document.body.replaceChildren();
});

function mount(view: () => JSX.Element) {
  const container = document.createElement('div');
  document.body.append(container);
  const dispose = render(view, container);
  disposers.push(dispose);
  return { container, dispose };
}

describe('canonical button contracts', () => {
  it('retains browser-owned external form submission and reset as its type and value change', async () => {
    const form = document.createElement('form');
    form.id = 'external-action-form';
    const input = document.createElement('input');
    input.defaultValue = 'saved';
    form.append(input);
    document.body.append(form);
    const submitted = vi.fn((event: SubmitEvent) => event.preventDefault());
    const reset = vi.fn();
    form.addEventListener('submit', submitted);
    form.addEventListener('reset', reset);
    const [type, setType] = createSignal<'button' | 'submit' | 'reset'>('button');
    const [value, setValue] = createSignal('save');
    const [cancel, setCancel] = createSignal(false);
    const activated = vi.fn((intent: Activation) => { if (cancel()) intent.preventDefault(); });
    const { container } = mount(() => {
      const state = constructItem('button.external-form', item => item.constant('state', {}));
      return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
        type={type()} form="external-action-form" name="intent" value={value()} onActivate={activated}>Apply</Button.View>;
    });
    const button = container.querySelector('button')!;
    expect(button.form).toBe(form);
    button.click();
    expect(submitted).not.toHaveBeenCalled();
    expect(reset).not.toHaveBeenCalled();
    setType('submit'); setValue('publish'); await settle();
    button.click();
    expect(submitted).toHaveBeenCalledOnce();
    expect(submitted.mock.calls[0][0].submitter).toBe(button);
    expect(button.name).toBe('intent');
    expect(button.value).toBe('publish');
    setCancel(true); await settle();
    button.click();
    expect(submitted).toHaveBeenCalledOnce();
    setType('reset'); await settle();
    input.value = 'draft';
    button.click();
    expect(reset).not.toHaveBeenCalled();
    expect(input.value).toBe('draft');
    setCancel(false); await settle();
    button.click();
    expect(reset).toHaveBeenCalledOnce();
    expect(input.value).toBe('saved');
    expect(activated).toHaveBeenCalledTimes(5);
    expect(container.querySelector('button')).toBe(button);
    expect(container.querySelector('wa-button')).toBeNull();
    expect(container.querySelector('[data-ui-form-submitter]')).toBeNull();
  });

  it('keeps external ARIA relationships, reactive semantics and focus on the same native element', async () => {
    const references = ['label', 'description', 'panel', 'details', 'error', 'next', 'owned', 'active'];
    for (const id of references) {
      const reference = document.createElement('span');
      reference.id = id;
      reference.textContent = id;
      document.body.append(reference);
    }
    const [referencesEnabled, setReferencesEnabled] = createSignal(true);
    const [selected, setSelected] = createSignal(false);
    const [role, setRole] = createSignal<'switch' | undefined>();
    const handles = vi.fn<(handle: FocusHandle | undefined) => void>();
    const mounted = vi.fn();
    const cleaned = vi.fn();
    const Label = () => {
      onSettled(mounted);
      onCleanup(cleaned);
      return <span data-label="">Choose</span>;
    };
    const { container } = mount(() => {
      const state = constructItem('button.aria-references', item => item.observe('state', () => ({
        pressed: selected(), expanded: selected(),
      })));
      return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
        role={role()} onHandle={handles} aria-label="Choose action"
        aria-checked={selected() ? 'true' : 'false'} aria-selected={selected() ? 'true' : 'false'}
        aria-labelledby={referencesEnabled() ? 'label' : undefined}
        aria-describedby={referencesEnabled() ? 'description' : undefined}
        aria-controls={referencesEnabled() ? 'panel' : undefined}
        aria-details={referencesEnabled() ? 'details' : undefined}
        aria-errormessage={referencesEnabled() ? 'error' : undefined}
        aria-flowto={referencesEnabled() ? 'next' : undefined}
        aria-owns={referencesEnabled() ? 'owned' : undefined}
        aria-activedescendant={referencesEnabled() ? 'active' : undefined}><Label /></Button.View>;
    });
    await settle();
    const button = container.querySelector('button')!;
    const label = button.querySelector('[data-label]');
    const handle = handles.mock.calls[0][0]!;
    handle.focus();
    expect(document.activeElement).toBe(button);
    const attributes = ['aria-labelledby', 'aria-describedby', 'aria-controls', 'aria-details',
      'aria-errormessage', 'aria-flowto', 'aria-owns', 'aria-activedescendant'];
    attributes.forEach((attribute, index) => expect(button.getAttribute(attribute)).toBe(references[index]));
    expect(button.getAttribute('aria-label')).toBe('Choose action');
    expect(button.getAttribute('aria-pressed')).toBe('false');
    setRole('switch'); setSelected(true); await settle();
    expect(button.getAttribute('role')).toBe('switch');
    for (const attribute of ['aria-pressed', 'aria-expanded', 'aria-checked', 'aria-selected']) {
      expect(button.getAttribute(attribute)).toBe('true');
    }
    expect(button.hasAttribute('data-ui-selected')).toBe(true);
    setReferencesEnabled(false); setRole(undefined); await settle();
    for (const attribute of attributes) expect(button.hasAttribute(attribute)).toBe(false);
    expect(button.hasAttribute('role')).toBe(false);
    expect(container.querySelector('button')).toBe(button);
    expect(button.querySelector('[data-label]')).toBe(label);
    expect(document.activeElement).toBe(button);
    expect(handles).toHaveBeenCalledOnce();
    expect(mounted).toHaveBeenCalledOnce();
    expect(cleaned).not.toHaveBeenCalled();
  });

  it('uses current activation and press callbacks and rejects events after disposal', async () => {
    const first = vi.fn<(intent: Activation) => void>();
    const second = vi.fn<(intent: Activation) => void>(intent => { intent.stopPropagation(); });
    const firstPress = vi.fn();
    const secondPress = vi.fn();
    const parent = vi.fn();
    const cleaned = vi.fn();
    const [activate, setActivate] = createSignal(() => first);
    const [press, setPress] = createSignal(() => firstPress);
    const { container, dispose } = mount(() => {
      const state = constructItem('button.current-callbacks', item => item.constant('state', {}));
      onCleanup(cleaned);
      return <div onClick={parent}><Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
        onActivate={activate()} onPressStart={press()}>Apply</Button.View></div>;
    });
    const button = container.querySelector('button')!;
    const pointer = () => button.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    pointer(); button.click();
    expect(firstPress).toHaveBeenCalledOnce();
    expect(first).toHaveBeenCalledOnce();
    expect(parent).toHaveBeenCalledOnce();
    setActivate(() => second); setPress(() => secondPress); await settle();
    pointer();
    button.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, shiftKey: true, ctrlKey: true }));
    expect(first).toHaveBeenCalledOnce();
    expect(firstPress).toHaveBeenCalledOnce();
    expect(secondPress).toHaveBeenCalledOnce();
    expect(second).toHaveBeenCalledOnce();
    expect(second.mock.calls[0][0]).toMatchObject({ shiftKey: true, ctrlKey: true, altKey: false, metaKey: false });
    expect(parent).toHaveBeenCalledOnce();
    dispose();
    document.body.append(button);
    pointer(); button.click();
    expect(secondPress).toHaveBeenCalledOnce();
    expect(second).toHaveBeenCalledOnce();
    expect(cleaned).toHaveBeenCalledOnce();
  });
});
