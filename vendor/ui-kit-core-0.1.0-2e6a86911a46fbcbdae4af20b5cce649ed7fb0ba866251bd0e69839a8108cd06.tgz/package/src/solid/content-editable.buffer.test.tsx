/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { Show, createSignal, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { attachDispatcher, surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ContentEditable, type ContentEditableHandle, type ContentEditableState } from './content-editable';

const cleanups: (() => void)[] = [];
afterEach(() => {
  cleanups.splice(0).reverse().forEach(cleanup => cleanup());
  document.body.replaceChildren(); vi.restoreAllMocks();
});
const settle = async () => {
  for (let index = 0; index < 8; index++) { await Promise.resolve(); flush(); }
};

async function mount(multiline: boolean, acceptDraft = false) {
  const container = document.createElement('div'); document.body.append(container);
  const [state, setState] = createSignal<ContentEditableState>({ text: 'Initial é 👩‍💻', editing: true });
  const [visible, setVisible] = createSignal(true);
  const changes = vi.fn(); const commits = vi.fn(); const cancels = vi.fn(); const blurs = vi.fn();
  let handle: ContentEditableHandle | undefined; let savedHandle: ContentEditableHandle | undefined;
  cleanups.push(render(() => {
    const observable = constructItem('inlineBuffer.test', item => item.observe('state', state));
    return <Show when={visible()}>
      <ContentEditable.View observable={observable} surface={{ kind: 'own', name: 'inlineBuffer.test', transparent: true }}
        hotkeys={[]} label="Task name" multiline={multiline} wrap={multiline} commitOnDispose
        onValueChange={value => {
          changes(value);
          if (acceptDraft) setState(previous => ({ ...previous, text: value }));
        }}
        onCommit={commits} onCancel={cancels} onBlur={blurs}
        onHandle={next => { handle = next; if (next) savedHandle = next; }} />
    </Show>;
  }, container));
  cleanups.push(attachDispatcher({ window, document, registry: surfaceRegistry,
    commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
  await settle();
  const input = container.querySelector<HTMLElement>('[contenteditable]')!;
  handle!.focus(); handle!.caretEnd();
  const type = (value: string, composing = false) => {
    input.innerText = value;
    input.dispatchEvent(new InputEvent('input', { bubbles: true, data: value, isComposing: composing }));
  };
  const key = (key: string, options: KeyboardEventInit = {}) => {
    const event = new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true, ...options });
    input.dispatchEvent(event); return event;
  };
  return { container, input, type, key, changes, commits, cancels, blurs, setState, setVisible,
    handle: () => handle!, savedHandle: () => savedHandle! };
}

describe.each([false, true])('inline browser buffer, multiline=%s', multiline => {
  it('applies clean writes synchronously and preserves the same element', async () => {
    const current = await mount(multiline);
    current.setState({ text: 'New clean é 👩‍💻', editing: true }); flush();
    current.handle().caretEnd();
    expect(current.input.textContent).toBe('New clean é 👩‍💻');
    expect(current.handle().getText()).toBe('New clean é 👩‍💻');
    expect(current.container.firstElementChild).toBe(current.input);
    expect(document.getSelection()?.isCollapsed).toBe(true);
  });

  it('retains a dirty draft and browser selection through stale echoes', async () => {
    const current = await mount(multiline);
    current.type('My draft');
    const range = document.createRange(); range.setStart(current.input.firstChild!, 2); range.setEnd(current.input.firstChild!, 5);
    document.getSelection()?.removeAllRanges(); document.getSelection()?.addRange(range);
    current.setState({ text: 'Old server echo', editing: true }); await settle();
    expect(current.handle().getText()).toBe('My draft');
    expect(document.getSelection()?.toString()).toBe(' dr');
    current.setState({ text: 'Rejected by controller', editing: false }); await settle();
    current.setState({ text: 'Next session', editing: true }); await settle();
    expect(current.input.textContent).toBe('Next session');
    expect(current.handle().getText()).toBe('Next session');
  });

  it('keeps a delayed accepted echo from replacing a newer browser draft', async () => {
    const current = await mount(multiline);
    current.type('First change');
    const accepted = Promise.resolve().then(() => current.setState({ text: 'First change', editing: true }));
    current.type('Second change'); await accepted; await settle();
    expect(current.handle().getText()).toBe('Second change');
    current.handle().blur(); expect(current.commits).toHaveBeenCalledExactlyOnceWith('Second change');
  });

  it.each([false, true])('saves final composition across deferred disposal with accepted draft=%s', async acceptDraft => {
    const current = await mount(multiline, acceptDraft);
    current.input.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    current.type('に', true);
    expect(current.key('Enter', { isComposing: true }).defaultPrevented).toBe(false);
    expect(current.key('Escape', { isComposing: true }).defaultPrevented).toBe(false);
    current.input.innerText = '日本';
    current.input.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: '日本' }));
    expect(current.changes).toHaveBeenLastCalledWith('日本');
    expect(current.handle().getText()).toBe('日本');
    current.setVisible(false); await Promise.resolve(); await settle();
    expect(current.commits).toHaveBeenCalledExactlyOnceWith('日本');
    expect(() => current.savedHandle().getText()).toThrow(/no longer available/);
    const count = current.changes.mock.calls.length; current.type('Late input');
    expect(current.changes).toHaveBeenCalledTimes(count);
  });

  it('replaces the full unpublished composition when a controller ends editing', async () => {
    const current = await mount(multiline);
    current.input.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    current.type('に', true); current.input.innerText = '日本';
    current.setState({ text: 'Saved', editing: false }); flush();
    expect(current.input.textContent).toBe('Saved');
    await settle(); expect(current.input.textContent).toBe('Saved');
  });

  it('cancels without saving on later disposal and leaves multiline Enter native', async () => {
    const current = await mount(multiline);
    current.type('Discard');
    if (multiline) expect(current.key('Enter').defaultPrevented).toBe(false);
    expect(current.key('Escape').defaultPrevented).toBe(true);
    current.setVisible(false); await settle();
    expect(current.cancels).toHaveBeenCalledOnce(); expect(current.commits).not.toHaveBeenCalled();
  });

  it('commits once across blur and subsequent deferred disposal', async () => {
    const current = await mount(multiline);
    current.type('Pending draft'); current.handle().blur();
    current.setVisible(false); await settle();
    expect(current.commits).toHaveBeenCalledExactlyOnceWith('Pending draft');
    expect(current.blurs).toHaveBeenCalledExactlyOnceWith('Pending draft');
  });
});
