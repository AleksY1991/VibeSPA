/** @jsxImportSource @solidjs/web */
import './controls.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle, guardNativeEvents } from '../infrastructure/activation';
import { bindSurfaceInteraction, type SurfaceInteraction } from '../infrastructure/surface-interaction';
import { createEffect, createSignal, onSettled, merge, untrack } from 'solid-js';

import { cn } from '../lib/utils';
import type { CardControlProps, ChoiceGroupControlProps, ToggleControlProps, FocusHandle } from '../contracts/controls';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { HOTKEY_PASS, type SurfaceHotkeyHandler } from '../contracts/platform';
import { assertControlPresentation, controlPlacement } from '../infrastructure/presentation';
import '../control-tokens.css';
import './choice-group.css';
import './control-geometry.css';

export interface ToggleProps extends Omit<ToggleControlProps, 'checked' | 'onElement'>, ElementConstruction<boolean> { }
export interface ChoiceGroupProps<T extends string = string> extends Omit<ChoiceGroupControlProps<T>, 'value' | 'onElement' | 'onNativeElement'>, ElementConstruction<T> { }
export interface SurfaceHandle extends FocusHandle {
  measure(): DOMRectReadOnly;
  contains(target: Node | null): boolean;
  isConnected(): boolean;
}
export type { CardRecipe } from '../contracts/controls';
export type CardProps = CardControlProps & ElementConstruction<boolean> & {
  readonly onHandle?: (handle: SurfaceHandle | undefined) => void;
  readonly interaction?: SurfaceInteraction;
  readonly onElement?: never;
};
function renderToggle(props: ToggleProps) {
  // Project rules can be temporarily unavailable while their explanation must
  // remain reachable by keyboard (DESIGN.md: explain disabled states). WA 3.12's
  // switch only exposes disabled, which removes its input from the tab order.
  // aria-disabled therefore keeps focus/description and the surface blocks just
  // the activation keys; available switches leave Space/arrows to the vendor.
  // Remove this guard if WA provides a focusable readonly switch with these keys.
  const readonlyKey: SurfaceHotkeyHandler = event => {
    if (!allowActivation(binding, event)) return;
    if (props['aria-disabled'] !== 'true') return HOTKEY_PASS;
    event.preventDefault();
    event.stopPropagation();
  };
  const binding = new ElementBinding('Toggle', props, {
    nativeKeys: ['Space', 'ArrowLeft', 'ArrowRight'],
    enabledWhen: () => !props.disabled && props['aria-disabled'] !== 'true',
    nativeActivation: true,
    builtins: { Space: readonlyKey, ArrowLeft: readonlyKey, ArrowRight: readonlyKey },
  });
  const Implementation = requireControlImplementation('Toggle');
  const change = (checked: boolean) => { if (allowActivation(binding)) props.onCheckedChange(checked); };
  const onHandle = (handle: FocusHandle | undefined) => props.onHandle?.(handle && guardFocusHandle(binding, handle));
  return <Implementation {...props} checked={binding.value()} onCheckedChange={change} onElement={element => binding.attach(element)} onHandle={onHandle} />;
}

function renderChoiceGroup<T extends string>(props: ChoiceGroupProps<T>) {
  // A choice row applies immediately, including when navigating to an endpoint
  // (DESIGN.md: One tap). WA 3.12/browser radios own arrows and Space but do not
  // provide Home/End. The surface adds endpoint selection rather than focus-only
  // movement so the visible choice and checked state cannot diverge. This adds
  // two library-owned keys; remove them if the vendor gains equivalent navigation.
  const edge = (last: boolean): SurfaceHotkeyHandler => (event, element) => {
    if (!allowActivation(binding, event)) return;
    if (props.disabled || element.hasAttribute('inert')) return HOTKEY_PASS;
    const enabled = props.options.filter(option => !option.disabled);
    const option = last ? enabled.at(-1) : enabled[0];
    if (!option) return HOTKEY_PASS;
    const target = [...element.querySelectorAll<HTMLElement>('[data-ui-choice-value]')]
      .find(node => node.getAttribute('data-ui-choice-value') === option.value);
    if (!target) return HOTKEY_PASS;
    event.preventDefault();
    target.focus();
    if (option.value !== props.observable.read()) props.onValueChange(option.value);
  };
  const binding = new ElementBinding('ChoiceGroup', props, {
    nativeKeys: ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space'],
    enabledWhen: () => !props.disabled,
    nativeActivation: true,
    builtins: { Home: edge(false), End: edge(true) },
  });
  const Implementation = requireControlImplementation('ChoiceGroup');
  // The vendor boundary emits strings; only declared domain choices reach the command.
  const change = (value: string) => {
    if (!allowActivation(binding)) return;
    const option = props.options.find(option => option.value === value);
    if (option && !option.disabled && !props.disabled && option.value !== binding.value()) props.onValueChange(option.value);
  };
  return binding.provide(() => <Implementation {...props} value={binding.value()} onValueChange={change}
    onElement={binding.attach} onNativeElement={binding.attachNative} />);
}

function NativeCard(props: Omit<CardControlProps, 'attributes'> & { readonly attributes: JSX.HTMLAttributes<HTMLElement> }) {
  // Card owns layout and surface lifetime, with no vendor-owned interactions.
  // A div supplies the same semantics for plain and surfaced variants without
  // adding a shadow body or moving retained editors when the variant changes.
  // Shared classes own the surface paint and geometry (DESIGN.md).
  return <div {...props.attributes} ref={props.onElement} class={cardClass(props)}
    style={controlPlacement('Card', props.placement)}>{props.children}</div>;
}

function cardClass(props: Pick<CardControlProps, 'recipe' | 'tone'>): string {
  const recipe = props.recipe ?? 'plain';
  if (!['plain', 'content', 'panel', 'popover', 'notice'].includes(recipe)) throw new TypeError(`Card: unsupported recipe ${recipe}`);
  if (recipe !== 'notice' && props.tone !== undefined) throw new TypeError('Card: only the notice recipe carries a semantic tone');
  const tone = props.tone ?? 'default';
  if (recipe === 'notice' && !['default', 'success', 'warning', 'error'].includes(tone)) throw new TypeError(`Card: unsupported notice tone ${tone}`);
  return cn('ui-card-base', recipe !== 'plain' && 'ui-card-surface', `ui-card-${recipe}`,
    recipe === 'notice' && `ui-card-notice-${tone}`);
}

function renderCard(props: CardProps) {
  assertControlPresentation('Card', props);
  untrack(() => { cardClass(props); if (props.attributes) assertControlPresentation('Card attributes', props.attributes); });
  const [element, setElement] = createSignal<HTMLElement | undefined>(undefined, { ownedWrite: true });
  const [mounted, setMounted] = createSignal(false);
  const relatedRoots = () => {
    const host = element();
    return mounted() && host ? props.interaction?.relatedRoots?.(host) ?? [] : [];
  };
  const binding = new ElementBinding('Card', props, {
    active: () => props.observable.read(),
    activationRoots: relatedRoots,
    dismissable: () => !!props.interaction?.onOutsideDismiss,
  });
  bindSurfaceInteraction(binding, element, () => props.interaction, relatedRoots);
  onSettled(() => { setMounted(true); });
  const attach = (node: HTMLElement) => { binding.attach(node); setElement(node); };
  createEffect(() => [mounted(), element(), props.onHandle] as const, ([ready, node, callback]) => {
    if (!ready || !node || !callback) return;
    let active = true;
    const current = () => { if (!active) throw new Error('Surface handle has been disposed'); return node; };
    untrack(() => callback(guardFocusHandle(binding, Object.freeze({
      measure: () => current().getBoundingClientRect(),
      contains: (target: Node | null) => active && node.contains(target),
      isConnected: () => active && node.isConnected,
      focus: (options?: FocusOptions) => current().focus(options),
      blur: () => current().blur(),
    }))));
    return () => { active = false; untrack(() => callback(undefined)); };
  });
  const attributes = guardNativeEvents(binding, merge(() => {
    const attributes = props.attributes ?? {};
    assertControlPresentation('Card attributes', attributes);
    return attributes;
  }, {
    get hidden() { return !binding.value(); }, get 'aria-hidden'() { return !binding.value() ? 'true' as const : undefined; },
  }));
  return binding.provide(() => <NativeCard {...props} attributes={attributes} onElement={attach} />);
}

export class Card extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: CardProps) {
    super('Card', props);
    this.element = renderCard(this.capture(props));
  }
  static View = (props: CardProps): JSX.Element => new Card(props).element;
}

export class Toggle extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: ToggleProps) {
    super('Toggle', props);
    this.element = renderToggle(this.capture(props));
  }
  static View = (props: ToggleProps): JSX.Element => new Toggle(props).element;
}

export class ChoiceGroup<T extends string = string> extends RenderedElement<T> {
  readonly element: JSX.Element;
  constructor(props: ChoiceGroupProps<T>) {
    super('ChoiceGroup', props);
    this.element = renderChoiceGroup(this.capture(props));
  }
  static View = <Value extends string,>(props: ChoiceGroupProps<Value>): JSX.Element => new ChoiceGroup(props).element;
}
