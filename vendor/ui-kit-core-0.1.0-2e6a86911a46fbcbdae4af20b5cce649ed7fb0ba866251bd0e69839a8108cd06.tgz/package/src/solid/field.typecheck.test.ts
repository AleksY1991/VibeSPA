import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import type { InputProps, TextInputProps } from './field';
import type { ElementConstruction } from '../contracts/construction';
import type { TextFieldControlProps } from '../contracts/controls';
declare const construction: ElementConstruction<string>;
const text: InputProps = { ...construction, type: 'text', onValueChange: () => {},
  onHandle: handle => { handle?.select(); handle?.setSelectionRange(0, 2); } };
const time: InputProps = { ...construction, type: 'time', onValueChange: () => {} };
const timeField: TextFieldControlProps = { label: 'Time', value: '', type: 'time', onValueChange: () => {} };
const file: InputProps = { ...construction, type: 'file', onFilesChange: files => {},
  onHandle: handle => { handle?.open(); handle?.reset(); } };
// @ts-expect-error file type cannot pass through the legacy text signature
const mislabeled: TextInputProps = { ...construction, type: 'file', onValueChange: () => {} };
// @ts-expect-error file inputs require a file-selection write command
const wrongCommand: InputProps = { ...construction, type: 'file', onValueChange: () => {} };
function useHandle(props: InputProps) {
  if (props.type === 'file') {
    props.onHandle?.({ focus: () => {}, blur: () => {}, open: () => {}, reset: () => {} });
  } else {
    props.onHandle?.({ focus: () => {}, blur: () => {}, select: () => {},
      selection: () => ({ start: 0, end: 0 }), setSelectionRange: () => {} });
  }
}
${['date', 'datetime-local', 'month', 'week'].map((type, index) => `
// @ts-expect-error native calendars cannot bypass CalendarField/RangeCalendar through Input
const calendarInput${index}: InputProps = { ...construction, type: '${type}', onValueChange: () => {} };
// @ts-expect-error native calendars cannot bypass CalendarField/RangeCalendar through TextField
const calendarField${index}: TextFieldControlProps = { label: 'Date', value: '', type: '${type}', onValueChange: () => {} };
`).join('')}
`;

it('separates native file commands and rejects alternate calendar controls while keeping time editing', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/solid/__field_typecheck__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  host.readFile = file => path.resolve(file) === filename ? source : read(file);
  host.fileExists = file => path.resolve(file) === filename || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename);
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30000);
