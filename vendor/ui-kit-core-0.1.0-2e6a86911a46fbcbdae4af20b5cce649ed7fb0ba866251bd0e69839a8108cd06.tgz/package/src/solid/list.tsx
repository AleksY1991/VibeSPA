/** @jsxImportSource @solidjs/web */
import type { Accessor } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction, Observable } from '../contracts/construction';
import { ItemCollection } from '../infrastructure/construction';
import { RenderedElement } from '../infrastructure/rendered-element';

export interface ListProps<T> extends ElementConstruction<readonly T[]> {
  /** A collection has no DOM or keyboard surface; rows inherit their container. */
  readonly surface: { readonly kind: 'inherit' };
  readonly hotkeys: readonly [];
  readonly keyBy: (record: T) => string | number;
  /** Called once per mounted key. Read row.read() reactively, including commands. */
  readonly children: (row: Observable<T>, index: Accessor<number>) => JSX.Element;
  readonly fallback?: JSX.Element;
}

/** Collection composition owns row lifetime without adding layout or DOM.
 * Native/vendor controls supply individual elements; this boundary also supplies
 * validated record identity and current values across immutable replacements.
 * Solid owns row scopes and movement, so removal releases all child resources. */
export class List<T> extends RenderedElement<readonly T[]> {
  readonly element: JSX.Element;

  constructor(props: ListProps<T>) {
    super('List', props);
    if (props.surface.kind !== 'inherit' || props.hotkeys.length) {
      throw new TypeError('List inherits its container surface and cannot register hotkeys');
    }
    const captured = this.capture(props);
    const rows = ItemCollection.map('List.rows', captured.observable, captured.keyBy, captured.children);
    const content = () => {
      const content = rows();
      return content.length ? content : captured.fallback;
    };
    this.element = <>{content()}</>;
  }

  static View = <T,>(props: ListProps<T>): JSX.Element => new List(props).element;
}
