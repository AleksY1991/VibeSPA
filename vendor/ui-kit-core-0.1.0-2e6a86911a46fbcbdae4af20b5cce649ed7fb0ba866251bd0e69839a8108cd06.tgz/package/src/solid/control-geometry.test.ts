// @vitest-environment happy-dom
/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { parse } from 'postcss';
import { afterEach, describe, expect, it } from 'vitest';

const read = (file: string) => readFileSync(file, 'utf8').replace(/@import[^;]+;/g, '')
  // Happy DOM needs physical padding properties. Preserve custom-property names
  // such as --ui-control-padding-inline when translating logical declarations.
  .replace(/(?<![-\w])padding-inline:\s*([^;}]+)/g, 'padding-left: $1; padding-right: $1');
const reset = read('src/reset.css');
const tokens = read('src/control-tokens.css');
const geometry = read('src/solid/control-geometry.css');
const vendor = parse(readFileSync('src/vendor/web-awesome/text-field.css', 'utf8'));
const vendorPadding = () => {
  const selector = ':where([data-ui-root]) :is(wa-input[data-ui-text-field], wa-select[data-ui-select], wa-textarea[data-ui-textarea])';
  let value: string | undefined;
  vendor.walkRules(rule => {
    if (!rule.selectors.includes(selector)) return;
    rule.walkDecls('--wa-form-control-padding-inline', declaration => { value = declaration.value; });
  });
  return value;
};
const orders: [string, string[]][] = [
  ['reset first', [reset, tokens, geometry]],
  ['reset last', [tokens, geometry, reset]],
];

afterEach(() => {
  document.body.replaceChildren();
  document.querySelector('[data-control-geometry-test]')?.remove();
});

function install(sheets: string[]) {
  const style = document.createElement('style');
  style.dataset.controlGeometryTest = '';
  style.textContent = sheets.join('\n');
  document.head.append(style);
}

function padding(tag: string, className: string, size = 'compact') {
  const field = document.createElement(tag);
  field.className = className;
  field.dataset.uiRoot = '';
  field.dataset.uiControlSize = size;
  document.body.append(field);
  const style = getComputedStyle(field);
  return `${style.paddingLeft} ${style.paddingRight}`;
}

describe('canonical field inline padding', () => {
  it.each(orders)('keeps the shared size contract with %s', (order, sheets) => {
    install(sheets);
    for (const [size, inline] of [['dense', '4px'], ['compact', '8px'], ['standard', '12px'], ['large', '16px']]) {
      expect(padding('input', 'ui-native-field', size), `${order}: ${size} Input`).toBe(`${inline} ${inline}`);
      // Canonical WA fields consume this same size token through public parts.
      expect(vendorPadding()).toBe('var(--ui-control-padding-inline)');
    }
  });

});
