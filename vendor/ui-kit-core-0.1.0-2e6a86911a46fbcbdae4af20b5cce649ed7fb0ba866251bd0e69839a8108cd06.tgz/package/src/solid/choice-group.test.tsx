/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { createRoot, createSignal, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { hotkeys } from '../runtime/hotkeys';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeChoiceGroup } from '../vendor/web-awesome/controls.adapter';
import { ChoiceGroup } from './controls';

class RadioDouble extends HTMLElement { readonly updateComplete = Promise.resolve(true); }
class GroupDouble extends HTMLElement {
  readonly updateComplete = Promise.resolve(true);
  value = '';
  disabled = false;
}
beforeAll(() => {
  customElements.define('wa-radio', RadioDouble);
  customElements.define('wa-radio-group', GroupDouble);
});
const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });
const settle = async () => { for (let pass = 0; pass < 32; pass++) { flush(); await Promise.resolve(); } };
const options = [
  { value: 'unavailable', label: 'Unavailable', disabled: true },
  { value: 'priority', label: 'Priority', tip: 'Highest priority first' },
  { value: 'status', label: 'Status' },
] as const;
type Mode = typeof options[number]['value'];

function mount() {
  const host = document.createElement('div');
  document.body.append(host);
  const background = vi.fn();
  createRoot(dispose => {
    disposers.push(dispose);
    hotkeys({ name: 'choice.background', transparent: true, keys: { ArrowDown: background, Space: background, Home: background, End: background } })(host);
  });
  disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
  const [mode, setMode] = createSignal<Mode>('priority');
  const [disabled, setDisabled] = createSignal(false);
  const changed = vi.fn((value: Mode) => setMode(value));
  const implementation = { ChoiceGroup: WebAwesomeChoiceGroup };
  disposers.push(render(() => {
    const value = constructItem('choice.test', item => item.observe('mode', mode));
    return <ImplementationContext value={implementation}>
      <ChoiceGroup.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Sort tasks" labelPosition="hidden" options={options} disabled={disabled()} onValueChange={changed} />
    </ImplementationContext>;
  }, host));
  return { host, mode, setMode, setDisabled, changed, background };
}
function key(target: HTMLElement, value: string) {
  const event = new KeyboardEvent('keydown', { key: value, bubbles: true, composed: true, cancelable: true });
  target.dispatchEvent(event);
  return event;
}

describe('single-choice control contract', () => {
  it('owns Home/End while preserving vendor arrows and Space', async () => {
    const fixture = mount();
    await settle();
    const controls = [...fixture.host.querySelectorAll<HTMLElement>('[data-ui-choice-value]')];
    controls[1].focus();
    expect(key(controls[1], 'End').defaultPrevented).toBe(true);
    await settle();
    expect(fixture.mode()).toBe('status');
    expect(document.activeElement).toBe(controls[2]);
    expect(key(controls[2], 'Home').defaultPrevented).toBe(true);
    await settle();
    expect(fixture.mode()).toBe('priority');
    expect(document.activeElement).toBe(controls[1]);
    expect(fixture.changed.mock.calls.map(([value]) => value)).toEqual(['status', 'priority']);
    expect(key(controls[1], 'ArrowDown').defaultPrevented).toBe(false);
    expect(key(controls[1], ' ').defaultPrevented).toBe(false);
    expect(fixture.background).not.toHaveBeenCalled();
    fixture.setDisabled(true);
    await settle();
    key(controls[1], 'End');
    expect(fixture.changed).toHaveBeenCalledTimes(2);
  });

  it('keeps group choices controlled and group-local without repeated commands', async () => {
    const first = mount();
    const second = mount();
    await settle();
    const firstGroup = first.host.querySelector<GroupDouble>('wa-radio-group')!;
    const secondGroup = second.host.querySelector<GroupDouble>('wa-radio-group')!;
    const firstRadios = [...firstGroup.querySelectorAll<HTMLElement>('wa-radio')];
    expect(firstGroup.getAttribute('label')).toBe('Sort tasks');
    expect(firstRadios[0].hasAttribute('disabled')).toBe(true);
    firstGroup.value = 'status';
    firstGroup.dispatchEvent(new Event('change', { bubbles: true }));
    await settle();
    expect(first.mode()).toBe('status');
    expect(second.mode()).toBe('priority');
    expect(firstGroup.value).toBe('status');
    expect(secondGroup.value).toBe('priority');
    firstGroup.dispatchEvent(new Event('change', { bubbles: true }));
    expect(first.changed).toHaveBeenCalledOnce();
    first.setMode('priority');
    await settle();
    expect(firstGroup.value).toBe('priority');
  });

  // A visible row names each option; only a per-option hint can say what one does.
  it('carries a hint on the option that declares one, and on no other', async () => {
    const fixture = mount();
    await settle();
    const controls = [...fixture.host.querySelectorAll<HTMLElement>('[data-ui-choice-value]')];
    const tip = (control: HTMLElement) => (control.closest('[data-tip]') as HTMLElement | null)?.getAttribute('data-tip') ?? null;
    expect(controls.map(tip)).toEqual([null, 'Highest priority first', null]);
    // The hint never becomes the accessible name.
    expect(controls[1].getAttribute('aria-label')).toBeNull();
  });
});
