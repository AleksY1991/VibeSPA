/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { afterEach, beforeAll, expect, it } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeDivider } from '../vendor/web-awesome/divider.adapter';
import { MenuSeparator } from './menu-separator';

class DividerDouble extends HTMLElement {
  static update: () => Promise<boolean> = () => Promise.resolve(true);
  get updateComplete() { return DividerDouble.update(); }
}
const implementation = { Divider: WebAwesomeDivider };
const disposers: (() => void)[] = [];
const settle = async () => { for (let i = 0; i < 24; i++) { flush(); await Promise.resolve(); } };
beforeAll(() => customElements.define('wa-divider', DividerDouble));
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  DividerDouble.update = () => Promise.resolve(true);
  document.body.replaceChildren();
});

it('keeps one separator host and ties visibility and surface activity to its observable', async () => {
  const [visible, setVisible] = createSignal(true);
  const container = document.createElement('div'); document.body.append(container);
  disposers.push(render(() => {
    const model = constructItem('divider.visibility', item => item.observe('visible', visible));
    return <ImplementationContext value={implementation}><MenuSeparator.View observable={model}
      surface={{ kind: 'own', name: 'divider.visibility', transparent: true }} hotkeys={[]} id="section-divider" />
    </ImplementationContext>;
  }, container));
  await settle();
  const host = container.querySelector<DividerDouble>('wa-divider')!;
  const surfaces = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'divider.visibility');
  expect(host.getAttribute('role')).toBe('separator');
  expect(host.getAttribute('aria-orientation')).toBe('horizontal');
  expect(host.id).toBe('section-divider'); expect(host.hidden).toBe(false); expect(surfaces()).toHaveLength(1);
  setVisible(false); await settle();
  expect(container.querySelector('wa-divider')).toBe(host); expect(host.hidden).toBe(true); expect(surfaces()).toHaveLength(0);
  setVisible(true); await settle(); expect(host.hidden).toBe(false); expect(surfaces()).toHaveLength(1);
});

it('retains separator semantics on a failed host and releases its surface on disposal', async () => {
  DividerDouble.update = () => Promise.reject(new Error('Failed divider update'));
  const container = document.createElement('div'); document.body.append(container);
  const dispose = render(() => {
    const model = constructItem('divider.failure', item => item.constant('visible', true));
    return <ImplementationContext value={implementation}><MenuSeparator.View observable={model}
      surface={{ kind: 'own', name: 'divider.failure', transparent: true }} hotkeys={[]} />
    </ImplementationContext>;
  }, container);
  disposers.push(dispose); await settle();
  const host = container.querySelector('wa-divider')!;
  expect(host.hasAttribute('data-ui-ready')).toBe(false);
  expect(host.getAttribute('data-ui-error')).toBe('update-failed');
  expect(host.hasAttribute('inert')).toBe(false); expect(host.getAttribute('role')).toBe('separator');
  expect(container.querySelectorAll('[role="separator"]')).toHaveLength(1);
  expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'divider.failure')).toBe(true);
  dispose(); await settle();
  expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'divider.failure')).toBe(false);
});
