/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { FilePicker } from './file-picker';
import { useStyles } from '../../tests/styles';

useStyles('solid/file-picker.css');

const disposers: (() => void)[] = [];
const settle = async () => { for (let i = 0; i < 24; i++) { flush(); await Promise.resolve(); } };
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); vi.restoreAllMocks(); });
async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const dispose = render(view, container); disposers.push(dispose); await settle(); return { container, dispose };
}

describe('shared file picker', () => {
  it('uses a named action, keeps the engine hidden, and resets after an external selection clear', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture(); disposers.push(diagnostics.stop);
    const [file, setFile] = createSignal<File | null>(null);
    const { container } = await mount(() => {
      const selected = constructItem('file-picker.file', item => item.observe('file', file));
      return <FilePicker.View observable={selected} surface={{ kind: 'inherit' }} hotkeys={[]} label="Emoji image" accept="image/png,image/webp" onFileChange={setFile} />;
    });
    const trigger = container.querySelector('button')!;
    const input = container.querySelector<HTMLInputElement>('input[type="file"]')!;
    expect(trigger.getAttribute('aria-label')).toBe('Choose file: Emoji image');
    expect(input.hidden).toBe(true); expect(getComputedStyle(input).display).toBe('none'); expect(input.tabIndex).toBe(-1); expect(input.accept).toBe('image/png,image/webp');
    const open = vi.spyOn(input, 'click'); trigger.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    expect(open).toHaveBeenCalledOnce();
    const selected = new File(['png'], 'party.png', { type: 'image/png' });
    Object.defineProperty(input, 'files', { configurable: true, value: [selected] });
    input.dispatchEvent(new Event('change', { bubbles: true })); await settle();
    expect(container.querySelector('[role="status"]')?.textContent).toBe('party.png');
    setFile(null); await settle();
    expect(container.querySelector('[role="status"]')?.textContent).toBe('No file chosen'); expect(input.value).toBe('');
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });
  it('rejects disabled activation and change events and disposes its owned surface', async () => {
    const changed = vi.fn();
    const { container, dispose } = await mount(() => {
      const selected = constructItem('file-picker.disabled', item => item.constant<File | null>('file', null));
      return <FilePicker.View observable={selected}
        surface={{ kind: 'own', name: 'file-picker.disabled', transparent: true }} hotkeys={[]} label="Emoji image" disabled onFileChange={changed} />;
    });
    const input = container.querySelector<HTMLInputElement>('input[type="file"]')!;
    const open = vi.spyOn(input, 'click'); container.querySelector('button')!.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    expect(open).not.toHaveBeenCalled(); expect(changed).not.toHaveBeenCalled();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'file-picker.disabled')).toBe(true);
    dispose(); await settle();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'file-picker.disabled')).toBe(false);
  });

  it('clears the chooser after every selection so a rejected file can be selected again', async () => {
    const changed = vi.fn();
    const { container, dispose } = await mount(() => {
      const selected = constructItem('file-picker.retry', item => item.constant<File | null>('file', null));
      return <FilePicker.View observable={selected} surface={{ kind: 'inherit' }} hotkeys={[]} label="Attachment" onFileChange={changed} />;
    });
    const input = container.querySelector<HTMLInputElement>('input[type="file"]')!;
    const file = new File(['text'], 'retry.txt', { type: 'text/plain' });
    const value = vi.spyOn(input, 'value', 'set');
    Object.defineProperty(input, 'files', { configurable: true, value: [file] });
    for (let attempt = 0; attempt < 2; attempt++) {
      input.dispatchEvent(new Event('change', { bubbles: true })); await settle();
      expect(value).toHaveBeenLastCalledWith('');
    }
    expect(changed).toHaveBeenCalledTimes(2); expect(changed).toHaveBeenLastCalledWith(file);
    expect(container.querySelector('[role="status"]')?.textContent).toBe('No file chosen');
    dispose(); input.dispatchEvent(new Event('change', { bubbles: true }));
    expect(changed).toHaveBeenCalledTimes(2);
  });
});
