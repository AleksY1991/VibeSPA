/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { constructItem } from '../infrastructure/construction';
import { Image, type ImageState } from './image';

const disposers: (() => void)[] = [];
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  document.body.replaceChildren();
});

describe('Image construction', () => {
  it('retains the node, geometry and alternative while the registered source changes', () => {
    const host = document.createElement('div'); document.body.append(host);
    const [state, setState] = createSignal<ImageState>({ src: '/first.png' });
    let reads = 0;
    disposers.push(render(() => {
      const observable = constructItem('image.test', item => item.observe('source', state));
      return new Image({
        get observable() { reads++; return observable; },
        surface: { kind: 'inherit' }, hotkeys: [], alt: 'Smile', class: 'h-6 w-6 object-contain',
        width: 24, height: 24, style: { width: '24px' },
      }).element;
    }, host));
    const image = host.querySelector('img')!;
    expect(reads).toBe(1); expect(image.getAttribute('src')).toBe('/first.png');
    expect(image.alt).toBe('Smile'); expect(image.className).toBe('h-6 w-6 object-contain');
    expect(image.width).toBe(24); expect(image.height).toBe(24); expect(image.style.width).toBe('24px');
    setState({ src: '/second.png', srcset: '/second@2x.png 2x' }); flush();
    expect(host.firstElementChild).toBe(image); expect(reads).toBe(1);
    expect(image.getAttribute('src')).toBe('/second.png'); expect(image.srcset).toBe('/second@2x.png 2x');
    setState({ src: undefined }); flush();
    expect(image.hasAttribute('src')).toBe(false); expect(image.hasAttribute('srcset')).toBe(false);
  });

  it('exposes semantic load/error callbacks without leaking native events, and silences removed images', () => {
    const host = document.createElement('div'); document.body.append(host);
    const onError = vi.fn(); const onLoad = vi.fn();
    const dispose = render(() => {
      const observable = constructItem('image.events', item => item.constant('source', { src: '/emoji.png' }));
      return new Image({ observable, surface: { kind: 'inherit' }, hotkeys: [], alt: '', onError, onLoad }).element;
    }, host);
    disposers.push(dispose);
    const image = host.querySelector('img')!;
    image.dispatchEvent(new Event('error')); image.dispatchEvent(new Event('load'));
    expect(onError).toHaveBeenCalledExactlyOnceWith(); expect(onLoad).toHaveBeenCalledExactlyOnceWith();
    dispose(); image.dispatchEvent(new Event('error')); image.dispatchEvent(new Event('load'));
    expect(onError).toHaveBeenCalledOnce(); expect(onLoad).toHaveBeenCalledOnce();
  });
});
