/** @jsxImportSource @solidjs/web */
import { omit, onCleanup } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { RenderedElement } from '../infrastructure/rendered-element';

export interface ImageState {
  readonly src: string | undefined;
  readonly srcset?: string;
}

type ImagePresentation = Omit<JSX.ImgHTMLAttributes<HTMLImageElement>,
  'ref' | 'src' | 'srcset' | 'alt' | Extract<keyof JSX.ImgHTMLAttributes<HTMLImageElement>, `on${string}`>>;

export interface ImageProps extends ImagePresentation, ElementConstruction<ImageState> {
  /** Use an empty alternative for a decorative image. */
  readonly alt: string;
  readonly onError?: () => void;
  readonly onLoad?: () => void;
}

/**
 * WA Avatar and Image Comparer solve identity/comparison UI, not ordinary images.
 * A stable native img preserves srcset selection, lazy loading, decoding and alt
 * semantics without a wrapper that changes inline geometry. This boundary only
 * binds the source and silences load/error commands after its owner is disposed.
 */
export class Image extends RenderedElement<ImageState> {
  readonly element: JSX.Element;
  static View = (props: ImageProps): JSX.Element => new Image(props).element;

  constructor(props: ImageProps) {
    super('Image', props);
    this.element = this.render(this.capture(props));
  }

  private render(props: ImageProps): JSX.Element {
    const binding = new ElementBinding('Image', props);
    let active = true;
    onCleanup(() => { active = false; });
    const native = omit(props, 'observable', 'surface', 'hotkeys', 'onError', 'onLoad');
    return <img {...native} ref={binding.attach} src={binding.value().src} srcset={binding.value().srcset}
      onError={() => { if (active) props.onError?.(); }}
      onLoad={() => { if (active) props.onLoad?.(); }} />;
  }
}
