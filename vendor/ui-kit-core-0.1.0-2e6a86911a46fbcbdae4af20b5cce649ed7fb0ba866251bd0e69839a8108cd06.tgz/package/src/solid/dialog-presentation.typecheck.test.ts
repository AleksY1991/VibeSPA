/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import { Dialog, type DialogProps, type DialogDrawerState } from './dialog';
import type { Observable } from '../contracts/construction';
import { importedPaint, importedOverlayPaint, importedStyleProps } from './__dialog_imported_presentation__';
declare const construction: Pick<DialogProps, 'observable' | 'surface' | 'hotkeys'>;
const dialog: DialogProps = { ...construction, children: 'Content', onOpenChange: () => {} };
const small: DialogProps = { ...dialog, recipe: 'dialog', size: 'sm', placement: 'start' };
const editor: DialogProps = { ...construction, children: 'Editor', onOpenChange: () => {}, recipe: 'editor', size: 'md', placement: 'corner', contentLifetime: 'owner', modal: false };
const fullscreen: DialogProps = { ...construction, children: 'Full screen', onOpenChange: () => {}, recipe: 'fullscreen' };
const detached: DialogProps = { ...construction, children: 'Panels', onOpenChange: () => {}, recipe: 'detached' };
declare const drawerModel: Observable<DialogDrawerState>;
const form: DialogProps = { ...dialog, recipe: 'form', size: 'md' };
const media: DialogProps = { ...construction, children: 'Preview', onOpenChange: () => {}, recipe: 'media' };
const drawer: DialogProps = { ...construction, children: 'Panel', onOpenChange: () => {}, recipe: 'drawer', drawer: drawerModel };
const dockedDrawer: DialogProps = { ...drawer, dock: 'end' };
const large: DialogProps = { ...dialog, size: 'lg' };
const wide: DialogProps = { ...form, size: 'xl' };
const extraWide: DialogProps = { ...editor, size: '2xl' };
const behavior: DialogProps = { ...dialog, role: 'alertdialog', closeOnEscape: false, closeOnOutsidePointerDown: false, withoutHeader: false, preventScroll: false, trapFocus: false, initialFocus: () => undefined, restoreFocus: () => null, 'aria-label': 'Review', 'aria-describedby': 'review-description' };
new Dialog(small); new Dialog(editor); new Dialog(fullscreen); new Dialog(detached); new Dialog(behavior);
new Dialog(form); new Dialog(media); new Dialog(drawer);
new Dialog(dockedDrawer); new Dialog(large); new Dialog(wide); new Dialog(extraWide);
// @ts-expect-error docking belongs only to the drawer recipe
const dockedForm: DialogProps = { ...form, dock: 'end' };
// @ts-expect-error docking is a closed frame option rather than an arbitrary edge
const unsupportedDock: DialogProps = { ...drawer, dock: 'start' };
// @ts-expect-error a custom recipe cannot reopen independent style choices
const custom: DialogProps = { ...dialog, recipe: 'custom' };
// @ts-expect-error ordinary dialog sizes remain a closed scale
const width: DialogProps = { ...dialog, size: 'wide' };
// @ts-expect-error placement is a supported position, not arbitrary CSS
const position: DialogProps = { ...dialog, placement: 'bottom-right' };
// @ts-expect-error fullscreen geometry cannot also accept a bounded frame size
const fullscreenSize: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'fullscreen', size: 'sm' };
// @ts-expect-error fullscreen placement is owned by its recipe
const fullscreenPlacement: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'fullscreen', placement: 'corner' };
// @ts-expect-error detached panels occupy the viewport instead of a bounded width
const detachedSize: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'detached', size: 'md' };
// @ts-expect-error detached panel placement is not caller-controlled
const detachedPlacement: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'detached', placement: 'start' };
// @ts-expect-error media owns its preview width
const unsupportedMedia: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'media', size: 'sm' };
// @ts-expect-error the drawer requires its typed live panel model
const unconfiguredDrawer: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'drawer' };
// @ts-expect-error a copied width is not a registered panel model
const copiedDrawer: DialogProps = { ...construction, children: '', onOpenChange: () => {}, recipe: 'drawer', drawer: { width: 640 } };
// @ts-expect-error ordinary frames cannot acquire interactive drawer geometry
const drawerOnForm: DialogProps = { ...dialog, recipe: 'form', drawer: drawerModel };
// @ts-expect-error drawer positioning is owned by its panel model
const placedDrawer: DialogProps = { ...drawer, placement: 'corner' };
// @ts-expect-error no alternate paint policy
const standard: DialogProps = { ...dialog, visualStyle: 'standard' };
// @ts-expect-error variant has been replaced by the recipe contract
const variant: DialogProps = { ...dialog, variant: 'fullscreen' };
// @ts-expect-error recipe owns content layout
const layout: DialogProps = { ...dialog, layout: 'column' };
// @ts-expect-error recipe owns content padding
const padding: DialogProps = { ...dialog, padding: 'none' };
// @ts-expect-error recipe owns content gap
const gap: DialogProps = { ...dialog, gap: 'none' };
// @ts-expect-error recipe owns content height
const height: DialogProps = { ...dialog, height: 'viewport' };
// @ts-expect-error recipe owns clipping
const overflow: DialogProps = { ...dialog, overflow: 'hidden' };
// @ts-expect-error recipe owns its backdrop
const backdrop: DialogProps = { ...dialog, backdrop: 'transparent' };
// @ts-expect-error no pixel/string inset override
const blockStart: DialogProps = { ...dialog, blockStart: '60px' };
// @ts-expect-error viewport clearance belongs to the shared frame
const viewportInset: DialogProps = { ...dialog, viewportInset: 31 };
// @ts-expect-error no class escape
const className: DialogProps = { ...dialog, class: 'p-4' };
// @ts-expect-error no legacy class alias
const legacyClass: DialogProps = { ...dialog, className: 'p-4' };
// @ts-expect-error classList must not bypass the complete control
const classList: DialogProps = { ...dialog, classList: { rounded: true } };
// @ts-expect-error no arbitrary inline styling
const style: DialogProps = { ...dialog, style: { padding: '7px' } };
// @ts-expect-error no outer overlay class escape
const overlayClass: DialogProps = { ...dialog, overlayClass: 'p-4' };
// @ts-expect-error no legacy overlay class alias
const overlayClassName: DialogProps = { ...dialog, overlayClassName: 'p-4' };
const importedClass = { class: 'p-4' };
// @ts-expect-error an imported/spread object cannot bypass forbidden props
const spreadClass: DialogProps = { ...dialog, ...importedClass };
const importedAlias = { className: 'p-4' };
// @ts-expect-error a spread legacy alias is still rejected
new Dialog({ ...dialog, ...importedAlias });
const importedStyle = { style: { width: '777px' } };
// @ts-expect-error a placement-looking style object cannot hide arbitrary control styling
const spreadStyle: DialogProps = { ...dialog, ...importedStyle };
const importedClassList = { classList: { padded: true } };
// @ts-expect-error indirect classList is still an appearance escape
new Dialog({ ...dialog, ...importedClassList });
const importedOverlay = { overlayClass: 'unapproved-overlay' };
// @ts-expect-error indirect overlay styling is still rejected
const spreadOverlay: DialogProps = { ...dialog, ...importedOverlay };
const importedLayout = { layout: 'column' as const, padding: 'none' as const };
// @ts-expect-error removed knobs cannot hide in a reusable composition object
const spreadLayout: DialogProps = { ...dialog, ...importedLayout };
const mixedFullscreen = { ...fullscreen, placement: 'corner' as const };
// @ts-expect-error indirect construction still obeys the recipe's geometry constraints
new Dialog(mixedFullscreen);
// @ts-expect-error imported classes are not fresh literals, but must still be rejected
new Dialog({ ...dialog, ...importedPaint });
// @ts-expect-error imported overlay classes are not a presentation boundary escape
const importedOverlayProps: DialogProps = { ...dialog, ...importedOverlayPaint };
// @ts-expect-error importing a reusable inline-style object cannot restyle the control
new Dialog({ ...dialog, ...importedStyleProps });
`;

const importedSource = `
export const importedPaint = { class: 'p-4' };
export const importedOverlayPaint = { overlayClassName: 'unapproved-overlay' };
export const importedStyleProps = { style: { width: '777px' } };
`;

it('closes Dialog recipes and rejects direct, imported and spread presentation overrides', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/solid/__dialog_presentation_typecheck__.ts');
  const importedFilename = path.join(root, 'src/solid/__dialog_imported_presentation__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  const fixtures = new Map([[filename, source], [importedFilename, importedSource]]);
  host.readFile = file => fixtures.get(path.resolve(file)) ?? read(file);
  host.fileExists = file => fixtures.has(path.resolve(file)) || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30_000);
