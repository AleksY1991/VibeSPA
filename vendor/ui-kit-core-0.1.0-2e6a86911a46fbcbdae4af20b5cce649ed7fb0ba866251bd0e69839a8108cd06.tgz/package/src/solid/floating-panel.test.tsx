/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { Show, createRoot, createSignal, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { floatingPanel } from './floating-panel';

const cleanups: Array<() => void> = [];
afterEach(() => {
  cleanups.splice(0).reverse().forEach((cleanup) => cleanup());
  document.body.replaceChildren();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

function rectangle(left: number, top: number, width: number, height: number): DOMRect {
  return { left, top, width, height, right: left + width, bottom: top + height, x: left, y: top, toJSON: () => ({}) };
}

function observers() {
  const observed = new Set<Element>();
  let resize: () => void = () => {};
  let mutate: (target: Node) => void = () => {};
  const disconnectResize = vi.fn(() => observed.clear());
  const disconnectMutation = vi.fn();
  vi.stubGlobal('ResizeObserver', class implements ResizeObserver {
    constructor(callback: ResizeObserverCallback) { resize = () => callback([], this); }
    observe(target: Element) { observed.add(target); }
    unobserve(target: Element) { observed.delete(target); }
    disconnect = disconnectResize;
  });
  vi.stubGlobal('MutationObserver', class implements MutationObserver {
    constructor(callback: MutationCallback) {
      mutate = (target) => callback([{ target } as MutationRecord], this);
    }
    observe() {}
    disconnect = disconnectMutation;
    takeRecords() { return []; }
  });
  return { observed, resize: () => resize(), mutate: (target: Node) => mutate(target), disconnectResize, disconnectMutation };
}

describe('inline floating panel placement', () => {
  it('settles sibling panels sharing a layout root and still follows anchor changes', async () => {
    const Observer = MutationObserver;
    let deliveries = 0;
    vi.stubGlobal('MutationObserver', class extends Observer {
      constructor(callback: MutationCallback) {
        super((records, observer) => {
          // Bound the regression: a feedback loop must fail instead of starving
          // the test timeout with an endless chain of mutation microtasks.
          if (++deliveries >= 20) { observer.disconnect(); return; }
          callback(records, observer);
        });
      }
    });
    const toolbar = document.createElement('div');
    document.body.append(toolbar);
    let left = 40;
    const panels = [0, 1].map((index) => {
      const anchor = document.createElement('div');
      const panel = document.createElement('div');
      toolbar.append(anchor);
      anchor.append(panel);
      anchor.getBoundingClientRect = () => rectangle(left + index * 100, 24, 44, 44);
      panel.getBoundingClientRect = () => rectangle(0, 0, 80, 120);
      cleanups.push(createRoot(dispose => {
        floatingPanel({ strategy: 'fixed', align: 'start', layoutRoot: () => toolbar })(panel);
        return dispose;
      }));
      return panel;
    });
    flush();
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(deliveries).toBeLessThan(20);
    expect(panels.map(panel => panel.style.left)).toEqual(['40px', '140px']);

    left = 60;
    toolbar.setAttribute('class', 'wrapped');
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(deliveries).toBeLessThan(20);
    expect(panels.map(panel => panel.style.left)).toEqual(['60px', '160px']);
  });

  it('keeps fixed toolbar panels in viewport coordinates while the row scrolls', () => {
    observers();
    vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(390);
    vi.spyOn(window, 'innerHeight', 'get').mockReturnValue(844);
    const toolbar = document.createElement('div');
    const anchor = document.createElement('div');
    const panel = document.createElement('div');
    toolbar.append(anchor);
    anchor.append(panel);
    document.body.append(toolbar);
    let anchorBox = rectangle(310, 24, 44, 44);
    anchor.getBoundingClientRect = () => anchorBox;
    panel.getBoundingClientRect = () => rectangle(0, 0, 200, 120);
    Object.defineProperty(panel, 'offsetParent', { get: () => anchor });
    cleanups.push(createRoot(dispose => {
      floatingPanel({ strategy: 'fixed', align: 'start', offset: 8, layoutRoot: () => toolbar })(panel);
      return dispose;
    }));
    flush();
    expect(panel.style.position).toBe('fixed');
    expect(panel.style.left).toBe('174px');
    expect(panel.style.top).toBe('76px');
    expect(panel.parentElement).toBe(anchor);
    anchorBox = rectangle(40, 24, 44, 44);
    toolbar.dispatchEvent(new Event('scroll', { bubbles: false }));
    expect(panel.style.left).toBe('40px');
    expect(panel.style.top).toBe('76px');
  });
  it('keeps a tall menu below the full toolbar and scrolls in the remaining space after wrapping', () => {
    const watch = observers();
    vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(390);
    vi.spyOn(window, 'innerHeight', 'get').mockReturnValue(300);
    const toolbar = document.createElement('div');
    const trigger = document.createElement('div');
    const panel = document.createElement('div');
    toolbar.append(trigger);
    trigger.append(panel);
    document.body.append(toolbar);
    let toolbarBox = rectangle(24, 24, 342, 80);
    toolbar.getBoundingClientRect = () => toolbarBox;
    trigger.getBoundingClientRect = () => rectangle(24, 28, 36, 36);
    panel.getBoundingClientRect = () => rectangle(0, 0, 342,
      Math.min(1000, Number.parseFloat(panel.style.maxHeight)));
    Object.defineProperty(panel, 'offsetParent', { get: () => trigger });
    cleanups.push(createRoot((dispose) => {
      floatingPanel({ anchor: () => toolbar, side: 'bottom', offset: 8, constrainToSide: true })(panel);
      return dispose;
    }));
    flush();
    expect(Number.parseFloat(panel.style.top) + 28).toBe(112);
    expect(panel.style.maxHeight).toBe('172px');
    expect(panel.style.overflowY).toBe('auto');
    toolbarBox = rectangle(24, 24, 342, 160);
    watch.resize();
    expect(Number.parseFloat(panel.style.top) + 28).toBe(192);
    expect(panel.style.maxHeight).toBe('92px');
  });

  it('clamps the right edge, flips above and follows wrapping without changing DOM parentage', () => {
    const watch = observers();
    vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(390);
    vi.spyOn(window, 'innerHeight', 'get').mockReturnValue(300);
    const toolbar = document.createElement('div');
    const anchor = document.createElement('div');
    const panel = document.createElement('div');
    toolbar.append(anchor);
    anchor.append(panel);
    document.body.append(toolbar);
    let anchorBox = rectangle(310, 220, 64, 36);
    anchor.getBoundingClientRect = () => anchorBox;
    panel.getBoundingClientRect = () => rectangle(0, 0, 200, 100);
    Object.defineProperty(panel, 'offsetParent', { get: () => anchor });
    cleanups.push(createRoot((dispose) => {
      floatingPanel({ align: 'start', offset: 8, layoutRoot: () => toolbar })(panel);
      return dispose;
    }));
    flush();
    expect(panel.parentElement).toBe(anchor);
    expect(Number.parseFloat(panel.style.left) + anchorBox.left).toBe(174);
    expect(Number.parseFloat(panel.style.top) + anchorBox.top).toBe(112);
    expect(watch.observed.has(toolbar)).toBe(true);
    expect(watch.observed.has(panel)).toBe(true);

    anchorBox = rectangle(40, 100, 64, 36);
    watch.mutate(toolbar);
    expect(panel.style.left).toBe('0px');
    expect(panel.style.top).toBe('44px');

    anchorBox = rectangle(250, 100, 64, 36);
    watch.resize();
    expect(Number.parseFloat(panel.style.left) + anchorBox.left).toBe(174);
    expect(Number.parseFloat(panel.style.top) + anchorBox.top).toBe(144);
  });

  it('constrains oversized panels to the visible viewport and accounts for parent border and scroll', () => {
    observers();
    vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(240);
    vi.spyOn(window, 'innerHeight', 'get').mockReturnValue(200);
    const anchor = document.createElement('div');
    const panel = document.createElement('div');
    anchor.append(panel);
    document.body.append(anchor);
    anchor.getBoundingClientRect = () => rectangle(180, 20, 40, 36);
    panel.getBoundingClientRect = () => rectangle(0, 0,
      Math.min(500, Number.parseFloat(panel.style.maxWidth)),
      Math.min(500, Number.parseFloat(panel.style.maxHeight)));
    Object.defineProperties(anchor, {
      clientLeft: { value: 2 }, clientTop: { value: 3 },
      scrollLeft: { value: 5 }, scrollTop: { value: 7 },
    });
    Object.defineProperty(panel, 'offsetParent', { get: () => anchor });
    cleanups.push(createRoot((dispose) => { floatingPanel({ align: 'start' })(panel); return dispose; }));
    flush();
    expect(panel.style.maxWidth).toBe('208px');
    expect(panel.style.maxHeight).toBe('168px');
    expect(Number.parseFloat(panel.style.left) + 180 + 2 - 5).toBe(16);
    expect(Number.parseFloat(panel.style.top) + 20 + 3 - 7).toBe(16);
    expect(panel.style.overflowY).toBe('auto');
  });

  it('releases geometry observers and listeners when an open panel unmounts', () => {
    const watch = observers();
    const remove = vi.spyOn(window, 'removeEventListener');
    const [open, setOpen] = createSignal(true);
    const host = document.createElement('div');
    document.body.append(host);
    cleanups.push(render(() => <div>
      <Show when={open()}><div ref={floatingPanel()}>Choices</div></Show>
    </div>, host));
    flush();
    expect(watch.observed.size).toBeGreaterThan(0);
    setOpen(false);
    flush();
    expect(watch.disconnectResize).toHaveBeenCalledOnce();
    expect(watch.disconnectMutation).toHaveBeenCalledOnce();
    expect(remove).toHaveBeenCalledWith('resize', expect.any(Function));
    expect(remove).toHaveBeenCalledWith('scroll', expect.any(Function), true);
  });
});
