/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, expect, it, vi } from 'vitest';
import { createSignal, flush } from 'solid-js';
import { renderPrepared as render } from '../../tests/prepared';
import { useStyles } from '../../tests/styles';
import { constructItem } from '../infrastructure/construction';
import type { SelectRecipe, TextareaRecipe, TextFieldRecipe } from '../contracts/field-presentation';
import type { SelectElement, TextareaElement, TextFieldElement } from '../vendor/web-awesome/elements';
import { TextField } from './text-field';
import { Textarea } from './textarea';
import { Select } from './select';

useStyles('tokens.css', 'reset.css', 'control-tokens.css', 'vendor/web-awesome/text-field.css');

const settle = async () => { for (let cycle = 0; cycle < 48; cycle++) { flush(); await Promise.resolve(); } };
const disposers: (() => void)[] = [];
afterEach(() => { for (const dispose of disposers.splice(0)) dispose(); document.body.replaceChildren(); });

function container(): HTMLDivElement {
  const element = document.createElement('div');
  document.body.append(element);
  return element;
}

it('changes single-line editing roles without replacing the draft, selection or focus owner', async () => {
  const host = container();
  const attached = vi.fn();
  const [value, setValue] = createSignal('Draft search and title');
  const [recipe, setRecipe] = createSignal<TextFieldRecipe>('form');
  disposers.push(render(() => {
    const text = constructItem('field.roles.input', item => item.observe('text', value));
    return <TextField.View observable={text} surface={{ kind: 'inherit' }} hotkeys={[]}
      label="Editable name" size="standard" recipe={recipe()} onElement={attached} onValueChange={setValue} />;
  }, host));
  await settle();
  const field = host.querySelector<TextFieldElement>('wa-input')!;
  const input = field.input;
  input.focus(); input.setSelectionRange(2, 7);
  for (const next of ['entry', 'title', 'search-action', 'form'] as const) {
    setRecipe(next); await settle();
    expect(host.querySelector('wa-input')).toBe(field);
    expect(field.input).toBe(input);
    expect(field.getAttribute('data-ui-field-recipe')).toBe(next);
    expect(input.value).toBe('Draft search and title');
    expect([input.selectionStart, input.selectionEnd]).toEqual([2, 7]);
    expect(field.shadowRoot!.activeElement).toBe(input);
  }
  expect(attached).toHaveBeenCalledTimes(1);
  input.value = 'Continued draft';
  input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
  await settle();
  expect(value()).toBe('Continued draft');
});

it('changes writing roles without replacing the textarea or losing the in-progress edit', async () => {
  const host = container();
  const [value, setValue] = createSignal('Writing across recipes');
  const [recipe, setRecipe] = createSignal<TextareaRecipe>('form');
  disposers.push(render(() => {
    const text = constructItem('field.roles.textarea', item => item.observe('text', value));
    return <Textarea.View observable={text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Document"
      recipe={recipe()} size="compact" rows={1} resize="auto" maxHeight={130} onValueChange={setValue} />;
  }, host));
  await settle();
  const field = host.querySelector<TextareaElement>('wa-textarea')!;
  const input = field.input;
  input.focus(); input.setSelectionRange(1, 6);
  for (const next of ['entry', 'reading', 'compact-composer', 'composer', 'form'] as const) {
    setRecipe(next); await settle();
    expect(host.querySelector('wa-textarea')).toBe(field);
    expect(field.input).toBe(input);
    expect(field.getAttribute('data-ui-field-recipe')).toBe(next);
    expect(input.value).toBe('Writing across recipes');
    expect([input.selectionStart, input.selectionEnd]).toEqual([1, 6]);
    expect(field.shadowRoot!.activeElement).toBe(input);
    expect(field.hasAttribute('data-ui-auto-height')).toBe(true);
    expect(field.getAttribute('data-ui-max-height')).toBe('');
  }
  input.value = 'A retained edit';
  input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
  await settle();
  expect(value()).toBe('A retained edit');
});

it('changes select entry typography while retaining its options, selected value and focus target', async () => {
  const host = container();
  const [value, setValue] = createSignal('b');
  const [recipe, setRecipe] = createSignal<SelectRecipe>('form');
  const options = [{ value: 'a', label: 'Alpha' }, { value: 'b', label: 'Beta' }];
  disposers.push(render(() => {
    const selected = constructItem('field.roles.select', item => item.observe('choice', value));
    return <Select.View observable={selected} surface={{ kind: 'inherit' }} hotkeys={[]} label="Choice"
      options={options} recipe={recipe()} onValueChange={setValue} />;
  }, host));
  await settle();
  const field = host.querySelector<SelectElement>('wa-select')!;
  const input = field.displayInput;
  const option = field.querySelector('wa-option[value="b"]');
  input.focus();
  for (const next of ['entry', 'form'] as const) {
    setRecipe(next); await settle();
    expect(host.querySelector('wa-select')).toBe(field);
    expect(field.displayInput).toBe(input);
    expect(field.querySelector('wa-option[value="b"]')).toBe(option);
    expect(field.value).toBe('b');
    expect(field.getAttribute('data-ui-field-recipe')).toBe(next);
    expect(field.shadowRoot!.activeElement).toBe(input);
  }
});

it('owns entry, title and reading typography independently of application text', async () => {
  const host = container();
  host.style.cssText = 'font-size:30px;font-weight:900;font-family:fantasy;line-height:3';
  disposers.push(render(() => {
    const value = constructItem('field.roles.type', item => item.constant('text', 'A value'));
    return <>
      <TextField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Entry" recipe="entry" onValueChange={() => {}} />
      <TextField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Title" recipe="title" onValueChange={() => {}} />
      <Textarea.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Reading" recipe="reading" onValueChange={() => {}} />
      <Textarea.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Conversation" recipe="compact-composer" onValueChange={() => {}} />
      <Select.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Choice" recipe="entry"
        options={[{ value: 'A value', label: 'A value' }]} onValueChange={() => {}} />
    </>;
  }, host));
  await settle();
  for (const entry of host.querySelectorAll('[data-ui-field-recipe="entry"]')) {
    expect(getComputedStyle(entry).fontSize).toBe('16px');
    expect(getComputedStyle(entry).fontWeight).toBe('400');
    expect(getComputedStyle(entry).fontFamily).not.toContain('fantasy');
  }
  const title = getComputedStyle(host.querySelector('[data-ui-field-recipe="title"]')!);
  expect(title.fontSize).toBe('17px'); expect(title.fontWeight).toBe('600');
  const reading = getComputedStyle(host.querySelector('[data-ui-field-recipe="reading"]')!);
  expect(reading.fontSize).toBe('17px'); expect(reading.fontWeight).toBe('400');
  const conversation = getComputedStyle(host.querySelector('[data-ui-field-recipe="compact-composer"]')!);
  expect(conversation.fontSize).toBe('13px'); expect(conversation.lineHeight).toBe('20px');
});
