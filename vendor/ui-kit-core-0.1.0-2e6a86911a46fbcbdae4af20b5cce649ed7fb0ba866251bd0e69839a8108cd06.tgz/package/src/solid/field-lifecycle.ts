import './field-lifecycle.css';
import { createEffect, onSettled, untrack } from 'solid-js';
import type { InputFocusHandle, TextFieldControlProps } from '../contracts/controls';


interface Focusable { focus(options?: FocusOptions): void; blur(): void; }

const IMPLICIT_SUBMIT_TYPES = new Set(['text', 'search', 'url', 'tel', 'email', 'password', 'date', 'month', 'week', 'time', 'datetime-local', 'number']);

/** WA 3.12's submitOnEnter calls requestSubmit without activating the submit
 * button. Restore the browser's default-button click, including cancellation and
 * disabled-first-button behavior; remove when WA provides that native contract.
 * The app dispatcher can cancel first; editing and validation stay browser-owned. */
export function implicitFormSubmission(
  host: HTMLElement,
  input: () => HTMLInputElement,
  formOwner: () => HTMLFormElement | null,
  ready: () => boolean,
) {
  onSettled(() => {
    let active = true;
    const keydown = (event: KeyboardEvent) => {
      if (event.key !== 'Enter' || event.isComposing || event.keyCode === 229
        || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey
        || event.defaultPrevented || !event.composedPath().includes(input())) return;
      // Let the app's single dispatcher and ancestors cancel first. A vendor's
      // deferred implicit submission observes preventDefault before its timeout.
      queueMicrotask(() => {
        if (!active || !ready() || !host.isConnected || event.defaultPrevented
          || input().disabled || host.matches(':disabled')) return;
        const form = formOwner();
        if (!form) return;
        const controls = [...form.elements];
        const submitters = controls.filter((element): element is HTMLButtonElement | HTMLInputElement =>
          (element instanceof HTMLButtonElement || element instanceof HTMLInputElement)
          && (element.type === 'submit' || element.type === 'image'));
        const submitter = submitters[0];
        event.preventDefault();
        if (submitter) {
          // A native click preserves activation/cancellation before validation;
          // requestSubmit alone would skip the submit button's action intent.
          if (!submitter.matches(':disabled')) submitter.click();
          return;
        }
        const blocking = controls.filter(element => IMPLICIT_SUBMIT_TYPES.has(
          element instanceof HTMLInputElement ? element.type : element.getAttribute('data-ui-input-type') ?? '',
        )).length + (controls.includes(host) ? 0 : 1);
        if (blocking <= 1) form.requestSubmit();
      });
    };
    host.addEventListener('keydown', keydown);
    return () => { active = false; host.removeEventListener('keydown', keydown); };
  });
}

export function fieldAria(props: Pick<TextFieldControlProps,
  'role' | 'aria-activedescendant' | 'aria-autocomplete' | 'aria-controls'
  | 'aria-expanded' | 'aria-haspopup' | 'aria-invalid' | 'aria-labelledby'>) {
  return {
    role: props.role,
    'aria-activedescendant': props['aria-activedescendant'],
    'aria-autocomplete': props['aria-autocomplete'],
    'aria-controls': props['aria-controls'],
    'aria-expanded': props['aria-expanded'],
    'aria-haspopup': props['aria-haspopup'],
    'aria-invalid': props['aria-invalid'],
    'aria-labelledby': props['aria-labelledby'],
  };
}

/** Handles do not expose native/vendor nodes and are revoked with the control. */
export function fieldFocusHandle(
  target: () => Focusable,
  callback: () => ((handle: InputFocusHandle | undefined) => void) | undefined,
  isReady: () => boolean = () => true,
  select?: () => void,
  selectionTarget?: () => HTMLInputElement | HTMLTextAreaElement,
  settleSelection?: () => Promise<unknown>,
  writeSelection?: (start: number, end: number) => void,
) {
  let mounted = false;
  let publishCurrent = () => {};
  let revokeCurrent = () => {};
  createEffect(() => ({ ready: isReady(), publish: callback() }), ({ ready, publish }) => {
    if (!ready || !publish) { publishCurrent = () => {}; return; }
    let released = false;
    let published = false;
    const control = () => {
      if (!mounted || released) throw new Error('Text field handle is no longer available');
      return target();
    };
    const handle = Object.freeze({
      focus: (options?: FocusOptions) => control().focus(options),
      blur: () => control().blur(),
      select: () => { control(); select?.(); },
      selection: () => {
        control();
        if (!selectionTarget) throw new Error('This control does not support text selection');
        const field = selectionTarget();
        return { start: field.selectionStart ?? 0, end: field.selectionEnd ?? 0 };
      },
      setSelectionRange: (start: number, end: number) => {
        control();
        if (!selectionTarget) throw new Error('This control does not support text selection');
        const apply = () => {
          if (!mounted || released) return;
          if (writeSelection) writeSelection(start, end); else selectionTarget().setSelectionRange(start, end);
        };
        queueMicrotask(() => {
          if (!mounted || released) return;
          if (settleSelection) void settleSelection().then(apply, () => {}); else apply();
        });
      },
    });
    publishCurrent = () => {
      if (!mounted || released || published) return;
      published = true;
      untrack(() => publish(handle));
    };
    revokeCurrent = () => {
      if (released) return;
      released = true;
      if (published) untrack(() => publish(undefined));
    };
    publishCurrent();
    return revokeCurrent;
  });
  onSettled(() => {
    mounted = true;
    publishCurrent();
    return () => { mounted = false; revokeCurrent(); };
  });
}

/** Keep rejected input and selection correct even when Solid's value has not changed. */
export function normalizedInputValue(
  input: HTMLInputElement | HTMLTextAreaElement,
  normalize: ((value: string) => string) | undefined,
  composing = false,
): string {
  const value = input.value;
  const next = !composing && normalize ? normalize(value) : value;
  if (next !== value) {
    const start = input.selectionStart;
    const end = input.selectionEnd;
    input.value = next;
    if (start !== null && end !== null) {
      const delta = next.length - value.length;
      input.setSelectionRange(Math.max(0, start + delta), Math.max(0, end + delta));
    }
  }
  return next;
}
