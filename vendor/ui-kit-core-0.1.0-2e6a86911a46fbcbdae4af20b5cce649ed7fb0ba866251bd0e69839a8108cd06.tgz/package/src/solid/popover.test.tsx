/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createRoot, createSignal, onCleanup, type Accessor } from 'solid-js';
import { captureArtifact } from '@solidjs/diagnostics';
import { renderPrepared as render } from '../../tests/prepared';

import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { HOTKEY_PASS } from '../contracts/platform';
import { constructItem } from '../infrastructure/construction';
import { authoredStyle, useStyles } from '../../tests/styles';

import { Button } from './button';
import { Popover, type PopoverProps, type PopoverRecipe } from './popover';
import { ModalPortalContext, type ModalPortalScope } from './portal';

useStyles('solid/popover.css', 'vendor/web-awesome/surfaces.css');

const settle = async () => {
  for (let count = 0; count < 48; count++) await Promise.resolve();
};

const popoverState = (name: string, initial = false, change?: (open: boolean) => void) => {
  const [open, setOpen] = createSignal(initial);
  return constructItem(name, (item) => ({
    observable: item.observe('open', open),
    surface: { kind: 'own', name, transparent: false, layer: true } as const,
    hotkeys: [],
    onOpenChange: (next: boolean) => { change?.(next); setOpen(next); },
  }));
};

function modalScopeFixture(open: Accessor<boolean>) {
  const mount = document.createElement('dialog');
  mount.open = true;
  document.body.append(mount);
  const scope: ModalPortalScope = { mount, open };
  return { scope, mount };
}

let detachDispatcher: (() => void) | undefined;
beforeEach(() => {
  detachDispatcher = attachDispatcher({
    window,
    document,
    registry: surfaceRegistry,
    commands: { dispatch: () => {} },
    runtime: () => ({ editing: false, keyboardLayer: null }),
  });
});

afterEach(() => {
  detachDispatcher?.();
  detachDispatcher = undefined;
  document.body.replaceChildren();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('Solid Popover', () => {
  it('keeps repeated controlled action toggles free of source/lifetime relay tears', async () => {
    const [open, setOpen] = createSignal(false, { name: 'optionsOpen' });
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const state = constructItem('test.actions.repeated', item => ({
        open: item.observe('open', open),
        trigger: item.observe('trigger', () => ({ expanded: open() })),
        action: item.constant('action', {}),
      }));
      return <Popover.View observable={state.open}
        surface={{ kind: 'own', name: 'test.actions.repeated', transparent: false, layer: true }} hotkeys={[]}
        recipe="actions" onOpenChange={setOpen}
        trigger={api => <Button.View observable={state.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
          id="repeated-actions-trigger" aria-controls={api.contentId} onActivate={api.toggle}>Project actions</Button.View>}>
        {api => <Button.View observable={state.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="menu-item" id="repeated-action" onActivate={api.close}>Export project</Button.View>}
      </Popover.View>;
    }, host);
    try {
      await settle();
      const { artifact } = await captureArtifact(async () => {
        for (let count = 0; count < 6; count++) {
          host.querySelector<HTMLButtonElement>('#repeated-actions-trigger')!.click(); await settle();
          expect(document.activeElement?.id).toBe('repeated-action');
          document.querySelector<HTMLButtonElement>('#repeated-action')!.click(); await settle();
          expect(document.activeElement?.id).toBe('repeated-actions-trigger');
          expect(document.querySelector('[data-ui-popover]')).toBeNull();
        }
      }, { scenario: 'repeated-actions-open-and-completion' });
      expect(artifact.diagnostics.filter(event => event.code === 'EFFECT_RELAY_TEAR')).toEqual([]);
    } finally { dispose(); }
  });

  it('fits secondary actions to their content and focuses the first enabled command with native Tab behavior', async () => {
    const viewportWidth = vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(640);
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const construction = popoverState('test.actions');
      const controls = constructItem('test.actions.controls', item => ({
        trigger: item.observe('trigger', () => ({ expanded: construction.observable.read() })),
        disabled: item.constant('disabled', { disabled: true }),
        unavailable: item.constant('unavailable', { ariaDisabled: true }),
        action: item.constant('action', {}),
      }));
      return <Popover.View {...construction} recipe="actions" aria-label="Project actions"
        trigger={api => <Button.View observable={controls.trigger} surface={{ kind: 'inherit' }} hotkeys={[]}
          id="actions-trigger" variant="ghost" aria-haspopup="dialog" aria-controls={api.contentId} onActivate={api.toggle}>Project actions</Button.View>}>
        {api => <>
          <Button.View observable={controls.disabled} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="menu-item">Unavailable export</Button.View>
          <Button.View observable={controls.unavailable} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="menu-item">Export blocked by policy</Button.View>
          <Button.View observable={controls.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            id="first-action" recipe="menu-item" onActivate={api.close}>Export project</Button.View>
          <Button.View observable={controls.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="menu-item" onActivate={api.close}>Duplicate project</Button.View>
        </>}
      </Popover.View>;
    }, host);
    try {
      const trigger = host.querySelector<HTMLButtonElement>('#actions-trigger')!;
      trigger.getBoundingClientRect = () => ({ left: 32, right: 172, top: 24, bottom: 56,
        width: 140, height: 32, x: 32, y: 24, toJSON: () => ({}) });
      trigger.focus(); trigger.click(); await settle();
      const panel = document.querySelector<HTMLElement>('[data-ui-popover]')!;
      const content = panel.querySelector<HTMLElement>('[data-ui-surface-content]')!;
      const command = document.querySelector<HTMLButtonElement>('#first-action')!;
      expect(document.activeElement).toBe(command);
      expect(panel.shadowRoot?.querySelector('dialog')?.getAttribute('role')).toBe('dialog');
      expect(panel.shadowRoot?.querySelector('dialog')?.getAttribute('aria-label')).toBe('Project actions');
      expect(trigger.getAttribute('aria-expanded')).toBe('true');
      expect(panel.style.width).toBe('max-content');
      expect(panel.style.minWidth).toBe('140px');
      expect(panel.style.maxWidth).toBe('624px');
      expect(getComputedStyle(content).padding).toBe('4px');
      expect(getComputedStyle(content).display).toBe('grid');
      expect(getComputedStyle(content).overflow).toBe('auto');
      const tab = new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true });
      command.dispatchEvent(tab);
      expect(tab.defaultPrevented).toBe(false);
      const arrow = new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, cancelable: true });
      command.dispatchEvent(arrow);
      expect(arrow.defaultPrevented).toBe(false);
      viewportWidth.mockReturnValue(120);
      window.dispatchEvent(new Event('resize')); await settle();
      expect(panel.style.minWidth).toBe('104px');
      expect(panel.style.maxWidth).toBe('104px');
      command.click(); await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(document.activeElement).toBe(trigger);
      expect(trigger.getAttribute('aria-expanded')).toBe('false');
      expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.actions')).toHaveLength(0);
    } finally { dispose(); }
  });

  it.each(['selection', 'Escape'] as const)('returns focus inside its surviving parent after an actions %s close', async method => {
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const parent = popoverState('test.actions.parent');
      const child = popoverState('test.actions.child');
      return <Popover.View {...parent} trigger={api => <button id="parent-actions-trigger" onClick={api.toggle}>Project</button>}>
        {() => <Popover.View {...child} recipe="actions" aria-label="Project actions"
          trigger={api => <button id="child-actions-trigger" onClick={api.toggle}>Project actions</button>}>
          {api => <button id="nested-action" onClick={api.close}>Export project</button>}
        </Popover.View>}
      </Popover.View>;
    }, host);
    try {
      host.querySelector<HTMLButtonElement>('#parent-actions-trigger')!.click(); await settle();
      const trigger = document.querySelector<HTMLButtonElement>('#child-actions-trigger')!;
      trigger.focus(); trigger.click(); await settle();
      const action = document.querySelector<HTMLButtonElement>('#nested-action')!;
      expect(document.activeElement).toBe(action);
      if (method === 'selection') action.click();
      else action.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      await settle();
      expect(document.querySelector('#nested-action')).toBeNull();
      expect(document.activeElement).toBe(trigger);
      expect(document.querySelectorAll('[data-ui-popover]')).toHaveLength(1);
      expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.actions.parent')).toHaveLength(1);
    } finally { dispose(); }
  });

  it('leaves outside-pointer focus and explicit command destinations alone when actions close', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const outside = document.createElement('input'); document.body.append(outside);
    const dispose = render(() => {
      const construction = popoverState('test.actions.focusDestination');
      return <Popover.View {...construction} recipe="actions"
        trigger={api => <button id="destination-trigger" onClick={api.toggle}>Project actions</button>}>
        {api => <button id="destination-action" onClick={() => { api.close(); outside.focus(); }}>Open search</button>}
      </Popover.View>;
    }, host);
    try {
      const trigger = host.querySelector<HTMLButtonElement>('#destination-trigger')!;
      trigger.focus(); trigger.click(); await settle();
      expect(document.activeElement?.id).toBe('destination-action');
      outside.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
      outside.focus(); await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(document.activeElement).toBe(outside);
      trigger.focus(); trigger.click(); await settle();
      document.querySelector<HTMLButtonElement>('#destination-action')!.click(); await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(document.activeElement).toBe(outside);
    } finally { dispose(); }
  });

  it.each(['selection', 'Escape'] as const)('does not return action focus when its controlled owner refuses a %s close', async method => {
    const host = document.createElement('div'); document.body.append(host);
    const requests: boolean[] = [];
    const dispose = render(() => {
      const construction = popoverState('test.actions.controlled', true);
      return <Popover.View {...construction} recipe="actions" onOpenChange={next => requests.push(next)}
        trigger={api => <button id="controlled-action-trigger" onClick={api.toggle}>Project actions</button>}>
        {api => <button id="controlled-action" onClick={api.close}>Export project</button>}
      </Popover.View>;
    }, host);
    try {
      await settle();
      const action = document.querySelector<HTMLButtonElement>('#controlled-action')!;
      expect(document.activeElement).toBe(action);
      if (method === 'selection') action.click();
      else action.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      await settle();
      expect(requests).toEqual([false]);
      expect(document.querySelector('[data-ui-popover]')).not.toBeNull();
      expect(document.activeElement).toBe(action);
    } finally { dispose(); }
  });

  it.each(['selection', 'Escape'] as const)('returns action focus when the controlled owner later accepts a %s close', async method => {
    const [open, setOpen] = createSignal(true);
    const host = document.createElement('div'); document.body.append(host);
    const requests: boolean[] = [];
    let acceptClose: (() => void) | undefined;
    const dispose = render(() => {
      const observable = constructItem('test.actions.delayed', item => item.observe('open', open));
      return <Popover.View observable={observable}
        surface={{ kind: 'own', name: 'test.actions.delayed', transparent: false, layer: true }} hotkeys={[]}
        recipe="actions" onOpenChange={next => { requests.push(next); acceptClose = () => setOpen(next); }}
        trigger={api => <button id="delayed-action-trigger" onClick={api.toggle}>Project actions</button>}>
        {api => <button id="delayed-action" onClick={api.close}>Export project</button>}
      </Popover.View>;
    }, host);
    try {
      await settle();
      const trigger = host.querySelector<HTMLButtonElement>('#delayed-action-trigger')!;
      const action = document.querySelector<HTMLButtonElement>('#delayed-action')!;
      expect(document.activeElement).toBe(action);
      if (method === 'selection') action.click();
      else action.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      await settle();
      expect(requests).toEqual([false]);
      expect(document.activeElement).toBe(action);
      expect(document.querySelector('[data-ui-popover]')).not.toBeNull();
      acceptClose?.(); await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(document.activeElement).toBe(trigger);
    } finally { dispose(); }
  });

  it('waits for action readiness without stealing a later focus destination or focusing after disposal', async () => {
    const [ready, setReady] = createSignal(false);
    const host = document.createElement('div'); document.body.append(host);
    const outside = document.createElement('input'); document.body.append(outside);
    const dispose = render(() => {
      const construction = popoverState('test.actions.pending');
      return <Popover.View {...construction} recipe="actions"
        trigger={api => <button id="pending-actions-trigger" onClick={api.toggle}>Project actions</button>}>
        {api => <div data-ui-ready={ready() ? undefined : 'false'}>
          <button id="pending-action" onClick={api.close}>Export project</button>
        </div>}
      </Popover.View>;
    }, host);
    const trigger = host.querySelector<HTMLButtonElement>('#pending-actions-trigger')!;
    try {
      trigger.focus(); trigger.click(); await settle();
      expect(document.activeElement).toBe(trigger);
      setReady(true); await settle();
      expect(document.activeElement?.id).toBe('pending-action');
      document.querySelector<HTMLButtonElement>('#pending-action')!.click(); await settle();
      setReady(false); trigger.click(); await settle();
      outside.focus(); setReady(true); await settle();
      expect(document.activeElement).toBe(outside);
      trigger.click(); await settle();
      setReady(false); trigger.click(); await settle();
      outside.focus();
    } finally { dispose(); }
    setReady(true); await settle();
    expect(document.querySelector('[data-ui-popover]')).toBeNull();
    expect(document.activeElement).toBe(outside);
  });

  it('lets a successor action surface own focus after a command opens it', async () => {
    const [successorOpen, setSuccessorOpen] = createSignal(false);
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const construction = popoverState('test.actions.beforeSuccessor');
      const successor = constructItem('test.actions.successor', item => item.observe('open', successorOpen));
      return <>
        <Popover.View {...construction} recipe="actions"
          trigger={api => <button id="successor-opener" onClick={api.toggle}>Project actions</button>}>
          {api => <button id="open-successor" onClick={() => { api.close(); setSuccessorOpen(true); }}>Edit project</button>}
        </Popover.View>
        <Popover.View observable={successor} surface={{ kind: 'own', name: 'test.actions.successor', transparent: false, layer: true }} hotkeys={[]}
          recipe="actions" onOpenChange={setSuccessorOpen}
          trigger={api => <button onClick={api.toggle}>Edit actions</button>}>
          {() => <button id="successor-command">Rename project</button>}
        </Popover.View>
      </>;
    }, host);
    try {
      const trigger = host.querySelector<HTMLButtonElement>('#successor-opener')!;
      trigger.focus(); trigger.click(); await settle();
      document.querySelector<HTMLButtonElement>('#open-successor')!.click(); await settle();
      expect(document.activeElement?.id).toBe('successor-command');
      expect(document.querySelectorAll('[data-ui-popover]')).toHaveLength(1);
    } finally { dispose(); }
  });

  it('changes its complete recipe without replacing the popup, editing draft, focus, or surface lease', async () => {
    const [recipe, setRecipe] = createSignal<PopoverRecipe>('popover');
    const host = document.createElement('div'); document.body.append(host);
    const cleaned = vi.fn();
    let constructed = 0;
    const Draft = () => {
      constructed++;
      onCleanup(cleaned);
      return <input aria-label="Recipe draft" />;
    };
    const dispose = render(() => {
      const construction = popoverState('test.recipePopover', true);
      return <Popover.View {...construction} recipe={recipe()} aria-label="Editing choices"
        trigger={api => <button onClick={api.toggle}>Choose</button>}>
        {() => <Draft />}
      </Popover.View>;
    }, host);
    try {
      await settle();
      const panel = document.querySelector<HTMLElement>('[data-ui-popover]')!;
      const content = panel.querySelector<HTMLElement>('[data-ui-surface-content]')!;
      const input = content.querySelector<HTMLInputElement>('input')!;
      input.value = 'A retained editing draft';
      input.focus();
      input.setSelectionRange(2, 10);
      const profiles = [
        ['picker', '4px', 'grid', '288px'],
        ['content', '0px', 'block', '288px'],
        ['form', '8px', 'flex', '320px'],
        ['popover', '16px', 'block', '288px'],
      ] as const;
      for (const [next, padding, display, width] of profiles) {
        setRecipe(next); await settle();
        expect(document.querySelector('[data-ui-popover]')).toBe(panel);
        expect(content.querySelector('input')).toBe(input);
        expect(input.value).toBe('A retained editing draft');
        expect([input.selectionStart, input.selectionEnd]).toEqual([2, 10]);
        expect(document.activeElement).toBe(input);
        expect(getComputedStyle(panel).padding).toBe('0px');
        expect(getComputedStyle(content).padding).toBe(padding);
        expect(getComputedStyle(content).display).toBe(display);
        expect(getComputedStyle(panel).width).toBe(width);
        expect(panel.shadowRoot?.querySelector('dialog')?.getAttribute('aria-label')).toBe('Editing choices');
        expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.recipePopover')).toHaveLength(1);
        expect(constructed).toBe(1);
        expect(cleaned).not.toHaveBeenCalled();
      }
    } finally { dispose(); }
    expect(cleaned).toHaveBeenCalledTimes(1);
    expect(document.querySelector('[data-ui-popover]')).toBeNull();
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.recipePopover')).toHaveLength(0);
  });

  it.each(['class', 'className', 'style', 'style:padding', 'data-ui-popup'] as const)(
    'rejects a forged %s presentation escape before rendering a popup', key => {
      createRoot(dispose => {
        try {
          const construction = popoverState('test.forgedPresentation', true);
          const props = { ...construction, [key]: 'unapproved', trigger: () => 'Open', children: () => 'Content' } as unknown as PopoverProps;
          expect(() => new Popover(props)).toThrow(/presentation|closed/);
        } finally { dispose(); }
      });
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
    },
  );

  it('places retained trigger variants against the visible box through display contents', async () => {
    const [filled, setFilled] = createSignal(true);
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const popover = popoverState('test.retainedPlacement');
      return <Popover.View {...popover} trigger={api => <>
        <span id="filled-host" hidden={!filled()}><button id="filled-trigger" onClick={api.toggle}>Filled</button></span>
        <span id="empty-host" hidden={filled()} style="display: contents"><button id="empty-trigger" onClick={api.toggle}>Empty</button></span>
      </>}>{() => <button>Choice</button>}</Popover.View>;
    }, host);
    try {
      const filledHost = host.querySelector<HTMLElement>('#filled-host')!;
      const filledTrigger = host.querySelector<HTMLButtonElement>('#filled-trigger')!;
      const emptyTrigger = host.querySelector<HTMLButtonElement>('#empty-trigger')!;
      const rectangle = (left: number, width: number): DOMRect => ({ left, right: left + width, top: 40,
        bottom: 64, width, height: 24, x: left, y: 40, toJSON: () => ({}) });
      filledHost.getBoundingClientRect = () => rectangle(100, 100);
      filledTrigger.getBoundingClientRect = () => rectangle(120, 40);
      emptyTrigger.getBoundingClientRect = () => rectangle(420, 80);
      filledTrigger.click(); await settle();
      expect(document.querySelector<HTMLElement>('[data-ui-popover]')?.style.left).toBe('150px');
      filledTrigger.click(); await settle();
      setFilled(false); await settle();
      emptyTrigger.click(); await settle();
      expect(document.querySelector<HTMLElement>('[data-ui-popover]')?.style.left).toBe('460px');
      const choice = document.querySelector<HTMLButtonElement>('[data-ui-popover] button')!;
      choice.focus();
      choice.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(document.activeElement).toBe(emptyTrigger);
    } finally { dispose(); }
  });

  it('closes its body portal when a retained trigger host is hidden and does not reopen when shown', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const changes = vi.fn();
    const dispose = render(() => {
      const popover = popoverState('test.retainedHost', false, changes);
      const control = constructItem('popover.retainedControl', item => item.constant('state', {}));
      return <Popover.View {...popover} trigger={api => <Button.View observable={control}
        surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={api.toggle} id="retained-trigger">Choose</Button.View>}>
        {() => <input aria-label="Retained popup choice" />}
      </Popover.View>;
    }, host);
    try {
      const trigger = host.querySelector<HTMLButtonElement>('#retained-trigger')!;
      trigger.click(); await settle();
      expect(document.querySelector('[data-ui-popover]')).not.toBeNull();
      expect(host.querySelector('[data-ui-popover]')).toBeNull();
      host.hidden = true;
      await vi.waitFor(() => expect(document.querySelector('[data-ui-popover]')).toBeNull());
      expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.retainedHost')).toHaveLength(0);
      host.hidden = false;
      await new Promise(resolve => setTimeout(resolve, 0));
      await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(changes.mock.calls).toEqual([[true], [false]]);
      trigger.click(); await settle();
      expect(document.querySelector('[data-ui-popover]')).not.toBeNull();
    } finally { dispose(); }
  });

  it('allows its declared trigger to close the open popup while blocking unrelated controls', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const unrelated = vi.fn();
    const changes = vi.fn();
    const dispose = render(() => {
      const popover = popoverState('test.anchorActivation', false, changes);
      const control = constructItem('popover.activationControl', item => item.constant('state', {}));
      return <>
        <Button.View observable={control} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={unrelated} id="unrelated-action">Unrelated</Button.View>
        <Popover.View {...popover} trigger={api => <Button.View observable={control} surface={{ kind: 'inherit' }} hotkeys={[]}
          onActivate={api.toggle} id="related-trigger">Choose</Button.View>}>
          {() => <button>Choice</button>}
        </Popover.View>
      </>;
    }, host);
    try {
      const trigger = document.querySelector<HTMLButtonElement>('#related-trigger')!;
      trigger.click(); await settle();
      expect(document.querySelector('[data-ui-popover]')).not.toBeNull();
      document.querySelector<HTMLButtonElement>('#unrelated-action')!.click();
      expect(unrelated).not.toHaveBeenCalled();
      trigger.click(); await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(changes.mock.calls).toEqual([[true], [false]]);
    } finally { dispose(); }
  });

  it('keeps its portal and keyboard lifetime inside the parent modal without changing its own open state', async () => {
    const [parentOpen, setParentOpen] = createSignal(false);
    const modal = modalScopeFixture(parentOpen);
    const host = document.createElement('div');
    document.body.append(host);
    const change = vi.fn();
    const dispose = render(() => {
      const construction = popoverState('test.modalLifetime', true, change);
      return <ModalPortalContext value={modal.scope}>
        <Popover.View {...construction}
          trigger={api => <button id="modal-lifetime-trigger" onClick={api.toggle}>Choose</button>}>
          {() => <input aria-label="Modal choice" />}
        </Popover.View>
      </ModalPortalContext>;
    }, host);
    const surfaces = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.modalLifetime');
    await settle();
    expect(document.querySelector('[data-ui-popover]')).toBeNull();
    expect(surfaces()).toHaveLength(0);

    setParentOpen(true);
    await settle();
    const panel = modal.mount.querySelector<HTMLElement>('[data-ui-popover]')!;
    expect(panel).not.toBeNull();
    expect(getComputedStyle(panel).position).toBe('fixed');
    expect(getComputedStyle(panel).width).toBe('288px');
    expect(surfaces()).toHaveLength(1);

    setParentOpen(false);
    await settle();
    expect(document.querySelector('[data-ui-popover]')).toBeNull();
    expect(surfaces()).toHaveLength(0);
    expect(change).not.toHaveBeenCalled();

    setParentOpen(true);
    await settle();
    expect(modal.mount.querySelector('[data-ui-popover]')).not.toBeNull();
    expect(surfaces()).toHaveLength(1);
    dispose();
    expect(surfaces()).toHaveLength(0);
  });

  it.each(['builtin', 'pass', 'handled'] as const)('composes delegated native-modal Escape with its %s handler while focus stays on the trigger', async mode => {
    const modal = modalScopeFixture(() => true);
    const change = vi.fn();
    const custom = vi.fn(() => mode === 'pass' ? HOTKEY_PASS : undefined);
    const dispose = render(() => {
      const construction = popoverState('test.modalEscape', true, change);
      return <ModalPortalContext value={modal.scope}>
        <Popover.View {...construction}
          hotkeys={mode === 'builtin' ? [] : [{ key: 'Escape', handler: custom }]}
          trigger={api => <button id="modal-escape-trigger" onClick={api.toggle}>Choose</button>}>
          {() => <input aria-label="Modal choice" />}
        </Popover.View>
      </ModalPortalContext>;
    }, modal.mount);
    await settle();
    const trigger = modal.mount.querySelector<HTMLButtonElement>('#modal-escape-trigger')!;
    trigger.focus();
    const panel = modal.mount.querySelector<HTMLElement>('[data-ui-popover]')!;
    const escape = new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true });
    trigger.dispatchEvent(escape);
    await settle();
    expect(custom).toHaveBeenCalledTimes(mode === 'builtin' ? 0 : 1);
    if (mode !== 'builtin') expect(custom).toHaveBeenCalledWith(escape, panel);
    expect(change).toHaveBeenCalledTimes(mode === 'handled' ? 0 : 1);
    expect(modal.mount.querySelector('[data-ui-popover]') !== null).toBe(mode === 'handled');
    expect(document.activeElement).toBe(trigger);
    dispose();
  });

  it('retains a modal child and its Escape lease when the controlled close command refuses dismissal', async () => {
    const modal = modalScopeFixture(() => true);
    const change = vi.fn();
    const dispose = render(() => {
      const construction = popoverState('test.modalRefusal', true);
      return <ModalPortalContext value={modal.scope}>
        <Popover.View {...construction} onOpenChange={change}
          trigger={api => <button onClick={api.toggle}>Choose</button>}>
          {() => <input aria-label="Modal choice" />}
        </Popover.View>
      </ModalPortalContext>;
    }, modal.mount);
    await settle();
    modal.mount.querySelector('button')!.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
    await settle();
    expect(change).toHaveBeenCalledExactlyOnceWith(false);
    expect(modal.mount.querySelector('[data-ui-popover]')).not.toBeNull();
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.modalRefusal')).toHaveLength(1);
    dispose();
  });

  it('follows the visual viewport during keyboard/zoom movement and releases its listeners', async () => {
    const viewport = Object.assign(new EventTarget(), { width: 300, height: 300, offsetLeft: 40, offsetTop: 100 });
    vi.stubGlobal('visualViewport', viewport);
    const removed = vi.spyOn(viewport, 'removeEventListener');
    const added = vi.spyOn(viewport, 'addEventListener');
    const root = document.createElement('div');
    document.body.append(root);
    const dispose = render(() => {
      const construction = popoverState('test.visualViewport');
      return <Popover.View {...construction}
        fitContentWidth align="start" trigger={api => <button id="viewport-trigger" onClick={api.toggle}>Choose</button>}>
        {() => <button>Choice</button>}
      </Popover.View>;
    }, root);
    const trigger = root.querySelector<HTMLButtonElement>('#viewport-trigger')!;
    trigger.getBoundingClientRect = () => ({ left: 300, right: 340, top: 340, bottom: 376,
      width: 40, height: 36, x: 300, y: 340, toJSON: () => ({}) });
    trigger.click();
    await settle();
    const panel = document.querySelector<HTMLElement>('[data-ui-popover]')!;
    Object.defineProperty(panel, 'offsetWidth', { get: () => 120 });
    Object.defineProperty(panel, 'offsetHeight', { get: () => 80 });
    viewport.dispatchEvent(new Event('resize'));
    await settle();
    expect(panel.style.left).toBe('212px');
    expect(panel.style.top).toBe('256px');
    expect(panel.style.maxWidth).toBe('284px');
    expect(panel.style.getPropertyValue('--ui-floating-available-width')).toBe('284px');
    expect(panel.style.getPropertyValue('--ui-floating-available-height')).toBe('284px');
    viewport.offsetLeft = 200;
    viewport.height = 180;
    viewport.dispatchEvent(new Event('scroll'));
    await settle();
    expect(panel.style.left).toBe('300px');
    expect(panel.style.getPropertyValue('--ui-floating-available-height')).toBe('164px');
    trigger.click();
    await settle();
    expect(removed.mock.calls.map(([event]) => event).sort()).toEqual(added.mock.calls.map(([event]) => event).sort());
    dispose();
  });

  it('writes trigger state through its binding, portals content, dismisses outside, and exposes ARIA linkage', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const changes: boolean[] = [];
    const dispose = render(() => {
      const construction = popoverState('test.optionsPopover', false, (open) => changes.push(open));
      return (
        <Popover.View
          {...construction}
          aria-label="Options"
          trigger={(api) => (
            <button
              id="trigger"
              aria-haspopup="dialog"
              aria-expanded={api.open() ? 'true' : 'false'}
              aria-controls={api.contentId}
              onClick={api.toggle}
            >
              Options
            </button>
          )}
        >
          {() => <button id="inside">Inside</button>}
        </Popover.View>
      );
    }, host);

    const trigger = document.querySelector<HTMLButtonElement>('#trigger')!;
    trigger.getBoundingClientRect = () => ({
      left: 120, right: 160, top: 40, bottom: 64, width: 40, height: 24,
      x: 120, y: 40, toJSON: () => ({}),
    });
    trigger.click();
    await settle();
    const panel = document.body.querySelector<HTMLElement>('[data-ui-popover]');
    expect(panel?.getAttribute('role')).toBe('presentation');
    expect(panel?.shadowRoot?.querySelector('dialog')?.getAttribute('role')).toBe('dialog');
    expect(panel?.shadowRoot?.querySelector('dialog')?.getAttribute('aria-label')).toBe('Options');
    expect(getComputedStyle(panel!).width).toBe('288px');
    expect(getComputedStyle(panel!.querySelector('[data-ui-surface-content]')!).padding).toBe('16px');
    expect(authoredStyle(panel!, '--wa-color-surface-default')).toBe('hsl(var(--ui-popover))');
    expect(document.querySelector('#trigger')?.getAttribute('aria-controls')).toBe(panel?.id);
    expect(document.querySelector('#trigger')?.getAttribute('aria-expanded')).toBe('true');
    expect(panel?.style.left).toBe('140px');
    expect(panel?.style.width).toBe('');
    expect(changes).toEqual([true]);

    document.body.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    await settle();
    expect(document.body.querySelector('[data-ui-popover]')).toBeNull();
    expect(changes).toEqual([true, false]);
    dispose();
  });

  it('matches the positioning trigger width, follows its resize, and releases the observer on close', async () => {
    const observed = new Set<Element>();
    let notifyResize: (() => void) | undefined;
    const disconnect = vi.fn(() => observed.clear());
    const constructed = vi.fn();
    vi.stubGlobal('ResizeObserver', class implements ResizeObserver {
      constructor(callback: ResizeObserverCallback) {
        constructed();
        notifyResize = () => callback([], this);
      }

      observe(target: Element) { observed.add(target); }
      unobserve(target: Element) { observed.delete(target); }
      disconnect = disconnect;
    });
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const construction = popoverState('test.triggerWidthPopover');
      return (
        <Popover.View
          {...construction}
          matchTriggerWidth
          trigger={(api) => <button id="width-trigger" onClick={api.toggle}>Assignees</button>}
        >
          {() => <button>Choice</button>}
        </Popover.View>
      );
    }, host);
    const trigger = host.querySelector<HTMLButtonElement>('#width-trigger')!;
    let width = 320;
    trigger.getBoundingClientRect = () => ({
      left: 120, right: 120 + width, top: 40, bottom: 76, width, height: 36,
      x: 120, y: 40, toJSON: () => ({}),
    });
    trigger.click();
    await settle();
    const panel = document.body.querySelector<HTMLElement>('[data-ui-popover]')!;
    Object.defineProperty(panel, 'offsetWidth', { get: () => Number.parseFloat(panel.style.width) });
    notifyResize?.();
    await settle();
    expect(panel.style.width).toBe('320px');
    expect(panel.style.left).toBe('120px');
    expect(panel.style.top).toBe('80px');
    expect(observed.has(trigger)).toBe(true);
    expect(observed.has(panel)).toBe(true);

    width = 240;
    notifyResize?.();
    await settle();
    expect(panel.style.width).toBe('240px');
    expect(panel.style.left).toBe('120px');

    trigger.click();
    await settle();
    expect(disconnect).toHaveBeenCalledTimes(constructed.mock.calls.length);
    expect(observed.size).toBe(0);
    dispose();
  });

  it('restores the default panel width when matching is disabled while open', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const [matchWidth, setMatchWidth] = createSignal(true);
    const dispose = render(() => {
      const construction = popoverState('test.dynamicWidthPopover');
      return (
        <Popover.View
          {...construction}
          matchTriggerWidth={matchWidth()}
          trigger={(api) => <button id="dynamic-width-trigger" onClick={api.toggle}>Assignees</button>}
        >
          {() => <button>Choice</button>}
        </Popover.View>
      );
    }, host);
    const trigger = host.querySelector<HTMLButtonElement>('#dynamic-width-trigger')!;
    trigger.getBoundingClientRect = () => ({
      left: 120, right: 440, top: 40, bottom: 76, width: 320, height: 36,
      x: 120, y: 40, toJSON: () => ({}),
    });
    trigger.click();
    await settle();
    const panel = document.body.querySelector<HTMLElement>('[data-ui-popover]')!;
    expect(panel.style.width).toBe('320px');

    setMatchWidth(false);
    await settle();
    expect(panel.style.width).toBe('');
    dispose();
  });

  it('fits content, repositions after content changes, and clamps its trigger minimum to the viewport', async () => {
    const viewportWidth = vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(640);
    const observed = new Set<Element>();
    let notifyResize: (() => void) | undefined;
    const disconnect = vi.fn(() => observed.clear());
    const constructed = vi.fn();
    vi.stubGlobal('ResizeObserver', class implements ResizeObserver {
      constructor(callback: ResizeObserverCallback) {
        constructed();
        notifyResize = () => callback([], this);
      }

      observe(target: Element) { observed.add(target); }
      unobserve(target: Element) { observed.delete(target); }
      disconnect = disconnect;
    });
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const construction = popoverState('test.contentWidthPopover');
      return (
        <Popover.View
          {...construction}
          fitContentWidth
          matchTriggerWidth
          align="start"
          margin={12}
          trigger={(api) => <button id="content-width-trigger" onClick={api.toggle}>Tags</button>}
        >
          {() => <button>A name that can grow</button>}
        </Popover.View>
      );
    }, host);
    const trigger = host.querySelector<HTMLButtonElement>('#content-width-trigger')!;
    let triggerWidth = 80;
    trigger.getBoundingClientRect = () => ({
      left: 500, right: 500 + triggerWidth, top: 40, bottom: 76, width: triggerWidth, height: 36,
      x: 500, y: 40, toJSON: () => ({}),
    });
    trigger.click();
    await settle();
    const panel = document.body.querySelector<HTMLElement>('[data-ui-popover]')!;
    // Happy DOM cannot lay out text; supply the browser's measured outer width.
    let measuredWidth = 180;
    Object.defineProperty(panel, 'offsetWidth', { get: () => measuredWidth });
    notifyResize?.();
    await settle();
    expect(panel.style.width).toBe('max-content');
    expect(panel.style.minWidth).toBe('80px');
    expect(panel.style.maxWidth).toBe('616px');
    expect(panel.style.left).toBe('448px');
    expect(observed.has(trigger)).toBe(true);
    expect(observed.has(panel)).toBe(true);

    measuredWidth = 420;
    notifyResize?.();
    await settle();
    expect(panel.style.width).toBe('max-content');
    expect(panel.style.left).toBe('208px');

    triggerWidth = 300;
    viewportWidth.mockReturnValue(260);
    measuredWidth = 236;
    window.dispatchEvent(new Event('resize'));
    await settle();
    expect(panel.style.minWidth).toBe('236px');
    expect(panel.style.maxWidth).toBe('236px');
    expect(panel.style.left).toBe('12px');

    viewportWidth.mockReturnValue(20);
    measuredWidth = 0;
    window.dispatchEvent(new Event('resize'));
    await settle();
    expect(panel.style.minWidth).toBe('0px');
    expect(panel.style.maxWidth).toBe('0px');

    trigger.click();
    await settle();
    expect(disconnect).toHaveBeenCalledTimes(constructed.mock.calls.length);
    expect(observed.size).toBe(0);
    dispose();
  });

  it('switches content fitting on and restores trigger or default sizing when it is disabled', async () => {
    vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(640);
    const host = document.createElement('div');
    document.body.append(host);
    const [fitContent, setFitContent] = createSignal(false);
    const [matchWidth, setMatchWidth] = createSignal(false);
    const dispose = render(() => {
      const construction = popoverState('test.dynamicContentWidthPopover');
      return (
        <Popover.View
          {...construction}
          fitContentWidth={fitContent()}
          matchTriggerWidth={matchWidth()}
          trigger={(api) => <button id="dynamic-content-trigger" onClick={api.toggle}>Assignees</button>}
        >
          {() => <button>Choice</button>}
        </Popover.View>
      );
    }, host);
    const trigger = host.querySelector<HTMLButtonElement>('#dynamic-content-trigger')!;
    trigger.getBoundingClientRect = () => ({
      left: 120, right: 440, top: 40, bottom: 76, width: 320, height: 36,
      x: 120, y: 40, toJSON: () => ({}),
    });
    trigger.click();
    await settle();
    const panel = document.body.querySelector<HTMLElement>('[data-ui-popover]')!;
    expect(panel.style.width).toBe('');

    setFitContent(true);
    await settle();
    expect(panel.style.width).toBe('max-content');
    expect(panel.style.minWidth).toBe('320px');
    expect(panel.style.maxWidth).toBe('624px');

    setMatchWidth(true);
    await settle();
    expect(panel.style.width).toBe('max-content');
    setFitContent(false);
    await settle();
    expect(panel.style.width).toBe('320px');
    expect(panel.style.minWidth).toBe('');
    expect(panel.style.maxWidth).toBe('');

    setFitContent(true);
    setMatchWidth(false);
    await settle();
    setFitContent(false);
    await settle();
    expect(panel.style.width).toBe('');
    expect(panel.style.minWidth).toBe('');
    expect(panel.style.maxWidth).toBe('');
    dispose();
  });

  it('closes the topmost popover on Escape and returns focus to its trigger', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const construction = popoverState('test.escapePopover', true);
      return (
        <Popover.View
          {...construction}
          trigger={(api) => <button id="escape-trigger" onClick={api.toggle}>Open</button>}
        >
          {() => <button>Choice</button>}
        </Popover.View>
      );
    }, host);
    await settle();
    const trigger = document.querySelector<HTMLElement>('#escape-trigger')!;
    trigger.focus();
    trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
    await settle();
    expect(document.body.querySelector('[data-ui-popover]')).toBeNull();
    expect(document.activeElement?.id).toBe('escape-trigger');
    dispose();
  });

  it('leaves native Tab navigation unclaimed when the custom hotkeys array is empty', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const construction = popoverState('test.nativeTabPopover', true);
      return <Popover.View {...construction}
        trigger={(api) => <button onClick={api.toggle}>Open</button>}>
        {() => <><input aria-label="Search choices" /><button>Choice</button></>}
      </Popover.View>;
    }, host);
    await settle();
    const input = document.querySelector<HTMLInputElement>('[aria-label="Search choices"]')!;
    input.focus();
    const event = new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true });
    input.dispatchEvent(event);
    expect(event.defaultPrevented).toBe(false);
    expect(document.querySelector('[data-ui-popover]')).not.toBeNull();
    dispose();
  });

  it('keeps controlled open state with the owner while reporting dismiss requests', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const changes: boolean[] = [];
    const dispose = render(() => {
      const [open, setOpen] = createSignal(true);
      const observable = constructItem('controlledPopover', (item) => item.observe('open', open));
      return (
        <Popover.View
          surface={{ kind: 'own', name: 'test.controlledPopover', transparent: false, layer: true }}
          observable={observable}
          hotkeys={[]}
          onOpenChange={(nextOpen) => {
            changes.push(nextOpen);
            setOpen(nextOpen);
          }}
          trigger={(api) => <button id="controlled-trigger" onClick={api.toggle}>Open</button>}
        >
          {() => <button>Choice</button>}
        </Popover.View>
      );
    }, host);
    await settle();

    expect(document.body.querySelector('[data-ui-popover]')).not.toBeNull();
    document.body.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    await settle();
    expect(changes).toEqual([false]);
    expect(document.body.querySelector('[data-ui-popover]')).toBeNull();
    dispose();
  });
});
