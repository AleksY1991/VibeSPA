/** @jsxImportSource @solidjs/web */
import { Show } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import type { TabPanelControlProps, TabsControlProps, TabsState } from '../contracts/tabs';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import './tabs.css';

export const TAB_KEYS = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Enter', 'Space'] as const;
export type TabsProps<Value extends string = string> = Omit<TabsControlProps, 'state' | 'onElement' | 'onNativeElement' | 'onValueChange' | 'canMoveFocus'>
  & ElementConstruction<TabsState<Value>> & {
    
    readonly onValueChange: (value: Value) => void;
  };
export type TabPanelProps = Omit<TabPanelControlProps, 'active' | 'onElement'>
  & ElementConstruction<boolean>;

function renderTabs<Value extends string>(props: TabsProps<Value>) {
  const binding = new ElementBinding('Tabs', props, {
    nativeKeys: TAB_KEYS, activeWhen: state => state.tabs.length > 0, enabledWhen: state => !state.disabled,
    nativeActivation: true,
  });
  const Implementation = requireControlImplementation('Tabs');
  return binding.provide(() => <Show when={binding.value().tabs.length > 0}><Implementation {...props} state={binding.value()} onElement={binding.attach}
    onNativeElement={binding.attachNative}
    canMoveFocus={() => binding.isLive() && binding.authority()?.canMoveFocus() === true}
    onHandle={handle => props.onHandle?.(handle && guardFocusHandle(binding, handle))}
    onValueChange={value => {
      if (!allowActivation(binding)) return;
      const tab = binding.value().tabs.find(tab => tab.value === value && !tab.disabled);
      if (tab && !binding.value().disabled) props.onValueChange(tab.value);
    }} /></Show>);
}

function renderTabPanel(props: TabPanelProps) {
  const binding = new ElementBinding('TabPanel', props, { activeWhen: active => active });
  const Implementation = requireControlImplementation('TabPanel');
  return binding.provide(() => <Implementation {...props} active={binding.value()} onElement={binding.attach} />);
}

export class Tabs<Value extends string = string> extends RenderedElement<TabsState<Value>> {
  readonly element: JSX.Element;
  constructor(props: TabsProps<Value>) {
    super('Tabs', props);
    this.element = renderTabs(this.capture(props));
  }
  static View = <Value extends string>(props: TabsProps<Value>): JSX.Element => new Tabs(props).element;
}

/** Panels consume visibility without deciding whether their content stays mounted. */
export class TabPanel extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: TabPanelProps) {
    super('TabPanel', props);
    this.element = renderTabPanel(this.capture(props));
  }
  static View = (props: TabPanelProps): JSX.Element => new TabPanel(props).element;
}
