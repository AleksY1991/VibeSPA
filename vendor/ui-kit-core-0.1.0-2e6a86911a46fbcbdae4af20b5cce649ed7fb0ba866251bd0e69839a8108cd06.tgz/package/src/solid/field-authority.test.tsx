/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render as renderSolid, type JSX } from '@solidjs/web';
import { createComponent, createSignal, flush } from 'solid-js';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { hotkeys } from '../runtime/hotkeys';
import type { InputFocusHandle, TextFieldControlProps } from '../contracts/controls';
import type { TextareaControlProps } from '../contracts/fields';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { Button } from './button';
import { Input, type FileInputHandle } from './field';
import { Card } from './controls';
import { TextField } from './text-field';
import { WebAwesomeTextField } from '../vendor/web-awesome/text-field.adapter';
import { Textarea } from './textarea';
import { WebAwesomeTextarea } from '../vendor/web-awesome/textarea.adapter';

class AuthorityInput extends HTMLElement {
  readonly updateComplete = Promise.resolve(true);
  readonly input: HTMLInputElement | HTMLTextAreaElement;
  constructor(tag = 'input') { super(); this.input = document.createElement(tag) as HTMLInputElement; this.attachShadow({ mode: 'open' }).append(this.input); }
  get value() { return this.input.value; }
  set value(value: string) { this.input.value = value; }
  select() { this.input.select(); }
  setSelectionRange(start: number, end: number) { this.input.setSelectionRange(start, end); }
  focus(options?: FocusOptions) { this.input.focus(options); }
  blur() { this.input.blur(); }
}
class AuthorityTextarea extends AuthorityInput { constructor() { super('textarea'); } }
beforeAll(() => { customElements.define('wa-input', AuthorityInput); customElements.define('wa-textarea', AuthorityTextarea); });
function render(view: () => JSX.Element, host: HTMLElement) {
  return renderSolid(() => <ImplementationContext value={{ TextField: WebAwesomeTextField, Textarea: WebAwesomeTextarea }}>{createComponent(view, {})}</ImplementationContext>, host);
}
const editingHost = (host: HTMLElement) => host.querySelector<AuthorityInput>('wa-input,wa-textarea')!;

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });
const settle = async () => { for (let turn = 0; turn < 8; turn++) { flush(); await Promise.resolve(); } };

it.each(['TextField', 'Textarea'] as const)('%s guards typed writes while preserving blur and disposal observations', async family => {
  const [visible, setVisible] = createSignal(true);
  const [blocked, setBlocked] = createSignal(false);
  const [readonly, setReadonly] = createSignal(false);
  const change = vi.fn(); const commit = vi.fn(); const blur = vi.fn();
  let captured!: TextFieldControlProps | TextareaControlProps;
  const CaptureField = (props: TextFieldControlProps) => { captured = props; return <WebAwesomeTextField {...props} />; };
  const CaptureTextarea = (props: TextareaControlProps) => { captured = props; return <WebAwesomeTextarea {...props} />; };
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => {
    const model = constructItem('field.authority', item => ({
      visible: item.observe('visible', visible), blocked: item.observe('blocked', blocked), text: item.constant('text', 'original'),
    }));
    const field = () => family === 'TextField'
      ? <TextField.View observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Value" readonly={readonly()} onValueChange={change} onValueCommit={commit} onBlur={blur} />
      : <Textarea.View observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Value" readonly={readonly()} onValueChange={change} onValueCommit={commit} onBlur={blur} />;
    return <ImplementationContext value={{ TextField: CaptureField, Textarea: CaptureTextarea }}>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>{field()}</Card.View>
      <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'field.blocker', transparent: false, layer: true }} hotkeys={[]}>Dialog</Card.View>
    </ImplementationContext>;
  }, host);
  disposers.push(dispose); await settle();
  const field = editingHost(host);
  const input = field.input;
  input.value = 'native'; field.dispatchEvent(new InputEvent('input', { bubbles: true }));
  field.dispatchEvent(new Event('change', { bubbles: true }));
  expect(change).toHaveBeenCalledExactlyOnceWith('native'); expect(commit).toHaveBeenCalledExactlyOnceWith('native');
  const emit = () => { captured.onValueChange('blocked'); captured.onValueCommit?.('blocked'); };
  setBlocked(true); await settle(); emit();
  setBlocked(false); setReadonly(true); await settle(); emit();
  setReadonly(false); setVisible(false); await settle(); emit();
  captured.onBlur?.(); expect(blur).toHaveBeenCalledOnce();
  expect(change).toHaveBeenCalledOnce(); expect(commit).toHaveBeenCalledOnce();
  setVisible(true); await settle(); captured.onValueChange('resumed');
  expect(change).toHaveBeenLastCalledWith('resumed');
  dispose(); emit(); expect(change).toHaveBeenCalledTimes(2); expect(commit).toHaveBeenCalledOnce();
});

it('declares interactive field slots as children without claiming their native activation', async () => {
  const host = document.createElement('div'); document.body.append(host);
  const override = vi.fn();
  disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
    runtime: () => ({ editing: false, keyboardLayer: null }) }));
  disposers.push(render(() => {
    const model = constructItem('field.slot', item => ({ text: item.constant('text', ''), button: item.constant('button', {}) }));
    return <TextField.View observable={model.text} surface={{ kind: 'own', name: 'field.slot', transparent: false }}
      hotkeys={[{ key: 'Enter', overrideNative: true, handler: override }]} label="Value" onValueChange={() => {}}
      end={<Button.View observable={model.button} surface={{ kind: 'own', name: 'field.slot.action', transparent: false }} hotkeys={[]}>Clear</Button.View>} />;
  }, host));
  await settle();
  const surfaces = surfaceRegistry.read().activeSurfaces;
  expect(surfaces.find(surface => surface.name === 'field.slot.action')?.parentId).toBe(surfaces.find(surface => surface.name === 'field.slot')?.instanceId);
  const event = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, composed: true, cancelable: true });
  host.querySelector('button')!.dispatchEvent(event);
  expect(event.defaultPrevented).toBe(false); expect(override).not.toHaveBeenCalled();
});

it.each(['TextField', 'Textarea'] as const)('%s publishes focus handles while denying focus outside its live scope', async family => {
  const [visible, setVisible] = createSignal(true);
  const [blocked, setBlocked] = createSignal(false);
  const first = vi.fn<(handle: InputFocusHandle | undefined) => void>();
  const second = vi.fn<(handle: InputFocusHandle | undefined) => void>();
  const [callback, setCallback] = createSignal(() => first);
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => {
    const model = constructItem('field.focus', item => ({
      text: item.constant('text', 'value'), visible: item.observe('visible', visible),
    }));
    const blocker = hotkeys({ name: 'field.focus.blocker', transparent: false, layer: true, modal: true, active: blocked, keys: {} });
    const field = () => family === 'TextField'
      ? <TextField.View observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Value" onValueChange={() => {}} onHandle={callback()} />
      : <Textarea.View observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Value" onValueChange={() => {}} onHandle={callback()} />;
    return <>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>{field()}</Card.View>
      <div ref={blocker} hidden={!blocked()}>Dialog</div>
    </>;
  }, host);
  disposers.push(dispose); await settle();
  const field = editingHost(host);
  const input = field.input;
  const focus = vi.spyOn(input, 'focus');
  const blur = vi.spyOn(input, 'blur');
  const handle = first.mock.calls[0][0]!;
  handle.focus(); expect(focus).toHaveBeenCalledOnce();
  setBlocked(true); await settle();
  handle.focus(); expect(focus).toHaveBeenCalledOnce();
  handle.blur(); expect(blur).toHaveBeenCalledOnce();
  expect(handle.selection()).toEqual({ start: input.selectionStart, end: input.selectionEnd });
  setCallback(() => second); await settle();
  expect(first).toHaveBeenLastCalledWith(undefined);
  const replacement = second.mock.calls[0][0]!;
  replacement.focus(); expect(focus).toHaveBeenCalledOnce();
  setBlocked(false); setVisible(false); await settle();
  replacement.focus(); expect(focus).toHaveBeenCalledOnce();
  expect(second).toHaveBeenCalledOnce();
  setVisible(true); await settle(); replacement.focus(); expect(focus).toHaveBeenCalledTimes(2);
  dispose(); expect(second).toHaveBeenLastCalledWith(undefined);
  expect(() => replacement.focus()).toThrow(/disposed|no longer available/);
});


it('retains a hidden file engine behind its public trigger handle and revokes launch authority', async () => {
  const [blocked, setBlocked] = createSignal(false);
  const received = vi.fn<(handle: FileInputHandle | undefined) => void>();
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => {
    const model = constructItem('file.engine', item => item.constant('selection', ''));
    const blocker = hotkeys({ name: 'file.engine.blocker', transparent: false, layer: true, modal: true, active: blocked, keys: {} });
    return <>
      <Input.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
        type="file" visuallyHidden multiple aria-label="Choose attachments" onFilesChange={() => {}} onHandle={received} />
      <div ref={blocker} hidden={!blocked()}>Dialog</div>
    </>;
  }, host);
  disposers.push(dispose); await settle();
  const input = host.querySelector<HTMLInputElement>('input')!;
  const click = vi.spyOn(input, 'click');
  const handle = received.mock.calls[0][0]!;
  expect(input.hidden).toBe(false);
  expect(input.tabIndex).toBe(-1);
  expect(input.getAttribute('aria-hidden')).toBe('true');
  expect(input.hasAttribute('data-ui-file-engine')).toBe(true);
  handle.open(); expect(click).toHaveBeenCalledOnce();
  setBlocked(true); await settle();
  handle.open(); expect(click).toHaveBeenCalledOnce();
  setBlocked(false); await settle();
  handle.open(); expect(click).toHaveBeenCalledTimes(2);
  dispose();
  expect(received).toHaveBeenLastCalledWith(undefined);
  expect(() => handle.open()).toThrow('disposed');
  expect(click).toHaveBeenCalledTimes(2);
});
