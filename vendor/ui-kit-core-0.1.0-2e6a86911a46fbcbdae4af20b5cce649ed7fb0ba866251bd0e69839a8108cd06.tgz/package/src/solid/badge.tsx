/** @jsxImportSource @solidjs/web */
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import type { BadgeControlProps } from '../contracts/badge';
import { ElementBinding } from '../infrastructure/element';
import { RenderedElement } from '../infrastructure/rendered-element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import './badge.css';

export interface BadgeProps extends Omit<BadgeControlProps, 'value' | 'onElement'>, ElementConstruction<string> {
  
}

function renderBadge(props: BadgeProps) {
  const binding = new ElementBinding('Badge', props, { nativeKeys: [] });
  const Implementation = requireControlImplementation('Badge');
  return <Implementation {...props} value={binding.value()} onElement={binding.attach} />;
}

/** Counts and short statuses share caption geometry and an explicit reactive text source. */
export class Badge extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: BadgeProps) {
    super('Badge', props);
    this.element = renderBadge(this.capture(props));
  }
  static View = (props: BadgeProps): JSX.Element => new Badge(props).element;
}
