/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeSpinner } from '../vendor/web-awesome/spinner.adapter';
import { Spinner } from './spinner';

/** Wiring double only; browser checks own vendor geometry, motion and accessibility. */
class SpinnerDouble extends HTMLElement {
  static update: () => Promise<boolean> = () => Promise.resolve(true);
  static exposesProgressRole = true;
  readonly indicator = document.createElement('div');
  constructor() {
    super();
    if (SpinnerDouble.exposesProgressRole) this.indicator.setAttribute('role', 'progressbar');
    this.attachShadow({ mode: 'open' }).append(this.indicator);
  }
  get updateComplete() { return SpinnerDouble.update(); }
}

const disposers: (() => void)[] = [];
const implementation = { Spinner: WebAwesomeSpinner };
const settle = async () => { for (let i = 0; i < 24; i++) { flush(); await Promise.resolve(); } };
beforeAll(() => customElements.define('wa-spinner', SpinnerDouble));
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  SpinnerDouble.update = () => Promise.resolve(true);
  SpinnerDouble.exposesProgressRole = true;
  document.body.replaceChildren();
});
async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const dispose = render(view, container); disposers.push(dispose);
  await settle(); return { container, dispose };
}

describe('shared spinner construction', () => {
  it('uses the canonical renderer and names a standalone indicator once', async () => {
    const { container } = await mount(() => {
      const busy = constructItem('spinner.gate', item => item.constant('busy', true));
      return <ImplementationContext value={implementation}>
        <Spinner.View observable={busy} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" label="Loading attachment" />
        <ImplementationContext value={implementation}>
          <Spinner.View observable={busy} surface={{ kind: 'inherit' }} hotkeys={[]}
            size="md" decorative />
        </ImplementationContext>
      </ImplementationContext>;
    });
    const vendor = container.querySelector<SpinnerDouble>('wa-spinner')!;
    const wrapper = vendor.parentElement!;
    expect(vendor.hasAttribute('data-ui-ready')).toBe(false);
    expect(vendor.dataset.size).toBe('sm');
    expect(wrapper.getAttribute('aria-label')).toBe('Loading attachment');
    expect(wrapper.getAttribute('role')).toBe('progressbar');
    expect(vendor.getAttribute('aria-hidden')).toBe('true');
    expect(vendor.indicator.getAttribute('aria-hidden')).toBeNull();
    const native = container.querySelectorAll<HTMLElement>('[data-ui-spinner-wrapper]')[1]!;
    expect(native.dataset.size).toBe('md');
    expect(native.getAttribute('aria-hidden')).toBe('true');
    expect(native.hasAttribute('role')).toBe(false);
    expect(container.querySelectorAll('[role="progressbar"]')).toHaveLength(1);
  });

  it('keeps live presentation updates on one host and disposes both visibility and surface from the busy observable', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture(); disposers.push(diagnostics.stop);
    const [busy, setBusy] = createSignal(false);
    const [label, setLabel] = createSignal('Loading attachment');
    const { container, dispose } = await mount(() => {
      const model = constructItem('spinner.lifetime', item => item.observe('busy', busy));
      return <ImplementationContext value={implementation}>
        <Spinner.View observable={model}
          surface={{ kind: 'own', name: 'spinner.lifetime', transparent: true }} hotkeys={[]}
          size="sm" label={label()} />
      </ImplementationContext>;
    });
    const surfaces = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'spinner.lifetime');
    expect(container.querySelector('[data-ui-spinner]')).toBeNull(); expect(surfaces()).toHaveLength(0);
    setBusy(true); await settle();
    const original = container.querySelector('wa-spinner')!;
    expect(surfaces()).toHaveLength(1);
    setLabel('Saving attachment'); await settle();
    expect(container.querySelector('wa-spinner')).toBe(original);
    expect(original.parentElement!.getAttribute('aria-label')).toBe('Saving attachment');
    setBusy(false); await settle();
    expect(container.querySelector('[data-ui-spinner]')).toBeNull(); expect(surfaces()).toHaveLength(0);
    setBusy(true); await settle();
    expect(container.querySelector('wa-spinner')).not.toBe(original); expect(surfaces()).toHaveLength(1);
    dispose(); await settle(); expect(surfaces()).toHaveLength(0);
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });

  it('keeps its local identity without a duplicate announcement beside existing status text', async () => {
    const initial = new Set(surfaceRegistry.read().activeSurfaces.map(surface => surface.instanceId));
    const { container } = await mount(() => {
      const busy = constructItem('spinner.decorative', item => item.constant('busy', true));
      return <ImplementationContext value={implementation}>
        <div role="status"><Spinner.View observable={busy} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" decorative />Uploading…</div>
      </ImplementationContext>;
    });
    const vendor = container.querySelector<SpinnerDouble>('wa-spinner')!;
    const spinners = surfaceRegistry.read().activeSurfaces.filter(surface => !initial.has(surface.instanceId));
    expect(spinners).toHaveLength(1);
    expect(spinners[0]).toMatchObject({ name: 'Spinner', layer: false, transparent: false });
    expect(vendor.getAttribute('aria-hidden')).toBe('true');
    expect(vendor.hasAttribute('role')).toBe(false);
    expect(vendor.hasAttribute('aria-label')).toBe(false);
    expect(vendor.parentElement!.getAttribute('aria-hidden')).toBe('true');
    expect(vendor.parentElement!.hasAttribute('role')).toBe(false);
    expect(vendor.parentElement!.hasAttribute('aria-label')).toBe(false);
    expect(vendor.indicator.getAttribute('aria-hidden')).toBeNull();
    expect(vendor.shadowRoot!.querySelector('style')!.textContent).toContain('animation: none !important;');
    expect(vendor.shadowRoot!.querySelector('style')!.textContent).toContain('transition: none !important;');
  });

  it('keeps the same contract on update failure and releases the recovery surface when hidden', async () => {
    SpinnerDouble.update = () => Promise.reject(new Error('Failed vendor update'));
    const [busy, setBusy] = createSignal(true);
    const { container } = await mount(() => {
      const model = constructItem('spinner.failure', item => item.observe('busy', busy));
      return <ImplementationContext value={implementation}>
        <Spinner.View observable={model}
          surface={{ kind: 'own', name: 'spinner.failure', transparent: true }} hotkeys={[]}
          size="md" label="Loading preview" class="text-muted-foreground" />
      </ImplementationContext>;
    });
    expect(container.querySelector('wa-spinner')).not.toBeNull();
    const recovery = container.querySelector<HTMLElement>('[data-ui-spinner]')!;
    expect(recovery.dataset.uiError).toBe('update-failed');
    expect(recovery.hasAttribute('data-ui-ready')).toBe(false);
    expect(recovery.dataset.size).toBe('md');
    expect(recovery.getAttribute('aria-label')).toBe('Loading preview');
    expect(recovery.classList.contains('text-muted-foreground')).toBe(true);
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'spinner.failure')).toHaveLength(1);
    setBusy(false); await settle();
    expect(container.querySelector('[data-ui-spinner]')).toBeNull();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'spinner.failure')).toBe(false);
  });

  it('ignores a vendor definition that settles after the owning busy state has ended', async () => {
    let finish!: (ready: boolean) => void;
    const pending = new Promise<boolean>(resolve => { finish = resolve; });
    SpinnerDouble.update = () => pending;
    const [busy, setBusy] = createSignal(true);
    const { container } = await mount(() => {
      const model = constructItem('spinner.late', item => item.observe('busy', busy));
      return <ImplementationContext value={implementation}>
        <Spinner.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" label="Loading" />
      </ImplementationContext>;
    });
    const old = container.querySelector<SpinnerDouble>('wa-spinner')!;
    expect(old.hasAttribute('data-ui-ready')).toBe(false);
    setBusy(false); await settle(); finish(true); await settle();
    expect(container.querySelector('[data-ui-spinner]')).toBeNull();
    expect(old.hasAttribute('data-ui-ready')).toBe(false);
    expect(old.shadowRoot!.querySelector('style')).toBeNull();
  });

  it('keeps contextual semantics independent of the vendor template role', async () => {
    SpinnerDouble.exposesProgressRole = false;
    const { container } = await mount(() => {
      const busy = constructItem('spinner.template', item => item.constant('busy', true));
      return <ImplementationContext value={implementation}>
        <Spinner.View observable={busy} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" label="Loading attachment" />
      </ImplementationContext>;
    });
    const vendor = container.querySelector('wa-spinner')!;
    expect(vendor.getAttribute('aria-hidden')).toBe('true');
    const wrapper = container.querySelector('[data-ui-spinner-wrapper]')!;
    expect(wrapper.hasAttribute('data-ui-fallback')).toBe(false);
    expect(wrapper.getAttribute('aria-label')).toBe('Loading attachment');
    expect(container.querySelectorAll('[role="progressbar"]')).toHaveLength(1);
  });
});
