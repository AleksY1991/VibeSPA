/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createMemo, createRoot, createSignal, flush, OBSERVE, onCleanup, untrack } from 'solid-js';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { constructItem, ItemCollection } from '../infrastructure/construction';
import { List, type ListProps } from './list';
import type { Observable } from '../contracts/construction';
import { WebAwesomeSelect } from '../vendor/web-awesome/select.adapter';
import { WebAwesomeChoiceGroup } from '../vendor/web-awesome/controls.adapter';
import { WebAwesomeTabs } from '../vendor/web-awesome/tabs.adapter';
// This suite verifies keyed option ownership; vendor browser behavior has its own suites.
class OptionDouble extends HTMLElement {
  readonly updateComplete = Promise.resolve(true);
  get disabled() { return this.hasAttribute('disabled'); }
  set disabled(value: boolean) { this.toggleAttribute('disabled', value); }
  get value() { return this.getAttribute('value') ?? ''; }
  set value(value: string) { this.setAttribute('value', value); }
}
class SelectDouble extends OptionDouble {}
class SelectOptionDouble extends OptionDouble {}
class RadioGroupDouble extends OptionDouble {}
class RadioDouble extends OptionDouble {}
class TabGroupDouble extends OptionDouble {}
class TabDouble extends OptionDouble {}
class TabPanelDouble extends OptionDouble {}
beforeAll(() => {
  customElements.define('wa-select', SelectDouble); customElements.define('wa-option', SelectOptionDouble);
  customElements.define('wa-radio-group', RadioGroupDouble); customElements.define('wa-radio', RadioDouble);
  customElements.define('wa-tab-group', TabGroupDouble); customElements.define('wa-tab', TabDouble);
  customElements.define('wa-tab-panel', TabPanelDouble);
});

interface Row { readonly id: string; readonly label: string }
let dispose: (() => void) | undefined;
afterEach(() => { dispose?.(); dispose = undefined; document.body.replaceChildren(); });

it('retains DOM, local state and current commands across snapshots, edits and reorder; disposes only removed keys', () => {
  const host = document.createElement('div'); document.body.append(host);
  const [rows, setRows] = createSignal<readonly Row[]>([{ id: 'a', label: 'Alpha' }, { id: 'b', label: 'Beta' }]);
  const builds = vi.fn();
  const release = vi.fn();
  const activate = vi.fn();
  const identityWarnings: string[] = [];
  const stop = OBSERVE!.diagnostics.subscribe(event => { if (event.code === 'UNSTABLE_LIST_IDENTITY') identityWarnings.push(event.message); });
  const input = (id: string) => host.querySelector<HTMLInputElement>(`[data-row="${id}"] input`)!;
  const button = (id: string) => host.querySelector<HTMLButtonElement>(`[data-row="${id}"] button`)!;
  try {
    dispose = render(() => {
      const source = constructItem('test.list', item => item.observe('rows', rows));
      return <List.View observable={source} surface={{ kind: 'inherit' }} hotkeys={[]} keyBy={row => row.id}>
        {(row, index) => {
          const id = untrack(() => row.read().id);
          builds(id); onCleanup(() => release(id));
          return <div data-row={id} data-index={index()}>
            <input aria-label={row.read().label} />
            <button onClick={() => activate(row.read())}>{row.read().label}</button>
          </div>;
        }}
      </List.View>;
    }, host);
    flush();
    const alpha = input('a'); const beta = input('b');
    alpha.value = 'unsaved draft'; alpha.focus(); alpha.setSelectionRange(2, 5);
    setRows([{ id: 'a', label: 'Alpha' }, { id: 'b', label: 'Beta' }]); flush();
    expect(input('a')).toBe(alpha); expect(input('b')).toBe(beta);
    expect(document.activeElement).toBe(alpha); expect(alpha.selectionStart).toBe(2);
    setRows([{ id: 'a', label: 'Renamed' }, { id: 'b', label: 'Beta' }]); flush();
    expect(button('a').textContent).toBe('Renamed');
    expect(alpha.getAttribute('aria-label')).toBe('Renamed');
    button('a').click(); expect(activate).toHaveBeenLastCalledWith({ id: 'a', label: 'Renamed' });
    setRows([{ id: 'b', label: 'Beta' }, { id: 'a', label: 'Renamed' }, { id: 'c', label: 'Gamma' }]); flush();
    expect([...host.querySelectorAll('[data-row]')].map(node => node.getAttribute('data-row'))).toEqual(['b', 'a', 'c']);
    expect(input('a')).toBe(alpha); expect(input('b')).toBe(beta); expect(alpha.value).toBe('unsaved draft');
    expect(host.querySelector('[data-row="a"]')?.getAttribute('data-index')).toBe('1');
    expect(builds.mock.calls.map(([id]) => id)).toEqual(['a', 'b', 'c']); expect(release).not.toHaveBeenCalled();
    setRows([{ id: 'a', label: 'Renamed' }, { id: 'c', label: 'Gamma' }]); flush();
    expect(release.mock.calls).toEqual([['b']]);
    setRows([{ id: 'b', label: 'Returned' }, { id: 'a', label: 'Renamed' }]); flush();
    expect(input('b')).not.toBe(beta); expect(input('a')).toBe(alpha);
    expect(identityWarnings).toEqual([]);
    dispose(); dispose = undefined;
    expect(release.mock.calls.map(([id]) => id).sort()).toEqual(['a', 'b', 'b', 'c']);
    setRows([]); flush(); expect(builds).toHaveBeenCalledTimes(4);
  } finally { stop(); }
});

it('renders empty fallback and switches back without retaining removed row owners', () => {
  const host = document.createElement('div'); document.body.append(host);
  const [rows, setRows] = createSignal<readonly Row[]>([]);
  dispose = render(() => {
    const source = constructItem('test.empty', item => item.observe('rows', rows));
    return <List.View observable={source} surface={{ kind: 'inherit' }} hotkeys={[]} keyBy={row => row.id} fallback={<p>Empty</p>}>
      {row => <span>{row.read().label}</span>}
    </List.View>;
  }, host);
  flush(); expect(host.textContent).toBe('Empty');
  setRows([{ id: 'a', label: 'Alpha' }]); flush(); expect(host.textContent).toBe('Alpha');
  setRows([]); flush(); expect(host.textContent).toBe('Empty');
});

it.each(['select', 'choices', 'tabs'] as const)('the ready-made %s preserves options and renders their current data', kind => {
  const host = document.createElement('div'); document.body.append(host);
  const initial = [
    { value: 'a', label: 'Alpha', id: 'a', panelId: 'panel-a', disabled: false },
    { value: 'b', label: 'Beta', id: 'b', panelId: 'panel-b', disabled: false },
    { value: '', label: 'Unassigned', id: 'empty', panelId: 'panel-empty', disabled: false },
  ];
  const [options, setOptions] = createSignal(initial);
  dispose = render(() => kind === 'select'
    ? <WebAwesomeSelect label="Options" value="a" options={options()} onValueChange={() => {}} />
    : kind === 'choices'
      ? <WebAwesomeChoiceGroup label="Options" value="a" options={options()} onValueChange={() => {}} />
      : <WebAwesomeTabs label="Options" size="compact" state={{ value: 'a', tabs: options() }} onValueChange={() => {}} />,
  host);
  flush();
  const selector = kind === 'select' ? 'wa-option' : kind === 'choices' ? 'wa-radio' : 'wa-tab';
  const original = [...host.querySelectorAll(selector)];
  expect(original).toHaveLength(initial.length);
  setOptions(initial.map(row => ({ ...row }))); flush();
  expect([...host.querySelectorAll(selector)]).toEqual(original);
  setOptions([{ ...initial[1], label: 'Renamed', disabled: true }, { ...initial[0] }]); flush();
  const updated = [...host.querySelectorAll(selector)];
  expect(updated[0]).toBe(original[1]); expect(updated[1]).toBe(original[0]);
  expect((updated[0] as HTMLInputElement).disabled).toBe(true);
  expect(updated[0].textContent).toContain('Renamed');
});

it.each([undefined, null, {}, NaN, Infinity])('rejects invalid keys before constructing children (%s)', key => {
  createRoot(stop => {
    try {
      const rows = constructItem('test.invalid', item => item.constant('rows', [{ id: key }]));
      const build = vi.fn();
      const mapped = ItemCollection.map('test.invalid', rows, row => row.id as string, build);
      expect(() => untrack(mapped)).toThrow('item keys'); expect(build).not.toHaveBeenCalled();
    } finally { stop(); }
  });
});

it('rejects duplicate keys before constructing children, and requires valid construction ownership', () => {
  createRoot(stop => {
    try {
      const rows = constructItem('test.duplicate', item => item.constant('rows', [{ id: 'a' }, { id: 'a' }]));
      const build = vi.fn();
      const mapped = ItemCollection.map('test.duplicate', rows, row => row.id, build);
      expect(() => untrack(mapped)).toThrow('duplicate item key'); expect(build).not.toHaveBeenCalled();
      const invalid = createMemo(() => {
        expect(() => ItemCollection.map('test.reactive', rows, row => row.id, build)).toThrow('reactive computation');
        return true;
      });
      expect(invalid()).toBe(true);
    } finally { stop(); }
  });
  expect(() => ItemCollection.map('test.ownerless', {} as Observable<readonly Row[]>, row => row.id, vi.fn())).toThrow('construction owner');
});

// These contracts are verified by tsc without constructing or executing UI.
function types(source: Observable<readonly Row[]>) {
  // @ts-expect-error record identity is required
  const missingKey: ListProps<Row> = { observable: source, surface: { kind: 'inherit' }, hotkeys: [], children: () => null };
  // @ts-expect-error ordinary arrays cannot replace registered observables
  const array: ListProps<Row> = { observable: [], surface: { kind: 'inherit' }, hotkeys: [], keyBy: row => row.id, children: () => null };
  // @ts-expect-error object identity is not a record key
  const objectKey: ListProps<Row> = { observable: source, surface: { kind: 'inherit' }, hotkeys: [], keyBy: row => row, children: () => null };
  return [missingKey, array, objectKey];
}
void types;
