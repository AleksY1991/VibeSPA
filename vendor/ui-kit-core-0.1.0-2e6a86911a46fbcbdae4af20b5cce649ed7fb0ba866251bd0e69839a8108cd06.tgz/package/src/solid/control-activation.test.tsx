/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import type { JSX } from '@solidjs/web';
import { renderPrepared } from '../../tests/prepared';
import { createSignal, flush } from 'solid-js';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import type { FocusHandle } from '../contracts/controls';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext, type PreparedImplementation } from '../infrastructure/implementation-context';
import { Checkbox } from './checkbox';
import { Card, ChoiceGroup, Toggle } from './controls';
import { FilePicker } from './file-picker';
import { Input } from './field';
import { Tabs } from './tabs';
const disposers: (() => void)[] = [];
const settle = async () => { for (let index = 0; index < 60; index++) { flush(); await Promise.resolve(); } };
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const dispose = renderPrepared(view, container); disposers.push(dispose); await settle();
  return { container, dispose };
}

describe('control commands use their live surface authority', () => {
  it.each(['reset', 'submit'] as const)('blocks callback-free native %s input defaults outside the active owner', async type => {
    const [blocked, setBlocked] = createSignal(false);
    const command = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('activation.nativeFormAction', item => ({
        blocked: item.observe('blocked', blocked), value: item.constant('value', 'Apply'),
      }));
      return <>
        <form onSubmit={event => { event.preventDefault(); command('submit'); }} onReset={() => command('reset')}>
          <Input.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]} type={type} onValueChange={() => {}} />
        </form>
        <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'activation.nativeFormModal', transparent: false, layer: true }} hotkeys={[]}>
          <span>Modal</span>
        </Card.View>
      </>;
    });
    const input = container.querySelector('input')!;
    input.click(); expect(command).toHaveBeenCalledExactlyOnceWith(type);
    setBlocked(true); await settle(); input.click(); expect(command).toHaveBeenCalledOnce();
    setBlocked(false); await settle(); input.click(); expect(command).toHaveBeenCalledTimes(2);
  });

  it('retains readonly native input focus and selection while rejecting synthetic value writes', async () => {
    const command = vi.fn();
    const { container } = await mount(() => {
      const value = constructItem('activation.readonlyInput', item => item.constant('value', 'Readonly'));
      return <Input.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} readonly onValueChange={command} />;
    });
    const input = container.querySelector('input')!;
    const click = new MouseEvent('click', { bubbles: true, cancelable: true }); input.dispatchEvent(click);
    expect(click.defaultPrevented).toBe(false);
    input.focus(); input.setSelectionRange(0, 4);
    expect(document.activeElement).toBe(input); expect(input.selectionEnd).toBe(4);
    input.value = 'Changed'; input.dispatchEvent(new Event('input', { bubbles: true }));
    expect(command).not.toHaveBeenCalled();
  });

  it.each(['Input', 'Card'] as const)('gates raw %s command handlers while retaining gesture cleanup', async family => {
    const [blocked, setBlocked] = createSignal(false);
    const command = vi.fn(); const cleanup = vi.fn();
    const { container, dispose } = await mount(() => {
      const model = constructItem('activation.rawEvents', item => ({
        blocked: item.observe('blocked', blocked), visible: item.constant('visible', true), value: item.constant('value', ''),
      }));
      return <>
        {family === 'Input'
          ? <Input.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]} onValueChange={() => {}}
            onClick={command} onPointerLeave={cleanup} />
          : <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]}
            attributes={{ onClick: command, onPointerLeave: cleanup }}><span>Card</span></Card.View>}
        <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'activation.rawModal', transparent: false, layer: true }} hotkeys={[]}>
          <span>Modal</span>
        </Card.View>
      </>;
    });
    const target = container.firstElementChild!;
    const click = () => { const event = new MouseEvent('click', { bubbles: true, cancelable: true }); target.dispatchEvent(event); return event; };
    expect(click().defaultPrevented).toBe(false); expect(command).toHaveBeenCalledOnce();
    setBlocked(true); await settle();
    expect(click().defaultPrevented).toBe(true); expect(command).toHaveBeenCalledOnce();
    target.dispatchEvent(new PointerEvent('pointerleave')); expect(cleanup).toHaveBeenCalledOnce();
    dispose(); target.dispatchEvent(new PointerEvent('pointerleave')); click();
    expect(command).toHaveBeenCalledOnce(); expect(cleanup).toHaveBeenCalledOnce();
  });

  it.each(['Toggle', 'Checkbox', 'Input', 'Tabs'] as const)('checks %s public focus handles against the registry modal owner', async family => {
    let handle: FocusHandle | undefined;
    const onHandle = (next: FocusHandle | undefined) => { handle = next; };
    const { container, dispose } = await mount(() => {
      const model = constructItem('activation.focusHandle', item => ({
        value: item.constant('value', ''), checked: item.constant('checked', false),
        tabs: item.constant('tabs', { value: 'one', tabs: [{ value: 'one', label: 'One', id: 'one', panelId: 'panel-one' }] }),
      }));
      switch (family) {
        case 'Toggle': return <Toggle.View observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]}
          label="Toggle" onCheckedChange={() => {}} onHandle={onHandle} />;
        case 'Checkbox': return <Checkbox.View observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]}
          label="Checkbox" onCheckedChange={() => {}} onHandle={onHandle} />;
        case 'Input': return <Input.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]}
          onValueChange={() => {}} onHandle={onHandle} />;
        case 'Tabs': return <Tabs.View observable={model.tabs} surface={{ kind: 'inherit' }} hotkeys={[]} label="Tabs" size="compact" onValueChange={() => {}} onHandle={onHandle} />;
      }
    });
    const target = container.querySelector(family === 'Toggle' ? 'wa-switch' : family === 'Checkbox' ? 'wa-checkbox' : family === 'Tabs' ? 'wa-tab' : 'input')!;
    handle!.focus(); expect(document.activeElement).toBe(target);
    const modal = document.createElement('div'); modal.tabIndex = -1; document.body.append(modal);
    const release = surfaceRegistry.mountElement({ name: 'activation.focusModal', element: modal, transparent: false,
      layer: true, modal: true, keys: {} });
    disposers.push(() => { release(); modal.remove(); });
    modal.focus(); handle!.focus(); expect(document.activeElement).toBe(modal);
    release(); handle!.focus(); expect(document.activeElement).toBe(target);
    const stale = handle!; dispose(); expect(() => stale.focus()).toThrow();
  });

  it.each(['Toggle', 'Checkbox', 'ChoiceGroup'] as const)('cancels denied %s browser checked-state activation', async family => {
    const [blocked, setBlocked] = createSignal(false);
    const command = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('activation.nativeDefault', item => ({
        blocked: item.observe('blocked', blocked), checked: item.constant('checked', false), value: item.constant('value', 'one'),
      }));
      return <>
        {family === 'Toggle'
          ? <Toggle.View observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]} label="Toggle" onCheckedChange={command} />
          : family === 'Checkbox'
            ? <Checkbox.View observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]} label="Checkbox" onCheckedChange={command} />
            : <ChoiceGroup.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Choices"
              options={[{ value: 'one', label: 'One' }, { value: 'two', label: 'Two' }]} onValueChange={command} />}
        <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'activation.nativeModal', transparent: false, layer: true }} hotkeys={[]}>
          <span>Modal owner</span>
        </Card.View>
      </>;
    });
    const host = container.querySelector<HTMLElement & { checked: boolean }>(family === 'Toggle' ? 'wa-switch' : family === 'Checkbox' ? 'wa-checkbox' : 'wa-radio[data-ui-choice-value="two"]')!;
    const activationTarget = host.shadowRoot!.querySelector<HTMLInputElement>('input');
    const click = () => {
      if (activationTarget) { activationTarget.click(); return; }
      const event = new MouseEvent('click', { bubbles: true, composed: true, cancelable: true });
      // Happy DOM does not retarget shadow-origin clicks for outside listeners.
      // Preserve the real origin/path and supply the browser-visible radio host.
      Object.defineProperty(event, 'target', { configurable: true, value: host });
      host.shadowRoot!.querySelector('[part="control"]')!.dispatchEvent(event);
    };
    expect(host.closest('[data-ui-ready]')?.getAttribute('data-ui-ready')).toBe('true');
    click(); await settle();
    expect(command).toHaveBeenCalledOnce(); expect(host.checked).toBe(true);
    host.checked = false;
    if (family === 'ChoiceGroup') (host.closest('wa-radio-group') as HTMLElement & { value: string }).value = 'one';
    await settle();
    setBlocked(true); await settle(); click(); await settle();
    expect(command).toHaveBeenCalledOnce(); expect(host.checked).toBe(false);
    setBlocked(false); await settle(); click(); await settle();
    expect(command).toHaveBeenCalledTimes(2); expect(host.checked).toBe(true);
  });

  it.each(['Toggle', 'Checkbox', 'ChoiceGroup', 'Tabs'] as const)(
    'checks retained %s vendor callbacks against visibility, disabled state, modal ownership and disposal', async family => {
      const [visible, setVisible] = createSignal(true);
      const [blocked, setBlocked] = createSignal(false);
      const [disabled, setDisabled] = createSignal(false);
      const command = vi.fn();
      let invoke!: () => void;
      const implementation: PreparedImplementation = {
        Toggle: props => { invoke = () => props.onCheckedChange(true); return <span ref={props.onElement} />; },
        Checkbox: props => { invoke = () => props.onCheckedChange(true); return <span ref={props.onElement} />; },
        ChoiceGroup: props => { invoke = () => props.onValueChange('two'); return <span ref={props.onElement} />; },
        Tabs: props => { invoke = () => props.onValueChange('two'); return <span ref={props.onElement} />; },
      };
      const { dispose } = await mount(() => {
        const model = constructItem('activation.vendor', item => ({
          visible: item.observe('visible', visible), blocked: item.observe('blocked', blocked),
          present: item.constant('present', true), checked: item.constant('checked', false),
          value: item.constant('value', 'one'),
          tabs: item.observe('tabs', () => ({ value: 'one', disabled: disabled(), tabs: [
            { value: 'one', label: 'One', id: 'one', panelId: 'one-panel' },
            { value: 'two', label: 'Two', id: 'two', panelId: 'two-panel' },
          ] })),
        }));
        const control = () => {
          switch (family) {
            case 'Toggle': return <Toggle.View observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]} label="Toggle" disabled={disabled()} onCheckedChange={command} />;
            case 'Checkbox': return <Checkbox.View observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]} label="Checkbox" disabled={disabled()} onCheckedChange={command} />;
            case 'ChoiceGroup': return <ChoiceGroup.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]} label="Choice" disabled={disabled()} options={[{ value: 'one', label: 'One' }, { value: 'two', label: 'Two' }]}
              onValueChange={command} />;
            case 'Tabs': return <Tabs.View observable={model.tabs} surface={{ kind: 'inherit' }} hotkeys={[]} label="Tabs" size="compact" onValueChange={command} />;
          }
        };
        return <ImplementationContext value={implementation}>
          <Card.View observable={model.visible} surface={{ kind: 'own', name: 'activation.owner', transparent: false }} hotkeys={[]}>
            {control()}
          </Card.View>
          <Card.View observable={model.present} surface={{ kind: 'own', name: 'activation.localSibling', transparent: false }} hotkeys={[]}>
            <span>Local sibling</span>
          </Card.View>
          <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'activation.modal', transparent: false, layer: true }} hotkeys={[]}>
            <span>Modal owner</span>
          </Card.View>
        </ImplementationContext>;
      });
      invoke(); expect(command).toHaveBeenCalledOnce();
      setVisible(false); await settle(); invoke(); expect(command).toHaveBeenCalledOnce();
      setVisible(true); setDisabled(true); await settle(); invoke(); expect(command).toHaveBeenCalledOnce();
      setDisabled(false); setBlocked(true); await settle(); invoke(); expect(command).toHaveBeenCalledOnce();
      setBlocked(false); await settle(); invoke(); expect(command).toHaveBeenCalledTimes(2);
      dispose(); invoke(); expect(command).toHaveBeenCalledTimes(2);
    },
  );

  it.each(['Input', 'FilePicker'] as const)('cancels retained %s DOM events while its owning Card is hidden', async family => {
    const [visible, setVisible] = createSignal(true);
    const command = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('activation.native', item => ({
        visible: item.observe('visible', visible), value: item.constant('value', ''), file: item.constant<File | null>('file', null),
      }));
      return <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>
        {family === 'Input'
          ? <Input.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]} onValueChange={command} />
          : <FilePicker.View observable={model.file} surface={{ kind: 'inherit' }} hotkeys={[]} label="Attachment" onFileChange={command} />}
      </Card.View>;
    });
    const input = container.querySelector('input')!;
    const invoke = () => {
      if (family === 'Input') input.value = 'new';
      else Object.defineProperty(input, 'files', { configurable: true, value: [new File(['x'], 'file.txt')] });
      const event = new Event(family === 'Input' ? 'input' : 'change', { bubbles: true, cancelable: true });
      input.dispatchEvent(event); return event;
    };
    expect(invoke().defaultPrevented).toBe(false); expect(command).toHaveBeenCalledOnce();
    setVisible(false); await settle();
    expect(container.querySelector('input')).toBe(input);
    expect(invoke().defaultPrevented).toBe(true); expect(command).toHaveBeenCalledOnce();
    setVisible(true); await settle();
    expect(invoke().defaultPrevented).toBe(false); expect(command).toHaveBeenCalledTimes(2);
  });

});
