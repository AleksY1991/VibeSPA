/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import type { AvatarValue } from '../contracts/avatar';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeAvatar } from '../vendor/web-awesome/avatar.adapter';
import { Avatar } from './avatar';

/** Adapter wiring double. The browser verifies vendor rendering and image-error fallback. */
class AvatarDouble extends HTMLElement {
  static update: () => Promise<boolean> = () => Promise.resolve(true);
  image = ''; label = ''; initials = ''; shape = '';
  get updateComplete() { return AvatarDouble.update(); }
}

const implementation = { Avatar: WebAwesomeAvatar };
const disposers: (() => void)[] = [];
const settle = async () => { for (let index = 0; index < 24; index++) { flush(); await Promise.resolve(); } };
beforeAll(() => customElements.define('wa-avatar', AvatarDouble));
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  AvatarDouble.update = () => Promise.resolve(true);
  document.body.replaceChildren();
});
async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const dispose = render(view, container); disposers.push(dispose);
  await settle(); return { container, dispose };
}

describe('shared avatar', () => {
  it('uses the canonical vendor host and preserves image, initials, naming and square-corner size', async () => {
    const { container } = await mount(() => {
      const identity = constructItem('avatar.gate', item => item.constant<AvatarValue>('identity', {
        label: 'Ada Lovelace', initials: 'AL', image: 'https://example.test/ada.png',
      }));
      return <ImplementationContext value={implementation}>
        <Avatar.View observable={identity} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" data-tip="Ada Lovelace" />
      </ImplementationContext>;
    });
    const vendor = container.querySelector<AvatarDouble>('wa-avatar')!;
    expect(vendor.hasAttribute('data-ui-ready')).toBe(false);
    expect(vendor.hasAttribute('inert')).toBe(false);
    expect(vendor.image).toBe('https://example.test/ada.png');
    expect(vendor.label).toBe('Ada Lovelace');
    expect(vendor.initials).toBe('AL'); expect(vendor.shape).toBe('rounded');
    expect(vendor.dataset.size).toBe('sm'); expect(vendor.dataset.tip).toBe('Ada Lovelace');
    expect(vendor.dataset.uiControlSize).toBe('standard');
    expect(container.querySelectorAll('[data-ui-avatar]')).toHaveLength(1);
    expect(container.querySelector('.ui-avatar-native')).toBeNull();
  });

  it('keeps one host as profile identity changes and releases the owning surface on disposal', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture(); disposers.push(diagnostics.stop);
    const [identity, setIdentity] = createSignal<AvatarValue>({ label: 'Ada', initials: 'AD', symbol: '🎨' });
    const [decorative, setDecorative] = createSignal(true);
    const [size, setSize] = createSignal<'compact' | 'standard'>('compact');
    const { container, dispose } = await mount(() => {
      const model = constructItem('avatar.reactive', item => item.observe('identity', identity));
      return <ImplementationContext value={implementation}>
        <Avatar.View observable={model}
          surface={{ kind: 'own', name: 'avatar.reactive', transparent: true }} hotkeys={[]}
          size={size()} decorative={decorative()} data-tip={decorative() ? undefined : 'Grace Hopper'} />
      </ImplementationContext>;
    });
    const vendor = container.querySelector<AvatarDouble>('wa-avatar')!;
    expect(vendor.querySelector('[slot="icon"]')?.textContent).toBe('🎨');
    expect(vendor.initials).toBe(''); expect(vendor.getAttribute('aria-hidden')).toBe('true');
    expect(vendor.dataset.uiControlSize).toBe('compact');
    setIdentity({ label: 'Grace Hopper', initials: 'GH', image: 'https://example.test/grace.jpg' });
    setDecorative(false); setSize('standard'); await settle();
    expect(container.querySelector('wa-avatar')).toBe(vendor);
    expect(vendor.initials).toBe('GH'); expect(vendor.label).toBe('Grace Hopper');
    expect(vendor.dataset.uiControlSize).toBe('standard');
    expect(vendor.image).toBe('https://example.test/grace.jpg');
    expect(vendor.querySelector('[slot="icon"]')).toBeNull();
    expect(vendor.hasAttribute('aria-hidden')).toBe(false);
    expect(vendor.dataset.tip).toBe('Grace Hopper');
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'avatar.reactive')).toHaveLength(1);
    dispose(); await settle();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'avatar.reactive')).toBe(false);
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });

  it('keeps vendor image-error ownership and forwards a replacement image without replacing the host', async () => {
    const [identity, setIdentity] = createSignal<AvatarValue>({ label: 'Ada', initials: 'AD', image: '/missing.png' });
    const { container } = await mount(() => {
      const model = constructItem('avatar.image', item => item.observe('identity', identity));
      return <ImplementationContext value={implementation}><Avatar.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]} size="xs" /></ImplementationContext>;
    });
    const host = container.querySelector<AvatarDouble>('wa-avatar')!;
    expect(host.image).toBe('/missing.png'); expect(host.initials).toBe('AD');
    setIdentity({ label: 'Ada', initials: 'AD', image: '/replacement.png' }); await settle();
    expect(container.querySelector('wa-avatar')).toBe(host);
    expect(host.image).toBe('/replacement.png'); expect(host.label).toBe('Ada');
  });

  it('retains the canonical host after failure without duplicate identity announcements inside an action', async () => {
    AvatarDouble.update = () => Promise.reject(new Error('Failed avatar update'));
    const { container } = await mount(() => {
      const identity = constructItem('avatar.failure', item => item.constant<AvatarValue>('identity', {
        label: 'Unassigned', initials: '', symbol: '👤',
      }));
      return <ImplementationContext value={implementation}>
        <Avatar.View observable={identity} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" decorative />
      </ImplementationContext>;
    });
    const native = container.querySelector<HTMLElement>('wa-avatar')!;
    expect(native.dataset.uiError).toBe('update-failed'); expect(native.hasAttribute('data-ui-ready')).toBe(false);
    expect(native.hasAttribute('inert')).toBe(false); expect(native.dataset.size).toBe('sm');
    expect(native.getAttribute('aria-hidden')).toBe('true');
    expect(native.hasAttribute('aria-label')).toBe(false); expect(native.hasAttribute('role')).toBe(false);
    expect(native.textContent).toBe('👤');
  });

  it('keeps a failed canonical host named as the observable identity changes', async () => {
    AvatarDouble.update = () => Promise.reject(new Error('Failed avatar update'));
    const [identity, setIdentity] = createSignal<AvatarValue>({ label: 'Ada', initials: 'AD' });
    const { container } = await mount(() => {
      const model = constructItem('avatar.failed-name', item => item.observe('identity', identity));
      return <ImplementationContext value={implementation}><Avatar.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]} size="sm" /></ImplementationContext>;
    });
    const host = container.querySelector('wa-avatar')!;
    expect(host.getAttribute('role')).toBe('img');
    expect(host.getAttribute('aria-label')).toBe('Ada');
    setIdentity({ label: 'Grace', initials: 'GH' }); await settle();
    expect(container.querySelector('wa-avatar')).toBe(host);
    expect(host.getAttribute('aria-label')).toBe('Grace');
    expect(host.hasAttribute('inert')).toBe(false);
  });

  it('publishes identity without waiting for a vendor update and ignores rejection after disposal', async () => {
    let fail!: (error: Error) => void;
    AvatarDouble.update = () => new Promise<boolean>((_, reject) => { fail = reject; });
    const { container, dispose } = await mount(() => {
      const identity = constructItem('avatar.late', item => item.constant<AvatarValue>('identity', {
        label: 'Ada', initials: 'AD',
      }));
      return <ImplementationContext value={implementation}>
        <Avatar.View observable={identity} surface={{ kind: 'inherit' }} hotkeys={[]}
          size="sm" />
      </ImplementationContext>;
    });
    const vendor = container.querySelector<AvatarDouble>('wa-avatar')!;
    expect(vendor.label).toBe('Ada'); expect(vendor.initials).toBe('AD');
    expect(vendor.hasAttribute('data-ui-ready')).toBe(false);
    expect(vendor.hasAttribute('inert')).toBe(false);
    dispose(); fail(new Error('Late avatar update failure')); await settle();
    expect(vendor.hasAttribute('data-ui-error')).toBe(false);
    expect(container.querySelector('wa-avatar')).toBeNull();
  });
});
