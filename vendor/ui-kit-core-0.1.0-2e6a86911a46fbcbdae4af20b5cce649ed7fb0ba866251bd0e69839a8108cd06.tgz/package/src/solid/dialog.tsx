/** @jsxImportSource @solidjs/web */
import './dialog.css';
import { dialogFrameClass, dialogContentClass, resolveDialogPresentation, type DialogPresentation } from '../dialog-presentation';

import { RenderedElement } from '../infrastructure/rendered-element';
import { Show, createEffect, createMemo, createSignal, onCleanup, onSettled, untrack, useContext } from 'solid-js';
import type { JSX } from '@solidjs/web';
import { XIcon } from '../icons';

import { HOTKEY_DELEGATE, HOTKEY_PASS, type SurfaceHotkeyHandler } from '../contracts/platform';
import { cn } from '../lib/utils';
import type { ElementConstruction, ElementSurface } from '../contracts/construction';
import type { FocusHandle } from '../contracts/controls';
import type { SurfaceControlProps } from '../contracts/surfaces';
import { ElementBinding } from '../infrastructure/element';
import { LayerPortal, ModalPortalContext, PORTAL_LAYERS, createModalPortalScope, registerModalPortalScope } from './portal';
import '../popup.css';
import {
  focusInitialElement,
  containsFocus,
  focusedElement,
  lockDocumentScroll,
  trapTabKey,
} from './overlay';

interface DialogBehavior extends Omit<ElementConstruction<boolean>, 'surface'> {
  surface: Extract<ElementSurface, { kind: 'own' }> & { layer: true };
  /** Retain editing content only when its enclosing view requires it. */
  contentLifetime?: 'visible' | 'owner';
  label?: string;
  withoutHeader?: boolean;
  onOpenChange: (open: boolean) => void;
  children: JSX.Element;
  role?: 'dialog' | 'alertdialog';
  'aria-label'?: string;
  'aria-labelledby'?: string;
  'aria-describedby'?: string;
  layer?: number;
  /** Explicit modality can change without remounting a panel's editor. */
  modal?: boolean;
  trapFocus?: boolean;
  preventScroll?: boolean;
  closeOnEscape?: boolean;
  closeOnOutsidePointerDown?: boolean;
  initialFocus?: () => HTMLElement | FocusHandle | null | undefined;
  restoreFocus?: () => HTMLElement | null | undefined;
  onEscapeKeyDown?: (event: KeyboardEvent) => void;
  onOutsidePointerDown?: (event: PointerEvent) => void;
  id?: string;
  'data-surface'?: string;
}

export type DialogProps = DialogBehavior & DialogPresentation;
export type { DialogRecipe, DialogSize, DialogPlacement, DialogDrawerState } from '../dialog-presentation';

function renderDialog(props: DialogProps) {
  // WA 3.12 cannot switch modality or authorize its queued focus through the
  // surface registry. One browser dialog owns native inertness for modal panels
  // and remains the same host when pinned. The binding owns dismissal and focus.
  const parent = useContext(ModalPortalContext);
  const presentation = createMemo(() => resolveDialogPresentation(props));
  const Surface = DialogSurface;
  const customEscape = untrack(() => props.hotkeys.find(binding => binding.key === 'Escape'));
  const open = (): boolean => binding.active();
  let overlay: HTMLDialogElement | undefined;
  const [mounted, setMounted] = createSignal(false);
  let nativeModal = false;
  let content: HTMLElement | undefined;
  // The centered panel is transformed. Its overlay preserves viewport-based
  // coordinates for fixed child portals while keeping one owned focus region.
  const scope = createModalPortalScope(() => overlay, open);
  let previouslyFocused: HTMLElement | null = null;
  const rememberOpener = () => {
    const active = focusedElement(document);
    const container = overlay ?? content;
    if (active instanceof HTMLElement && active !== document.body && (!container || !containsFocus(container, active))) previouslyFocused = active;
  };
  let focusEpoch = 0;
  let disposed = false;
  onCleanup(() => { disposed = true; });

  const setOpen = (next: boolean) => {
    if (next === open()) return;
    props.onOpenChange(next);
  };

  const handleKeyDown: SurfaceHotkeyHandler = (event) => {
    if (!content) return HOTKEY_PASS;
    if (event.key === 'Escape' && props.closeOnEscape !== false) {
      const child = binding.authority()?.dispatchChildEscape(event);
      if (child && child.kind !== 'unclaimed') return child.kind === 'blocked' ? HOTKEY_PASS : undefined;
      if (!binding.authority()?.canDismiss(event.target)) return HOTKEY_PASS;
      props.onEscapeKeyDown?.(event);
      if (!event.defaultPrevented) {
        event.preventDefault();
        event.stopPropagation();
        setOpen(false);
      }
      return;
    }
    return HOTKEY_PASS;
  };

  // Modal containment belongs to the nearest modal owner, independently of
  // child dismissal/shortcut ownership. Portals remain inside its overlay mount
  // so a popover can own Escape while Tab still follows the modal's full tree.
  const containFocus = (event: KeyboardEvent) => {
    if (!content || props.modal === false || props.trapFocus === false) return HOTKEY_DELEGATE;
    trapTabKey(event, overlay ?? content, content);
    return event.defaultPrevented ? undefined : HOTKEY_PASS;
  };

  // Changing native modality requires close/show, never reconstructing content.
  // Pinned panels release background input and keep Escape local to their tree.
  const binding: ElementBinding<boolean> = new ElementBinding('Dialog', props, {
    activeWhen: open => open && (parent?.open() ?? true),
    layer: () => props.modal !== false,
    dismissable: true,
    modal: () => props.modal !== false && props.trapFocus !== false,
    builtins: { Escape: handleKeyDown },
    focusKeys: { Tab: containFocus, 'Shift+Tab': containFocus },
  });

  onSettled(() => { setMounted(true); });
  const closeNative = () => {
    if (overlay?.open) overlay.close();
    nativeModal = false;
  };
  onCleanup(closeNative);
  createEffect(() => ({ mounted: mounted(), live: binding.lifetime(), modal: props.modal !== false && props.trapFocus !== false }), state => {
    if (!state.mounted || !overlay) return;
    if (!state.live) { closeNative(); return; }
    if (overlay.open && nativeModal === state.modal) return;
    const active = focusedElement(overlay.ownerDocument);
    closeNative();
    // Native showModal focuses a descendant synchronously. The shared owner
    // waits for child readiness and the explicit initialFocus handle instead.
    // Keep this suppression synchronous so host observers never see inertness.
    const inert = overlay.inert;
    overlay.inert = true;
    try { if (state.modal) overlay.showModal(); else overlay.show(); }
    finally { overlay.inert = inert; }
    nativeModal = state.modal;
    // A native mode change can move focus; keep an existing editor and caret.
    if (active instanceof HTMLElement && overlay.contains(active) && binding.authority()?.canMoveFocus()) active.focus({ preventScroll: true });
  });

  createEffect(() => binding.lifetime() && props.modal !== false && props.preventScroll !== false, locked => {
    if (locked) return lockDocumentScroll(document);
  });

  createEffect(binding.lifetime, live => {
    if (!live) return;
    const releaseContent = content && registerModalPortalScope(content, scope);
    const releaseOverlay = overlay && registerModalPortalScope(overlay, scope);
    return () => { releaseContent?.(); releaseOverlay?.(); };
  });

  createEffect(binding.lifetime, (active) => {
    if (!active || typeof document === 'undefined') return;
    const authority = binding.authority();
    const epoch = ++focusEpoch;
    rememberOpener();
    let cancelled = false;
    let initialFocusFinished = false;
    let focusObserver: MutationObserver | undefined;
    queueMicrotask(() => {
      if (cancelled || !binding.lifetime() || !content) return;
      const focusWhenReady = () => {
        if (cancelled || initialFocusFinished || !binding.lifetime() || !content || !binding.authority()?.canMoveFocus()) return;
        if (content.matches('[data-ui-ready="false"]') || content.querySelector('[data-ui-ready="false"]')) return;
        const preferred = props.initialFocus?.();
        const activeElement = focusedElement(document);
        if (props.initialFocus && !preferred) return;
        initialFocusFinished = true;
        focusObserver?.disconnect();
        if (!props.initialFocus && activeElement !== content && containsFocus(overlay ?? content, activeElement)) return;
        if (preferred && !(preferred instanceof HTMLElement)) preferred.focus({ preventScroll: true });
        else focusInitialElement(content, preferred);
      };
      // Readiness attributes change before Solid publishes the control's focus handle.
      // Let that pending reactive commit run before resolving the preferred handle.
      focusObserver = new MutationObserver(() => queueMicrotask(focusWhenReady));
      focusObserver.observe(content, { attributes: true, childList: true, subtree: true, attributeFilter: ['data-ui-ready', 'inert'] });
      focusWhenReady();
    });

    return () => {
      cancelled = true;
      focusObserver?.disconnect();
      const target = untrack(() => props.restoreFocus?.()) ?? previouslyFocused;
      // Closing an underlying modal must not steal focus from a surviving
      // child; a close/reopen before this microtask also cancels stale return.
      if (target && authority) queueMicrotask(() => {
        // Conditional hosts dispose an open dialog instead of setting its
        // local observable false. Disposal must restore focus too.
        if (focusEpoch === epoch && (disposed || !binding.lifetime()) && authority.canRestoreFocus(target) && target.isConnected) target.focus({ preventScroll: true });
      });
      // Keep the opener through a close/reopen in the same turn. A stale return
      // is cancelled by focusEpoch, and a new external opener replaces it.
    };
  });

  return (
      <LayerPortal.View observable={props.observable} surface={{ kind: 'inherit' }} hotkeys={[]}>
        <ModalPortalContext value={scope}>
        <dialog
          ref={element => { overlay = element; }}
          role="presentation"
          data-ui-dialog-overlay=""
          hidden={!open()}
          onCancel={event => {
            // Controlled state decides whether a browser cancel is accepted.
            event.preventDefault();
            if (!content) return;
            const escape = new KeyboardEvent('keydown', { key: 'Escape', cancelable: true });
            const child = binding.authority()?.dispatchChildEscape(escape);
            if (child && child.kind !== 'unclaimed') return;
            if (customEscape && customEscape.handler(escape, content) !== HOTKEY_PASS) return;
            handleKeyDown(escape, content);
          }}
          class={cn(
            "ui-dialog-overlay",
            presentation().backdrop === 'transparent' && 'ui-dialog-backdrop-transparent',
          )}
          style={{ 'z-index': props.layer ?? PORTAL_LAYERS.dialog, 'pointer-events': props.modal === false ? 'none' : undefined }}
          data-state="open"
          onPointerDown={(event) => {
            if (event.target !== event.currentTarget || props.closeOnOutsidePointerDown === false) return;
            if (!binding.authority()?.claimDismissal(event)) return;
            props.onOutsidePointerDown?.(event);
            if (!event.defaultPrevented) {
              // Closing on pointerdown restores the opener before the browser's
              // focus default. Cancel that default so it cannot steal focus back.
              event.preventDefault();
              setOpen(false);
            }
          }}
        >
          <Show when={props.contentLifetime === 'owner' || open()}><Surface
            header={<Show when={props.withoutHeader === false}>
              <header class="ui-dialog-header">
                <span>{props.label ?? props['aria-label'] ?? 'Dialog'}</span>
                <button type="button" class="ui-dialog-close" aria-label="Close" data-dialog="close"
                  onClick={() => { if (binding.authority()?.canDismiss()) setOpen(false); }}><XIcon /></button>
              </header>
            </Show>}
            variant={presentation().variant}
            overflow={presentation().overflow}
            contentClass={dialogContentClass(presentation())}
            onElement={(element) => {
              content = element;
              // Capture before child focus handles run in their settled effects.
              // The lifetime effect may run after one of them has taken focus.
              rememberOpener();
              binding.attach(element);
            }}
            id={props.id}
            role={props.role ?? 'dialog'}
            aria-modal={props.modal === false ? 'false' : 'true'}
            aria-label={props['aria-label'] ?? props.label ?? 'Dialog'}
            aria-labelledby={props['aria-labelledby']}
            aria-describedby={props['aria-describedby']}
            data-surface={props['data-surface']}
            style={{ 'pointer-events': 'auto', '--ui-dialog-panel-width': presentation().recipe === 'drawer'
              ? `${presentation().panelWidth}px` : undefined }}
            class={dialogFrameClass(presentation())}
            onPointerDown={(event) => {
              event.stopPropagation();
              const target = event.composedPath()[0];
              const gap = target === content || (target instanceof HTMLElement
                && target.hasAttribute('data-ui-surface-content') && target.parentElement === content);
              if (presentation().recipe !== 'detached' || !gap || props.closeOnOutsidePointerDown === false
                || !binding.authority()?.claimDismissal(event)) return;
              props.onOutsidePointerDown?.(event);
              if (!event.defaultPrevented) {
                event.preventDefault();
                setOpen(false);
              }
            }}
          >
            {binding.provide(() => props.children)}
          </Surface></Show>
        </dialog>
        </ModalPortalContext>
      </LayerPortal.View>
  );
}

function DialogSurface(props: SurfaceControlProps & { readonly header?: JSX.Element }) {
  return <section ref={props.onElement} id={props.id} role={props.role} aria-modal={props['aria-modal']}
    aria-label={props['aria-label']} aria-labelledby={props['aria-labelledby']} aria-describedby={props['aria-describedby']}
    data-surface={props['data-surface']} data-state="open" tabindex="-1"
    style={{ ...props.style, overflow: props.overflow }}
    class={cn("ui-dialog-ink", props.variant === 'detached' ? "ui-dialog-transparent" : "ui-dialog-surface",
      props.variant !== 'fullscreen' && props.variant !== 'detached' && 'ui-popup-frame', props.class)}
    onPointerDown={props.onPointerDown}>{props.header}<div data-ui-surface-content="" class={props.contentClass}>{props.children}</div></section>;
}

export class Dialog extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: DialogProps) {
    super('Dialog', props);
    this.element = renderDialog(this.capture(props));
  }
  static View = (props: DialogProps): JSX.Element => new Dialog(props).element;
}
