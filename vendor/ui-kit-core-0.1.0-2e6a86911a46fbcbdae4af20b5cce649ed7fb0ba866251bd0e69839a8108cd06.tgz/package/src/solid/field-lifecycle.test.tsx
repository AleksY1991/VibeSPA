/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { fieldFocusHandle, implicitFormSubmission } from './field-lifecycle';

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

it('publishes a focus command outside reactive tracking and revokes it once', async () => {
  const diagnostics = OBSERVE!.diagnostics.capture();
  disposers.push(diagnostics.stop);
  const [ready, setReady] = createSignal(false);
  const [focusAllowed] = createSignal(true);
  const input = document.createElement('input');
  const host = document.createElement('div'); document.body.append(host);
  const received = vi.fn(handle => { if (handle && focusAllowed()) handle.focus(); });
  const dispose = render(() => {
    fieldFocusHandle(() => input, () => received, ready);
    return input;
  }, host);
  disposers.push(dispose);
  await Promise.resolve();
  setReady(true); flush();
  expect(document.activeElement).toBe(input);
  expect(received).toHaveBeenCalledOnce();
  disposers.pop()!();
  expect(received).toHaveBeenLastCalledWith(undefined);
  expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
});

function fixture(withSubmitter = true) {
  const form = document.createElement('form');
  form.id = 'external-form';
  document.body.append(form);
  const mount = document.createElement('div');
  document.body.append(mount);
  const host = document.createElement('span');
  const input = document.createElement('input');
  host.attachShadow({ mode: 'open' }).append(input);
  const submitter = document.createElement('button');
  submitter.type = 'submit';
  submitter.hidden = true;
  submitter.setAttribute('data-ui-form-submitter', '');
  if (withSubmitter) form.append(submitter);
  const submitted = vi.fn((event: Event) => event.preventDefault());
  form.addEventListener('submit', submitted);
  const dispose = render(() => {
    implicitFormSubmission(host, () => input, () => form, () => true);
    return host;
  }, mount);
  disposers.push(dispose);
  const enter = (init: KeyboardEventInit = {}) => {
    const event = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, composed: true, cancelable: true, ...init });
    input.dispatchEvent(event); return event;
  };
  return { form, host, input, submitter, submitted, dispose, enter };
}

describe('form-associated field implicit submission', () => {
  it('activates the native submitter once and respects its cancellation before validation', async () => {
    const { submitter, submitted, enter } = fixture();
    const activated = vi.fn((event: Event) => event.preventDefault());
    submitter.addEventListener('click', activated);
    const event = enter(); await Promise.resolve();
    expect(event.defaultPrevented).toBe(true);
    expect(activated).toHaveBeenCalledOnce();
    expect(submitted).not.toHaveBeenCalled();
  });

  it('lets later ancestor handlers cancel before activating a submitter', async () => {
    const { host, submitter, submitted, enter } = fixture();
    const click = vi.spyOn(submitter, 'click');
    host.parentElement!.addEventListener('keydown', event => event.preventDefault());
    enter(); await Promise.resolve();
    expect(click).not.toHaveBeenCalled(); expect(submitted).not.toHaveBeenCalled();
  });

  it('retains native validation and the externally owned form submitter', async () => {
    const { form, submitter, submitted, enter } = fixture();
    const required = document.createElement('input'); required.required = true; form.prepend(required);
    const activated = vi.fn(); submitter.addEventListener('click', activated);
    enter(); await Promise.resolve();
    expect(activated).toHaveBeenCalledOnce(); expect(submitted).not.toHaveBeenCalled();
    required.value = 'Complete'; enter(); await Promise.resolve();
    expect(activated).toHaveBeenCalledTimes(2); expect(submitted).toHaveBeenCalledOnce();
  });

  it.each([{ ctrlKey: true }, { metaKey: true }, { altKey: true }, { shiftKey: true }, { isComposing: true }])(
    'leaves modified/composing Enter unchanged: %j', async init => {
      const { submitter, enter } = fixture(); const click = vi.spyOn(submitter, 'click');
      const event = enter(init); await Promise.resolve();
      expect(click).not.toHaveBeenCalled(); expect(event.defaultPrevented).toBe(false);
    },
  );

  it('does not replay an Enter action after the field owner is disposed', async () => {
    const { submitter, enter } = fixture(); const click = vi.spyOn(submitter, 'click');
    enter(); disposers.pop()!(); await Promise.resolve(); expect(click).not.toHaveBeenCalled();
  });

  it('submits a buttonless one-field form but not a form with multiple blocking inputs', async () => {
    const { form, submitted, enter } = fixture(false);
    enter(); await Promise.resolve(); expect(submitted).toHaveBeenCalledOnce();
    form.append(document.createElement('input'));
    enter(); await Promise.resolve(); expect(submitted).toHaveBeenCalledOnce();
  });

  it('retains read-only field submission and blocks a disabled submit button', async () => {
    const { input, submitter, submitted, enter } = fixture(); input.readOnly = true;
    enter(); await Promise.resolve(); expect(submitted).toHaveBeenCalledOnce();
    submitter.disabled = true; enter(); await Promise.resolve(); expect(submitted).toHaveBeenCalledOnce();
  });

  it('does not bypass a disabled default submitter to activate a later action', async () => {
    const { form, submitter, submitted, enter } = fixture();
    const later = document.createElement('button'); later.type = 'submit'; form.append(later);
    const activated = vi.fn(); later.addEventListener('click', activated);
    submitter.disabled = true;
    enter(); await Promise.resolve();
    expect(activated).not.toHaveBeenCalled(); expect(submitted).not.toHaveBeenCalled();
  });
});
