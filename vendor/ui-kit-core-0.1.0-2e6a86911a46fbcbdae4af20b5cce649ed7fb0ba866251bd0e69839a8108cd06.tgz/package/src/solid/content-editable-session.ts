import { createEffect, onCleanup, onSettled, untrack, type Accessor } from 'solid-js';
import { HOTKEY_DELEGATE, HOTKEY_PASS } from '../contracts/platform';
import type { ContentEditableActivation, ContentEditableControlProps, ContentEditableHandle, ContentEditableState } from '../contracts/content-editable';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation } from '../infrastructure/activation';

export const INLINE_EDITING_KEYS = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Backspace', 'Delete', 'Space', 'Printable'];

export interface InlineEditorPort {
  readonly element: () => HTMLElement;
  readonly ready: Accessor<boolean>;
  readonly readText: () => string;
  readonly writeText: (text: string, editing: boolean) => void;
  readonly focus: (options?: FocusOptions) => void;
  readonly blur: () => void;
  readonly select: (end: boolean) => void;
  readonly caretAtPoint: (point: { readonly x: number; readonly y: number }) => boolean;
  readonly refreshDraft?: (text: string) => void;
  readonly syncState?: (state: ContentEditableState) => void;
}

export function inlineActivation(event: MouseEvent | KeyboardEvent): ContentEditableActivation {
  return Object.freeze({
    altKey: event.altKey, ctrlKey: event.ctrlKey, metaKey: event.metaKey, shiftKey: event.shiftKey,
    preventDefault: () => event.preventDefault(), stopPropagation: () => event.stopPropagation(),
    clientX: 'clientX' in event ? event.clientX : 0,
    clientY: 'clientY' in event ? event.clientY : 0,
    detail: event.detail,
  });
}

/**
 * Editable labels edit in place and may receive older persistence echoes while a person
 * types. A stock input supplies the browser buffer, selection and IME, but has no
 * app edit session or commit/cancel contract. This shared session retains dirty
 * drafts, isolates editing presses from row activation, and owns single-line Enter
 * and Escape through the app dispatcher. Multiline Enter, selection, clipboard and
 * composition remain browser-owned. The tradeoff is explicit session state in
 * addition to the persisted text; callers must end editing after commit/cancel.
 * Acknowledged writes keep the browser draft editable while pending. Only one
 * submission runs at a time, and refusal or a newer draft rearms submission.
 */
export function inlineEditorSession(props: ContentEditableControlProps, port: InlineEditorPort) {
  let mounted = false;
  let released = false;
  let published = false;
  let editing = false;
  let dirty = false;
  let completed = false;
  let pending = false;
  let commitVersion = 0;
  let draftVersion = 0;
  let composing = false;
  const commit = (disposing = false) => {
    if (!editing || completed || released || !untrack(port.ready)) return;
    if (!disposing && !allowActivation(binding)) return;
    completed = true;
    pending = true;
    const version = ++commitVersion;
    const draft = draftVersion;
    const settle = (accepted: void | boolean) => {
      if (released || version !== commitVersion) return;
      pending = false;
      if (accepted === false || draft !== draftVersion) completed = false;
    };
    // Settle even synchronous refusals in a microtask: Enter's following blur is
    // the same submission, not a second attempt at a rejected write.
    try {
      void Promise.resolve(props.onCommit?.(port.readText())).then(settle, () => settle(false));
    } catch {
      queueMicrotask(() => settle(false));
    }
  };
  const binding: ElementBinding<ContentEditableState> = new ElementBinding('ContentEditable', props, {
    nativeKeys: props.multiline ? [...INLINE_EDITING_KEYS, 'Enter'] : INLINE_EDITING_KEYS,
    // The inline session cancels before a surrounding dialog and owns single-line
    // Enter before a surrounding form submits. Multiline Enter and composition
    // remain native; a form does not turn an inline edit into implicit submission.
    nativeOverrides: props.multiline ? ['Escape'] : ['Escape', 'Enter'],
    builtins: {
      Escape: event => {
        if (composing || event.isComposing) return HOTKEY_PASS;
        if (!editing) return HOTKEY_DELEGATE;
        if (!allowActivation(binding, event)) return HOTKEY_PASS;
        completed = true;
        pending = false;
        commitVersion++;
        props.onCancel?.();
        port.blur();
      },
      Enter: event => {
        if (composing || event.isComposing) return HOTKEY_PASS;
        if (!allowActivation(binding, event)) return HOTKEY_PASS;
        if (!editing) {
          if (binding.value().readonly || !props.onActivate) return HOTKEY_PASS;
          props.onActivate(inlineActivation(event));
        } else {
          if (props.multiline) return HOTKEY_PASS;
          commit();
          port.blur();
        }
      },
      Space: event => {
        if (editing || binding.value().readonly || !props.onActivate) return HOTKEY_PASS;
        if (!allowActivation(binding, event)) return HOTKEY_PASS;
        props.onActivate(inlineActivation(event));
      },
    },
  });
  const guard = () => {
    if (!mounted || released || !untrack(port.ready)) throw new Error('ContentEditable handle is no longer available');
  };
  const handle: ContentEditableHandle = Object.freeze({
    getText: () => { guard(); return editing ? port.readText() : untrack(binding.value).text; },
    focus: (options?: FocusOptions) => { guard(); port.focus(options); },
    blur: () => { guard(); port.blur(); },
    selectAll: () => { guard(); port.select(false); },
    caretEnd: () => { guard(); port.select(true); },
    caretAtPoint: (point: { readonly x: number; readonly y: number }) => {
      guard();
      if (port.caretAtPoint(point)) return true;
      port.select(false);
      return false;
    },
  });
  const focusEntry = () => {
    if (!mounted || released || !untrack(port.ready) || !editing || props.focusOnEdit === undefined || props.focusOnEdit === 'none') return;
    handle.focus();
    if (props.focusOnEdit === 'selectAll') handle.selectAll(); else handle.caretEnd();
  };
  const publishHandle = () => {
    if (!untrack(port.ready) || !mounted || published || released) return;
    published = true;
    untrack(() => props.onHandle?.(handle));
    queueMicrotask(focusEntry);
  };
  createEffect(() => ({ state: binding.value(), ready: port.ready(), placeholder: props.placeholder }), next => {
    const state = next.state;
    const nextEditing = state.editing && !state.readonly;
    const entering = nextEditing && !editing;
    if (nextEditing !== editing) { commitVersion++; pending = false; }
    if (entering) { dirty = false; completed = false; }
    // Removing editability can end an IME session without compositionend. Its
    // unfinished state must not suppress Enter or text synchronization next time.
    if (!nextEditing || entering) composing = false;
    editing = nextEditing;
    untrack(() => port.syncState?.(state));
    // Persistence echoes never replace an active browser draft or its caret.
    if (!editing || (!dirty && !composing)) untrack(() => port.writeText(state.text, editing));
    publishHandle();
    if (entering) queueMicrotask(focusEntry);
  });
  onSettled(() => {
    const target = port.element();
    const pointer = (event: PointerEvent) => { if (allowActivation(binding, event) && editing) event.stopPropagation(); };
    const press = (event: MouseEvent) => {
      if (editing) event.stopPropagation();
      if (untrack(binding.value).readonly) return;
      if (!allowActivation(binding, event)) return;
      props.onPressStart?.(inlineActivation(event));
    };
    const click = (event: MouseEvent) => {
      if (editing) event.stopPropagation();
      if (untrack(binding.value).readonly) return;
      if (!allowActivation(binding, event)) return;
      props.onActivate?.(inlineActivation(event));
    };
    const doubleClick = (event: MouseEvent) => {
      if (!untrack(binding.value).readonly && allowActivation(binding, event)) props.onDoubleActivate?.(inlineActivation(event));
    };
    const input = (event: Event) => {
      if (!editing || released || !untrack(port.ready)) return;
      if (!allowActivation(binding, event)) return;
      dirty = true;
      draftVersion++;
      if (!pending) completed = false;
      const text = port.readText();
      port.refreshDraft?.(text);
      props.onValueChange(text);
    };
    const compositionStart = () => { if (editing) composing = true; };
    const compositionEnd = (event: CompositionEvent) => { composing = false; input(event); };
    const focus = (event: FocusEvent) => { if (allowActivation(binding, event)) props.onFocus?.(); };
    const blur = (event: FocusEvent) => {
      if (event.relatedTarget instanceof Node && target.contains(event.relatedTarget)) return;
      if (!allowActivation(binding, event)) return;
      const text = port.readText();
      commit();
      props.onBlur?.(text);
    };
    target.addEventListener('pointerdown', pointer);
    target.addEventListener('mousedown', press);
    target.addEventListener('click', click);
    target.addEventListener('dblclick', doubleClick);
    target.addEventListener('input', input);
    target.addEventListener('compositionstart', compositionStart);
    target.addEventListener('compositionend', compositionEnd);
    target.addEventListener('focusin', focus);
    target.addEventListener('focusout', blur);
    mounted = true;
    untrack(publishHandle);
    return () => {
      target.removeEventListener('pointerdown', pointer);
      target.removeEventListener('mousedown', press);
      target.removeEventListener('click', click);
      target.removeEventListener('dblclick', doubleClick);
      target.removeEventListener('input', input);
      target.removeEventListener('compositionstart', compositionStart);
      target.removeEventListener('compositionend', compositionEnd);
      target.removeEventListener('focusin', focus);
      target.removeEventListener('focusout', blur);
    };
  });
  onCleanup(() => {
    // Explicit draft persistence is lifecycle cleanup, including after the surface
    // lease has ended; it must not require new activation authority.
    if (props.commitOnDispose) untrack(() => commit(true));
    released = true;
    if (published) untrack(() => props.onHandle?.(undefined));
  });
  return binding;
}
