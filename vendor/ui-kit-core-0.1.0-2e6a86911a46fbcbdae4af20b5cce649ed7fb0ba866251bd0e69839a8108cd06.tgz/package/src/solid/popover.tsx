/** @jsxImportSource @solidjs/web */
import './popover.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import { Show, createEffect, createSignal, untrack, useContext, type Accessor } from 'solid-js';
import type { JSX } from '@solidjs/web';

import { HOTKEY_PASS, type SurfaceAuthority } from '../contracts/platform';
import type { ElementConstruction, ElementSurface } from '../contracts/construction';
import type { ClosedControlPresentation } from '../contracts/presentation';
import { assertControlPresentation } from '../infrastructure/presentation';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { ElementBinding } from '../infrastructure/element';
import { LayerPortal, ModalPortalContext, PORTAL_LAYERS } from './portal';
import {
  containsFocus,
  focusedElement,
  placeFloatingBox,
  tabbableElements,
  type FloatingPlacementOptions,
} from './overlay';

export interface PopoverApi {
  readonly open: Accessor<boolean>;
  readonly contentId: string;
  setOpen(open: boolean): void;
  toggle(): void;
  close(): void;
}

let nextPopoverId = 0;

export type PopoverRecipe = 'popover' | 'picker' | 'content' | 'form' | 'actions';

export interface PopoverProps extends FloatingPlacementOptions, ClosedControlPresentation, Omit<ElementConstruction<boolean>, 'surface'> {
  surface: Extract<ElementSurface, { kind: 'own' }> & { layer: true };

  onOpenChange: (open: boolean) => void;
  trigger: (api: PopoverApi) => JSX.Element;
  children: (api: PopoverApi) => JSX.Element;
  /** Contextual prose, choices, a self-contained control, a form, or secondary actions. */
  recipe?: PopoverRecipe;
  anchorClass?: never;
  padding?: never;
  layout?: never;
  gap?: never;
  overflow?: never;
  matchTriggerWidth?: boolean;
  /** Fit names and controls, using the trigger as a minimum and the viewport as a limit. */
  fitContentWidth?: boolean;
  role?: 'dialog' | 'menu' | 'listbox';
  'aria-label'?: string;
  layer?: number;
  closeOnEscape?: boolean;
  closeOnOutsidePointerDown?: boolean;
  closeOnMouseLeave?: boolean;
}

function renderPopover(props: PopoverProps) {
  assertControlPresentation('Popover', props);
  // WA 3.12 popover.open closes other popovers; wa-popup enters a separate top
  // layer. Keep library placement/dismissal until WA supports independently owned,
  // in-place selectors. The modal scope keeps portals inside their native dialog
  // and delegates Escape to a child before closing its parent. Tab and text
  // editing stay native; the tradeoff is this shared placement/dismissal owner.
  const modalScope = useContext(ModalPortalContext);
  const Surface = requireControlImplementation('PopoverSurface');
  const [position, setPosition] = createSignal({ left: 0, top: 0 });
  const [activationRoots, setActivationRoots] = createSignal<readonly Element[]>([]);
  const contentId = `ui-popover-${++nextPopoverId}`;
  const open = (): boolean => binding.active();
  let anchor: HTMLSpanElement | undefined;
  let panel: HTMLElement | undefined;
  let focusEpoch = 0;
  let pendingActionFocus: {
    readonly panel: HTMLElement;
    readonly active: Element | null;
    readonly authority: SurfaceAuthority | undefined;
    readonly epoch: number;
  } | undefined;
  // The trigger remains rendered while the panel is closed, so its local
  // ownership authorizes opening independently of the panel's popup lease.
  const anchorBinding = new ElementBinding('PopoverTrigger', {
    observable: props.observable, surface: { kind: 'inherit' }, hotkeys: [],
  });

  const setOpen = (next: boolean, restoreActionFocus = false) => {
    if (next === open()) return;
    if (next ? !anchorBinding.canActivate() : !binding.authority()?.canDismiss()) return;
    const closingPanel = panel;
    const authority = binding.authority();
    const epoch = focusEpoch;
    const active = closingPanel ? focusedElement(closingPanel.ownerDocument) : null;
    const returnFocus = !next && restoreActionFocus && props.recipe === 'actions'
      && closingPanel && containsFocus(closingPanel, active);
    pendingActionFocus = returnFocus ? { panel: closingPanel, active, authority, epoch } : undefined;
    props.onOpenChange(next);
    // Completing an action removes its focused command. Wait for controlled
    // close acceptance, but leave a new dialog or explicit command destination
    // in charge of focus. Outside-pointer dismissal never enters this path.
    if (returnFocus) queueMicrotask(restoreCompletedActionFocus);
  };
  const focusAnchor = (authority: SurfaceAuthority | undefined) => {
    const target = anchor && tabbableElements(anchor)[0];
    if (target && authority?.canRestoreFocus(target)) target.focus({ preventScroll: true });
  };
  const restoreCompletedActionFocus = () => {
    const pending = pendingActionFocus;
    if (!pending) return;
    if (binding.isDisposed() || focusEpoch !== pending.epoch) {
      pendingActionFocus = undefined;
      return;
    }
    // A controlled owner may accept asynchronously. Keep the intent while it
    // remains open; a later accepted close resolves it through the lifetime
    // effect below. Parent suspension alone is not acceptance.
    if (untrack(() => binding.value())) return;
    pendingActionFocus = undefined;
    if (untrack(open) || !anchorBinding.isLive()) return;
    const current = focusedElement(pending.panel.ownerDocument);
    if (current !== pending.panel.ownerDocument.body && current !== pending.active
      && !containsFocus(pending.panel, current)) return;
    focusAnchor(pending.authority);
  };
  const positioningAnchor = () => {
    // Retained trigger variants may be hidden, or use a boxless display:contents
    // wrapper. Place against the first visible rendered host, preserving a normal
    // composite trigger's whole-row box rather than a nested remove button.
    const renderedHost = (parent: HTMLElement): HTMLElement | undefined => {
      for (const child of parent.children) {
        if (!(child instanceof HTMLElement) || child.hidden || child.inert) continue;
        const style = child.ownerDocument.defaultView?.getComputedStyle(child);
        if (style?.display === 'none' || style?.visibility === 'hidden' || style?.visibility === 'collapse') continue;
        if (style?.display === 'contents') {
          const descendant = renderedHost(child);
          if (descendant) return descendant;
          continue;
        }
        return child;
      }
    };
    return anchor && (renderedHost(anchor) ?? anchor);
  };
  const updatePosition = () => {
    const target = positioningAnchor();
    if (!binding.lifetime() || !target?.isConnected || !panel?.isConnected) return;
    const ownerWindow = panel.ownerDocument.defaultView;
    if (!ownerWindow) return;
    const viewport = ownerWindow.visualViewport;
    const width = viewport?.width ?? ownerWindow.innerWidth;
    const height = viewport?.height ?? ownerWindow.innerHeight;
    const originX = viewport?.offsetLeft ?? 0;
    const originY = viewport?.offsetTop ?? 0;
    const rect = target.getBoundingClientRect();
    const availableWidth = Math.max(0, width - 2 * (props.margin ?? 8));
    const availableHeight = Math.max(0, height - 2 * (props.margin ?? 8));
    // Publish the placement budget before measurement. Compositions choose their
    // preferred content extent within it, without another viewport subscription.
    panel.style.setProperty('--ui-floating-available-width', `${availableWidth}px`);
    panel.style.setProperty('--ui-floating-available-height', `${availableHeight}px`);
    const fitContentWidth = props.fitContentWidth ?? props.recipe === 'actions';
    panel.style.width = fitContentWidth ? 'max-content' : props.matchTriggerWidth ? `${rect.width}px` : '';
    panel.style.minWidth = fitContentWidth ? `${Math.min(rect.width, availableWidth)}px` : '';
    panel.style.maxWidth = fitContentWidth ? `${availableWidth}px` : '';
    const next = placeFloatingBox(
      { left: rect.left - originX, right: rect.right - originX, top: rect.top - originY,
        bottom: rect.bottom - originY, width: rect.width },
      { width: panel.offsetWidth, height: panel.offsetHeight },
      { width, height },
      { side: props.side, align: props.align, offset: props.offset, margin: props.margin },
    );
    setPosition({ left: Math.round(next.left + originX), top: Math.round(next.top + originY) });
  };

  const api: PopoverApi = {
    open,
    contentId,
    setOpen: next => setOpen(next, true),
    toggle: () => setOpen(!open(), true),
    close: () => setOpen(false, true),
  };

  const handleKeyDown = (event: KeyboardEvent) => {
    const authority = binding.authority();
    if (
      event.key !== 'Escape'
      || props.closeOnEscape === false
      || !authority?.canDismiss(event.target)
    ) return HOTKEY_PASS;
    event.preventDefault();
    event.stopPropagation();
    if (props.recipe === 'actions') setOpen(false, true);
    else {
      setOpen(false);
      focusAnchor(authority);
    }
  };

  const binding = new ElementBinding('Popover', props, {
    activeWhen: (open) => open && (modalScope?.open() ?? true),
    nativeKeys: ['Tab', 'Shift+Tab'],
    builtins: { Escape: handleKeyDown },
    dismissable: true,
    activationRoots,
  });

  // Actual rendered lifetime is published after controlled intent. Subscribe
  // only to that lifecycle fact; the restoration helper samples intent without
  // tracking so one source write cannot mix it with a stale mounted lease.
  createEffect(binding.lifetime, live => {
    if (!live) queueMicrotask(restoreCompletedActionFocus);
  }, { name: 'Popover.actionCompletion' });

  // A retained editor can hide its trigger without disposing this owner. A
  // portal escapes that hidden ancestor, so rendered host loss must close the
  // controlled popup as external DOM lifetime synchronization. Native-modal
  // suspension keeps its existing pinned-child behavior.
  createEffect(() => ({ present: anchorBinding.lifetime(), parentOpen: modalScope?.open() ?? true }), ({ present, parentOpen }) => {
    if (present || !parentOpen) return;
    // Reopening a retained modal publishes its logical state before its native
    // dialog leaves hidden state. Let the host reconcile, then refresh actual
    // presence so that suspension never becomes a controlled child close.
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled || anchorBinding.isLive() || !untrack(() => modalScope?.open() ?? true)) return;
      if (untrack(() => binding.value())) props.onOpenChange(false);
    });
    return () => { cancelled = true; };
  }, { name: 'Popover.anchorPresence' });

  createEffect(() => [binding.lifetime(), props.recipe, props.matchTriggerWidth, props.fitContentWidth, props.margin,
    props.side, props.align, props.offset] as const, ([active]) => {
    if (active) queueMicrotask(updatePosition);
  });

  // Actions use ordinary buttons and native Tab order, not ARIA menu navigation.
  // The body portal cannot supply a nearby sequential entry point, and WA's
  // in-place surface deliberately does not run its own opening focus lifecycle.
  // Keep first-command focus here so hosts do not each replace popup behavior.
  createEffect(() => ({ active: binding.lifetime(), actions: props.recipe === 'actions' }), state => {
    if (!state.active || !state.actions || !panel) return;
    const currentPanel = panel;
    const epoch = ++focusEpoch;
    const originalFocus = focusedElement(currentPanel.ownerDocument);
    let cancelled = false;
    let finished = false;
    const observer = new MutationObserver(() => queueMicrotask(focusWhenReady));
    const focusWhenReady = () => {
      if (cancelled || finished || focusEpoch !== epoch || !binding.isLive() || !currentPanel.isConnected) return;
      if (currentPanel.matches('[data-ui-ready="false"]') || currentPanel.querySelector('[data-ui-ready="false"]')) return;
      const authority = binding.authority();
      if (!authority?.canMoveFocus() || !authority.canDismiss()) return;
      const current = focusedElement(currentPanel.ownerDocument);
      finished = true;
      observer.disconnect();
      if (containsFocus(currentPanel, current)
        || current !== originalFocus && current !== currentPanel.ownerDocument.body) return;
      const command = tabbableElements(currentPanel).find(element => element.getAttribute('aria-disabled') !== 'true');
      (command ?? currentPanel).focus({ preventScroll: true });
    };
    observer.observe(currentPanel, { attributes: true, childList: true, subtree: true,
      attributeFilter: ['data-ui-ready', 'inert'] });
    queueMicrotask(focusWhenReady);
    return () => { cancelled = true; observer.disconnect(); };
  }, { name: 'Popover.actionOpeningFocus' });

  createEffect(binding.lifetime, (active) => {
    const ownerDocument = panel?.ownerDocument;
    const ownerWindow = ownerDocument?.defaultView;
    if (!active || !ownerDocument || !ownerWindow) return;
    queueMicrotask(updatePosition);
    const onPointerDown = (event: PointerEvent) => {
      if (props.closeOnOutsidePointerDown === false) return;
      const target = event.target as Node | null;
      const path = event.composedPath();
      if (path.includes(anchor!) || path.includes(panel!) || (target && (anchor?.contains(target) || panel?.contains(target)))) return;
      if (!binding.authority()?.claimDismissal(event)) return;
      setOpen(false);
    };
    ownerDocument.addEventListener('pointerdown', onPointerDown, true);
    ownerWindow.addEventListener('resize', updatePosition);
    ownerWindow.addEventListener('scroll', updatePosition, true);
    ownerWindow.visualViewport?.addEventListener('resize', updatePosition);
    ownerWindow.visualViewport?.addEventListener('scroll', updatePosition);
    const resizeObserver = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(updatePosition);
    if (panel) resizeObserver?.observe(panel);
    const target = positioningAnchor();
    if (target) resizeObserver?.observe(target);
    return () => {
      ownerDocument.removeEventListener('pointerdown', onPointerDown, true);
      ownerWindow.removeEventListener('resize', updatePosition);
      ownerWindow.removeEventListener('scroll', updatePosition, true);
      ownerWindow.visualViewport?.removeEventListener('resize', updatePosition);
      ownerWindow.visualViewport?.removeEventListener('scroll', updatePosition);
      resizeObserver?.disconnect();
    };
  });

  return (
    <>
      <span
        ref={(element) => { anchor = element; anchorBinding.attach(element); setActivationRoots([element]); }}
        class="ui-popover-anchor"
      >
        {anchorBinding.provide(() => props.trigger(api))}
      </span>
      <Show when={open()}>
        <LayerPortal.View observable={props.observable} surface={{ kind: 'inherit' }} hotkeys={[]}>
          <Surface
            onElement={(element) => { panel = element; binding.attach(element); queueMicrotask(updatePosition); }}
            id={contentId}
            role={props.role ?? 'dialog'}
            aria-label={props['aria-label']}
            data-ui-popover=""
            contentClass={`ui-popover-content ui-popover-content-${props.recipe ?? 'popover'}`}
            class={`ui-popup-frame ui-popover-surface ui-popover-surface-${props.recipe ?? 'popover'}`}
            style={{
              left: `${position().left}px`,
              top: `${position().top}px`,
              'z-index': props.layer ?? PORTAL_LAYERS.popover,
            }}
            onPointerLeave={(event) => {
              if (props.closeOnMouseLeave && event.pointerType === 'mouse') setOpen(false);
            }}
            onPointerDown={(event) => event.stopPropagation()}
          >
            {binding.provide(() => props.children(api))}
          </Surface>
        </LayerPortal.View>
      </Show>
    </>
  );
}

export class Popover extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: PopoverProps) {
    super('Popover', props);
    this.element = renderPopover(this.capture(props));
  }
  static View = (props: PopoverProps): JSX.Element => new Popover(props).element;
}
