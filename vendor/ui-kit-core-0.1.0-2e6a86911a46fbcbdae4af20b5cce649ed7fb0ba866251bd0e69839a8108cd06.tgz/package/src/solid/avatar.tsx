/** @jsxImportSource @solidjs/web */
import type { JSX } from '@solidjs/web';
import { type AvatarControlProps, type AvatarValue } from '../contracts/avatar';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { RenderedElement } from '../infrastructure/rendered-element';
import './avatar.css';

export interface AvatarProps extends Omit<AvatarControlProps, 'value' | 'onElement'>, ElementConstruction<AvatarValue> {
  
}

function renderAvatar(props: AvatarProps) {
  const binding = new ElementBinding('Avatar', props, { nativeKeys: [] });
  const Implementation = requireControlImplementation('Avatar');
  return <Implementation {...props} value={binding.value()} onElement={binding.attach} />;
}

export class Avatar extends RenderedElement<AvatarValue> {
  readonly element: JSX.Element;
  constructor(props: AvatarProps) {
    super('Avatar', props);
    this.element = renderAvatar(this.capture(props));
  }
  static View = (props: AvatarProps): JSX.Element => new Avatar(props).element;
}
