/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Show, createSignal, flush, onCleanup } from 'solid-js';
import { renderPrepared as render } from '../../tests/prepared';

import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { HOTKEY_DELEGATE, HOTKEY_PASS } from '../contracts/platform';
import { constructItem } from '../infrastructure/construction';
import { Button } from './button';
import { Dialog, type DialogDrawerState } from './dialog';
import { Popover } from './popover';
import { TextField } from './text-field';
import { LayerPortal, ModalPortalContext, createModalPortalScope, modalPortalMountForAnchor } from './portal';
import { authoredStyle, useStyles } from '../../tests/styles';

useStyles('solid/dialog.css');

const settle = async () => {
  for (let pass = 0; pass < 48; pass++) { flush(); await Promise.resolve(); }
};

const dialogState = (name: string, initial = true, change?: (open: boolean) => void) => {
  const [open, setOpen] = createSignal(initial);
  return constructItem(name, (item) => ({
    observable: item.observe('open', open),
    surface: { kind: 'own', name, transparent: false, layer: true } as const,
    hotkeys: [],
    onOpenChange: (next: boolean) => { change?.(next); setOpen(next); },
  }));
};

let detachDispatcher: (() => void) | undefined;
beforeEach(() => {
  detachDispatcher = attachDispatcher({
    window,
    document,
    registry: surfaceRegistry,
    commands: { dispatch: () => {} },
    runtime: () => ({ editing: false, keyboardLayer: null }),
  });
});

afterEach(() => {
  detachDispatcher?.();
  detachDispatcher = undefined;
  document.body.replaceChildren();
  document.body.removeAttribute('style');
});

describe('Solid Dialog', () => {
  it.each([
    ['dialog', '16px', 16, '32rem'],
    ['detached', '24px', 16, 'none'],
    ['form', '0px', 0, '32rem'],
    ['editor', '0px', 0, '32rem'],
    ['media', '0px', 0, '48rem'],
    ['drawer', '0px', 0, 'none'],
    ['fullscreen', '0px', 0, 'none'],
  ] as const)('keeps %s content spacing and frame bounds recipe-owned', async (recipe, padding, gap, maxWidth) => {
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const state = dialogState(`test.spacing.${recipe}`);
      const drawer = constructItem(`test.spacing.${recipe}.drawer`, item => item.constant('panel', { width: 400 }));
      const presentation = recipe === 'drawer' ? { recipe, drawer } : { recipe };
      return <Dialog.View {...state} {...presentation} label="Recipe spacing"><button>Apply</button></Dialog.View>;
    }, host);
    try {
      await settle();
      const panel = document.querySelector<HTMLElement>('[role="dialog"]')!;
      const content = panel.querySelector<HTMLElement>('[data-ui-surface-content]')!;
      expect(getComputedStyle(content).padding).toBe(padding);
      expect(Number.parseFloat(getComputedStyle(content).gap)).toBe(gap);
      expect(authoredStyle(panel, 'max-width')).toBe(maxWidth);
    } finally { dispose(); }
  });

  it('lets the explicit initial focus target take precedence over native autofocus', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const showModal = vi.spyOn(HTMLDialogElement.prototype, 'showModal').mockImplementation(function (this: HTMLDialogElement) {
      this.open = true;
      // Happy DOM omits the browser's synchronous dialog autofocus algorithm.
      this.querySelector<HTMLInputElement>('input')?.focus();
    });
    let preferred!: HTMLInputElement;
    const dispose = render(() => {
      const state = dialogState('test.nativeAutofocus');
      return <Dialog.View {...state} label="Explicit focus" initialFocus={() => preferred}>
        <input aria-label="First" /><input ref={element => { preferred = element; }} aria-label="Preferred" />
      </Dialog.View>;
    }, host);
    try {
      await settle();
      expect(document.activeElement).toBe(preferred);
    } finally { dispose(); showModal.mockRestore(); }
  });

  it('waits for an initially absent preferred handle after native modality opens', async () => {
    const host = document.createElement('div');
    const opener = document.createElement('button'); document.body.append(opener, host); opener.focus();
    const nativeShow = HTMLDialogElement.prototype.showModal;
    const inertAtOpen: boolean[] = [];
    const showModal = vi.spyOn(HTMLDialogElement.prototype, 'showModal').mockImplementation(function (this: HTMLDialogElement) {
      inertAtOpen.push(this.inert);
      nativeShow.call(this);
    });
    let preferred!: HTMLInputElement;
    let ready = false;
    const dispose = render(() => {
      const state = dialogState('test.absentInitialFocus');
      return <Dialog.View {...state} label="Delayed preferred focus" initialFocus={() => ready ? preferred : undefined}>
        <input aria-label="First" /><input ref={element => { preferred = element; }} aria-label="Preferred" />
      </Dialog.View>;
    }, host);
    try {
      await settle();
      expect(inertAtOpen).toEqual([true]);
      expect(document.activeElement).not.toBe(preferred);
      ready = true;
      preferred.setAttribute('data-ui-ready', 'true');
      await vi.waitFor(async () => { await settle(); expect(document.activeElement).toBe(preferred); });
    } finally { dispose(); showModal.mockRestore(); }
  });

  it.each(['state', 'host'] as const)('restores the opener after child handle focus and %s closure', async closure => {
    const host = document.createElement('div');
    const opener = document.createElement('button');
    document.body.append(opener, host); opener.focus();
    const [open, setOpen] = createSignal(true);
    const [shown, setShown] = createSignal(true);
    const dispose = render(() => {
      const controls = constructItem('dialog.childFocus', item => ({ open: item.observe('open', open), value: item.constant('value', '') }));
      return <Show when={shown()}><Dialog.View observable={controls.open}
        surface={{ kind: 'own', name: 'test.childFocus', transparent: false, layer: true }} hotkeys={[]}
        label="Child focus" onOpenChange={setOpen}>
        <TextField.View observable={controls.value} surface={{ kind: 'inherit' }} hotkeys={[]} label="First field"
          onHandle={handle => handle?.focus()} onValueChange={() => {}} />
      </Dialog.View></Show>;
    }, host);
    try {
      flush(); await settle();
      await vi.waitFor(() => { flush(); const field = document.querySelector('wa-input') as HTMLElement & { input: HTMLInputElement }; expect(field?.input).toBeDefined(); expect(field.shadowRoot?.activeElement).toBe(field.input); });
      if (closure === 'state') setOpen(false); else setShown(false);
      flush(); await settle(); await settle();
      expect(document.activeElement).toBe(opener);
    } finally { dispose(); }
  });

  it('keeps workspace focus when a pinned panel closes after focus moved outside it', async () => {
    const host = document.createElement('div');
    const opener = document.createElement('button');
    const workspace = document.createElement('input');
    document.body.append(opener, workspace, host);
    opener.focus();
    const [open, setOpen] = createSignal(true);
    const dispose = render(() => {
      const observable = constructItem('dialog.pinnedFocusReturn', item => item.observe('open', open));
      return <Dialog.View observable={observable} surface={{ kind: 'own', name: 'test.pinnedFocusReturn', transparent: false, layer: true }}
        hotkeys={[]} modal={false} label="Pinned panel" onOpenChange={setOpen}><button>Panel action</button></Dialog.View>;
    }, host);
    try {
      flush(); await settle();
      workspace.focus();
      setOpen(false); flush(); await settle();
      expect(document.activeElement).toBe(workspace);
    } finally { dispose(); }
  });

  it('releases scroll and keyboard effects while its retained rendered host is hidden', async () => {
    const host = document.createElement('div');
    const background = document.createElement('button');
    document.body.append(background, host);
    const requests = vi.fn();
    const dispose = render(() => {
      const dialog = dialogState('test.hiddenHost', true, requests);
      return <Dialog.View {...dialog} modal aria-label="Hidden host"><button>Inside</button></Dialog.View>;
    }, host);
    try {
      flush(); await settle();
      const panel = document.querySelector<HTMLElement>('[aria-label="Hidden host"]')!;
      expect(document.body.style.overflow).toBe('hidden');
      panel.hidden = true;
      await vi.waitFor(() => {
        flush();
        expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'test.hiddenHost')).toBe(false);
        expect(document.body.style.overflow).toBe('');
      });
      background.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      expect(requests).not.toHaveBeenCalled();
      panel.hidden = false;
      await vi.waitFor(() => {
        flush();
        expect(document.querySelector('[aria-label="Hidden host"]')).toBe(panel);
        expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.hiddenHost')).toHaveLength(1);
        expect(document.body.style.overflow).toBe('hidden');
      });
    } finally { dispose(); }
  });

  it('contains Tab across opaque controls and an owned popover while Escape dismisses the popover first', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const dialog = dialogState('test.focusOwner');
      const popover = dialogState('test.focusChild');
      const control = constructItem('dialog.focusControl', item => item.constant('state', {}));
      return <Dialog.View {...dialog} modal aria-label="Focus owner">
        <Button.View observable={control} surface={{ kind: 'own', name: 'test.focusFirst', transparent: false }}
          hotkeys={[{ key: 'Escape', handler: () => HOTKEY_DELEGATE }]} id="focus-first">First</Button.View>
        <Popover.View {...popover} trigger={api => <button onClick={api.toggle}>Options</button>}>
          {() => <Button.View observable={control} surface={{ kind: 'own', name: 'test.focusLast', transparent: false }}
            hotkeys={[{ key: 'Escape', handler: () => HOTKEY_DELEGATE }]} id="focus-last">Choice</Button.View>}
        </Popover.View>
      </Dialog.View>;
    }, host);
    try {
      flush(); await settle();
      const dialog = document.querySelector<HTMLElement>('[aria-label="Focus owner"]')!;
      const first = document.getElementById('focus-first')!;
      const last = document.getElementById('focus-last')!;
      const overlay = dialog.parentElement!;
      expect(overlay.contains(last)).toBe(true);
      expect(dialog.contains(last)).toBe(false);
      expect(modalPortalMountForAnchor(first)).toBe(overlay);
      expect(modalPortalMountForAnchor(last)).toBe(overlay);
      expect(getComputedStyle(overlay).position).toBe('fixed');
      expect(getComputedStyle(overlay).transform).not.toContain('translate');
      expect(document.activeElement).toBe(first);
      last.focus();
      const tab = new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true });
      last.dispatchEvent(tab);
      expect(tab.defaultPrevented).toBe(true);
      expect(document.activeElement).toBe(first);
      const reverseTab = new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, bubbles: true, cancelable: true });
      first.dispatchEvent(reverseTab);
      expect(reverseTab.defaultPrevented).toBe(true);
      expect(document.activeElement).toBe(last);
      last.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      flush(); await settle();
      expect(document.querySelector('[data-ui-popover]')).toBeNull();
      expect(document.querySelector('[aria-label="Focus owner"]')).toBe(dialog);
      first.focus();
      first.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      flush(); await settle();
      expect(document.querySelector('[aria-label="Focus owner"]')).toBeNull();
    } finally { dispose(); }
  });

  it('releases a retained fallback dialog when its modal parent hides and restores one host lease on reopening', async () => {
    const host = document.createElement('div');
    const background = document.createElement('button');
    document.body.append(background, host);
    const [parentOpen, setParentOpen] = createSignal(true);
    let dismissals = 0;
    const scope = createModalPortalScope(() => undefined, parentOpen);
    const dispose = render(() => {
      const dialog = dialogState('test.retainedFallback', true, () => { dismissals++; });
      return <ModalPortalContext value={scope}>
        <Dialog.View {...dialog} modal aria-label="Retained fallback"><button>Inside</button></Dialog.View>
      </ModalPortalContext>;
    }, host);
    try {
      for (let round = 0; round < 3; round++) {
        flush(); await settle();
        expect(document.querySelector('[aria-label="Retained fallback"]')).not.toBeNull();
        expect(document.body.style.overflow).toBe('hidden');
        expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.retainedFallback')).toHaveLength(1);
        setParentOpen(false); flush(); await settle();
        expect(document.querySelector('[aria-label="Retained fallback"]')).toBeNull();
        expect(document.body.style.overflow).toBe('');
        expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.retainedFallback')).toHaveLength(0);
        background.focus();
        background.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
        expect(dismissals).toBe(0);
        setParentOpen(true);
      }
    } finally { dispose(); }
  });

  it('shares logical visibility with a retained portal parent', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const [visible, setVisible] = createSignal(true);
    const dispose = render(() => {
      const parent = constructItem('dialog.portalVisibility', item => item.observe('visible', visible));
      const dialog = dialogState('test.portalFallback');
      return <LayerPortal.View observable={parent} surface={{ kind: 'own', name: 'test.retainedPortal', transparent: false }} hotkeys={[]}>
        <Dialog.View {...dialog} modal aria-label="Portal fallback"><button>Inside</button></Dialog.View>
      </LayerPortal.View>;
    }, host);
    try {
      flush(); await settle();
      expect(document.querySelector('[aria-label="Portal fallback"]')).not.toBeNull();
      setVisible(false); flush(); await settle();
      expect(document.querySelector('[aria-label="Portal fallback"]')).toBeNull();
      expect(document.body.style.overflow).toBe('');
      expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'test.portalFallback')).toBe(false);
      setVisible(true); flush(); await settle();
      expect(document.querySelector('[aria-label="Portal fallback"]')).not.toBeNull();
      expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.portalFallback')).toHaveLength(1);
    } finally { dispose(); }
  });

  it('samples the current focus target when an effect closes the dialog', async () => {
    const host = document.createElement('div');
    const target = document.createElement('button'); document.body.append(target, host);
    const [open, setOpen] = createSignal(true);
    const [focusTarget] = createSignal(target);
    const dispose = render(() => {
      const observable = constructItem('dialog.focusSnapshot', item => item.observe('open', open));
      return <Dialog.View observable={observable} surface={{ kind: 'own', name: 'test.focusSnapshot', transparent: false, layer: true }} hotkeys={[]}
        label="Focus snapshot" restoreFocus={focusTarget} onOpenChange={setOpen}><button>Inside</button></Dialog.View>;
    }, host);
    try {
      flush(); await settle();
      setOpen(false); flush(); await settle();
      expect(document.activeElement).toBe(target);
    } finally { dispose(); }
  });
  it('switches modality without replacing content or intercepting background keys while pinned', async () => {
    const host = document.createElement('div');
    const workspace = document.createElement('button'); document.body.append(workspace, host);
    const [modal, setModal] = createSignal(true);
    const dispose = render(() => {
      const construction = dialogState('test.pinnable');
      return <Dialog.View {...construction} modal={modal()} closeOnOutsidePointerDown={modal()} aria-label="Pinnable">
        <textarea aria-label="Draft" /><button>Last control</button>
      </Dialog.View>;
    }, host);
    await settle();
    const panel = document.querySelector<HTMLElement>('[aria-label="Pinnable"]')!;
    const editor = panel.querySelector('textarea')!;
    editor.value = 'Draft'; editor.focus(); editor.setSelectionRange(1, 3);
    setModal(false); await settle();
    expect(document.querySelector('textarea')).toBe(editor);
    expect(editor.selectionStart).toBe(1); expect(editor.selectionEnd).toBe(3);
    expect(panel.getAttribute('aria-modal')).toBe('false');
    expect(panel.parentElement!.style.pointerEvents).toBe('none');
    expect(panel.style.pointerEvents).toBe('auto');
    expect(document.body.style.overflow).toBe('');
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.pinnable')).toMatchObject([{ layer: false }]);
    workspace.focus();
    workspace.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true })); await settle();
    expect(document.querySelector('[aria-label="Pinnable"]')).toBe(panel);
    expect(document.activeElement).toBe(workspace);
    const last = panel.querySelector('button')!; last.focus();
    const tab = new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true }); last.dispatchEvent(tab);
    expect(tab.defaultPrevented).toBe(false);
    setModal(true); await settle();
    expect(panel.getAttribute('aria-modal')).toBe('true');
    expect(document.body.style.overflow).toBe('hidden');
    expect(document.querySelector('textarea')).toBe(editor);
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.pinnable')).toMatchObject([{ layer: true }]);
    last.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true }));
    expect(document.activeElement).toBe(editor);
    editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true })); await settle();
    expect(document.querySelector('[aria-label="Pinnable"]')).toBeNull();
    expect(document.body.style.overflow).toBe('');
    dispose();
  });
  it('changes fixed presentation recipes without replacing a retained editor or its surface', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const [recipe, setRecipe] = createSignal<'dialog' | 'editor' | 'fullscreen'>('dialog');
    const cleaned = vi.fn();
    const Draft = () => { onCleanup(cleaned); return <textarea aria-label="Recipe draft" />; };
    const dispose = render(() => {
      const construction = dialogState('test.recipeLifetime');
      return <Dialog.View {...construction} recipe={recipe()} label="Recipe editor"><Draft /></Dialog.View>;
    }, host);
    await settle();
    const panel = document.querySelector<HTMLElement>('[role="dialog"]')!;
    const overlay = panel.closest('dialog')!;
    const editor = panel.querySelector('textarea')!;
    editor.value = 'Unsubmitted draft'; editor.focus(); editor.setSelectionRange(2, 8);
    for (const next of ['editor', 'fullscreen', 'dialog'] as const) {
      setRecipe(next); await settle();
      expect(document.querySelector('[role="dialog"]')).toBe(panel);
      expect(panel.closest('dialog')).toBe(overlay);
      expect(panel.querySelector('textarea')).toBe(editor);
      expect(editor.value).toBe('Unsubmitted draft');
      expect(editor.selectionStart).toBe(2); expect(editor.selectionEnd).toBe(8);
      expect(document.activeElement).toBe(editor);
      expect(panel.classList.contains(`ui-dialog-recipe-${next}`)).toBe(true);
      expect(cleaned).not.toHaveBeenCalled();
      expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.recipeLifetime')).toHaveLength(1);
    }
    dispose();
    expect(cleaned).toHaveBeenCalledOnce();
  });

  it('keeps detached panel interactions inside the modal and dismisses from the transparent gap', async () => {
    const root = document.createElement('div');
    const opener = document.createElement('button');
    document.body.append(opener, root);
    opener.focus();
    const changes: boolean[] = [];
    const dispose = render(() => {
      const construction = dialogState('test.detached', true, open => changes.push(open));
      return <Dialog.View {...construction} recipe="detached" aria-label="Detached settings">
        <aside><button>Category</button></aside><section><button>Setting</button></section>
      </Dialog.View>;
    }, root);
    await settle();
    const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!;
    dialog.querySelector('section')!.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
    expect(changes).toEqual([]);
    dialog.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    await settle();
    expect(changes).toEqual([false]);
    expect(document.querySelector('[role="dialog"]')).toBeNull();
    expect(document.activeElement).toBe(opener);
    dispose();
  });

  it('restores the opener when a conditional host disposes a still-open dialog', async () => {
    const root = document.createElement('div');
    const opener = document.createElement('button');
    document.body.append(opener, root);
    opener.focus();
    const [visible, setVisible] = createSignal(true);
    function OpenDialog() {
      const observable = constructItem('conditionalDialog', item => item.constant('open', true));
      return <Dialog.View observable={observable}
        surface={{ kind: 'own', name: 'test.conditionalDialog', transparent: false, layer: true }}
        hotkeys={[]} label="Conditional dialog" onOpenChange={() => setVisible(false)}><button>Inside</button></Dialog.View>;
    }
    const dispose = render(() => <Show when={visible()}><OpenDialog /></Show>, root);
    await settle();
    expect(document.activeElement?.textContent).toBe('Inside');
    setVisible(false);
    await settle();
    await settle();
    expect(document.querySelector('[role="dialog"]')).toBeNull();
    expect(document.activeElement).toBe(opener);
    dispose();
  });

  it('uses the public label and does not restore focus beneath a surviving child overlay', async () => {
    const root = document.createElement('div');
    const trigger = document.createElement('button');
    document.body.append(trigger, root);
    trigger.focus();
    const [parentOpen, setParentOpen] = createSignal(true);
    const [childOpen, setChildOpen] = createSignal(false);
    const dispose = render(() => {
      const parent = constructItem('parentFocus', item => item.observe('open', parentOpen));
      const child = constructItem('childFocus', item => item.observe('open', childOpen));
      return <>
        <Dialog.View observable={parent} surface={{ kind: 'own', name: 'test.parentFocus', transparent: false, layer: true }}
          hotkeys={[]} label="Parent label" onOpenChange={setParentOpen}><button>Parent action</button></Dialog.View>
        <Dialog.View observable={child} surface={{ kind: 'own', name: 'test.childFocus', transparent: false, layer: true }}
          hotkeys={[]} label="Child label" onOpenChange={setChildOpen}><button id="surviving-child">Child action</button></Dialog.View>
      </>;
    }, root);
    await settle();
    expect(document.querySelector('[role="dialog"]')?.getAttribute('aria-label')).toBe('Parent label');
    setChildOpen(true);
    await settle();
    expect(document.activeElement?.id).toBe('surviving-child');
    setParentOpen(false);
    await settle();
    await settle();
    expect(document.activeElement?.id).toBe('surviving-child');
    dispose();
  });

  it('keeps observable open state authoritative when its command does not accept dismissal', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const requests: boolean[] = [];
    const dispose = render(() => {
      const observable = constructItem('readonlyDialog', (item) => item.constant('open', true));
      return <Dialog.View observable={observable}
        surface={{ kind: 'own', name: 'test.readonlyDialog', transparent: false, layer: true }} hotkeys={[]}
        onOpenChange={(next) => requests.push(next)} aria-label="Read only dialog"><button>Inside</button></Dialog.View>;
    }, host);
    await settle();
    document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
    await settle();
    expect(requests).toEqual([false]);
    expect(document.querySelector('[aria-label="Read only dialog"]')).not.toBeNull();
    expect(surfaceRegistry.read().activeSurfaces.filter((surface) => surface.name === 'test.readonlyDialog')).toHaveLength(1);
    dispose();
    await settle();
    expect(surfaceRegistry.read().activeSurfaces.filter((surface) => surface.name === 'test.readonlyDialog')).toHaveLength(0);
  });

  it('composes custom Escape with dismissal and never accumulates registrations across reopening', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    let setOpen!: (next: boolean) => void;
    let intercepted = 0;
    const dispose = render(() => {
      const [open, writeOpen] = createSignal(false);
      setOpen = writeOpen;
      const observable = constructItem('reopenedDialog', (item) => item.observe('open', open));
      return <Dialog.View observable={observable}
        surface={{ kind: 'own', name: 'test.reopenedDialog', transparent: false, layer: true }}
        hotkeys={[{ key: 'Escape', handler: () => { intercepted++; return HOTKEY_PASS; } }]}
        onOpenChange={writeOpen} aria-label="Reopened dialog"><button>Inside</button></Dialog.View>;
    }, host);
    for (let round = 0; round < 5; round++) {
      setOpen(true);
      await settle();
      expect(surfaceRegistry.read().activeSurfaces.filter((surface) => surface.name === 'test.reopenedDialog')).toHaveLength(1);
      document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
      await settle();
      expect(document.querySelector('[aria-label="Reopened dialog"]')).toBeNull();
      expect(surfaceRegistry.read().activeSurfaces.filter((surface) => surface.name === 'test.reopenedDialog')).toHaveLength(0);
    }
    expect(intercepted).toBe(5);
    dispose();
  });

  it('portals an accessible controlled dialog, traps focus, closes on Escape, and restores focus', async () => {
    const trigger = document.createElement('button');
    trigger.textContent = 'Open';
    document.body.append(trigger);
    trigger.focus();
    const host = document.createElement('div');
    document.body.append(host);
    let openDialog!: () => void;

    const dispose = render(() => {
      const [open, setOpen] = createSignal(false);
      const observable = constructItem('controlledDialog', (item) => item.observe('open', open));
      openDialog = () => setOpen(true);
      return (
        <Dialog.View
          surface={{ kind: 'own', name: 'test.controlledDialog', transparent: false, layer: true }}
          observable={observable}
          hotkeys={[]}
          onOpenChange={setOpen}
          aria-labelledby="dialog-title"
          aria-describedby="dialog-description"
        >
          <h2 id="dialog-title">Confirm</h2>
          <p id="dialog-description">Review the change.</p>
          <button id="cancel">Cancel</button>
          <button id="confirm">Confirm</button>
        </Dialog.View>
      );
    }, host);

    openDialog();
    await settle();
    const dialog = document.body.querySelector<HTMLElement>('[role="dialog"]');
    expect(dialog).not.toBeNull();
    expect(host.querySelector('[role="dialog"]')).toBeNull();
    expect(dialog?.getAttribute('aria-modal')).toBe('true');
    expect(dialog?.getAttribute('aria-labelledby')).toBe('dialog-title');
    expect(authoredStyle(dialog!, 'background-color')).toBe('hsl(var(--ui-background))');
    expect(document.body.style.overflow).toBe('hidden');
    expect(document.activeElement?.id).toBe('cancel');

    document.querySelector<HTMLElement>('#confirm')?.focus();
    document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true }));
    expect(document.activeElement?.id).toBe('cancel');

    document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }));
    await settle();
    expect(document.body.querySelector('[role="dialog"]')).toBeNull();
    expect(document.body.style.overflow).toBe('');
    await settle();
    expect(document.activeElement).toBe(trigger);
    dispose();
  });

  it('writes outside-pointer dismissal through the constructed open binding', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const changes: boolean[] = [];
    const dispose = render(() => {
      const construction = dialogState('test.outsideDialog', true, (open) => changes.push(open));
      return (
        <Dialog.View {...construction} aria-label="Outside dialog">
          <button>Inside</button>
        </Dialog.View>
      );
    }, host);
    await settle();
    const overlay = document.body.querySelector<HTMLElement>('[data-state="open"]');
    const outsidePress = new PointerEvent('pointerdown', { bubbles: true, cancelable: true });
    overlay?.dispatchEvent(outsidePress);
    expect(outsidePress.defaultPrevented).toBe(true);
    await settle();
    expect(changes).toEqual([false]);
    expect(document.body.querySelector('[role="dialog"]')).toBeNull();
    dispose();
  });

  it('uses the bounded editor recipe for clipping without presentation overrides', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dispose = render(() => {
      const construction = dialogState('test.mediaDialog');
      return <Dialog.View {...construction} recipe="editor"
        aria-label="Attachment preview"><img alt="Preview" /></Dialog.View>;
    }, host);
    await settle();
    const panel = document.querySelector<HTMLElement>('[role="dialog"]')!;
    expect(panel.style.overflow).toBe('hidden');
    expect(panel.classList.contains('ui-dialog-recipe-editor')).toBe(true);
    expect(panel.classList.contains('ui-dialog-height-viewport')).toBe(true);
    expect(panel.querySelector('[data-ui-surface-content]')!.classList.contains('ui-dialog-padding-none')).toBe(true);
    dispose();
  });

  it('keeps the drawer editor and surface while resizing and expanding its live panel model', async () => {
    const host = document.createElement('div'); document.body.append(host);
    let setDrawer!: (next: DialogDrawerState) => void;
    let editor!: HTMLTextAreaElement;
    let cleanups = 0;
    const Content = () => {
      onCleanup(() => { cleanups++; });
      return <textarea ref={element => { editor = element; }} aria-label="Drawer draft" />;
    };
    const dispose = render(() => {
      const [panel, writePanel] = createSignal<DialogDrawerState>({ width: 480 });
      setDrawer = writePanel;
      const model = constructItem('drawer.model', item => item.observe('panel', panel));
      const construction = dialogState('test.drawer');
      return <Dialog.View {...construction} recipe="drawer" drawer={model}
        aria-label="Resizable drawer"><Content /></Dialog.View>;
    }, host);
    try {
      await settle();
      const panel = document.querySelector<HTMLElement>('[aria-label="Resizable drawer"]')!;
      const overlay = document.querySelector('dialog[data-ui-dialog-overlay]');
      const surface = surfaceRegistry.read().activeSurfaces.find(value => value.name === 'test.drawer')?.instanceId;
      expect(surface).toBeDefined();
      editor.value = 'Retained draft'; editor.focus(); editor.setSelectionRange(2, 7);
      const originalEditor = editor;
      for (const next of [{ width: 768 }, { width: 768, expanded: true }, { width: 320, expanded: false }]) {
        setDrawer(next); await settle();
        expect(document.querySelector('[aria-label="Resizable drawer"]')).toBe(panel);
        expect(document.querySelector('dialog[data-ui-dialog-overlay]')).toBe(overlay);
        expect(panel.querySelector('textarea')).toBe(originalEditor);
        expect(editor.value).toBe('Retained draft');
        expect([editor.selectionStart, editor.selectionEnd]).toEqual([2, 7]);
        expect(document.activeElement).toBe(editor);
        expect(surfaceRegistry.read().activeSurfaces.find(value => value.name === 'test.drawer')?.instanceId).toBe(surface);
        expect(panel.classList.contains('ui-dialog-variant-fullscreen')).toBe(next.expanded === true);
        expect(panel.style.getPropertyValue('--ui-dialog-panel-width')).toBe(`${next.width}px`);
        expect(cleanups).toBe(0);
      }
    } finally { dispose(); }
    expect(cleanups).toBe(1);
    expect(surfaceRegistry.read().activeSurfaces.some(value => value.name === 'test.drawer')).toBe(false);
  });

  it('waits for asynchronous controls before resolving a public initial focus handle', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    let field!: HTMLButtonElement;
    let ready = false;
    const dispose = render(() => {
      const construction = dialogState('test.readyDialog');
      return <Dialog.View {...construction} aria-label="Ready dialog"
        initialFocus={() => ready ? { focus: () => field.focus(), blur: () => field.blur() } : undefined}>
        <button>Close</button>
        <button ref={(element) => { field = element; }} data-ui-ready="false" inert>Category</button>
      </Dialog.View>;
    }, host);
    await settle();
    expect(document.activeElement).not.toBe(field);
    field.removeAttribute('inert');
    field.setAttribute('data-ui-ready', 'true');
    queueMicrotask(() => { ready = true; });
    for (let pass = 0; pass < 4; pass++) { flush(); await settle(); }
    expect(document.activeElement).toBe(field);
    dispose();
  });

  it('lets the top popover own the first outside press without also dismissing its dialog', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const dialogChanges: boolean[] = [];
    const dispose = render(() => {
      const construction1 = dialogState('test.parentDialog', true, (open) => dialogChanges.push(open));
      const construction2 = dialogState('test.childPopover');
      return (
        <Dialog.View {...construction1} aria-label="Parent dialog">
          <Popover.View
            {...construction2}
            trigger={(api) => <button onClick={api.toggle}>Options</button>}
          >
            {() => <button>Choice</button>}
          </Popover.View>
        </Dialog.View>
      );
    }, host);
    await settle();

    const overlay = document.body.querySelector<HTMLElement>('[aria-label="Parent dialog"]')?.parentElement;
    overlay?.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    await settle();
    expect(document.body.querySelector('[data-ui-popover]')).toBeNull();
    expect(document.body.querySelector('[aria-label="Parent dialog"]')).not.toBeNull();
    expect(dialogChanges).toEqual([]);

    overlay?.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    await settle();
    expect(document.body.querySelector('[aria-label="Parent dialog"]')).toBeNull();
    expect(dialogChanges).toEqual([false]);
    dispose();
  });
});
