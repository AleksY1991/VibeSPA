/** @jsxImportSource @solidjs/web */
import { omit, onCleanup, onSettled, untrack } from 'solid-js';
import { Dynamic, type JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import type { FocusHandle } from '../contracts/controls';
import { ElementBinding } from '../infrastructure/element';
import { RenderedElement } from '../infrastructure/rendered-element';

export interface MediaState {
  readonly src: string | undefined;
}

export interface MediaHandle extends FocusHandle {
  currentTime(): number;
  duration(): number;
  setCurrentTime(seconds: number): void;
  play(): Promise<void>;
  pause(): void;
}

type MediaPresentation = Omit<JSX.VideoHTMLAttributes<HTMLVideoElement>,
  'ref' | 'src' | Extract<keyof JSX.VideoHTMLAttributes<HTMLVideoElement>, `on${string}`>>;

export interface MediaProps extends MediaPresentation, ElementConstruction<MediaState> {
  readonly kind?: 'video' | 'audio';
  readonly onHandle?: (handle: MediaHandle | undefined) => void;
  readonly onError?: () => void;
}

const PLAYBACK_KEYS = ['Space', 'Enter', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'];

/**
 * Clip playback needs captions, transcript seeking, rejected play promises and
 * the existing preview dimensions. WA 3.12's Pro wa-video supports video sources,
 * tracks and playback APIs, but its implementation is absent from our installed
 * package. Replace the video branch once Pro is available and those contracts
 * are verified; this is a dependency limitation, not unsupported video behavior.
 * https://webawesome.com/docs/components/video/
 *
 * Audio stays native: WA documents no audio player, and wa-video's default slot
 * accepts source/track children, not a native audio host. Browser controls own
 * playback keys and focus; the tradeoff is platform-specific control paint.
 * The wrapper owns source disposal and revocable handles, never playback state.
 */
export class Media extends RenderedElement<MediaState> {
  readonly element: JSX.Element;
  static View = (props: MediaProps): JSX.Element => new Media(props).element;

  constructor(props: MediaProps) {
    super('Media', props);
    this.element = this.render(this.capture(props));
  }

  private render(props: MediaProps): JSX.Element {
    const binding = new ElementBinding('Media', props, { nativeKeys: PLAYBACK_KEYS });
    let element!: HTMLMediaElement;
    let mounted = false;
    let released = false;
    const current = () => {
      if (!mounted || released) throw new Error('Media handle is no longer available');
      return element;
    };
    const handle: MediaHandle = Object.freeze({
      currentTime: () => current().currentTime,
      duration: () => current().duration,
      setCurrentTime: (seconds: number) => { current().currentTime = seconds; },
      play: () => current().play(),
      pause: () => current().pause(),
      focus: (options?: FocusOptions) => current().focus(options),
      blur: () => current().blur(),
    });
    onSettled(() => {
      mounted = true;
      untrack(() => props.onHandle?.(handle));
    });
    onCleanup(() => {
      released = true;
      if (element) {
        element.pause();
        element.removeAttribute('src');
        // Removing src alone leaves the selected resource and its decoder alive.
        // Remove fallback sources before load(), otherwise cleanup starts a new
        // resource selection from a child <source> instead of releasing playback.
        for (const source of element.querySelectorAll('source')) source.removeAttribute('src');
        element.load();
      }
      if (mounted) untrack(() => props.onHandle?.(undefined));
      mounted = false;
    });
    const native = omit(props, 'observable', 'surface', 'hotkeys', 'kind', 'onHandle', 'onError');
    return <Dynamic component={props.kind ?? 'video'} {...native}
      ref={(node: HTMLMediaElement) => { element = node; binding.attach(node); }}
      src={binding.value().src}
      data-ui-keyboard-owner={props.controls ? PLAYBACK_KEYS.join(' ') : undefined}
      onError={() => { if (!released) props.onError?.(); }} />;
  }
}
