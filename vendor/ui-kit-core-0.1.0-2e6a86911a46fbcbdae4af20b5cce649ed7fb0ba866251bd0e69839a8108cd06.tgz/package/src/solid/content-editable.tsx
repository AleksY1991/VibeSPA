/** @jsxImportSource @solidjs/web */
import { Dynamic, type JSX } from '@solidjs/web';
import type { ContentEditableControlProps, ContentEditableState } from '../contracts/content-editable';
import { RenderedElement } from '../infrastructure/rendered-element';
import { INLINE_EDITING_KEYS, inlineEditorSession } from './content-editable-session';
import './content-editable.css';

export type { ContentEditableActivation, ContentEditableHandle, ContentEditableState } from '../contracts/content-editable';
export type ContentEditableProps = ContentEditableControlProps;

/**
 * Plaintext contenteditable is the single inline editor implementation. WA's
 * input/textarea requires a second sizing mirror and cross-shadow caret and ARIA
 * bridges to preserve inline text geometry. The browser already owns those
 * contracts on this element; the shared session adds activation and commit/cancel.
 */
function NativeContentEditable(props: ContentEditableControlProps) {
  let element!: HTMLElement;
  const select = (end: boolean) => {
    const range = element.ownerDocument.createRange();
    range.selectNodeContents(element);
    if (end) range.collapse(false);
    const selection = element.ownerDocument.getSelection();
    selection?.removeAllRanges();
    selection?.addRange(range);
  };
  const binding = inlineEditorSession(props, {
    element: () => element,
    ready: () => true,
    readText: () => element.innerText ?? element.textContent ?? '',
    writeText: (text, editing) => {
      const display = !editing && !text ? props.placeholder ?? '' : text;
      if (element.textContent !== display) element.textContent = display;
    },
    focus: options => element.focus(options),
    blur: () => element.blur(),
    select,
    caretAtPoint: point => {
      const doc = element.ownerDocument as Document & {
        caretPositionFromPoint?: (x: number, y: number) => { offsetNode: Node; offset: number } | null;
        caretRangeFromPoint?: (x: number, y: number) => Range | null;
      };
      let range: Range | null = null;
      const position = doc.caretPositionFromPoint?.(point.x, point.y);
      if (position && element.contains(position.offsetNode)) {
        range = doc.createRange();
        range.setStart(position.offsetNode, position.offset);
        range.collapse(true);
      } else {
        const hit = doc.caretRangeFromPoint?.(point.x, point.y);
        if (hit && element.contains(hit.startContainer) && element.contains(hit.endContainer)) range = hit;
      }
      if (!range) return false;
      const selection = doc.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      return true;
    },
  });
  return <Dynamic component={props.as ?? 'div'}
    ref={(target: HTMLElement) => { element = target; binding.attach(target); }}
    id={props.id} class={props.class} style={props.style}
    role="textbox" aria-label={props.label} aria-multiline={props.multiline ? 'true' : 'false'}
    aria-readonly={binding.value().readonly ? 'true' : 'false'} aria-describedby={props['aria-describedby']}
    tabindex={props.tabindex ?? (binding.value().readonly ? -1 : 0)}
    contenteditable={binding.value().editing && !binding.value().readonly ? 'plaintext-only' : 'false'}
    spellcheck={props.spellcheck ?? false} data-testid={props['data-testid']} data-ui-native-inline-editor=""
    data-ui-wrap={props.multiline || props.wrap ? '' : undefined}
    data-ui-text-entry={binding.value().editing && !binding.value().readonly ? 'true' : undefined}
    data-ui-keyboard-owner={binding.value().editing && !binding.value().readonly
      ? (props.multiline ? [...INLINE_EDITING_KEYS, 'Enter'] : INLINE_EDITING_KEYS).join(' ') : undefined}
  />;
}

/** Every inline editor shares the typed observable, keyboard ownership and session. */
export class ContentEditable extends RenderedElement<ContentEditableState> {
  readonly element: JSX.Element;
  static View = (props: ContentEditableProps): JSX.Element => new ContentEditable(props).element;

  constructor(props: ContentEditableProps) {
    super('ContentEditable', props);
    const captured = this.capture(props);
    this.element = <NativeContentEditable {...captured} />;
  }
}
