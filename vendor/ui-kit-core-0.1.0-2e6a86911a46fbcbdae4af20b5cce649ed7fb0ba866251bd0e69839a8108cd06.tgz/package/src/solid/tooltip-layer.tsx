/** @jsxImportSource @solidjs/web */
import { RenderedElement } from '../infrastructure/rendered-element';
import { Show, createEffect, createSignal, onCleanup, onSettled } from 'solid-js';
import type { JSX } from '@solidjs/web';

import type { ElementConstruction } from '../contracts/construction';
import { readObservable } from '../infrastructure/construction';
import { fitCenteredBox } from '../lib/viewportFit';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { renderUiRoot } from '../infrastructure/renderUiRoot';
import { LayerPortal, PORTAL_LAYERS, modalPortalMountForAnchor } from './portal';

const DELAY_MS = 300;
const MARGIN = 8;
const MAX_W = 256;
// Detailed paths and visibility explanations need readable body text and measure;
// ordinary one-line hints retain their compact geometry (DESIGN.md).
const DETAIL_MAX_W = 384;

export const TIP_ATTR = 'data-tip';
const TIP_SELECTOR = `[${TIP_ATTR}]`;

interface TipState {
  text: string;
  element: HTMLElement;
  anchor: { left: number; right: number; top: number; bottom: number };
  left: number;
  top: number;
  placed: boolean;
}

export interface TooltipLayerProps extends ElementConstruction<boolean> {
  
  /** Test seam; production always uses the canonical 300ms delay. */
  delayMs?: number;
  controllerRef?: (controller: TooltipLayerController) => void;
}

export interface TooltipLayerController {
  openFor(element: HTMLElement): void;
  close(): void;
}

export interface TooltipDelegationOptions {
  delayMs?: number;
  open(element: HTMLElement): void;
  close(): void;
}

function composedParent(element: Element): Element | null {
  const root = element.getRootNode();
  return element.assignedSlot ?? element.parentElement ?? (root instanceof ShadowRoot ? root.host : null);
}

function tooltipAvailable(element: HTMLElement): boolean {
  if (!element.isConnected || !element.getAttribute(TIP_ATTR)?.trim()) return false;
  for (let ancestor: Element | null = element; ancestor; ancestor = composedParent(ancestor)) {
    if (ancestor.matches(':disabled,[disabled],[aria-disabled="true"],[inert],[hidden],[data-ui-ready="false"],dialog[data-ui-dialog-overlay]:not([open])')) return false;
  }
  const control = element.shadowRoot?.querySelector<HTMLElement>('button,input,textarea,select,[role="switch"],[role="checkbox"],[role="radio"]');
  return !control?.matches(':disabled,[disabled],[aria-disabled="true"]');
}

/** DESIGN's data-tip is an optional mouse hint, never the accessible name or the
 * only way to discover an action. WA's stock hover/focus trigger would add a
 * a target-name association and does not enforce the control library's disabled/touch rule.
 * One delegated owner therefore handles delay, eligibility and dismissal; the
 * tradeoff is that keyboard users rely on the control's own visible/ARIA name.
 */
export function installTooltipDelegation(
  ownerDocument: Document,
  ownerWindow: Window,
  options: TooltipDelegationOptions,
): () => void {
  let timer: ReturnType<typeof setTimeout> | undefined;
  let host: HTMLElement | null = null;
  let observer: MutationObserver | undefined;
  const close = () => {
    clearTimeout(timer);
    observer?.disconnect();
    observer = undefined;
    host = null;
    options.close();
  };
  const onPointerOver = (event: PointerEvent) => {
    if (event.pointerType !== 'mouse') { close(); return; }
    const element = (event.target as Element | null)?.closest?.(TIP_SELECTOR) as HTMLElement | null;
    if (element === host) return;
    close();
    if (!element || !tooltipAvailable(element)) return;
    host = element;
    const text = element.getAttribute(TIP_ATTR);
    // An already visible hint must also disappear when its control is disabled,
    // replaced or removed. Observe only the active target and its ancestor chain;
    // a document-wide subtree observer would wake for unrelated page updates.
    observer = new MutationObserver(() => {
      if (!tooltipAvailable(element) || element.getAttribute(TIP_ATTR) !== text) close();
    });
    const attributes = [TIP_ATTR, 'disabled', 'aria-disabled', 'inert', 'hidden', 'data-ui-ready', 'open'];
    for (let ancestor: Element | null = element; ancestor; ancestor = composedParent(ancestor)) {
      observer.observe(ancestor, { attributes: true, attributeFilter: attributes, childList: true });
      const root = ancestor.getRootNode();
      if (!ancestor.parentElement && root instanceof ShadowRoot) observer.observe(root, { childList: true });
    }
    if (element.shadowRoot) observer.observe(element.shadowRoot, {
      attributes: true, attributeFilter: attributes, childList: true, subtree: true,
    });
    const delay = options.delayMs ?? DELAY_MS;
    if (delay <= 0) options.open(element);
    else timer = setTimeout(() => { if (tooltipAvailable(element)) options.open(element); }, delay);
  };
  const onPointerOut = (event: PointerEvent) => {
    const related = event.relatedTarget as Node | null;
    if (host && related && host.contains(related)) return;
    close();
  };
  ownerDocument.addEventListener('pointerover', onPointerOver, true);
  ownerDocument.addEventListener('pointerout', onPointerOut, true);
  ownerDocument.addEventListener('pointerdown', close, true);
  ownerWindow.addEventListener('scroll', close, true);
  ownerWindow.addEventListener('blur', close);
  ownerWindow.addEventListener('resize', close);
  return () => {
    close();
    ownerDocument.removeEventListener('pointerover', onPointerOver, true);
    ownerDocument.removeEventListener('pointerout', onPointerOut, true);
    ownerDocument.removeEventListener('pointerdown', close, true);
    ownerWindow.removeEventListener('scroll', close, true);
    ownerWindow.removeEventListener('blur', close);
    ownerWindow.removeEventListener('resize', close);
  };
}

function renderTooltipLayer(props: TooltipLayerProps) {
  const enabled = readObservable(props.observable);
  const Surface = requireControlImplementation('TooltipSurface');
  const [tip, setTip] = createSignal<TipState | null>(null);
  const [mounted, setMounted] = createSignal(false);
  let alive = true;
  onCleanup(() => { alive = false; });

  const close = () => {
    setTip(null);
  };
  const open = (element: HTMLElement) => {
    if (!alive || !enabled() || !tooltipAvailable(element)) return;
    const text = element.getAttribute(TIP_ATTR)?.trim();
    if (!text) return;
    const rect = element.getBoundingClientRect();
    setTip({
      text,
      element,
      anchor: { left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom },
      left: 0,
      top: 0,
      placed: false,
    });
  };
  const measure = (element: HTMLElement) => {
    const current = tip();
    if (!current || !element.isConnected) return;
    const placement = fitCenteredBox(
      { width: element.offsetWidth, height: element.offsetHeight },
      current.anchor,
      { width: window.innerWidth, height: window.innerHeight },
      { margin: MARGIN, gap: MARGIN },
    );
    const left = Math.round(placement.left);
    const top = Math.round(placement.top);
    if (current.placed && current.left === left && current.top === top) return;
    setTip({ ...current, left, top, placed: true });
  };

  onSettled(() => {
    props.controllerRef?.({ openFor: open, close });
    setMounted(true);
  });
  createEffect(() => ({ active: mounted() && enabled(), delayMs: props.delayMs }), ({ active, delayMs }) => {
    if (!active) return;
    return installTooltipDelegation(document, window, {
      delayMs,
      open,
      close,
    });
  });

  return (
    <Show when={enabled() ? tip() : null}>
      {(current) => (
        <LayerPortal.View observable={props.observable} surface={props.surface} hotkeys={props.hotkeys}
          mount={modalPortalMountForAnchor(current().element)}>
          <Surface anchor={current().element} text={current().text} left={current().left} top={current().top}
            layer={PORTAL_LAYERS.tooltip} maxWidth={Math.max(0, Math.min(current().text.includes('\n') ? DETAIL_MAX_W : MAX_W, window.innerWidth - 2 * MARGIN))}
            visible={current().placed} onMeasure={measure} />
        </LayerPortal.View>
      )}
    </Show>
  );
}

export const mountTooltipLayer = (
  host: HTMLElement,
  props: () => TooltipLayerProps,
): (() => void) => renderUiRoot(() => { const construction = props(); return <TooltipLayer.View {...construction} />; }, host);

export class TooltipLayer extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: TooltipLayerProps) {
    super('TooltipLayer', props);
    this.element = renderTooltipLayer(this.capture(props));
  }
  static View = (props: TooltipLayerProps): JSX.Element => new TooltipLayer(props).element;
}
