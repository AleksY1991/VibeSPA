/** @jsxImportSource @solidjs/web */
import './text-field.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle, surfaceCommand } from '../infrastructure/activation';
import type { TextFieldControlProps } from '../contracts/controls';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { assertControlPresentation } from '../infrastructure/presentation';
import { fieldRecipe } from '../field-presentation';
import { untrack } from 'solid-js';
import './control-geometry.css';

export interface TextFieldProps extends Omit<TextFieldControlProps, 'value'>, ElementConstruction<string> { }
export type { TextFieldRecipe } from '../contracts/field-presentation';

export type SearchFieldProps = Omit<TextFieldProps, 'recipe' | 'size' | 'type'> & {
  readonly recipe?: never; readonly size?: never; readonly type?: never;
};

/** Picker searches reuse the field's editing contract. A text input avoids an
 * extra browser search-clear action beside the picker's own actions; dense
 * geometry and caret-only focus follow DESIGN's field and size requirements. */
function renderSearchField(props: SearchFieldProps) {
  assertControlPresentation('SearchField', props, ['recipe', 'size', 'type']);
  return <TextField.View {...props} type="text" size="dense" recipe="inline" />;
}

function renderTextField(props: TextFieldProps) {
  assertControlPresentation('TextField', props);
  untrack(() => fieldRecipe('TextField', props.recipe));
  const binding = new ElementBinding('TextField', props, {
    nativeKeys: ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Backspace', 'Delete', 'Space', 'Printable'],
    enabledWhen: () => !props.disabled,
  });
  const Implementation = requireControlImplementation('TextField');
  const attach = (element: HTMLElement) => { binding.attach(element); props.onElement?.(element); };
  const writes = { canActivate: () => binding.canActivate() && !props.readonly };
  const change = surfaceCommand(writes, (value: string) => props.onValueChange(value));
  const commit = surfaceCommand(writes, (value: string) => props.onValueCommit?.(value));
  const activate: NonNullable<TextFieldControlProps['onActivate']> = event => {
    if (allowActivation(binding, event)) props.onActivate?.(event);
  };
  const publishHandle = () => {
    const callback = props.onHandle;
    return callback ? (handle: Parameters<NonNullable<TextFieldControlProps['onHandle']>>[0]) =>
      callback(handle ? guardFocusHandle(binding, handle) : undefined) : undefined;
  };
  return binding.provide(() => <Implementation {...props} value={binding.value()} onElement={attach}
    onValueChange={change} onValueCommit={commit} onActivate={activate} onHandle={publishHandle()} />);
}

export class TextField extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: TextFieldProps) {
    super('TextField', props);
    this.element = renderTextField(this.capture(props));
  }
  static View = (props: TextFieldProps): JSX.Element => new TextField(props).element;
}

export class SearchField extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: SearchFieldProps) {
    super('SearchField', props);
    this.element = renderSearchField(this.capture(props));
  }
  static View = (props: SearchFieldProps): JSX.Element => new SearchField(props).element;
}
