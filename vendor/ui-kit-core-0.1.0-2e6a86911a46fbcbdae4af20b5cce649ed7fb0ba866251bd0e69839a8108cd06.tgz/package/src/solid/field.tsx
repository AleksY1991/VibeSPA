/** @jsxImportSource @solidjs/web */
import './field.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import { Show, omit, createEffect, createSignal, onSettled, untrack } from 'solid-js';
import type { JSX } from '@solidjs/web';

import type { FocusHandle, InputFocusHandle } from '../contracts/controls';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle, guardNativeEvents } from '../infrastructure/activation';
import { cn } from '../lib/utils';
import { fieldFocusHandle } from './field-lifecycle';
import { DEFAULT_CONTROL_SIZE } from '../control-size';
import './control-geometry.css';

interface InputPresentation extends Omit<JSX.InputHTMLAttributes<HTMLInputElement>, 'value' | 'ref' | 'onInput' | 'onChange' | 'onKeyDown' | 'onKeyUp' | 'onKeyPress'>, ElementConstruction<string> {
  class?: string;
  className?: string;
}
export interface FileInputHandle extends FocusHandle {
  open(): void;
  reset(): void;
}
// Solid's HTML type includes arbitrary strings, so Exclude<..., 'file'> still
// accepts 'file' and cannot discriminate file commands from text-selection
// commands. Explicit types also keep native calendar popups from bypassing the
// consolidated CalendarField/RangeCalendar. Native time editing remains available.
type NativeNonFileInputType = 'button' | 'checkbox' | 'color'
  | 'email' | 'hidden' | 'image' | 'number' | 'password' | 'radio' | 'range'
  | 'reset' | 'search' | 'submit' | 'tel' | 'text' | 'time' | 'url';
export interface TextInputProps extends InputPresentation {
  readonly visuallyHidden?: never;
  type?: NativeNonFileInputType | Extract<JSX.InputHTMLAttributes<HTMLInputElement>['type'], null | false>;
  onValueChange: (value: string) => void;
  onFilesChange?: never;
  onHandle?: (handle: InputFocusHandle | undefined) => void;
}
export interface FileInputProps extends InputPresentation {
  type: 'file';
  /** A separately named trigger opens this browser engine through its handle. */
  readonly visuallyHidden?: boolean;
  onValueChange?: never;
  onFilesChange: (files: readonly File[]) => void;
  onHandle?: (handle: FileInputHandle | undefined) => void;
}
export type InputProps = TextInputProps | FileInputProps;

/** Native input escape hatch for file engines and full HTML input attributes.
 * WA 3.12 wa-input/TextField excludes type="file" from its supported contract;
 * its native input reference is not a supported file-picker replacement. Pro
 * wa-file-input supports file selection and reset, but is not installed here.
 * This browser engine preserves the explicit FileList/reset handle used for
 * same-file reselection. Visible text controls use TextField. The legacy text signature
 * remains compatible with native HTML types/attributes, without a second WA
 * adapter or replacement editing behavior. */
function renderInput(props: InputProps) {
  const binding = new ElementBinding('Input', props, {
    nativeKeys: ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Backspace', 'Delete', 'Space', 'Printable'],
    enabledWhen: () => !props.disabled,
    nativeActivation: true,
  });
  let input!: HTMLInputElement;
  const [mounted, setMounted] = createSignal(false);
  const onTextHandle = (handle: InputFocusHandle | undefined) => {
    if (props.type !== 'file') props.onHandle?.(handle && guardFocusHandle(binding, handle));
  };
  fieldFocusHandle(() => input, () => props.type === 'file' || !props.onHandle ? undefined : onTextHandle,
    undefined, () => input.select(), () => input);
  onSettled(() => { setMounted(true); });
  createEffect(() => [mounted(), props.type === 'file' ? props.onHandle : undefined] as const, ([ready, callback]) => {
    if (!ready || !callback) return;
    let active = true;
    const current = () => { if (!active) throw new Error('Input handle has been disposed'); return input; };
    untrack(() => callback(guardFocusHandle(binding, Object.freeze({
      focus: (options?: FocusOptions) => current().focus(options),
      blur: () => current().blur(),
      open: () => { const element = current(); if (allowActivation(binding)) element.click(); },
      reset: () => { current().value = ''; },
    }))));
    return () => { active = false; untrack(() => callback(undefined)); };
  });
  const native = guardNativeEvents(binding, omit(props, 'class', 'className', 'observable', 'surface', 'hotkeys', 'onValueChange', 'onFilesChange', 'onHandle', 'visuallyHidden'));
  return (
    <input
      {...native}
      data-ui-control-size={DEFAULT_CONTROL_SIZE}
      data-ui-file-engine={props.type === 'file' && props.visuallyHidden ? '' : undefined}
      tabindex={props.type === 'file' && props.visuallyHidden ? -1 : props.tabindex}
      aria-hidden={props.type === 'file' && props.visuallyHidden ? 'true' : props['aria-hidden']}
      data-ui-keyboard-owner="ArrowLeft ArrowRight ArrowUp ArrowDown Home End Backspace Delete Space Printable"
      ref={element => { input = element; binding.attach(element); }} value={props.type === 'file' ? undefined : binding.value()}
      onInput={event => { if (allowActivation(binding, event) && !props.readonly) props.onValueChange?.(event.currentTarget.value); }}
      onChange={event => { if (allowActivation(binding, event)) props.onFilesChange?.(Object.freeze(Array.from(event.currentTarget.files ?? []))); }}
      class={cn(
        "ui-native-field ui-input-base",
        props.class,
        props.className,
      )}
    />
  );
}

export { Textarea, type TextareaProps } from './textarea';

export interface FieldProps extends ElementConstruction<string> {
  for?: string;
  htmlFor?: string;
  required?: boolean;
  error?: JSX.Element;
  hint?: JSX.Element;
  children: JSX.Element;
  class?: string;
  className?: string;
}

/** Outer label/error layout for native controls and forms whose labels share a
 * common caption style. WA has field-specific labels, but no arbitrary-child
 * form-field wrapper; keep those controls free to own editing and validation.
 * `for` identifies the child's public id; required here is a visual annotation,
 * while required/invalid/description relationships belong to the actual input. */
function renderField(props: FieldProps) {
  const binding = new ElementBinding('Field', props);
  return binding.provide(() => (
    <div ref={element => binding.attach(element)} class={cn("ui-field-stack", props.class, props.className)}>
      <label
        for={props.for ?? props.htmlFor}
        class="ui-field-label"
      >
        {binding.value()}
        <Show when={props.required}>
          <span class="ui-field-required" aria-hidden="true">*</span>
        </Show>
      </label>
      {props.children}
      <Show
        when={props.error}
        fallback={<Show when={props.hint}>{(hint) => <p class="ui-field-hint">{hint()}</p>}</Show>}
      >
        {(error) => <p class="ui-field-error" role="alert">{error()}</p>}
      </Show>
    </div>
  ));
}

export class Input extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: InputProps) {
    super('Input', props);
    this.element = renderInput(this.capture(props));
  }
  static View = (props: InputProps): JSX.Element => new Input(props).element;
}

export class Field extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: FieldProps) {
    super('Field', props);
    this.element = renderField(this.capture(props));
  }
  static View = (props: FieldProps): JSX.Element => new Field(props).element;
}
