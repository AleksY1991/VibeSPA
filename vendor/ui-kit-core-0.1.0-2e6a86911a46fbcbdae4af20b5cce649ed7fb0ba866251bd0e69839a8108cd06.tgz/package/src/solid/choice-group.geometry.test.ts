import { readFileSync } from 'node:fs';
import { parse } from 'postcss';
import { describe, expect, it } from 'vitest';

const choice = parse(readFileSync('src/solid/choice-group.css', 'utf8'));
const vendor = parse(readFileSync('src/vendor/web-awesome/controls.css', 'utf8'));

describe('canonical choice geometry', () => {
  it('gives short labels square minimum targets and responsive spacing', () => {
    const declarations = (sheet: typeof choice, selector: string) => {
      const result: Record<string, string> = {};
      sheet.walkRules(rule => {
        if (!rule.selectors.includes(`:where([data-ui-root]) ${selector}`)) return;
        rule.walkDecls(declaration => { result[declaration.prop] = declaration.value; });
      });
      return result;
    };
    const prepared = declarations(vendor, 'wa-radio[data-ui-choice]');
    // Even a one-character label must fill the minimum target on both axes.
    for (const property of ['min-width', 'min-height']) {
      expect(prepared[property]).toBe('var(--ui-choice-minimum)');
    }
    expect(declarations(vendor, 'wa-radio-group[data-ui-choice-group]::part(form-control-input)').gap)
      .toBe('var(--ui-choice-gap)');
    const responsive: Record<string, string> = {};
    choice.walkAtRules('media', media => {
      expect(media.params).toBe('(pointer: coarse), (max-width: 767px)');
      media.walkDecls(declaration => { responsive[declaration.prop] = declaration.value; });
    });
    expect(declarations(choice, '.ui-choice-group')['--ui-choice-minimum']).toBe('var(--ui-control-target)');
    expect(responsive).toEqual({ '--ui-choice-gap': '8px' });
  });
});
