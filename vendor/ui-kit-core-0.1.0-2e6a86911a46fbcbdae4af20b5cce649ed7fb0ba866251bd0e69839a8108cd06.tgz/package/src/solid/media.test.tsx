/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { Media, type MediaHandle, type MediaProps, type MediaState } from './media';

const disposers: (() => void)[] = [];
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  document.body.replaceChildren(); vi.restoreAllMocks();
});

async function fixture(overrides: Partial<Omit<MediaProps, 'observable'>> = {}) {
  const host = document.createElement('div'); document.body.append(host);
  const [state, setState] = createSignal<MediaState>({ src: '/first.webm' });
  let handle: MediaHandle | undefined; let savedHandle: MediaHandle | undefined;
  const onHandle = vi.fn((next: MediaHandle | undefined) => { handle = next; if (next) savedHandle = next; });
  const onError = vi.fn();
  const dispose = render(() => {
    const observable = constructItem('media.test', item => item.observe('source', state));
    return new Media({ observable, surface: { kind: 'inherit' }, hotkeys: [], controls: true,
      playsinline: true, preload: 'metadata', 'aria-label': 'Play clip',
      class: 'max-h-80 w-full', style: { height: '120px' }, onHandle, onError, ...overrides,
      children: <track kind="captions" src="/captions.vtt" label="Transcript" default />,
    }).element;
  }, host);
  disposers.push(dispose);
  await Promise.resolve(); flush(); await Promise.resolve();
  const element = host.querySelector('video,audio')! as HTMLMediaElement;
  return { host, element, setState, dispose, onHandle, onError, handle: () => handle!, savedHandle: () => savedHandle! };
}

describe('Media construction and playback', () => {
  it('keeps playback controls, captions, geometry and node identity through source changes', async () => {
    const current = await fixture();
    expect(current.element.tagName).toBe('VIDEO'); expect(current.element.controls).toBe(true);
    expect(current.element.hasAttribute('playsinline')).toBe(true);
    expect(current.element.preload).toBe('metadata'); expect(current.element.getAttribute('aria-label')).toBe('Play clip');
    expect(current.element.className).toBe('max-h-80 w-full'); expect(current.element.style.height).toBe('120px');
    expect(current.element.querySelector('track')?.getAttribute('src')).toBe('/captions.vtt');
    current.setState({ src: '/second.webm' }); flush();
    expect(current.host.firstElementChild).toBe(current.element);
    expect(current.element.getAttribute('src')).toBe('/second.webm');
    expect(current.onHandle).toHaveBeenCalledOnce();
    current.setState({ src: undefined }); flush(); expect(current.element.hasAttribute('src')).toBe(false);
  });

  it('supports an audio host through the same playback contract', async () => {
    const current = await fixture({ kind: 'audio' });
    expect(current.element.tagName).toBe('AUDIO'); expect(current.element.controls).toBe(true);
  });

  it('uses browser playback state and commands directly without publishing model writes', async () => {
    const current = await fixture();
    const play = vi.spyOn(current.element, 'play').mockResolvedValue();
    const pause = vi.spyOn(current.element, 'pause').mockImplementation(() => {});
    Object.defineProperty(current.element, 'duration', { configurable: true, value: 120 });
    current.handle().setCurrentTime(12.5);
    expect(current.element.currentTime).toBe(12.5); expect(current.handle().currentTime()).toBe(12.5);
    expect(current.handle().duration()).toBe(120);
    await current.handle().play(); current.handle().pause();
    expect(play).toHaveBeenCalledOnce(); expect(pause).toHaveBeenCalledOnce();
    play.mockRejectedValueOnce(new Error('Autoplay blocked'));
    await expect(current.handle().play()).rejects.toThrow('Autoplay blocked');
  });

  it('revokes the handle, stops playback, clears the source and ignores late errors after disposal', async () => {
    const current = await fixture();
    const pause = vi.spyOn(current.element, 'pause').mockImplementation(() => {});
    const fallback = document.createElement('source'); fallback.src = '/fallback.webm'; current.element.append(fallback);
    const load = vi.spyOn(current.element, 'load').mockImplementation(() => {
      expect(current.element.hasAttribute('src')).toBe(false);
      expect(fallback.hasAttribute('src')).toBe(false);
    });
    current.element.dispatchEvent(new Event('error'));
    expect(current.onError).toHaveBeenCalledExactlyOnceWith();
    current.dispose();
    expect(pause).toHaveBeenCalledOnce(); expect(current.element.hasAttribute('src')).toBe(false);
    expect(load).toHaveBeenCalledOnce();
    expect(current.onHandle).toHaveBeenLastCalledWith(undefined);
    current.element.dispatchEvent(new Event('error')); expect(current.onError).toHaveBeenCalledOnce();
    expect(() => current.savedHandle().currentTime()).toThrow(/no longer available/);
    expect(() => current.savedHandle().duration()).toThrow(/no longer available/);
    expect(() => current.savedHandle().setCurrentTime(1)).toThrow(/no longer available/);
    expect(() => current.savedHandle().pause()).toThrow(/no longer available/);
    expect(() => current.savedHandle().play()).toThrow(/no longer available/);
  });

  it('leaves native playback keys to the browser when custom hotkeys are empty', async () => {
    const current = await fixture();
    const dispatch = vi.fn();
    disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
      commands: { dispatch }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
    for (const key of [' ', 'Enter', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End']) {
      const event = new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true });
      current.element.dispatchEvent(event); expect(event.defaultPrevented).toBe(false);
    }
    expect(dispatch).not.toHaveBeenCalled();
  });

  it('permits explicit custom overrides of native playback keys', async () => {
    const handler = vi.fn();
    const current = await fixture({ hotkeys: [{ key: 'Space', overrideNative: true, handler }] });
    disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
      commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
    const event = new KeyboardEvent('keydown', { key: ' ', bubbles: true, composed: true, cancelable: true });
    current.element.dispatchEvent(event); expect(event.defaultPrevented).toBe(true); expect(handler).toHaveBeenCalledOnce();
  });
});
