import { hotkeys } from '../runtime/hotkeys';

/** A temporarily unavailable selection remains focusable but cannot change by key. */
export function readonlySelectionKeys(readonly: () => boolean): (element: Element) => void {
  return hotkeys({
    name: 'designSystem.readonlySelection',
    transparent: true,
    active: readonly,
    keys: ['Space', 'ArrowLeft', 'ArrowRight'],
    onKeyDown: event => {
      event.preventDefault();
      event.stopPropagation();
    },
  });
}
