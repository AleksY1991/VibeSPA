/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import postcss from 'postcss';
import { flush } from 'solid-js';
import { constructItem } from '../infrastructure/construction';
import { Dialog } from './dialog';
import { renderPrepared as render } from '../../tests/prepared';
import { authoredStyle, useStyles } from '../../tests/styles';

useStyles('solid/dialog.css');
const settle = async () => {
  for (let pass = 0; pass < 48; pass++) { flush(); await Promise.resolve(); }
};
afterEach(() => { document.body.replaceChildren(); });

describe('bounded dialog sizes and docked drawer frames', () => {
  it.each([
    ['default', '32rem'], ['sm', '24rem'], ['md', '28rem'],
    ['lg', '40rem'], ['xl', '60rem'], ['2xl', '80rem'],
  ] as const)('owns the %s frame width without consumer CSS', async (size, width) => {
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const open = constructItem('dialog.width', item => item.constant('open', true));
      return <Dialog.View observable={open} surface={{ kind: 'own', name: 'dialog.width', layer: true, transparent: false }}
        hotkeys={[]} recipe="form" size={size} aria-label="Bounded editor" onOpenChange={() => {}}>
        <p>Editor content</p>
      </Dialog.View>;
    }, host);
    try {
      await settle();
      const panel = document.querySelector('[aria-label="Bounded editor"]')!;
      expect(authoredStyle(panel, 'max-width')).toBe(width);
    } finally { dispose(); }
  });

  it('docks a modal drawer to the viewport end and fills narrow screens', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const dispose = render(() => {
      const state = constructItem('dialog.dock', item => ({
        open: item.constant('open', true), drawer: item.constant('panel', { width: 420 }),
      }));
      return <Dialog.View observable={state.open} surface={{ kind: 'own', name: 'dialog.dock', layer: true, transparent: false }}
        hotkeys={[]} recipe="drawer" drawer={state.drawer} dock="end" aria-label="Record drawer" onOpenChange={() => {}}>
        <p>Record content</p>
      </Dialog.View>;
    }, host);
    try {
      await settle();
      const panel = document.querySelector('[aria-label="Record drawer"]')!;
      expect(panel.getAttribute('aria-modal')).toBe('true');
      expect(Number.parseFloat(authoredStyle(panel, 'top'))).toBe(0);
      expect(Number.parseFloat(authoredStyle(panel, 'right'))).toBe(0);
      expect(authoredStyle(panel, 'left')).toBe('auto');
      expect(authoredStyle(panel, 'transform')).toBe('none');
      // Happy DOM drops dvh/min() lengths from CSSStyleDeclaration. Inspect the
      // real parsed rule rather than accepting its missing-property fallback.
      const declarations = new Map<string, string>();
      postcss.parse(readFileSync(join(process.cwd(), 'src/solid/dialog.css'), 'utf8')).walkRules(rule => {
        if (rule.parent?.type === 'root' && rule.selector.includes('.ui-dialog-dock-end')) {
          rule.walkDecls(declaration => { declarations.set(declaration.prop, declaration.value); });
        }
      });
      expect(declarations.get('height')).toBe('100dvh');
      expect(declarations.get('width')).toBe('min(var(--ui-dialog-panel-width), 100vw)');
      const match = vi.spyOn(window, 'matchMedia').mockImplementation(query => ({
        matches: query === '(max-width: 720px)', media: query,
      }) as MediaQueryList);
      try { expect(authoredStyle(panel, 'width')).toBe('100vw'); }
      finally { match.mockRestore(); }
    } finally { dispose(); }
  });
});
