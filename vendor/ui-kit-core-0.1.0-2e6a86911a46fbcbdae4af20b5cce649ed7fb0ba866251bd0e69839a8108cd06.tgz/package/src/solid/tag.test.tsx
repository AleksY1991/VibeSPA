/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { importTagElement } from '../vendor/web-awesome/elements';
import { WebAwesomeTag } from '../vendor/web-awesome/tag.adapter';
import { Tag } from './tag';

let dispose: (() => void) | undefined;
const settle = async () => { for (let i = 0; i < 30; i++) { flush(); await Promise.resolve(); } };
beforeAll(async () => { await importTagElement(); });
afterEach(() => { dispose?.(); dispose = undefined; vi.restoreAllMocks(); document.body.replaceChildren(); });

it('keeps the label inert and the named remove action keyboard accessible', async () => {
  const [label, setLabel] = createSignal('Planning');
  const [disabled, setDisabled] = createSignal(false);
  const remove = vi.fn();
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const state = constructItem('tag.test', item => item.observe('state', () => ({
      label: label(), removeLabel: `Remove ${label()} filter`, disabled: disabled(),
    })));
    const view = () => <Tag.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} onRemove={remove} />;
    return <ImplementationContext value={{ Tag: WebAwesomeTag }}>{view()}</ImplementationContext>;
  }, container);
  await settle();
  const tag = container.querySelector<HTMLElement>('[data-ui-tag]')!;
  expect(tag.localName).toBe('wa-tag');
  tag.querySelector<HTMLElement>('[data-ui-tag-label]')!.click();
  expect(remove).not.toHaveBeenCalled();
  const button = container.querySelector<HTMLElement>('button')!;
  expect(button.getAttribute('aria-label')).toBe('Remove Planning filter');
  button.focus();
  expect(document.activeElement).toBe(button);
  button.click(); await settle(); expect(remove).toHaveBeenCalledOnce();
  setLabel('Work'); setDisabled(true); await settle();
  expect(button.getAttribute('aria-label')).toBe('Remove Work filter');
  expect(tag.textContent).toContain('Work');
  button.click(); await settle(); expect(remove).toHaveBeenCalledOnce();
});

it('retains its label and independent remove action when the vendor shell update rejects', async () => {
  vi.spyOn(customElements.get('wa-tag')!.prototype, 'updateComplete', 'get').mockImplementation(() => Promise.reject(new Error('Tag update failed')));
  const container = document.createElement('div'); document.body.append(container);
  const remove = vi.fn();
  dispose = render(() => {
    const state = constructItem('tag.recovery', item => item.constant('state', { label: 'Work', removeLabel: 'Remove Work' }));
    return <ImplementationContext value={{ Tag: WebAwesomeTag }}>
      <Tag.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} onRemove={remove} />
    </ImplementationContext>;
  }, container);
  const before = container.querySelector('button');
  await settle();
  expect(container.querySelector('wa-tag')).not.toBeNull();
  const host = container.querySelector('[data-ui-error="update-failed"]')!;
  expect(host.hasAttribute('inert')).toBe(false);
  expect(host.hasAttribute('data-ui-ready')).toBe(false);
  expect(container.querySelector('button')).toBe(before);
  (before as HTMLButtonElement).click(); await settle();
  expect(remove).toHaveBeenCalledOnce();
});

it('removes its named tag once without submitting a containing form', async () => {
  const remove = vi.fn();
  const submit = vi.fn((event: SubmitEvent) => event.preventDefault());
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const state = constructItem('tag.form', item => item.constant('state', { label: 'Work', removeLabel: 'Remove Work filter' }));
    const view = () => <form onSubmit={submit}><Tag.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} onRemove={remove} /></form>;
    return <ImplementationContext value={{ Tag: WebAwesomeTag }}>{view()}</ImplementationContext>;
  }, container);
  await settle();
  const button = container.querySelector<HTMLButtonElement>('button')!;
  expect(button.getAttribute('aria-label')).toBe('Remove Work filter');
  button.click(); await settle();
  expect(remove).toHaveBeenCalledOnce();
  expect(submit).not.toHaveBeenCalled();
});
