import { createEffect, createSignal, latest, onCleanup, untrack } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowFocus } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';

export interface CaretInputState { readonly disabled: boolean; }
export type CaretSelectionDirection = 'forward' | 'backward' | 'none';
export interface CaretSnapshot {
  readonly value: string;
  readonly selectionStart: number;
  readonly selectionEnd: number;
  readonly selectionDirection: CaretSelectionDirection;
}
export interface CaretSession {
  readonly value: string;
  readonly selectionStart: number;
  readonly selectionEnd: number;
  readonly selectionDirection?: CaretSelectionDirection;
}
export type CaretSnapshotReason = 'input' | 'keyup' | 'select' | 'paste' | 'cut';
export type CaretCompositionPhase = 'start' | 'update' | 'end';

export interface CaretInputHandle {
  /** Attaches the already constructed native engine; never allocates reactive bindings. */
  attach(host: HTMLElement): void;
  /** Detaches without destroying the native buffer or the construction-owned bindings. */
  detach(): void;
  snapshot(): CaretSnapshot;
  /** Replaces the buffer only when starting an edit, then focuses before selecting. */
  begin(session: CaretSession): boolean;
  setSelectionRange(start: number, end: number, direction?: CaretSelectionDirection): void;
  /** Host-relative position anchors the browser's IME candidate window at the painted caret. */
  setCaretPosition(point: { readonly x: number; readonly y: number }): void;
  focus(): void;
  blur(): void;
}

export interface CaretInputProps extends ElementConstruction<CaretInputState> {
  /** A native-renderer adapter supplies its owned mount; the native input never escapes through the handle. */
  readonly mount: HTMLElement | { readonly kind: 'deferred'; readonly document: Document };
  readonly label: string;
  readonly onSnapshot: (snapshot: CaretSnapshot, reason: CaretSnapshotReason) => void;
  readonly onComposition: (phase: CaretCompositionPhase, data: string, snapshot: CaretSnapshot) => void;
  readonly onBlur: (snapshot: CaretSnapshot) => void;
}

const nativeKeys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Backspace', 'Delete', 'Enter', 'Space', 'Tab', 'Printable'];

/**
 * Canvas labels need native text editing without a second visible field. An
 * invisible wa-textarea is feasible through its documented focus, setSelectionRange,
 * and setRangeText methods (https://webawesome.com/docs/components/textarea/).
 * WA 3.12's textarea.d.ts also exposes .input for native selection reads.
 * That option adds initial-render readiness and a shadow-input bridge to this
 * synchronous session/snapshot contract while leaving WA's visible UI unused.
 * Neither backend supplies canvas hit testing, painted caret/selection geometry,
 * or positioning of the input at the painted caret for the IME candidate window.
 * A directly constructed native textarea keeps that buffer ready before attachment.
 *
 * The browser owns the live buffer, native selection, composition, and native keys,
 * except declared dispatcher overrides. The control layer owns edit sessions, mirrors snapshots,
 * and positions the 1px focusable engine; it guards deferred clipboard delivery when
 * an edit is replaced or detached. The tradeoff is continued canvas ownership of
 * hit testing and visual caret/selection, with native focus and IME kept intact.
 */
export class CaretInput extends RenderedElement<CaretInputState> {
  static View = (props: CaretInputProps): JSX.Element => new CaretInput(props).element;
  readonly element: JSX.Element;
  readonly handle: CaretInputHandle;

  constructor(props: CaretInputProps) {
    super('CaretInput', props);
    props = this.capture(props);
    // The native engine attaches synchronously; state observations still use
    // Solid's latest settled value through the construction binding.
    let attached = !('kind' in props.mount);
    const [attachment, setAttachment] = createSignal(attached, { ownedWrite: true });
    const binding = new ElementBinding('CaretInput', props, {
      active: () => { attachment(); return attached; },
      enabledWhen: state => !state.disabled,
      nativeKeys,
    });
    const mount = props.mount;
    const deferred = 'kind' in mount;
    const ownerDocument = deferred ? mount.document : mount.ownerDocument;
    const input = ownerDocument.createElement('textarea');
    input.setAttribute('aria-label', props.label);
    input.setAttribute('autocomplete', 'off');
    input.setAttribute('autocorrect', 'off');
    input.setAttribute('autocapitalize', 'off');
    input.setAttribute('data-ui-text-entry', 'true');
    input.setAttribute('data-ui-keyboard-owner', nativeKeys.join(' '));
    input.spellcheck = false;
    input.tabIndex = -1;
    Object.assign(input.style, {
      position: 'absolute', width: '1px', height: '1px', padding: '0', margin: '0',
      border: '0', outline: 'none', resize: 'none', overflow: 'hidden', opacity: '0',
      color: 'transparent', background: 'transparent', caretColor: 'transparent',
      zIndex: '0', whiteSpace: 'pre', pointerEvents: 'none', left: '0px', top: '0px',
    });
    let alive = true;
    let sessionRevision = 0;
    const enabled = () => {
      input.disabled = !alive || latest(() => untrack(binding.value)).disabled;
      return !input.disabled;
    };
    const snapshot = (): CaretSnapshot => ({
      value: input.value, selectionStart: input.selectionStart, selectionEnd: input.selectionEnd,
      selectionDirection: input.selectionDirection,
    });
    const listeners: (() => void)[] = [];
    const listen = <K extends keyof HTMLElementEventMap>(name: K, listener: (event: HTMLElementEventMap[K]) => void) => {
      input.addEventListener(name, listener);
      listeners.push(() => input.removeEventListener(name, listener));
    };
    for (const reason of ['input', 'keyup', 'select'] as const) {
      listen(reason, () => { if (alive) props.onSnapshot(snapshot(), reason); });
    }
    for (const reason of ['paste', 'cut'] as const) {
      listen(reason, () => {
        const clipboardSession = sessionRevision;
        queueMicrotask(() => {
          if (alive && clipboardSession === sessionRevision) props.onSnapshot(snapshot(), reason);
        });
      });
    }
    for (const phase of ['start', 'update', 'end'] as const) {
      listen(`composition${phase}`, event => { if (alive) props.onComposition(phase, event.data, snapshot()); });
    }
    listen('blur', () => { if (alive) props.onBlur(snapshot()); });
    enabled();
    createEffect(() => binding.value().disabled, disabled => { input.disabled = disabled; });
    this.handle = Object.freeze({
      attach: (host: HTMLElement) => { if (alive) { host.append(input); attached = true; setAttachment(true); binding.isLive(); } },
      detach: () => { if (alive) { sessionRevision += 1; input.remove(); attached = false; setAttachment(false); binding.isLive(); } },
      snapshot,
      begin: (session: CaretSession) => {
        if (!enabled() || !allowFocus(binding)) return false;
        sessionRevision += 1;
        input.value = session.value;
        input.focus({ preventScroll: true });
        input.setSelectionRange(session.selectionStart, session.selectionEnd, session.selectionDirection);
        return true;
      },
      setSelectionRange: (start: number, end: number, direction?: CaretSelectionDirection) => {
        if (alive) input.setSelectionRange(start, end, direction);
      },
      setCaretPosition: (point: { readonly x: number; readonly y: number }) => {
        if (!alive) return;
        input.style.left = `${point.x}px`;
        input.style.top = `${point.y}px`;
      },
      focus: () => { if (enabled() && allowFocus(binding)) input.focus({ preventScroll: true }); },
      blur: () => { if (alive) input.blur(); },
    });
    this.element = input;
    if (!deferred) mount.append(input);
    binding.attach(input);
    onCleanup(() => {
      alive = false;
      for (const remove of listeners) remove();
      input.remove();
    });
  }
}
