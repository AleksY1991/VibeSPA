/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { importTabPanelElement } from '../vendor/web-awesome/elements';
import { WebAwesomeTabPanel } from '../vendor/web-awesome/tabs.adapter';
import { useStyles } from '../../tests/styles';
import { Card } from './controls';
import { TabPanel } from './tabs';

useStyles('solid/controls.css', 'solid/tabs.css', 'vendor/web-awesome/controls.css', 'vendor/web-awesome/tabs.css');
const disposers: (() => void)[] = [];
const settle = async () => { for (let index = 0; index < 24; index++) { flush(); await Promise.resolve(); } };
beforeAll(async () => { await importTabPanelElement(); });
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

describe('public surface viewport presentation', () => {
  it('keeps the column viewport stable while panel visibility changes', async () => {
    const [visible, setVisible] = createSignal(true);
    const container = document.createElement('div');
    document.body.append(container);
    disposers.push(render(() => {
      const model = constructItem('surface.presentation', item => ({
        card: item.constant('card', true), panel: item.observe('panel', visible),
      }));
      return <ImplementationContext value={{ TabPanel: WebAwesomeTabPanel }}>
        <Card.View observable={model.card} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="panel" attributes={{ id: 'viewport-card' }}>
          <TabPanel.View observable={model.panel} surface={{ kind: 'inherit' }} hotkeys={[]}
            id="viewport-panel" tabId="viewport-tab" value="one" layout="column" overflow="hidden">
            <div data-editor-draft="">Uncommitted editing content</div>
          </TabPanel.View>
        </Card.View>
      </ImplementationContext>;
    }, container));
    await settle();
    const card = container.querySelector<HTMLElement>('#viewport-card')!;
    const panel = container.querySelector<HTMLElement>('#viewport-panel')!;
    const draft = container.querySelector('[data-editor-draft]');
    expect(getComputedStyle(card).display).toBe('flex');
    expect(getComputedStyle(card).flexDirection).toBe('column');
    expect(getComputedStyle(card).height).toBe('100%');
    expect(Number.parseFloat(getComputedStyle(card).minHeight)).toBe(0);
    expect(getComputedStyle(card).overflow).toBe('hidden');
    expect(getComputedStyle(panel).display).toBe('flex');
    expect(Number.parseFloat(getComputedStyle(panel).minHeight)).toBe(0);
    expect(getComputedStyle(panel).overflow).toBe('hidden');
    setVisible(false); await settle();
    expect(panel.hidden).toBe(true);
    expect(getComputedStyle(panel).display).toBe('none');
    setVisible(true); await settle();
    expect(panel.hidden).toBe(false);
    expect(getComputedStyle(panel).display).toBe('flex');
    expect(container.querySelector('[data-editor-draft]')).toBe(draft);
  });
});
