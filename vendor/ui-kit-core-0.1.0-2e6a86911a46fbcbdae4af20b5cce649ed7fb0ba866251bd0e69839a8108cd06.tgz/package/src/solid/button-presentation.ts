import type { ButtonPresentation, ButtonVariant } from '../button-presets';
import { CONTROL_SIZES, controlSize } from '../control-size';
import { cn } from '../lib/utils';

const paints: Record<ButtonVariant, string> = {
  default: 'ui-button-default',
  destructive: 'ui-button-destructive',
  outline: 'ui-button-outline',
  secondary: 'ui-button-secondary ui-button-neutral-ink',
  ghost: '',
  link: 'ui-button-link',
};

/** Private shared geometry for native actions and real action-shaped anchors. */
export function buttonPresentationClasses(props: ButtonPresentation): string {
  const recipe = props.recipe ?? 'button';
  if (!['button', 'content', 'menu-item', 'navigation', 'inline-action', 'cell-action', 'property-row', 'selection-cell', 'action-row', 'fill-action', 'overlay-action'].includes(recipe)) {
    throw new TypeError(`Button: unsupported recipe ${recipe}`);
  }
  if (props.size !== undefined && !CONTROL_SIZES.includes(props.size)) {
    throw new TypeError(`Button: unsupported size ${props.size}; choose a canonical control size`);
  }
  if (props.shape !== undefined && props.shape !== 'icon') throw new TypeError('Button: unsupported shape');
  if (props.shape && recipe !== 'button' && recipe !== 'selection-cell') throw new TypeError(`Button: ${recipe} owns its shape`);
  if ((recipe === 'inline-action' || recipe === 'fill-action') && props.size !== undefined) throw new TypeError(`Button: ${recipe} owns its content-sized geometry`);
  if (!['button', 'content', 'action-row'].includes(recipe) && props.variant !== undefined) {
    throw new TypeError(`Button: ${recipe} owns its paint; remove variant`);
  }
  if (((props.shape === 'icon' && recipe === 'button') || recipe === 'content' || recipe === 'action-row') && props.variant === undefined) {
    throw new TypeError('Button: icon and content recipes require an explicit supported variant');
  }
  // DESIGN.md: ordinary commands do not claim primary attention by omission.
  // Hosts opt into the solid primary paint explicitly; geometry stays size-owned.
  const variant = props.variant ?? (recipe === 'button' ? 'secondary' : 'ghost');
  if (!Object.hasOwn(paints, variant)) throw new TypeError(`Button: unsupported variant ${variant}`);
  if (props.shape === 'icon' || recipe === 'overlay-action') {
    if (!['ghost', 'destructive', 'outline'].includes(variant)) throw new TypeError(`Button: icon action cannot use ${variant}`);
    const label = 'aria-label' in props ? props['aria-label'] : undefined;
    const labelledBy = 'aria-labelledby' in props ? props['aria-labelledby'] : undefined;
    if (!label?.trim() && !labelledBy?.trim()) throw new TypeError('Button: icon actions require an accessible name');
  }
  if ((recipe === 'content' || recipe === 'action-row') && !['outline', 'secondary', 'ghost'].includes(variant)) {
    throw new TypeError(`Button: ${recipe} cannot use ${variant}`);
  }
  return cn('ui-button ui-button-base', paints[variant],
    recipe !== 'inline-action' && recipe !== 'fill-action' && `ui-button-${controlSize(props.size)}`,
    (props.shape === 'icon' || recipe === 'overlay-action') && ['ui-button-icon', variant === 'ghost' && 'ui-button-muted-icon'],
    recipe === 'content' && 'ui-button-content',
    recipe === 'menu-item' && 'ui-button-option ui-button-menu',
    recipe === 'navigation' && 'ui-button-option ui-button-navigation ui-button-neutral-ink',
    recipe === 'inline-action' && 'ui-button-inline ui-button-prose',
    recipe === 'cell-action' && 'ui-button-cell-action',
    recipe === 'property-row' && 'ui-button-property-row',
    recipe === 'selection-cell' && 'ui-button-selection-cell',
    recipe === 'action-row' && 'ui-button-content ui-button-action-row',
    recipe === 'fill-action' && 'ui-button-fill-action');
}
