/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { constructItem } from '../infrastructure/construction';
import { Form, type FormProps, type FormState, type SubmitIntent } from './form';

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

function fixture(overrides: Partial<Omit<FormProps, 'observable'>> = {}) {
  const host = document.createElement('div'); document.body.append(host);
  const [state, setState] = createSignal<FormState>({});
  const onSubmit = vi.fn((intent: SubmitIntent) => intent.preventDefault());
  let captures = 0;
  const dispose = render(() => {
    const observable = constructItem('form.test', item => item.observe('model', state));
    const form = new Form({
      get observable() { captures++; return observable; },
      surface: { kind: 'inherit' }, hotkeys: [], onSubmit, ...overrides,
    });
    return form.element;
  }, host);
  disposers.push(dispose);
  const element = host.querySelector('form')!;
  const input = document.createElement('input'); input.name = 'title'; input.required = true;
  const submit = document.createElement('button'); submit.type = 'submit'; submit.name = 'action'; submit.value = 'save';
  element.append(input, submit);
  return { host, element, input, submit, onSubmit, setState, dispose, captures: () => captures };
}

describe('Form', () => {
  it('preserves a real form, browser validation and native button submission', () => {
    const { element, input, submit, onSubmit } = fixture({ action: '/save', method: 'post', class: 'flex gap-2', style: { width: '123px' } });
    expect(element.getAttribute('action')).toBe('/save'); expect(element.method).toBe('post');
    expect(element.className).toBe('flex gap-2'); expect(element.style.width).toBe('123px');
    submit.click(); expect(onSubmit).not.toHaveBeenCalled();
    input.value = 'A task'; submit.click(); expect(onSubmit).toHaveBeenCalledOnce();
    expect(onSubmit.mock.calls[0][0].formData().get('title')).toBe('A task');
  });

  it('leaves submission and Enter default behavior available to the browser', () => {
    const onSubmit = vi.fn(); const { element, input } = fixture({ onSubmit });
    const event = new SubmitEvent('submit', { bubbles: true, cancelable: true }); element.dispatchEvent(event);
    expect(onSubmit).toHaveBeenCalledOnce(); expect(event.defaultPrevented).toBe(false);
    const enter = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }); input.dispatchEvent(enter);
    expect(enter.defaultPrevented).toBe(false); expect(element.getAttribute('data-ui-keyboard-owner')).toBe('Enter');
  });

  it('exposes cancellation and form data without exposing the native element or event', () => {
    const { element, input, submit, onSubmit } = fixture(); input.value = 'Captured';
    const event = new SubmitEvent('submit', { bubbles: true, cancelable: true, submitter: submit });
    element.dispatchEvent(event);
    expect(event.defaultPrevented).toBe(true);
    const intent = onSubmit.mock.calls[0][0]; expect(Object.keys(intent).sort()).toEqual(['formData', 'preventDefault', 'stopPropagation']);
    expect(intent.formData().get('title')).toBe('Captured');
    expect(intent.formData().get('action')).toBe('save');
  });

  it('blocks disabled submissions without disabling fields or recreating the form', () => {
    const { host, element, input, setState, onSubmit, captures } = fixture();
    setState({ disabled: true }); flush();
    const disabled = new SubmitEvent('submit', { cancelable: true }); element.dispatchEvent(disabled);
    expect(disabled.defaultPrevented).toBe(true); expect(onSubmit).not.toHaveBeenCalled();
    expect(input.disabled).toBe(false); expect(element.getAttribute('aria-disabled')).toBe('true');
    setState({}); flush(); element.dispatchEvent(new SubmitEvent('submit', { cancelable: true }));
    expect(onSubmit).toHaveBeenCalledOnce(); expect(host.firstElementChild).toBe(element); expect(captures()).toBe(1);
    expect(element.hasAttribute('aria-disabled')).toBe(false);
  });

  it('blocks a retained form from submitting after its owner is removed', () => {
    const { element, onSubmit, dispose } = fixture();
    dispose();
    const event = new SubmitEvent('submit', { cancelable: true });
    element.dispatchEvent(event);
    expect(event.defaultPrevented).toBe(true); expect(onSubmit).not.toHaveBeenCalled();
  });
});
