/** @jsxImportSource @solidjs/web */
import './button.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import { untrack, createEffect, createSignal, omit, onSettled } from 'solid-js';
import type { JSX } from '@solidjs/web';

import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, eventScope, guardFocusHandle, guardNativeEvents } from '../infrastructure/activation';
import { activationFrom, type Activation, type FocusHandle } from '../contracts/controls';
import type { ButtonPresentation } from '../button-presets';
import type { ClosedControlPresentation, ControlPlacement } from '../contracts/presentation';
import { assertControlPresentation, controlPlacement } from '../infrastructure/presentation';
import { controlSize } from '../control-size';
import { cn } from '../lib/utils';
import { buttonPresentationClasses } from './button-presentation';
import { ChevronRightIcon } from '../icons';
import './button-geometry.css';

export interface ButtonState {
  readonly disabled?: boolean;
  readonly highlighted?: boolean;
  readonly ariaDisabled?: boolean | 'true' | 'false';
  readonly pressed?: boolean | 'true' | 'false' | 'mixed';
  readonly expanded?: boolean | 'true' | 'false';
}

interface ButtonBehaviorProps
  extends Omit<JSX.ButtonHTMLAttributes<HTMLButtonElement>, 'class' | 'className' | 'classList' | 'style' | 'disabled' | 'aria-disabled' | 'aria-pressed' | 'aria-expanded' | 'ref' | 'onClick' | 'onPointerDown' | 'onKeyDown' | 'onKeyUp' | 'onKeyPress'>,
    ElementConstruction<ButtonState>, ClosedControlPresentation {
  readonly placement?: ControlPlacement;
  start?: JSX.Element;
  end?: JSX.Element;
  readonly visualStyle?: never;
  readonly textSize?: never;
  readonly multiline?: never;
  readonly contentAlign?: never;
  readonly fillLabel?: never;
  readonly hitTarget?: never;
  readonly gap?: never;
  readonly padding?: never;
  readonly iconSize?: never;
  readonly selectionPaint?: never;
  onActivate?: (activation: Activation) => void;
  onPressStart?: (activation: Activation) => void;
  onHandle?: (handle: FocusHandle | undefined) => void;
  'data-tip'?: string;
  'data-testid'?: string;
}

export type ButtonProps = ButtonBehaviorProps & ButtonPresentation;

function renderButton(props: ButtonProps) {
  assertControlPresentation('Button', props);
  const binding = new ElementBinding('Button', props, { nativeKeys: ['Enter', 'Space'],
    nativeActivation: true,
    enabledWhen: state => !state.disabled,
    activationWhen: state => state.ariaDisabled !== true && state.ariaDisabled !== 'true' });
  const activate = eventScope((activation: Activation) => {
    if (allowActivation(binding, activation)) props.onActivate?.(activation);
  });
  const pressStart = eventScope((activation: Activation) => {
    if (allowActivation(binding, activation)) props.onPressStart?.(activation);
  });
  const native = guardNativeEvents(binding, omit(props, 'observable', 'surface', 'hotkeys', 'variant', 'size', 'shape', 'recipe', 'placement', 'class', 'className', 'classList', 'style', 'children', 'onActivate', 'onPressStart', 'onHandle', 'start', 'end'));
  // Browser buttons own Enter/Space, form submission/reset and external ARIA
  // references on one focus target. WA 3.12 needs shadow-reference and submitter
  // bridges plus native recovery to preserve these contracts; use the browser
  // implementation directly so preparation and vendor failures cannot replace
  // the control or reconstruct its content. Shared bindings still own activation,
  // surfaces, hotkeys and cleanup; shared CSS owns the existing geometry.
  let element: HTMLButtonElement | undefined;
  const [readyElement, setReadyElement] = createSignal<HTMLButtonElement>();
  let active = false;
  onSettled(() => {
    if (!element) return;
    active = true;
    setReadyElement(element);
    return () => { active = false; element = undefined; };
  });
  createEffect(
    () => [readyElement(), props.onHandle] as const,
    ([current, callback]) => {
      if (!current || !callback) return;
      let released = false;
      const assertActive = () => { if (!active || released) throw new Error('Button focus handle has been disposed'); };
      const handle: FocusHandle = guardFocusHandle(binding, Object.freeze({
        focus: (options?: FocusOptions) => { assertActive(); current.focus(options); },
        blur: () => { assertActive(); current.blur(); },
      }));
      // Handle delivery is an imperative mount/unmount notification, like fieldFocusHandle.
      untrack(() => callback(handle));
      return () => { released = true; untrack(() => callback(undefined)); };
    },
  );
  return binding.provide(() => (
    <button
      {...native}
      type={props.type === 'submit' || props.type === 'reset' ? props.type : 'button'}
      data-ui-keyboard-owner="Enter Space"
      data-ui-control-size={props.recipe === 'inline-action' || props.recipe === 'fill-action' ? undefined : controlSize(props.size)}
      data-ui-recipe={props.recipe ?? 'button'}
      data-ui-highlighted={binding.value().highlighted ? '' : undefined}
      data-ui-selected={props.recipe !== 'selection-cell' && (binding.value().pressed === true || binding.value().pressed === 'true'
        || props['aria-checked'] === 'true' || props['aria-selected'] === 'true'
        || (props['aria-current'] && props['aria-current'] !== 'false')) ? '' : undefined}
      ref={(node) => { element = node; binding.attach(node); }}
      disabled={binding.value().disabled} aria-disabled={binding.value().ariaDisabled === undefined ? undefined : String(binding.value().ariaDisabled) as 'true' | 'false'} aria-pressed={binding.value().pressed === undefined ? undefined : String(binding.value().pressed) as 'true' | 'false' | 'mixed'} aria-expanded={binding.value().expanded === undefined ? undefined : String(binding.value().expanded) as 'true' | 'false'}
      class={cn((props.shape === 'icon' || !['cell-action', 'property-row', 'selection-cell', 'action-row', 'fill-action'].includes(props.recipe ?? 'button')) && 'ui-control-icons', buttonPresentationClasses(props))}
      style={controlPlacement('Button', props.placement)}
      onClick={eventScope((event: MouseEvent) => {
        activate(activationFrom(event));
      })}
      onPointerDown={eventScope((event: PointerEvent) => {
        pressStart(activationFrom(event));
      })}
    >
      {props.recipe === 'navigation' && <ChevronRightIcon class="ui-navigation-marker" />}{props.start}
      <span data-ui-button-label="" class={props.recipe === 'menu-item' || props.recipe === 'navigation' ? 'ui-button-label-fill' : 'ui-button-label-contents'}>{props.children}</span>
      {props.end}
    </button>
  ));
}

export class Button extends RenderedElement<ButtonState> {
  readonly element: JSX.Element;
  constructor(props: ButtonProps) {
    super('Button', props);
    this.element = renderButton(this.capture(props));
  }
  static View = (props: ButtonProps): JSX.Element => new Button(props).element;
}
