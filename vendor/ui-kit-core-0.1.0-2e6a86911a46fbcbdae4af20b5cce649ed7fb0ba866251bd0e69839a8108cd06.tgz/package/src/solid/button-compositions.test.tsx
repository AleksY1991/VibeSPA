/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, expect, it, vi } from 'vitest';
import { createMemo, createSignal, flush, onCleanup, onSettled } from 'solid-js';
import { render } from '@solidjs/web';
import { constructItem } from '../infrastructure/construction';
import type { ButtonState } from './button';
import type { FocusHandle } from '../contracts/controls';
import type { ButtonPresentation } from '../button-presets';
import { Button } from './button';
import { useStyles } from '../../tests/styles';

useStyles('control-tokens.css', 'solid/button.css', 'solid/button-geometry.css', 'selection.css');
const disposers: (() => void)[] = [];
const settle = async () => { flush(); await Promise.resolve(); flush(); };
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

it('accepts reactive presentation spreads without consuming them during construction', async () => {
  const [icon, setIcon] = createSignal(false);
  const activated = vi.fn();
  const host = document.createElement('div'); document.body.append(host);
  disposers.push(render(() => {
    const state = constructItem('dynamic-action.test', item => item.constant('state', {}));
    const presentation = createMemo<ButtonPresentation>(() => icon()
      ? { shape: 'icon', variant: 'ghost', 'aria-label': 'Open destination' }
      : { recipe: 'navigation' });
    return <Button.View {...presentation()} observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
      onActivate={activated}><svg /></Button.View>;
  }, host));
  await settle();
  const button = host.querySelector('button')!;
  setIcon(true); await settle();
  expect(host.querySelector('button')).toBe(button);
  expect(button.getAttribute('aria-label')).toBe('Open destination');
  expect(button.getAttribute('data-ui-recipe')).toBe('button');
  button.click();
  expect(activated).toHaveBeenCalledOnce();
  setIcon(false); await settle();
  expect(host.querySelector('button')).toBe(button);
  expect(button.getAttribute('data-ui-recipe')).toBe('navigation');
});

it('keeps selection semantics while the containing composite owns paint', async () => {
  const [selected, setSelected] = createSignal(false);
  const [highlighted, setHighlighted] = createSignal(false);
  const [recipe, setRecipe] = createSignal<'button' | 'selection-cell'>('selection-cell');
  const mounted = vi.fn(); const cleaned = vi.fn();
  const Content = () => { onSettled(mounted); onCleanup(cleaned); return <span data-content="">Status</span>; };
  const host = document.createElement('div'); document.body.append(host);
  disposers.push(render(() => {
    const state = constructItem('selection-cell.test', item => item.observe<ButtonState>('state', () => ({ pressed: selected(), highlighted: highlighted() })));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} recipe={recipe()}
      role="radio" aria-checked={selected() ? 'true' : 'false'}><Content /></Button.View>;
  }, host));
  await settle();
  const button = host.querySelector('button')!;
  const content = button.querySelector('[data-content]');
  setSelected(true); await settle();
  expect(button.getAttribute('aria-pressed')).toBe('true');
  expect(button.getAttribute('aria-checked')).toBe('true');
  expect(button.hasAttribute('data-ui-selected')).toBe(false);
  setHighlighted(true); await settle();
  expect(button.hasAttribute('data-ui-highlighted')).toBe(true);
  setRecipe('button'); await settle();
  expect(button.hasAttribute('data-ui-selected')).toBe(true);
  expect(host.querySelector('button')).toBe(button);
  expect(button.querySelector('[data-content]')).toBe(content);
  expect(mounted).toHaveBeenCalledOnce();
  expect(cleaned).not.toHaveBeenCalled();
});

it('preserves nested property glyph geometry while keeping native action ownership', async () => {
  const host = document.createElement('div'); document.body.append(host);
  const activated = vi.fn();
  disposers.push(render(() => {
    const state = constructItem('property-row.test', item => item.constant('state', {}));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="property-row" size="compact" onActivate={activated}>
      <span><svg data-empty="" width="10" height="10" style={{ width: '10px', height: '10px' }} /><span>Value</span></span>
    </Button.View>;
  }, host));
  await settle();
  const button = host.querySelector('button')!;
  expect(button.classList.contains('ui-control-icons')).toBe(false);
  expect(getComputedStyle(button).height).toBe('auto');
  expect(getComputedStyle(button).minHeight).toBe('36px');
  expect(getComputedStyle(button).getPropertyValue('padding-block')).toBe('0px');
  expect(getComputedStyle(button.querySelector('[data-empty]')!).width).toBe('10px');
  button.click();
  expect(activated).toHaveBeenCalledOnce();
});

it('keeps an overlapping clear badge keyboard-sized with a glyph-only pointer box', async () => {
  const host = document.createElement('div'); document.body.append(host);
  const activated = vi.fn(); let handle: FocusHandle | undefined;
  disposers.push(render(() => {
    const state = constructItem('overlay-action.test', item => item.constant('state', {}));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="overlay-action" size="compact"
      aria-label="Clear choice" onActivate={activated} onHandle={next => { handle = next; }}><svg /></Button.View>;
  }, host));
  await settle();
  const button = host.querySelector('button')!;
  const label = button.querySelector('[data-ui-button-label]')!;
  expect(getComputedStyle(button).height).toBe('36px');
  expect(getComputedStyle(button).width).toBe('36px');
  expect(getComputedStyle(button).pointerEvents).toBe('none');
  expect(getComputedStyle(label).display).toBe('inline-flex');
  expect(getComputedStyle(label).pointerEvents).toBe('auto');
  expect(getComputedStyle(label.querySelector('svg')!).width).toBe('16px');
  handle!.focus();
  expect(document.activeElement).toBe(button);
  button.click();
  expect(activated).toHaveBeenCalledOnce();
});

it('retains canonical glyph sizing for named selection-cell icons', async () => {
  const host = document.createElement('div'); document.body.append(host);
  disposers.push(render(() => {
    const state = constructItem('selection-icon.test', item => item.constant('state', { pressed: true }));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="selection-cell" shape="icon" size="compact" aria-label="Select row"><svg /></Button.View>;
  }, host));
  await settle();
  const button = host.querySelector('button')!;
  expect(getComputedStyle(button).width).toBe('36px');
  expect(getComputedStyle(button.querySelector('svg')!).width).toBe('16px');
  expect(button.getAttribute('aria-pressed')).toBe('true');
  expect(button.hasAttribute('data-ui-selected')).toBe(false);
});
