/** @jsxImportSource @solidjs/web */
import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { Portal } from '@solidjs/web';
import { createContext, useContext } from 'solid-js';

/** Native showModal makes body siblings inert. Keep child portals inside the
 * owning modal, including independently mounted feature roots. This scope owns
 * only DOM mounting and visibility; the surface tree owns all focus/dismissal
 * decisions. Ordinary vendor modal Escape and Tab remain native. */
export interface ModalPortalScope {
  readonly mount: HTMLElement | undefined;
  readonly open: () => boolean;
}

export const ModalPortalContext = createContext<ModalPortalScope | null>(null);
const modalScopes = new WeakMap<Element, ModalPortalScope>();

export function createModalPortalScope(mount: () => HTMLElement | undefined, open: () => boolean): ModalPortalScope {
  return {
    get mount() { return mount(); },
    open,
  };
}

export function registerModalPortalScope(element: Element, scope: ModalPortalScope): () => void {
  modalScopes.set(element, scope);
  return () => { if (modalScopes.get(element) === scope) modalScopes.delete(element); };
}

/** Resolve actual DOM ownership for globally rendered affordances such as tooltips. */
export function modalPortalMountForAnchor(anchor: Element): HTMLElement | undefined {
  for (let element: Element | null = anchor; element;) {
    const scope = modalScopes.get(element);
    if (scope?.open()) return scope.mount;
    const root = element.getRootNode();
    element = element.assignedSlot ?? element.parentElement ?? (root instanceof ShadowRoot ? root.host : null);
  }
  return undefined;
}

/**
 * One explicit layer vocabulary for every Solid-owned surface. Keeping the
 * values here prevents feature-local z-index escalation and makes nested
 * overlays deterministic across independently owned Solid surfaces.
 * Solid Portal preserves the construction owner while escaping clipping
 * ancestors. ModalPortalContext keeps native-modal children in that ownership
 * tree; the visible wrapper deliberately keeps nonmodal child state alive.
 */
export const PORTAL_LAYERS = {
  view: 40,
  dialog: 60,
  popover: 70,
  notification: 80,
  tooltip: 100,
} as const;

export type PortalLayerName = keyof typeof PORTAL_LAYERS;

export interface LayerPortalProps extends ElementConstruction<boolean> {
  children: JSX.Element;
  mount?: Element;
}

function renderLayerPortal(props: LayerPortalProps) {
  const modal = useContext(ModalPortalContext);
  const binding = new ElementBinding('LayerPortal', props, { activeWhen: visible => visible && (modal?.open() ?? true) });
  // Pinned dialog backdrops release pointer input; their owned child portals
  // keep the interactivity they had when mounted directly in the document.
  return binding.provide(() => <Portal mount={props.mount ?? modal?.mount ?? document.body}><span data-ui-root="" ref={binding.attach} style={{ display: binding.active() ? 'contents' : 'none', 'pointer-events': modal ? 'auto' : undefined }}>{props.children}</span></Portal>);
}

export class LayerPortal extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: LayerPortalProps) {
    super('LayerPortal', props);
    this.element = renderLayerPortal(this.capture(props));
  }
  static View = (props: LayerPortalProps): JSX.Element => new LayerPortal(props).element;
}
