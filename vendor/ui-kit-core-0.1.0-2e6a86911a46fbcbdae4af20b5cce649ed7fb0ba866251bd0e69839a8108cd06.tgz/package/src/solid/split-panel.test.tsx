/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { captureArtifact } from '@solidjs/diagnostics';
import { createEffect, createSignal, flush, onCleanup } from 'solid-js';
import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { importSplitPanelElement, type SplitPanelElement } from '../vendor/web-awesome/elements';
import { WebAwesomeSplitPanel } from '../vendor/web-awesome/split-panel.adapter';
import { SplitPanel } from './split-panel';
import { Button } from './button';
import { Card } from './controls';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { hotkeys } from '../runtime/hotkeys';
import { useHotkeyElementContext } from '../runtime/context';

let dispose: (() => void) | undefined;
const settle = async () => { for (let i = 0; i < 40; i++) { flush(); await Promise.resolve(); } };
beforeAll(async () => { await importSplitPanelElement(); });
afterEach(() => { dispose?.(); dispose = undefined; vi.restoreAllMocks(); vi.unstubAllGlobals(); document.body.replaceChildren(); });

function pointerCapture(element: HTMLElement) {
  let captured: number | undefined;
  Object.defineProperties(element, {
    setPointerCapture: { configurable: true, value: (id: number) => { captured = id; } },
    hasPointerCapture: { configurable: true, value: (id: number) => captured === id },
    releasePointerCapture: { configurable: true, value: () => { captured = undefined; } },
  });
  return () => captured;
}
const pointer = (element: HTMLElement, type: string, x: number) => element.dispatchEvent(new PointerEvent(type, { pointerId: 1, clientX: x, button: 0, bubbles: true, cancelable: true }));

it('preserves pixel sizing, snapping, cancel, and close cleanup', async () => {
  // Happy DOM has no layout; WA measures its primary pane during connection.
  const measure = HTMLElement.prototype.getBoundingClientRect;
  vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockImplementation(function (this: HTMLElement) {
    return this.localName === 'wa-split-panel' ? { width: 1200, height: 800 } as DOMRect : measure.call(this);
  });
  vi.stubGlobal('ResizeObserver', class { observe() {} unobserve() {} disconnect() {} });
  const [width, setWidth] = createSignal(384);
  const [collapsed, setCollapsed] = createSignal(false);
  const changed = vi.fn((next: number) => setWidth(next));
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const state = constructItem('split.test', item => item.observe('state', () => ({ endSize: width(), collapsed: collapsed() })));
    const view = () => <SplitPanel.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
      min={320} max={800} step={16} label="Resize panel" onEndSizeChange={changed} start="Chart" end={<input aria-label="Draft" value="Unsaved" />} />;
    return <ImplementationContext value={{ SplitPanel: WebAwesomeSplitPanel }}>{view()}</ImplementationContext>;
  }, container);
  await settle();
  const host = container.querySelector<HTMLElement>('[data-ui-split-panel]')!;
  const divider = (host.shadowRoot ?? host).querySelector<HTMLElement>('[role="separator"]')!;
  const captured = pointerCapture(divider);
  vi.spyOn(host, 'getBoundingClientRect').mockReturnValue({ width: 1200 } as DOMRect);
  {
    // Lit's Node export skips WA's browser sizing lifecycle. Prime the measured
    // size through its public handlers; actual resize observation is browser QA.
    (host as SplitPanelElement).handleVerticalChange();
    (host as SplitPanelElement).handlePositionInPixelsChange();
    await settle();
  }
  expect(host.localName).toBe('wa-split-panel');
  expect(divider.getAttribute('aria-valuenow')).toBe('384');
  const repositioned = vi.fn();
  host.addEventListener('wa-reposition', repositioned);
  for (const key of ['Enter', 'Enter']) {
    const event = new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true });
    divider.dispatchEvent(event); await settle();
    expect(event.defaultPrevented).toBe(true);
  }
  for (const init of [{ key: 'ArrowLeft', ctrlKey: true }, { key: 'ArrowRight', altKey: true }, { key: 'ArrowUp' }]) {
    const event = new KeyboardEvent('keydown', { ...init, bubbles: true, composed: true, cancelable: true });
    divider.dispatchEvent(event); await settle();
    expect(event.defaultPrevented).toBe(false);
  }
  expect(changed).not.toHaveBeenCalled();
  expect(repositioned).not.toHaveBeenCalled();
  expect(divider.getAttribute('aria-valuenow')).toBe('384');
  host.removeEventListener('wa-reposition', repositioned);
  pointer(divider, 'pointerdown', 500); pointer(divider, 'pointermove', 450); await settle();
  expect(width()).toBe(434);
  expect(divider.getAttribute('aria-valuenow')).toBe('434');
  pointer(divider, 'pointermove', 489); await settle();
  expect(width()).toBe(400); // within 12px of one third
  pointer(divider, 'pointercancel', 489); await settle();
  expect(captured()).toBeUndefined();
  pointer(divider, 'pointermove', 350); await settle(); expect(width()).toBe(400);
  divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true, cancelable: true })); await settle();
  expect(width()).toBe(416);
  divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', shiftKey: true, bubbles: true, cancelable: true })); await settle();
  expect(width()).toBe(576);
  divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'End', bubbles: true, cancelable: true })); await settle();
  expect(width()).toBe(800);
  const draft = container.querySelector('input');
  setCollapsed(true); await settle();
  expect(divider.tabIndex).toBe(-1);
  expect(container.querySelector('input')).toBe(draft);
  divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true, cancelable: true })); await settle();
  expect(width()).toBe(800);
  setCollapsed(false); await settle();
  pointer(divider, 'pointerdown', 500);
  dispose(); dispose = undefined; await settle();
  expect(captured()).toBeUndefined();
  changed.mockClear();
  pointer(divider, 'pointermove', 250); divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true }));
  await settle(); expect(changed).not.toHaveBeenCalled();
});

it('reserves resize keys only on the divider and honors its explicit native override', async () => {
  const navigate = vi.fn();
  const overridden = vi.fn();
  const changed = vi.fn();
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const parent = hotkeys({ name: 'split.content.keys', transparent: true, keys: { ArrowLeft: navigate, Enter: navigate } });
    const state = constructItem('split.keyboard', item => item.constant('state', { endSize: 384, collapsed: false }));
    const view = () => <div ref={parent}><SplitPanel.View observable={state} surface={{ kind: 'inherit' }}
      hotkeys={[{ key: 'Home', overrideNative: true, handler: overridden }]}
      min={320} max={800} step={16} label="Resize panel" onEndSizeChange={changed}
      start={<div data-testid="chart-content" tabindex={0}>Chart</div>} end="Editor" /></div>;
    return <ImplementationContext value={{ SplitPanel: WebAwesomeSplitPanel }}>{view()}</ImplementationContext>;
  }, container);
  const detach = attachDispatcher({ window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
    runtime: () => ({ editing: false, keyboardLayer: null }) });
  try {
    await settle();
    const host = container.querySelector('[data-ui-split-panel]')!;
    const divider = (host.shadowRoot ?? host).querySelector<HTMLElement>('[role="separator"]')!;
    const key = (element: Element, value: string) => element.dispatchEvent(new KeyboardEvent('keydown', {
      key: value, bubbles: true, composed: true, cancelable: true,
    }));
    const chart = container.querySelector('[data-testid="chart-content"]')!;
    key(chart, 'ArrowLeft'); key(chart, 'Enter'); await settle();
    expect(navigate).toHaveBeenCalledTimes(2);
    expect(changed).not.toHaveBeenCalled();
    key(divider, 'Enter'); await settle();
    expect(navigate).toHaveBeenCalledTimes(2);
    expect(changed).not.toHaveBeenCalled();
    key(divider, 'Home'); await settle();
    expect(overridden).toHaveBeenCalledOnce();
    expect(changed).not.toHaveBeenCalled();
    key(divider, 'ArrowLeft'); await settle();
    expect(changed).toHaveBeenCalledExactlyOnceWith(400);
    expect(navigate).toHaveBeenCalledTimes(2);
  } finally { detach(); }
});

it('retains failed vendor layout content and blocks resize commands', async () => {
  vi.spyOn(customElements.get('wa-split-panel')!.prototype, 'updateComplete', 'get').mockReturnValue(Promise.resolve(false));
  let mounts = 0; const cleanup = vi.fn();
  const Content = () => { mounts++; onCleanup(cleanup); return <input value="Retained draft" />; };
  const [width, setWidth] = createSignal(384);
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const state = constructItem('split.recovery', item => item.observe('state', () => ({ endSize: width(), collapsed: false })));
    return <ImplementationContext value={{ SplitPanel: WebAwesomeSplitPanel }}>
      <SplitPanel.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
        min={320} max={800} step={16} label="Resize panel" onEndSizeChange={setWidth} start={<Content />} end="Editor" />
    </ImplementationContext>;
  }, container);
  const input = container.querySelector('input');
  await settle();
  const host = container.querySelector<SplitPanelElement>('wa-split-panel')!;
  expect(host.getAttribute('data-ui-error')).toBe('update-failed');
  expect(host.hasAttribute('inert')).toBe(true);
  expect(container.querySelector('[data-ui-fallback]')).toBeNull();
  expect(container.querySelector('input')).toBe(input);
  expect(mounts).toBe(1); expect(cleanup).not.toHaveBeenCalled();
  host.divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true }));
  await settle(); expect(width()).toBe(384);
});

it('releases an active pointer session when the existing vendor host fails', async () => {
  const changed = vi.fn();
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const state = constructItem('split.failedDrag', item => item.constant('state', { endSize: 384, collapsed: false }));
    return <ImplementationContext value={{ SplitPanel: WebAwesomeSplitPanel }}>
      <SplitPanel.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
        min={320} max={800} step={16} label="Resize panel" onEndSizeChange={changed} start="Chart" end="Editor" />
    </ImplementationContext>;
  }, container);
  await settle();
  const host = container.querySelector<SplitPanelElement>('wa-split-panel')!;
  const captured = pointerCapture(host.divider);
  pointer(host.divider, 'pointerdown', 500);
  expect(captured()).toBe(1);
  vi.spyOn(host, 'updateComplete', 'get').mockReturnValue(Promise.reject(new Error('Update failed')));
  host.dispatchEvent(new Event('wa-reposition'));
  await settle();
  expect(container.querySelector('wa-split-panel')).toBe(host);
  expect(host.getAttribute('data-ui-error')).toBe('update-failed');
  expect(captured()).toBeUndefined();
  pointer(host.divider, 'pointermove', 450);
  host.divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true, cancelable: true }));
  await settle();
  expect(changed).not.toHaveBeenCalled();
});

it('keeps the host and start pane live while suspending retained end controls', async () => {
  const [collapsed, setCollapsed] = createSignal(false);
  const frames: (readonly [boolean, boolean])[] = [];
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const model = constructItem('split.retained', item => ({
      state: item.observe('state', () => ({ endSize: 384, collapsed: collapsed() })),
      button: item.constant('button', {}),
    }));
    const End = () => {
      const context = useHotkeyElementContext()!;
      createEffect(() => [collapsed(), context.active()] as const, frame => { frames.push(frame); });
      return <ImplementationContext value={null}><Button.View observable={model.button} surface={{ kind: 'own', name: 'split.retained.end', transparent: false }} hotkeys={[]}>Editor</Button.View></ImplementationContext>;
    };
    const view = () => <SplitPanel.View observable={model.state} surface={{ kind: 'own', name: 'split.retained.host', transparent: false }} hotkeys={[]}
      min={320} max={800} step={16} label="Resize panel" onEndSizeChange={() => {}}
      start={<ImplementationContext value={null}><Button.View observable={model.button} surface={{ kind: 'own', name: 'split.retained.start', transparent: false }} hotkeys={[]}>Chart</Button.View></ImplementationContext>}
      end={<End />} />;
    return <ImplementationContext value={{ SplitPanel: WebAwesomeSplitPanel }}>{view()}</ImplementationContext>;
  }, container);
  await settle();
  const end = container.querySelector('[data-ui-split-end] button');
  const surfaces = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name.startsWith('split.retained.'));
  expect(surfaces().map(surface => surface.name).sort()).toEqual(['split.retained.end', 'split.retained.host', 'split.retained.start']);
  const owner = surfaces().find(surface => surface.name === 'split.retained.host')!;
  expect(surfaces().filter(surface => surface !== owner).every(surface => surface.parentId === owner.instanceId)).toBe(true);
  frames.length = 0;
  const { artifact } = await captureArtifact(async () => {
    for (const next of [true, false, true, false, true, false]) {
      setCollapsed(next); await settle();
      expect(container.querySelector('[data-ui-split-end] button')).toBe(end);
      expect(surfaces().map(surface => surface.name).sort()).toEqual(next
        ? ['split.retained.host', 'split.retained.start']
        : ['split.retained.end', 'split.retained.host', 'split.retained.start']);
    }
  }, { scenario: 'retained-split-scope-activity' });
  expect(frames).toEqual([[true, false], [false, true], [true, false], [false, true], [true, false], [false, true]]);
  expect(artifact.diagnostics.filter(event => event.code === 'EFFECT_RELAY_TEAR')).toEqual([]);
});

it('blocks resize commands beneath a global layer while still completing pointer cleanup', async () => {
  const [blocked, setBlocked] = createSignal(false);
  const changed = vi.fn();
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const model = constructItem('split.authority', item => ({
      state: item.constant('state', { endSize: 384, collapsed: false }), blocked: item.observe('blocked', blocked),
    }));
    return <ImplementationContext value={{ SplitPanel: WebAwesomeSplitPanel }}>
      <SplitPanel.View observable={model.state} surface={{ kind: 'inherit' }} hotkeys={[]}
        min={320} max={800} step={16} label="Resize" onEndSizeChange={changed} start="Chart" end="Editor" />
      <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'split.blocker', transparent: false, layer: true }} hotkeys={[]}>Dialog</Card.View>
    </ImplementationContext>;
  }, container);
  await settle();
  const divider = container.querySelector<SplitPanelElement>('wa-split-panel')!.divider;
  const captured = pointerCapture(divider);
  pointer(divider, 'pointerdown', 500);
  expect(captured()).toBe(1);
  setBlocked(true); await settle();
  pointer(divider, 'pointermove', 450);
  divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true, cancelable: true }));
  expect(changed).not.toHaveBeenCalled();
  pointer(divider, 'pointerup', 450); expect(captured()).toBeUndefined();
  setBlocked(false); await settle();
  divider.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true, cancelable: true }));
  expect(changed).toHaveBeenCalledExactlyOnceWith(320);
});
