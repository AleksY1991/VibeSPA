import type { SplitPanelControlProps } from '../contracts/split-panel';

export const SPLIT_KEYS = ['ArrowLeft', 'ArrowRight', 'Home', 'End', 'Enter'] as const;
const VENDOR_KEYS = [...SPLIT_KEYS, 'ArrowUp', 'ArrowDown'];
export const splitSize = (props: SplitPanelControlProps): number => props.state.collapsed ? 0
  : Math.max(props.min, Math.min(props.max, Number.isFinite(props.state.endSize) ? props.state.endSize : props.min));

/**
 * The control layer owns pixel steps and cancelable pointer capture. WA 3.12's drag helper
 * leaves document listeners alive until pointerup, including after unmount, and
 * its keyboard step is a percentage instead of the existing 16px. Use its public
 * position API for layout, but retain this shared input owner until the vendor
 * exposes disposable drag sessions and a pixel keyboard step. No window keys or
 * document drag listeners are installed; Tab and focus remain browser-owned.
 * Collapse belongs to the owner's visible close action and must preserve its
 * saved width. WA 3.12's unconditional Enter collapse bypasses that state and
 * briefly hides content before controlled layout restores it. Reserve Enter as
 * a no-op until WA exposes a way to disable or control keyboard collapse.
 */
export function bindSplitDivider(container: HTMLElement, divider: HTMLElement, props: SplitPanelControlProps): () => void {
  let pointer: number | undefined;
  let originX = 0;
  let originSize = 0;
  const commit = (size: number) => {
    if (props.state.collapsed || !Number.isFinite(size)) return;
    props.onEndSizeChange(Math.max(props.min, Math.min(props.max, Math.round(size))));
  };
  const stop = () => {
    const captured = pointer;
    pointer = undefined;
    if (captured !== undefined && divider.hasPointerCapture(captured)) divider.releasePointerCapture(captured);
    divider.removeAttribute('data-dragging');
  };
  const down = (event: PointerEvent) => {
    if (props.state.collapsed || event.button !== 0 || pointer !== undefined) return;
    event.preventDefault();
    divider.focus({ preventScroll: true });
    pointer = event.pointerId;
    originX = event.clientX;
    originSize = splitSize(props);
    divider.setPointerCapture(pointer);
    divider.setAttribute('data-dragging', '');
  };
  const move = (event: PointerEvent) => {
    if (pointer !== event.pointerId) return;
    if (props.state.collapsed) { stop(); return; }
    const rtl = getComputedStyle(container).direction === 'rtl';
    let next = originSize + (event.clientX - originX) * (rtl ? 1 : -1);
    const width = container.getBoundingClientRect().width;
    const snap = [1 / 3, 1 / 2, 2 / 3].map(part => width * part)
      .find(size => size >= props.min && size <= props.max && Math.abs(size - next) <= 12);
    if (snap !== undefined) next = snap;
    commit(next);
  };
  const key = (event: KeyboardEvent) => {
    if (props.state.collapsed || !VENDOR_KEYS.includes(event.key)) return;
    // WA also handles modified arrows and the other orientation's keys. Stop
    // that second handler while leaving unclaimed browser defaults intact;
    // the app dispatcher has already received the event in window capture.
    event.stopImmediatePropagation();
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    if (!SPLIT_KEYS.some(key => key === event.key)) return;
    event.preventDefault();
    if (event.key === 'Enter') return;
    const rtl = getComputedStyle(container).direction === 'rtl';
    commit(event.key === 'Home' ? props.min : event.key === 'End' ? props.max
      : splitSize(props) + props.step * (event.shiftKey ? 10 : 1) * ((event.key === 'ArrowLeft') !== rtl ? 1 : -1));
  };
  const suppressVendorDrag = (event: Event) => { event.preventDefault(); event.stopImmediatePropagation(); };
  divider.addEventListener('pointerdown', down);
  divider.addEventListener('pointermove', move);
  divider.addEventListener('pointerup', stop);
  divider.addEventListener('pointercancel', stop);
  divider.addEventListener('lostpointercapture', stop);
  divider.addEventListener('keydown', key, true);
  divider.addEventListener('mousedown', suppressVendorDrag, true);
  divider.addEventListener('touchstart', suppressVendorDrag, { capture: true, passive: false });
  return () => {
    stop();
    divider.removeEventListener('pointerdown', down);
    divider.removeEventListener('pointermove', move);
    divider.removeEventListener('pointerup', stop);
    divider.removeEventListener('pointercancel', stop);
    divider.removeEventListener('lostpointercapture', stop);
    divider.removeEventListener('keydown', key, true);
    divider.removeEventListener('mousedown', suppressVendorDrag, true);
    divider.removeEventListener('touchstart', suppressVendorDrag, true);
  };
}
