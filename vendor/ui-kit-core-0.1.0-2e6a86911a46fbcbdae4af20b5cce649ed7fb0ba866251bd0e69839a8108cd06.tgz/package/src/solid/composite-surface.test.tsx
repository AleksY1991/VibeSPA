/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import type { JSX } from '@solidjs/web';
import { renderPrepared as render } from '../../tests/prepared';
import { createSignal, flush } from 'solid-js';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { HOTKEY_PASS } from '../contracts/platform';
import { constructItem } from '../infrastructure/construction';
import type { TabsState } from '../contracts/tabs';
import type { FocusHandle } from '../contracts/controls';
import type { SelectElement } from '../vendor/web-awesome/elements';
import { Button } from './button';
import { FilePicker } from './file-picker';
import { Select } from './select';
import { Tag } from './tag';
import { TabPanel, Tabs } from './tabs';

const options = [{ value: 'one', label: 'One', id: 'one-tab', panelId: 'one-panel' },
  { value: 'two', label: 'Two', id: 'two-tab', panelId: 'two-panel' }];
const disposers: (() => void)[] = [];
const settle = async () => { for (let i = 0; i < 40; i++) { flush(); await Promise.resolve(); } };
const press = (target: Element, key: string, init: KeyboardEventInit = {}) => {
  const event = new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true, ...init });
  target.dispatchEvent(event);
  return event;
};
async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const dispose = render(view, container); disposers.push(dispose); await settle();
  return { container, dispose };
}
beforeEach(() => disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
  commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) })));
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  document.body.replaceChildren();
  vi.restoreAllMocks();
});

describe('explicit composite native ownership', () => {
  it.each(['FilePicker', 'Tag'] as const)('delivers %s native overrides from its internal Button', async control => {
    const override = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('composite.override', item => ({
        file: item.constant<File | null>('file', null),
        tag: item.constant('tag', { label: 'Work', removeLabel: 'Remove Work' }),
      }));
      const hotkeys = [{ key: 'Enter', overrideNative: true, handler: override }];
      return control === 'FilePicker'
        ? <FilePicker.View observable={model.file} surface={{ kind: 'own', name: 'composite.file', transparent: false }} hotkeys={hotkeys} label="Attachment" onFileChange={() => {}} />
        : <Tag.View observable={model.tag} surface={{ kind: 'own', name: 'composite.tag', transparent: false }} hotkeys={hotkeys} onRemove={() => {}} />;
    });
    expect(press(container.querySelector('button')!, 'Enter').defaultPrevented).toBe(true);
    expect(override).toHaveBeenCalledOnce();
  });

  it('delivers overrides from internal tabs to their tablist', async () => {
    const override = vi.fn(); const change = vi.fn();
    const { container } = await mount(() => {
      const state = constructItem('composite.tabs', item => item.constant('state', { value: 'one', tabs: options }));
      return <Tabs.View observable={state}
        surface={{ kind: 'own', name: 'composite.tabs', transparent: false }}
        hotkeys={[{ key: 'ArrowRight', overrideNative: true, handler: override }]}
         label="Sections" size="compact" onValueChange={change} />;
    });
    expect(press(container.querySelector('#one-tab')!, 'ArrowRight').defaultPrevented).toBe(true);
    expect(override).toHaveBeenCalledOnce(); expect(change).not.toHaveBeenCalled();
  });

  it('does not grant unrelated ancestors native override rights', async () => {
    const ancestor = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('composite.parent', item => ({
        active: item.constant('active', true), tag: item.constant('tag', { label: 'Work', removeLabel: 'Remove Work' }),
      }));
      return <TabPanel.View observable={model.active} surface={{ kind: 'own', name: 'composite.parent', transparent: false }}
        hotkeys={[{ key: 'Enter', overrideNative: true, handler: ancestor }]} id="parent" tabId="parent-tab" value="parent">
        <Tag.View observable={model.tag} surface={{ kind: 'inherit' }} hotkeys={[]} onRemove={() => {}} />
      </TabPanel.View>;
    });
    expect(press(container.querySelector('button')!, 'Enter').defaultPrevented).toBe(false);
    expect(ancestor).not.toHaveBeenCalled();
  });
});

describe('composite surface lifetimes', () => {
  it('removes and restores the Tabs lease with the rendered strip', async () => {
    const [state, setState] = createSignal<TabsState>({ value: 'one', tabs: options });
    const { container } = await mount(() => {
      const model = constructItem('composite.tabsLifetime', item => item.observe('state', state));
      return <Tabs.View observable={model}
        surface={{ kind: 'own', name: 'composite.tabsLifetime', transparent: false }} hotkeys={[]}
         label="Sections" size="compact" onValueChange={() => {}} />;
    });
    const live = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'composite.tabsLifetime');
    expect(live()).toHaveLength(1);
    setState({ value: 'one', tabs: options, disabled: true }); await settle();
    expect(container.querySelector('#one-tab')).not.toBeNull(); expect(live()).toHaveLength(1);
    setState({ value: null, tabs: [] }); await settle();
    expect(container.querySelector('[data-ui-tabs]')).toBeNull(); expect(live()).toHaveLength(0);
    setState({ value: 'one', tabs: options }); await settle();
    expect(container.querySelector('#one-tab')).not.toBeNull(); expect(live()).toHaveLength(1);
  });

  it('suspends retained TabPanel descendants and restores their same DOM with the panel', async () => {
    const [active, setActive] = createSignal(true); const command = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('composite.retainedPanel', item => ({
        active: item.observe('active', active), button: item.constant('button', {}),
      }));
      return <TabPanel.View observable={model.active} surface={{ kind: 'own', name: 'composite.retainedPanel', transparent: false }}
        hotkeys={[]} id="panel" tabId="tab" value="panel">
        <Button.View observable={model.button} surface={{ kind: 'own', name: 'composite.retainedButton', transparent: false }}
          hotkeys={[{ key: 'X', handler: command }]}>Retained action</Button.View>
      </TabPanel.View>;
    });
    const button = container.querySelector('button')!;
    const live = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name.startsWith('composite.retained'));
    expect(live()).toHaveLength(2); press(button, 'x'); expect(command).toHaveBeenCalledOnce();
    setActive(false); await settle();
    expect(container.querySelector('button')).toBe(button); expect(live()).toHaveLength(0);
    press(button, 'x'); expect(command).toHaveBeenCalledOnce();
    setActive(true); await settle();
    expect(container.querySelector('button')).toBe(button); expect(live()).toHaveLength(2);
    press(button, 'x'); expect(command).toHaveBeenCalledTimes(2);
  });
});

describe('Select native typeahead ownership', () => {
  it('retains printable keys in an inherited Select', async () => {
    const ancestor = vi.fn();
    const { container } = await mount(() => {
      const model = constructItem('select.typeahead', item => ({
        active: item.constant('active', true), value: item.constant('value', 'one'),
      }));
      return <TabPanel.View observable={model.active}
        surface={{ kind: 'own', name: 'select.typeaheadParent', transparent: false }}
        hotkeys={[{ key: 'T', overrideNative: true, handler: ancestor }, { key: 'Shift+T', overrideNative: true, handler: ancestor }]} id="select-typeahead-parent" tabId="typeahead-tab" value="typeahead">
        <Select.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[]}
           label="Choice" options={options} onValueChange={() => {}} />
      </TabPanel.View>;
    });
    const select = container.querySelector('wa-select')!;
    expect(press(select, 't').defaultPrevented).toBe(false);
    expect(press(select, 'T', { shiftKey: true }).defaultPrevented).toBe(false);
    expect(ancestor).not.toHaveBeenCalled();
    expect(press(container.querySelector('#select-typeahead-parent')!, 't').defaultPrevented).toBe(true);
    expect(ancestor).toHaveBeenCalledOnce();
  });

  it('honors explicit printable overrides on Select itself', async () => {
    const override = vi.fn();
    const { container } = await mount(() => {
      const value = constructItem('select.typeaheadOverride', item => item.constant('value', 'one'));
      return <Select.View observable={value} surface={{ kind: 'inherit' }}
        hotkeys={[{ key: 'T', overrideNative: true, handler: override }]}
         label="Choice" options={options} onValueChange={() => {}} />;
    });
    expect(press(container.querySelector('wa-select')!, 't').defaultPrevented).toBe(true);
    expect(override).toHaveBeenCalledOnce();
  });
});

describe('Select Escape ownership', () => {
  async function selectInPanel(customPass = false) {
    const dismiss = vi.fn();
    const mounted = await mount(() => {
      const model = constructItem('select.escape', item => ({ active: item.constant('active', true), value: item.constant('value', 'one') }));
      return <TabPanel.View observable={model.active}
        surface={{ kind: 'own', name: 'select.escapeParent', transparent: false }} hotkeys={[{ key: 'Escape', handler: dismiss }]} id="select-parent" tabId="select-parent-tab" value="select-parent">
        <Select.View observable={model.value} surface={{ kind: 'own', name: 'select.escape', transparent: false }}
          hotkeys={customPass ? [{ key: 'Escape', overrideNative: true, handler: () => HOTKEY_PASS }] : []}
           label="Choice" options={options} onValueChange={() => {}} />
      </TabPanel.View>;
    });
    return { ...mounted, dismiss };
  }

  it.each([false, true])('preserves open Select Escape, then delegates closed Escape (custom pass=%s)', async customPass => {
    const { container, dismiss } = await selectInPanel(customPass);
    const select = container.querySelector<SelectElement>('wa-select')!;
    const nativeEscape = vi.fn(() => { select.open = false; });
    select.displayInput.addEventListener('keydown', nativeEscape);
    select.open = true;
    expect(press(select.displayInput, 'Escape').defaultPrevented).toBe(false);
    expect(nativeEscape).toHaveBeenCalledOnce(); expect(dismiss).not.toHaveBeenCalled();
    expect(press(select.displayInput, 'Escape').defaultPrevented).toBe(true);
    expect(nativeEscape).toHaveBeenCalledOnce(); expect(dismiss).toHaveBeenCalledOnce();
  });

  it('retains one failed Select host without granting parent Escape or edit authority', async () => {
    vi.spyOn(customElements.get('wa-select')!.prototype, 'updateComplete', 'get').mockReturnValue(Promise.resolve(false));
    const { container, dismiss } = await selectInPanel();
    const select = container.querySelector<SelectElement>('wa-select')!;
    expect(select.getAttribute('data-ui-ready')).toBe('failed');
    expect(select.getAttribute('data-ui-error')).toBe('update-failed');
    expect(select.hasAttribute('inert')).toBe(true);
    expect(container.querySelector('select')).toBeNull();
    expect(press(select, 'Escape').defaultPrevented).toBe(false);
    expect(press(select, 'Enter').defaultPrevented).toBe(false);
    expect(dismiss).not.toHaveBeenCalled();
  });

});

describe('Select action authority', () => {
  it('suspends retained value commands with its parent surface', async () => {
    const [active, setActive] = createSignal(true); const changed = vi.fn();
    const [disabled, setDisabled] = createSignal(false); const shortcut = vi.fn();
    let handle: FocusHandle | undefined;
    const { container } = await mount(() => {
      const model = constructItem('select.activation', item => ({
        active: item.observe('active', active), value: item.constant('value', 'one'),
      }));
      return <TabPanel.View observable={model.active}
        surface={{ kind: 'own', name: 'select.activationParent', transparent: false }} hotkeys={[]} id="select-activation-parent" tabId="activation-tab" value="activation">
        <Select.View observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[{ key: 'F2', handler: shortcut }]}
          disabled={disabled()} onHandle={value => { handle = value; }}
           label="Choice" options={options} onValueChange={changed} />
      </TabPanel.View>;
    });
    const select = container.querySelector<SelectElement>('wa-select')!;
    const focus = vi.spyOn(select, 'focus');
    handle!.focus(); expect(focus).toHaveBeenCalledOnce();
    const change = () => { select.value = 'two'; select.dispatchEvent(new Event('change', { bubbles: true })); };
    change(); expect(changed).toHaveBeenCalledOnce();
    press(select, 'F2'); expect(shortcut).toHaveBeenCalledOnce();
    setDisabled(true); await settle();
    press(select, 'F2'); expect(shortcut).toHaveBeenCalledOnce();
    setDisabled(false); await settle();
    setActive(false); await settle();
    change(); expect(changed).toHaveBeenCalledOnce();
    handle!.focus(); expect(focus).toHaveBeenCalledOnce();
    setActive(true); await settle();
    change(); expect(changed).toHaveBeenCalledTimes(2);
    handle!.focus(); expect(focus).toHaveBeenCalledTimes(2);
  });
});
