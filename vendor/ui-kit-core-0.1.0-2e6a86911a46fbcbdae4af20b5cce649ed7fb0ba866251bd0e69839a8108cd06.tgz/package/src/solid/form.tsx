/** @jsxImportSource @solidjs/web */
import { omit } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';

export interface FormState {
  readonly disabled?: boolean;
}

/** Submission remains native unless the command explicitly prevents its default. */
export interface SubmitIntent {
  preventDefault(): void;
  stopPropagation(): void;
  formData(): FormData;
}

type NativeFormAttributes = Omit<JSX.FormHTMLAttributes<HTMLFormElement>,
  'ref' | 'aria-disabled' | Extract<keyof JSX.FormHTMLAttributes<HTMLFormElement>, `on${string}`>>;

export interface FormProps extends NativeFormAttributes, ElementConstruction<FormState> {
  readonly onSubmit: (intent: SubmitIntent) => void;
}

function renderForm(props: FormProps): JSX.Element {
  const binding = new ElementBinding('Form', props, { nativeKeys: ['Enter'], enabledWhen: state => !state.disabled });
  const native = omit(props, 'observable', 'surface', 'hotkeys', 'onSubmit');
  return binding.provide(() => <form {...native}
    ref={node => binding.attach(node)}
    data-ui-keyboard-owner="Enter"
    aria-disabled={binding.value().disabled ? 'true' : undefined}
    onSubmit={event => {
      if (!allowActivation(binding, event)) return;
      const form = event.currentTarget;
      const submitter = event.submitter;
      props.onSubmit(Object.freeze({
        preventDefault: () => event.preventDefault(),
        stopPropagation: () => event.stopPropagation(),
        formData: () => new FormData(form, submitter),
      }));
    }}
  />);
}

/**
 * WA form controls participate in a native form; there is no replacement wa-form
 * in WA 3.12. Native validation, submitter values and implicit Enter submission
 * stay browser-owned. This boundary adds typed cancellation and disabled/lifetime
 * guards without a fieldset wrapper that would change layout or disable editing.
 */
export class Form extends RenderedElement<FormState> {
  readonly element: JSX.Element;
  constructor(props: FormProps) {
    super('Form', props);
    if (typeof props.onSubmit !== 'function') throw new TypeError('Form: a typed onSubmit command is required');
    this.element = renderForm(this.capture(props));
  }
  static View = (props: FormProps): JSX.Element => new Form(props).element;
}
