/** @jsxImportSource @solidjs/web */
import { createEffect, createUniqueId, onCleanup } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { constructItem } from '../infrastructure/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';
import { Button, type ButtonState } from './button';
import { cn } from '../lib/utils';
import './file-picker.css';

export interface FilePickerProps extends ElementConstruction<File | null> {
  
  readonly label: string;
  readonly accept?: string;
  readonly disabled?: boolean;
  readonly onFileChange: (file: File | null) => void;
  readonly class?: string;
}

function renderFilePicker(props: FilePickerProps) {
  const binding = new ElementBinding('FilePicker', props, { nativeKeys: ['Enter', 'Space'], enabledWhen: () => !props.disabled });
  const descriptionId = createUniqueId();
  let alive = true;
  onCleanup(() => { alive = false; });
  let engine: HTMLInputElement | undefined;
  const triggerState = constructItem('FilePicker.trigger', item => item.observe<ButtonState>('state',
    () => ({ disabled: props.disabled }), { equals: (previous, next) => previous.disabled === next.disabled }));
  createEffect(binding.value, value => { if (!value && engine) engine.value = ''; });
  return binding.provide(() => <div ref={binding.attach} class={cn("ui-file-picker-content", props.class)} data-ui-file-picker="">
    <Button.View observable={triggerState} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" recipe="content" aria-label={`Choose file: ${props.label}`} aria-describedby={descriptionId}
      onActivate={event => { if (allowActivation(binding, event) && alive && !props.disabled) engine?.click(); }}>Choose file</Button.View>
    <span id={descriptionId} class="ui-file-picker-status" role="status">{binding.value()?.name ?? 'No file chosen'}</span>
    <input ref={element => { engine = element; binding.attachNative(element); }} type="file" hidden class="ui-file-picker-engine" tabindex={-1}
      accept={props.accept} disabled={props.disabled} aria-label={props.label} aria-hidden="true"
      onChange={event => {
        if (!allowActivation(binding, event) || !alive || props.disabled) return;
        const file = event.currentTarget.files?.[0] ?? null;
        // Keep the selection in its observable, not the engine: rejecting a file
        // must still let the user choose that same file again and receive change.
        event.currentTarget.value = '';
        props.onFileChange(file);
      }} />
  </div>, { nativeChildren: true });
}

/**
 * WA 3.12.0 supports file selection through wa-file-input (Pro), including File[]
 * access, clearing, a dropzone slot and public styling parts. That component is
 * absent from the installed free package; this is not a library capability gap.
 * https://webawesome.com/docs/components/file-input/
 *
 * Free native.css also styles input[type=file], but a visible native input alone
 * ties its filename to the browser's selection. The control library must keep the original File
 * and observable filename after rejection while clearing the chooser for retries.
 * Compose the shared native Button with a hidden file input to preserve that
 * contract and the compact geometry required by DESIGN.md. The tradeoff is owning
 * the filename announcement and reset wiring; selection itself never uploads.
 * The hidden input is a private browser engine of FilePicker's live surface;
 * assigning it a separately visible public Input lifetime would deny the launch.
 * https://webawesome.com/docs/utilities/native
 *
 * The browser owns file access; Button owns keyboard activation and its accessible
 * name includes the visible "Choose file" text. A Pro adapter can replace this
 * composition when available and verified for the same geometry and reselection.
 */
export class FilePicker extends RenderedElement<File | null> {
  readonly element: JSX.Element;
  constructor(props: FilePickerProps) {
    super('FilePicker', props);
    this.element = renderFilePicker(this.capture(props));
  }
  static View = (props: FilePickerProps): JSX.Element => new FilePicker(props).element;
}
