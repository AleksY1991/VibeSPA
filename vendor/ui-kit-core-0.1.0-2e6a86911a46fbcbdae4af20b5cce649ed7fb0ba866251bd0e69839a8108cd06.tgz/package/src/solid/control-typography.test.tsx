/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render as renderSolid, type JSX } from '@solidjs/web';
import { createComponent, flush } from 'solid-js';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeTextField } from '../vendor/web-awesome/text-field.adapter';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { Button } from './button';
import { TextField } from './text-field';
import { authoredStyle, useStyles } from '../../tests/styles';

useStyles('tokens.css', 'reset.css', 'solid/button.css', 'solid/button-geometry.css',
  'solid/text-field.css', 'solid/field-lifecycle.css', 'solid/control-geometry.css',
  'vendor/web-awesome/text-field.css');

class TypographyInput extends HTMLElement {
  readonly input = document.createElement('input');
  readonly updateComplete = Promise.resolve(true);
  constructor() { super(); this.attachShadow({ mode: 'open' }).append(this.input); }
}
beforeAll(() => { customElements.define('wa-input', TypographyInput); });
function render(code: () => JSX.Element, host: HTMLElement) {
  return renderSolid(() => <ImplementationContext value={{ TextField: WebAwesomeTextField }}>{createComponent(code, {})}</ImplementationContext>, host);
}
const settle = async () => { for (let n = 0; n < 12; n++) { flush(); await Promise.resolve(); } };

const disposers: (() => void)[] = [];
afterEach(() => {
  for (const dispose of disposers.splice(0)) dispose();
  document.body.replaceChildren();
});

function appProse() {
  const wrapper = document.createElement('div');
  wrapper.style.cssText = 'font-family: fantasy; font-size: 30px; font-weight: 900; font-style: italic; letter-spacing: 7px; word-spacing: 9px; line-height: 3;';
  wrapper.style.textTransform = 'uppercase';
  document.body.append(wrapper);
  return wrapper;
}

function expectOwnedFont(element: Element) {
  const style = getComputedStyle(element);
  const ownedFace = getComputedStyle(document.body).getPropertyValue('--ui-font-family')
    .split(',')[0].replace(/['"]/g, '').trim();
  expect(ownedFace).not.toBe('');
  expect(style.fontFamily).toContain(ownedFace);
  expect(style.fontFamily).not.toContain('fantasy');
  expect(style.fontStyle).toBe('normal');
  expect(style.letterSpacing).toBe('0px');
  expect(style.wordSpacing).toBe('0px');
  expect(style.textTransform).toBe('none');
}

describe('complete control typography isolation', () => {
  it('keeps default Button and TextField typography independent of application prose', async () => {
    const wrapper = appProse();
    disposers.push(render(() => {
      const button = constructItem('test.button', item => item.observe('state', () => ({})));
      const field = constructItem('test.field', item => item.observe('value', () => 'Example'));
      return <>
        <Button.View observable={button} surface={{ kind: 'inherit' }} hotkeys={[]}>Save</Button.View>
        <TextField.View observable={field} surface={{ kind: 'inherit' }} hotkeys={[]} label="Name" onValueChange={() => {}} />
      </>;
    }, wrapper));
    await settle();
    expect(wrapper.querySelectorAll('button, wa-input')).toHaveLength(2);
    for (const element of wrapper.querySelectorAll('button, wa-input')) {
      expectOwnedFont(element);
      expect(getComputedStyle(element).fontSize).toBe('13px');
      expect(getComputedStyle(element).fontWeight).toBe('400');
      expect(getComputedStyle(element).lineHeight).toBe('1.4');
    }
    expect(getComputedStyle(wrapper).fontFamily).toBe('fantasy');
  });

  it('gives the code recipe its owned monospace typography', async () => {
    const wrapper = appProse();
    disposers.push(render(() => {
      const value = constructItem('test.code', item => item.observe('value', () => 'code'));
      return <TextField.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Code" recipe="code" onValueChange={() => {}} />;
    }, wrapper));
    await settle();
    const vendor = wrapper.querySelector('wa-input')!;
    const style = getComputedStyle(vendor);
    expect(style.fontFamily).toContain('ui-monospace');
    expect(style.fontFamily).not.toContain('fantasy');
    expect(style.letterSpacing).toBe('0px');
    expect(style.textTransform).toBe('none');
    expect(getComputedStyle(vendor).getPropertyValue('--wa-font-family-body')).toContain('ui-monospace');
  });

  it('gives vendor control hosts the same owned defaults before their parts inherit them', () => {
    const wrapper = appProse();
    for (const [tag, marker] of [['wa-input', 'data-ui-text-field']] as const) {
      const element = document.createElement(tag);
      element.setAttribute(marker, '');
      wrapper.append(element);
      expectOwnedFont(element);
    }
  });

  it('lets the inline recipe match surrounding prose while keeping its owned font face', () => {
    const wrapper = appProse();
    disposers.push(render(() => {
      const button = constructItem('test.prose-action', item => item.observe('state', () => ({})));
      return <Button.View observable={button} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="inline-action">Action</Button.View>;
    }, wrapper));
    const button = wrapper.querySelector('button')!;
    expectOwnedFont(button);
    // Happy DOM preserves the authored keyword; Chromium resolves it against
    // the surrounding prose. The recipe owns this choice without a free knob.
    expect(authoredStyle(button, 'font-size')).toBe('inherit');
    expect(authoredStyle(button, 'line-height')).toBe('inherit');
    expect(getComputedStyle(wrapper).fontSize).toBe('30px');
    expect(getComputedStyle(button).fontWeight).toBe('400');
  });
});
