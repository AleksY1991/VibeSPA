/** @jsxImportSource @solidjs/web */
import type { JSX } from '@solidjs/web';
import { Show } from 'solid-js';
import type { ChoiceGroupControlProps } from '../contracts/controls';
import { controlSize } from '../control-size';
import { cn } from '../lib/utils';
import './controls.css';

/** Private layout shared with the canonical vendor composite, never an alternate control. */
export function ChoiceGroupLayout(props: Pick<ChoiceGroupControlProps, 'label' | 'labelPosition' | 'prefix' | 'layout' | 'class' | 'size'> & { readonly children: JSX.Element }) {
  return <div data-ui-control-size={controlSize(props.size)} class={cn('ui-choice-group ui-control-icons ui-choice-group-layout', props.class)}>
    <Show when={!props.labelPosition || props.labelPosition === 'above'}>
      <span aria-hidden="true" class="ui-choice-group-label-above">{props.label}</span>
    </Show>
    <div class="ui-choice-group-row">
      <Show when={props.prefix}><span aria-hidden="true" class="ui-choice-group-prefix">{props.prefix}</span></Show>
      <Show when={props.labelPosition === 'inline'}>
        <span aria-hidden="true" class="ui-choice-group-label-inline">{props.label}</span>
      </Show>
      {props.children}
    </div>
  </div>;
}
