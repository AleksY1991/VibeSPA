/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { createSignal, flush, useContext } from 'solid-js';
import { renderPrepared } from '../../tests/prepared';
import { registerModalPortalScope } from './portal';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { UiRootImplementation } from '../infrastructure/renderUiRoot';
import { authoredStyle, useStyles } from '../../tests/styles';

import {
  installTooltipDelegation,
  mountTooltipLayer,
  TooltipLayer,
  type TooltipLayerController,
} from './tooltip-layer';

useStyles('vendor/web-awesome/tooltip.css');

const disposers: (() => void)[] = [];
function mountLayer(...args: Parameters<typeof mountTooltipLayer>): () => void {
  const [host, props] = args;
  const dispose = renderPrepared(() => { const construction = props(); return <TooltipLayer.View {...construction} />; }, host);
  let active = true;
  const release = () => { if (active) { active = false; dispose(); } };
  disposers.push(release);
  return release;
}

const settle = async () => {
  for (let count = 0; count < 48; count++) { flush(); await Promise.resolve(); }
};

const pointerEvent = (type: string, pointerType: 'mouse' | 'touch') => {
  const event = new Event(type, { bubbles: true, cancelable: true });
  Object.defineProperty(event, 'pointerType', { value: pointerType });
  return event;
};

afterEach(() => {
  for (const dispose of disposers.splice(0).reverse()) dispose();
  document.body.replaceChildren();
  vi.useRealTimers();
});

describe('Solid TooltipLayer lifecycle', () => {
  it('inherits its prepared implementation when mounted into a registered host outside its owner', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const childHost = document.createElement('div');
    const releaseParent = renderPrepared(() => {
      const implementation = useContext(ImplementationContext)!;
      return <UiRootImplementation host={host} implementation={implementation}>{childHost}</UiRootImplementation>;
    }, host);
    let controller!: TooltipLayerController;
    const releaseChild = mountTooltipLayer(childHost, () => ({
      observable: constructItem('tooltip.inherited', item => item.constant('enabled', true)),
      surface: { kind: 'inherit' }, hotkeys: [], controllerRef: next => { controller = next; },
    }));
    const trigger = document.createElement('button'); trigger.dataset.tip = 'Inherited hint'; host.append(trigger);
    try {
      await settle(); controller.openFor(trigger); await settle();
      expect(document.querySelector('[role="tooltip"]')?.textContent).toBe('Inherited hint');
    } finally { releaseChild(); releaseParent(); }
  });

  it('tracks tooltip delay changes in the compute scope', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const trigger = document.createElement('button'); trigger.dataset.tip = 'Hint'; document.body.append(trigger);
    const [delay, setDelay] = createSignal(60_000);
    const dispose = mountLayer(host, () => ({
      observable: constructItem('tooltip.delay', item => item.constant('enabled', true)),
      surface: { kind: 'inherit' }, hotkeys: [], get delayMs() { return delay(); },
    }));
    try {
      await settle(); flush(); await settle();
      trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
      expect(document.querySelector('[role="tooltip"]')).toBeNull();
      setDelay(0); flush(); await settle();
      trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
      expect(document.querySelector('[role="tooltip"]')?.textContent).toBe('Hint');
    } finally { dispose(); }
  });
  it('mounts a globally owned hint inside the target modal scope and dismisses when that modal closes', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const modal = document.createElement('dialog'); modal.setAttribute('data-ui-dialog-overlay', ''); modal.setAttribute('open', '');
    const content = document.createElement('div'); modal.append(content); document.body.append(modal);
    const trigger = document.createElement('button'); trigger.setAttribute('data-tip', 'Modal hint'); content.append(trigger);
      const unregister = registerModalPortalScope(modal, { mount: content, open: () => modal.hasAttribute('open') });
    const dispose = mountLayer(host, () => ({
      observable: constructItem('tooltip.modal', item => item.constant('enabled', true)),
      surface: { kind: 'inherit' }, hotkeys: [], delayMs: 0,
    }));
    await settle(); flush(); await settle();
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
    expect(content.querySelector('[role="tooltip"]')?.textContent).toBe('Modal hint');
    modal.removeAttribute('open');
    await vi.waitFor(() => expect(document.querySelector('[role="tooltip"]')).toBeNull());
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
    expect(document.querySelector('[role="tooltip"]')).toBeNull();
    dispose(); unregister();
  });

  it('recognizes the canonical dialog and dismisses its hint when the native panel closes', async () => {
    const modal = document.createElement('dialog');
    modal.setAttribute('data-ui-dialog-overlay', ''); modal.setAttribute('open', '');
    const trigger = document.createElement('button'); trigger.dataset.tip = 'Visible in graph.';
    modal.append(trigger); document.body.append(modal);
    const open = vi.fn(); const close = vi.fn();
    const cleanup = installTooltipDelegation(document, window, { delayMs: 0, open, close });
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    expect(open).toHaveBeenCalledExactlyOnceWith(trigger);
    close.mockClear(); modal.removeAttribute('open');
    await vi.waitFor(() => expect(close).toHaveBeenCalledOnce());
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    expect(open).toHaveBeenCalledOnce();
    cleanup();
  });

  it('checks composed modal ancestors and observes removal inside a shadow root', async () => {
    const host = document.createElement('test-modal');
    const root = host.attachShadow({ mode: 'open' });
    const modal = document.createElement('dialog'); modal.setAttribute('data-ui-dialog-overlay', ''); root.append(modal);
    const wrapper = document.createElement('div'); modal.append(wrapper);
    const trigger = document.createElement('button'); trigger.setAttribute('data-tip', 'Shadow hint'); wrapper.append(trigger);
    document.body.append(host);
    const open = vi.fn(); const close = vi.fn();
    const cleanup = installTooltipDelegation(root as unknown as Document, window, { delayMs: 0, open, close });
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); expect(open).not.toHaveBeenCalled();
    modal.setAttribute('open', ''); trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); expect(open).toHaveBeenCalledOnce();
    close.mockClear(); wrapper.remove();
    await vi.waitFor(() => expect(close).toHaveBeenCalledOnce());
    cleanup();
  });

  it('delegates only mouse data-tip gestures and removes every listener on cleanup', () => {
    const trigger = document.createElement('button');
    trigger.setAttribute('data-tip', 'View settings');
    document.body.append(trigger);
    const opened: HTMLElement[] = [];
    let closes = 0;
    const cleanup = installTooltipDelegation(document, window, {
      delayMs: 0,
      open: (element) => opened.push(element),
      close: () => { closes += 1; },
    });

    trigger.dispatchEvent(pointerEvent('pointerover', 'touch'));
    expect(opened).toEqual([]);
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    expect(opened).toEqual([trigger]);
    document.dispatchEvent(pointerEvent('pointerdown', 'mouse'));
    expect(closes).toBeGreaterThan(0);

    cleanup();
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    expect(opened).toEqual([trigger]);
  });

  it('renders the themed tooltip through the shared body portal', async () => {
    const host = document.createElement('div');
    document.body.append(host);
    const trigger = document.createElement('button');
    trigger.setAttribute('data-tip', 'View settings');
    document.body.append(trigger);
    let controller!: TooltipLayerController;
    const dispose = mountLayer(host, () => ({
      observable: constructItem('tooltip test', item => item.constant('enabled', true)),
      surface: { kind: 'inherit' }, hotkeys: [],
      delayMs: 0,
      controllerRef: (next) => { controller = next; },
    }));
    await settle();

    controller.openFor(trigger);
    flush();
    await settle();
    const tooltip = document.body.querySelector<HTMLElement>('[role="tooltip"]');
    expect(tooltip?.textContent).toBe('View settings');
    expect(host.querySelector('[role="tooltip"]')).toBeNull();
    expect(tooltip?.getAttribute('aria-hidden')).toBe('true');
    // Happy DOM does not compute modern HSL token colors. Match the authored
    // selector against the rendered element to retain scoped paint coverage.
    expect(authoredStyle(tooltip!, 'background')).toBe('hsl(var(--ui-popover))');
    expect(authoredStyle(tooltip!, 'color')).toBe('hsl(var(--ui-foreground))');
    expect(document.querySelector('wa-popup[data-ui-tooltip]')).not.toBeNull();
    expect(trigger.hasAttribute('title')).toBe(false);

    controller.close();
    flush();
    expect(document.body.querySelector('[role="tooltip"]')).toBeNull();
    dispose();
  });

  it('gives detailed paths readable measure and wraps unbroken names inside the viewport', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const trigger = document.createElement('button');
    trigger.dataset.tip = `Path\nWorkspace → ${'LongNodeName'.repeat(30)}\n\nHidden in graph\n• Status filter: Done.`;
    document.body.append(trigger);
    mountLayer(host, () => ({
      observable: constructItem('tooltip.details', item => item.constant('enabled', true)),
      surface: { kind: 'inherit' }, hotkeys: [], delayMs: 0,
    }));
    await settle(); flush(); await settle();
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
    const tip = document.querySelector<HTMLElement>('[role="tooltip"]')!;
    expect(tip.textContent).toBe(trigger.dataset.tip);
    expect(tip.hasAttribute('data-ui-tooltip-detailed')).toBe(true);
    expect(tip.style.maxWidth).toBe(`${Math.min(384, window.innerWidth - 16)}px`);
    expect(authoredStyle(tip, 'font-size')).toBe('var(--ui-text-body)');
    expect(getComputedStyle(tip).overflowWrap).toBe('anywhere');
    expect(getComputedStyle(tip).whiteSpace).toBe('pre-wrap');
  });

  it('suppresses native, ARIA and shadow-disabled controls and rechecks pending tips', () => {
    vi.useFakeTimers();
    const disabled = document.createElement('button');
    disabled.disabled = true;
    const ariaDisabled = document.createElement('button');
    ariaDisabled.setAttribute('aria-disabled', 'true');
    const shadowDisabled = document.createElement('test-action');
    const inner = document.createElement('button'); inner.disabled = true;
    shadowDisabled.attachShadow({ mode: 'open' }).append(inner);
    const pending = document.createElement('button');
    for (const element of [disabled, ariaDisabled, shadowDisabled, pending]) {
      element.setAttribute('data-tip', 'Action hint'); document.body.append(element);
    }
    const open = vi.fn();
    const cleanup = installTooltipDelegation(document, window, { open, close: () => {} });
    for (const element of [disabled, ariaDisabled, shadowDisabled]) element.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    vi.advanceTimersByTime(300);
    expect(open).not.toHaveBeenCalled();
    pending.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    pending.disabled = true;
    vi.advanceTimersByTime(300);
    expect(open).not.toHaveBeenCalled();
    cleanup();
  });

  it('cancels a delayed hint and all delegated events when its owner is disposed', () => {
    vi.useFakeTimers();
    const trigger = document.createElement('button');
    trigger.setAttribute('data-tip', 'View settings'); document.body.append(trigger);
    const open = vi.fn(); const close = vi.fn();
    const cleanup = installTooltipDelegation(document, window, { open, close });
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    cleanup(); close.mockClear();
    vi.advanceTimersByTime(300);
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse'));
    trigger.dispatchEvent(pointerEvent('pointerout', 'mouse'));
    document.dispatchEvent(pointerEvent('pointerdown', 'mouse'));
    window.dispatchEvent(new Event('scroll'));
    window.dispatchEvent(new Event('resize'));
    window.dispatchEvent(new Event('blur'));
    vi.advanceTimersByTime(300);
    expect(open).not.toHaveBeenCalled();
    expect(close).not.toHaveBeenCalled();
  });

  it('closes a visible hint when its control becomes disabled or its ancestor is removed', async () => {
    const ancestor = document.createElement('div');
    const trigger = document.createElement('button');
    trigger.setAttribute('data-tip', 'View settings'); ancestor.append(trigger); document.body.append(ancestor);
    const open = vi.fn(); const close = vi.fn();
    const cleanup = installTooltipDelegation(document, window, { delayMs: 0, open, close });
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); close.mockClear();
    trigger.disabled = true;
    await vi.waitFor(() => expect(close).toHaveBeenCalledOnce());
    trigger.disabled = false;
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); close.mockClear();
    ancestor.remove();
    await vi.waitFor(() => expect(close).toHaveBeenCalledOnce());
    expect(open).toHaveBeenCalledTimes(2);
    cleanup();
  });

  it('releases disabled-layer gestures and requires a fresh gesture when enabled again', async () => {
    const host = document.createElement('div'); document.body.append(host);
    const trigger = document.createElement('button');
    trigger.setAttribute('data-tip', 'View settings'); document.body.append(trigger);
    const [enabled, setEnabled] = createSignal(true);
    const dispose = mountLayer(host, () => ({
      observable: constructItem('tooltip.enabled', item => item.observe('enabled', enabled)),
      surface: { kind: 'inherit' }, hotkeys: [], delayMs: 0,
    }));
    await settle(); flush(); await settle();
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
    expect(document.body.querySelector('[role="tooltip"]')).not.toBeNull();
    setEnabled(false); flush(); await settle();
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
    expect(document.body.querySelector('[role="tooltip"]')).toBeNull();
    setEnabled(true); flush(); await settle();
    expect(document.body.querySelector('[role="tooltip"]')).toBeNull();
    trigger.dispatchEvent(pointerEvent('pointerover', 'mouse')); flush(); await settle();
    expect(document.body.querySelector('[role="tooltip"]')).not.toBeNull();
    dispose();
  });
});
