// @vitest-environment happy-dom
/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import type { Window } from 'happy-dom';
import type { ButtonPresentation } from '../button-presets';
import { buttonPresentationClasses } from './button-presentation';
import { CONTROL_SIZES } from '../control-size';

const geometry = readFileSync('src/solid/button-geometry.css', 'utf8');
const paint = readFileSync('src/solid/button.css', 'utf8');
const tokens = readFileSync('src/control-tokens.css', 'utf8');
const browser = window as unknown as Window;

beforeEach(() => {
  document.body.setAttribute('data-ui-root', '');
  browser.happyDOM.setWindowSize({ width: 1200, height: 900 });
  browser.happyDOM.settings.navigator.maxTouchPoints = 0;
  const style = document.createElement('style');
  style.dataset.buttonTest = '';
  // Chromium checks real layout and the complete media-query list. Here test
  // each responsive condition separately because Happy DOM cannot evaluate OR.
  style.textContent = (tokens + paint + geometry).replace(/@import[^;]+;/g, '')
    .replaceAll('(pointer: coarse), (max-width: 767px)', '(max-width: 767px)');
  document.head.append(style);
});
afterEach(() => {
  document.body.removeAttribute('data-ui-root');
  document.body.replaceChildren();
  browser.happyDOM.settings.navigator.maxTouchPoints = 0;
  document.querySelector('[data-button-test]')?.remove();
});

function control(presentation: ButtonPresentation = {}) {
  const button = document.createElement('button');
  button.className = 'ui-control-icons ' + buttonPresentationClasses(presentation);
  document.body.append(button);
  return { button, style: getComputedStyle(button) };
}

describe('closed button recipe geometry', () => {
  it('defaults an ordinary action to the shared dense target', () => {
    const { style } = control();
    expect(style.height).toBe('32px');
    expect(style.minHeight).toBe('32px');
    expect(style.whiteSpace).toBe('nowrap');
  });

  it('gives the explicit button recipe the same ordinary geometry as omission', () => {
    const implicit = control().style;
    const explicit = control({ recipe: 'button' }).style;
    for (const property of ['height', 'minHeight', 'minWidth', 'gap', 'whiteSpace'] as const) {
      expect(explicit[property]).toBe(implicit[property]);
    }
  });

  it('resolves all four desktop heights and square icon shapes', () => {
    for (const [size, height] of [['dense', '32px'], ['compact', '36px'], ['standard', '40px'], ['large', '44px']] as const) {
      expect(control({ size }).style.height).toBe(height);
      const icon = control({ size, shape: 'icon', variant: 'ghost', 'aria-label': 'Open settings' }).style;
      expect(icon.height).toBe(height);
      expect(icon.width).toBe(height);
      expect(icon.minWidth).toBe(height);
      expect(icon.getPropertyValue('padding-inline')).toBe('0px');
      expect(icon.getPropertyValue('padding-block')).toBe('0px');
    }
  });

  it('reserves a physical 44px narrow-screen target without enlarging icons', () => {
    browser.happyDOM.setWindowSize({ width: 600, height: 900 });
    for (const size of CONTROL_SIZES) {
      const { button, style } = control({ size, shape: 'icon', variant: 'ghost', 'aria-label': 'Open settings' });
      expect(style.height).toBe('44px');
      expect(style.width).toBe('44px');
      expect(style.minWidth).toBe('44px');
      const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      button.append(icon);
      const expected = size === 'dense' || size === 'compact' ? '16px' : '20px';
      expect(getComputedStyle(icon).width).toBe(expected);
      expect(getComputedStyle(icon).height).toBe(expected);
    }
  });

  it('expands only the activation box for coarse pointers', () => {
    browser.happyDOM.settings.navigator.maxTouchPoints = 1;
    const sheet = document.querySelector('[data-button-test]')!;
    sheet.textContent = sheet.textContent!.replaceAll('(max-width: 767px)', '(pointer: coarse)');
    const { style } = control({ size: 'dense', shape: 'icon', variant: 'ghost', 'aria-label': 'Open settings' });
    expect(style.height).toBe('44px');
    expect(style.width).toBe('44px');
  });

  it('lets content grow with size-owned minimum and block padding', () => {
    for (const [size, height, padding] of [
      ['dense', '32px', '4px'], ['compact', '36px', '8px'],
      ['standard', '40px', '8px'], ['large', '44px', '12px'],
    ] as const) {
      const { style } = control({ recipe: 'content', variant: 'outline', size });
      expect(style.height).toBe('auto');
      expect(style.minHeight).toBe(height);
      expect(style.whiteSpace).toBe('normal');
      expect(style.getPropertyValue('padding-block')).toBe(padding);
    }
  });

  it('gives menu and navigation recipes fixed row alignment and wrapping', () => {
    for (const recipe of ['menu-item', 'navigation'] as const) {
      const { style } = control({ recipe, size: 'compact' });
      expect(style.height).toBe('auto');
      // A scrollable flex column must overflow instead of compressing wrapped
      // labels back to the minimum target and clipping their second line.
      expect(style.flexShrink).toBe('0');
      expect(style.minHeight).toBe('36px');
      expect(style.width).toBe('100%');
      expect(style.whiteSpace).toBe('normal');
      expect(style.justifyContent).toBe('flex-start');
      expect(style.textAlign).toBe('start');
      expect(style.gap).toBe('4px');
    }
  });

  it('scales row decoration spacing with the four owned sizes', () => {
    for (const recipe of ['menu-item', 'navigation'] as const) {
      for (const size of CONTROL_SIZES) {
        const { style } = control({ recipe, size });
        expect(style.gap).toBe(size === 'dense' || size === 'compact' ? '4px' : '8px');
      }
    }
  });

  it('reserves an 8px dense navigation start inset without changing the row target or end inset', () => {
    const { style } = control({ recipe: 'navigation', size: 'dense' });
    expect(style.getPropertyValue('padding-inline-start')).toBe('8px');
    expect(style.getPropertyValue('padding-inline')).toBe('4px');
    expect(style.width).toBe('100%');
    expect(style.minHeight).toBe('32px');
    browser.happyDOM.setWindowSize({ width: 600, height: 900 });
    const narrow = control({ recipe: 'navigation', size: 'dense' }).style;
    expect(narrow.minHeight).toBe('44px');
    expect(narrow.getPropertyValue('padding-inline-start')).toBe('8px');
    expect(control({ recipe: 'menu-item', size: 'dense' }).style.getPropertyValue('padding-inline')).toBe('4px');
    expect(control({ size: 'dense' }).style.getPropertyValue('padding-inline')).toBe('4px');
  });

  it('retains inherited inline text flow without an ordinary control-sized box', () => {
    const text = document.createElement('p');
    text.style.fontSize = '18px';
    text.style.lineHeight = '27px';
    document.body.append(text);
    const { button } = control({ recipe: 'inline-action' });
    text.append(button);
    const style = getComputedStyle(button);
    expect(style.display).toBe('inline');
    expect(style.height).toBe('auto');
    expect(style.minHeight).toBe('0px');
    expect(style.minWidth).toBe('0px');
    // Happy DOM retains the inherited keyword instead of resolving parent
    // font metrics; actual inherited rendering belongs to the browser suite.
    expect(getComputedStyle(text).fontSize).toBe('18px');
    expect(getComputedStyle(text).lineHeight).toBe('27px');
    expect(style.fontSize).toBe('inherit');
    expect(style.lineHeight).toBe('inherit');
    expect(style.getPropertyValue('padding-inline')).toBe('0px');
  });

  it('keeps content-owned row and selection targets at least 44px wide on narrow screens', () => {
    for (const recipe of ['cell-action', 'property-row', 'selection-cell'] as const) {
      expect(control({ recipe, size: 'dense' }).style.minWidth).toBe('0px');
      browser.happyDOM.setWindowSize({ width: 600, height: 900 });
      expect(control({ recipe, size: 'dense' }).style.minWidth).toBe('44px');
      browser.happyDOM.setWindowSize({ width: 1200, height: 900 });
    }
  });
});
