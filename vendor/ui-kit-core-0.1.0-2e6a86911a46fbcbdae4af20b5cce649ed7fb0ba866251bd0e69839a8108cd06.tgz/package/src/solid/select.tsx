/** @jsxImportSource @solidjs/web */
import './select.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { guardFocusHandle } from '../infrastructure/activation';
import type { FocusHandle } from '../contracts/controls';
import type { SelectControlProps } from '../contracts/fields';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { assertControlPresentation } from '../infrastructure/presentation';
import { fieldRecipe } from '../field-presentation';
import { untrack } from 'solid-js';
import { HOTKEY_DELEGATE, HOTKEY_PASS } from '../contracts/platform';
import './control-geometry.css';

export interface SelectProps extends Omit<SelectControlProps, 'value' | 'onElement' | 'onEscapeOwnership'>, ElementConstruction<string> { }

// Printable keys belong to native/vendor typeahead even when this surface
// explicitly delegates other shortcuts to its parent.
export const SELECT_KEYS = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Enter', 'Space', 'Escape', 'Printable'] as const;

function renderSelect(props: SelectProps) {
  assertControlPresentation('Select', props);
  untrack(() => fieldRecipe('Select', props.recipe, 'select'));
  let ownsEscape = () => true;
  const binding = new ElementBinding('Select', props, {
    nativeKeys: SELECT_KEYS,
    enabledWhen: () => !props.disabled,
    nativeOverrides: ['Escape'],
    builtins: { Escape: () => ownsEscape() ? HOTKEY_PASS : HOTKEY_DELEGATE },
  });
  const Implementation = requireControlImplementation('Select');
  const change = (value: string) => { if (!props.disabled && binding.canActivate()) props.onValueChange(value); };
  const onHandle = (handle: FocusHandle | undefined) => props.onHandle?.(handle && guardFocusHandle(binding, handle));
  return binding.provide(() => <Implementation {...props} value={binding.value()} onValueChange={change} onElement={binding.attach} onHandle={onHandle} onEscapeOwnership={policy => { ownsEscape = policy; }} />);
}

export class Select extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: SelectProps) {
    super('Select', props);
    this.element = renderSelect(this.capture(props));
  }
  static View = (props: SelectProps): JSX.Element => new Select(props).element;
}
