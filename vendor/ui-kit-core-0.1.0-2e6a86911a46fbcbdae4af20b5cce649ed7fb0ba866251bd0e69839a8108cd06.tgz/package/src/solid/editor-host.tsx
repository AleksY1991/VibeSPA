/** @jsxImportSource @solidjs/web */
import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import { createEffect, createSignal, onSettled, untrack } from 'solid-js';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { surfaceCommand } from '../infrastructure/activation';

export interface EditorHostState { readonly visible: boolean; readonly editable: boolean; }
export interface EditorHostController {
  update(state: EditorHostState): void;
  dispose(): void;
}
export interface EditorHostProps extends ElementConstruction<EditorHostState> {
  
  readonly class?: string;
  readonly label: string;
  /** Editor adapters alone receive a mount element; ordinary controls use handles. */
  readonly mount: (element: HTMLElement, context: {
    readonly signal: AbortSignal;
    readonly read: () => EditorHostState;
    /** Adapter write callbacks retain this host's authority and mount lifetime. */
    readonly command: <Args extends readonly unknown[], Result>(command: (...args: Args) => Result) => (...args: Args) => Result | undefined;
  }) => EditorHostController | Promise<EditorHostController>;
  readonly onError: (error: unknown) => void;
}

/**
 * Application lifecycle infrastructure for an imperative editor, not a custom
 * visible text control. Notes compose TipTap/ProseMirror with the WA toolbar.
 * WA 3.12's textarea can preserve raw Markdown; a textarea plus wa-markdown preview
 * would deliberately change the formatted editing experience, semantic mention
 * nodes, and editor commands/history/selection. The Markdown component renders
 * content; it does not supply that editing model:
 * https://webawesome.com/docs/components/markdown/
 *
 * The native div supplies the editor's mount. The editor owns document editing,
 * selection, IME and native text keys; the dispatcher owns declared shortcuts.
 * The control layer owns visibility/editability synchronization, mount cancellation and disposal
 * per CLAUDE's external-widget lifetime rule. The tradeoff is an explicit adapter
 * lifecycle: hidden or replaced hosts must dispose late editor instances.
 * Remove this host only when the chosen editor integration itself satisfies those
 * lifetime and observable/surface/hotkey construction contracts; changing the
 * visible component alone does not transfer those responsibilities.
 */
function renderEditorHost(props: EditorHostProps) {
  const binding = new ElementBinding('EditorHost', props, {
    activeWhen: state => state.visible,
    nativeKeys: ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Backspace', 'Delete', 'Enter', 'Space', 'Printable'],
  });
  let element!: HTMLDivElement;
  const [mounted, setMounted] = createSignal(false);
  const [controller, setController] = createSignal<EditorHostController>();
  onSettled(() => { setMounted(true); });
  createEffect(() => mounted() && binding.lifetime(), visible => {
    if (!visible) return;
    const lifetime = new AbortController();
    let activeController: EditorHostController | undefined;
    void Promise.resolve().then(() => {
      if (lifetime.signal.aborted) return;
      return props.mount(element, {
        signal: lifetime.signal, read: () => untrack(binding.value),
        command: command => surfaceCommand({
          canActivate: () => !lifetime.signal.aborted && binding.canActivate() && untrack(binding.value).editable,
        }, command),
      });
    }).then(next => {
      if (!next) return;
      if (lifetime.signal.aborted) { next.dispose(); return; }
      activeController = next;
      setController(next);
    }, error => { if (!lifetime.signal.aborted) props.onError(error); });
    return () => {
      lifetime.abort();
      untrack(() => activeController?.dispose());
      setController(undefined);
    };
  });
  // Widget callbacks are imperative. Visibility/editability are the tracked
  // inputs; the widget may sample its own state while updating or disposing.
  createEffect(() => [controller(), binding.value()] as const, ([current, state]) => {
    untrack(() => { current?.update(state); });
  });
  return <div ref={host => { element = host; binding.attach(host); }}
    role="group" aria-label={props.label} hidden={!binding.value().visible}
    data-ui-keyboard-owner="ArrowLeft ArrowRight ArrowUp ArrowDown Home End Backspace Delete Enter Space Printable"
    data-ui-text-entry="true" class={props.class} />;
}

export class EditorHost extends RenderedElement<EditorHostState> {
  readonly element: JSX.Element;
  constructor(props: EditorHostProps) {
    super('EditorHost', props);
    this.element = renderEditorHost(this.capture(props));
  }
  static View = (props: EditorHostProps): JSX.Element => new EditorHost(props).element;
}
