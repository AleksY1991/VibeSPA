/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeBadge } from '../vendor/web-awesome/badge.adapter';
import { Badge } from './badge';

class BadgeDouble extends HTMLElement {
  static update: () => Promise<boolean> = () => Promise.resolve(true);
  static statusRendered = false;
  constructor() {
    super();
    if (BadgeDouble.statusRendered) {
      const status = document.createElement('span');
      status.setAttribute('role', 'status');
      status.append(document.createElement('slot'));
      this.attachShadow({ mode: 'open' }).append(status);
    }
  }
  get updateComplete() { return BadgeDouble.update(); }
}
const disposers: (() => void)[] = [];
const implementation = { Badge: WebAwesomeBadge };
const settle = async () => { for (let i = 0; i < 24; i++) { flush(); await Promise.resolve(); } };
beforeAll(() => customElements.define('wa-badge', BadgeDouble));
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); BadgeDouble.update = () => Promise.resolve(true); BadgeDouble.statusRendered = false; document.body.replaceChildren(); });
async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const dispose = render(view, container); disposers.push(dispose); await settle(); return { container, dispose };
}

describe('shared unread badge', () => {
  it('uses the canonical vendor host and updates it from its exact text source', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture(); disposers.push(diagnostics.stop);
    const [value, setValue] = createSignal('3');
    const { container } = await mount(() => {
      const count = constructItem('badge.count', item => item.observe('text', value));
      return <ImplementationContext value={implementation}>
        <Badge.View observable={count} surface={{ kind: 'inherit' }} hotkeys={[]} tone="neutral" label={`${value()} unread messages`} />
      </ImplementationContext>;
    });
    const badge = container.querySelector('wa-badge')!;
    expect(badge.hasAttribute('data-ui-ready')).toBe(false); expect(badge.hasAttribute('inert')).toBe(false);
    expect(badge.querySelector('[data-ui-badge-value]')?.textContent).toBe('3');
    expect(badge.getAttribute('variant')).toBe('neutral'); expect(badge.getAttribute('appearance')).toBe('filled');
    expect(badge.getAttribute('attention')).toBe('none'); expect(badge.hasAttribute('pill')).toBe(false);
    expect(container.querySelectorAll('[data-ui-badge]')).toHaveLength(1);
    setValue('12'); await settle();
    expect(container.querySelector('wa-badge')).toBe(badge); expect(badge.querySelector('[data-ui-badge-value]')?.textContent).toBe('12');
    expect(badge.querySelector('[data-ui-badge-value]')?.getAttribute('aria-hidden')).toBe('true');
    expect(badge.querySelector('[data-ui-badge-label]')?.textContent).toBe('12 unread messages');
    expect(badge.hasAttribute('role')).toBe(false);
    expect(badge.hasAttribute('aria-label')).toBe(false);
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });
  it('retains the canonical host on vendor failure without losing the owned surface or accessible count', async () => {
    BadgeDouble.update = () => Promise.reject(new Error('Initialization failed'));
    const { container, dispose } = await mount(() => {
      const count = constructItem('badge.failure', item => item.constant('text', '7'));
      return <ImplementationContext value={implementation}><Badge.View observable={count}
        surface={{ kind: 'own', name: 'badge.failure', transparent: true }} hotkeys={[]} tone="accent" label="7 unread messages" /></ImplementationContext>;
    });
    const recovery = container.querySelector('wa-badge')!;
    expect(recovery.getAttribute('data-ui-error')).toBe('update-failed');
    expect(recovery.hasAttribute('data-ui-ready')).toBe(false);
    expect(recovery.hasAttribute('inert')).toBe(false);
    expect(recovery.getAttribute('role')).toBe('status');
    expect(recovery.querySelector('[data-ui-badge-value]')?.textContent).toBe('7');
    expect(recovery.querySelector('[data-ui-badge-value]')?.getAttribute('aria-hidden')).toBe('true');
    expect(recovery.querySelector('[data-ui-badge-label]')?.textContent).toBe('7 unread messages');
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'badge.failure')).toBe(true);
    dispose(); await settle();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'badge.failure')).toBe(false);
  });

  it('keeps a partially rendered vendor status as the sole announcement owner after failure', async () => {
    BadgeDouble.statusRendered = true;
    BadgeDouble.update = () => Promise.reject(new Error('Update failed after rendering its status'));
    const [value, setValue] = createSignal('7');
    const { container } = await mount(() => {
      const count = constructItem('badge.partial-failure', item => item.observe('text', value));
      return <ImplementationContext value={implementation}><Badge.View observable={count}
        surface={{ kind: 'inherit' }} hotkeys={[]} tone="accent" label={value() + ' unread messages'} /></ImplementationContext>;
    });
    const host = container.querySelector('wa-badge')!;
    const status = host.shadowRoot!.querySelector('[role="status"]')!;
    expect(host.getAttribute('data-ui-error')).toBe('update-failed');
    expect(host.hasAttribute('role')).toBe(false); expect(host.hasAttribute('inert')).toBe(false);
    expect(host.shadowRoot!.querySelectorAll('[role="status"]')).toHaveLength(1);
    setValue('12'); await settle();
    expect(container.querySelector('wa-badge')).toBe(host);
    expect(host.shadowRoot!.querySelector('[role="status"]')).toBe(status);
    expect(host.hasAttribute('role')).toBe(false);
    expect(host.querySelector('[data-ui-badge-label]')?.textContent).toBe('12 unread messages');
  });

  it('restores plain visible text to accessibility when contextual labeling is removed', async () => {
    const [label, setLabel] = createSignal<string | undefined>('3 unread messages');
    const { container } = await mount(() => {
      const count = constructItem('badge.label', item => item.constant('text', '3'));
      return <ImplementationContext value={implementation}>
        <Badge.View observable={count} surface={{ kind: 'inherit' }} hotkeys={[]} tone="neutral" label={label()} />
        <Badge.View observable={count} surface={{ kind: 'inherit' }} hotkeys={[]} tone="neutral" label={label()} />
      </ImplementationContext>;
    });
    setLabel(undefined); await settle();
    for (const badge of container.querySelectorAll('[data-ui-badge]')) {
      expect(badge.querySelector('[data-ui-badge-value]')?.hasAttribute('aria-hidden')).toBe(false);
      expect(badge.querySelector<HTMLElement>('[data-ui-badge-label]')?.hidden).toBe(true);
      expect(badge.textContent).toBe('3');
    }
  });
});
