/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { expect, it } from 'vitest';
import { flush } from 'solid-js';
import { render } from '@solidjs/web';
import { constructItem } from '../infrastructure/construction';
import { LayerPortal } from './portal';

it('portals through a scoped contents wrapper without an extra layout box', async () => {
  const host = document.createElement('div');
  const destination = document.createElement('div');
  document.body.append(host, destination);
  const dispose = render(() => {
    const visible = constructItem('portal.layout', item => item.constant('visible', true));
    return <LayerPortal.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]} mount={destination}>
      <button>Action</button>
    </LayerPortal.View>;
  }, host);
  try {
    for (let turn = 0; turn < 4; turn++) { flush(); await Promise.resolve(); }
    const action = destination.querySelector('button')!;
    expect(destination.children).toHaveLength(1);
    expect(action.parentElement?.parentElement).toBe(destination);
    expect(action.parentElement?.hasAttribute('data-ui-root')).toBe(true);
    expect(getComputedStyle(action.parentElement!).display).toBe('contents');
    expect(host.querySelector('button')).toBeNull();
  } finally { dispose(); host.remove(); destination.remove(); }
});
