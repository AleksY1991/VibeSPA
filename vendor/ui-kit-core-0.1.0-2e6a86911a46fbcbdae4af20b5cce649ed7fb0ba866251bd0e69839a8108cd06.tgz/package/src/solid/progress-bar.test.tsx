/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { constructItem } from '../infrastructure/construction';
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { afterEach, beforeAll, describe, expect, it } from 'vitest';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { WebAwesomeProgressBar } from '../vendor/web-awesome/progress-bar.adapter';
import { ProgressBar } from './progress-bar';

/** Wiring double; browser verification owns vendor rendering and actual track geometry. */
class ProgressBarDouble extends HTMLElement {
  static failUpdate = false;
  value = 0;
  indeterminate = false;
  label = '';
  readonly indicator = document.createElement('div');
  constructor() {
    super();
    this.indicator.setAttribute('role', 'progressbar');
    this.attachShadow({ mode: 'open' }).append(this.indicator);
  }
  get updateComplete(): Promise<boolean> {
    return ProgressBarDouble.failUpdate ? Promise.reject(new Error('Failed update')) : Promise.resolve(true);
  }
}

const cleanups: (() => void)[] = [];
const implementation = {
  ProgressBar: WebAwesomeProgressBar,
};
const settle = async () => {
  for (let index = 0; index < 24; index += 1) { flush(); await Promise.resolve(); }
};

beforeAll(() => customElements.define('wa-progress-bar', ProgressBarDouble));
afterEach(() => {
  cleanups.splice(0).reverse().forEach(dispose => dispose());
  ProgressBarDouble.failUpdate = false;
  document.body.replaceChildren();
});

async function mount(view: () => JSX.Element) {
  const container = document.createElement('div');
  document.body.append(container);
  cleanups.push(render(view, container));
  await settle();
  return container;
}

describe('shared progress bar', () => {
  it('uses one prepared renderer and retains original-unit semantics', async () => {
    const container = await mount(() => {
      const value = constructItem('test.ProgressBar', item => item.constant('value', 15));
      return <ImplementationContext value={implementation}>
        <ProgressBar.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} max={20} label="Other work" />
      </ImplementationContext>;
    });
    const vendor = container.querySelector<ProgressBarDouble>('wa-progress-bar')!;
    expect(vendor.value).toBe(75); expect(vendor.hasAttribute('data-ui-ready')).toBe(false);
    const semantic = vendor.parentElement!;
    expect(semantic.getAttribute('aria-valuenow')).toBe('15');
    expect(semantic.getAttribute('aria-valuemax')).toBe('20');
    expect(semantic.getAttribute('aria-label')).toBe('Other work');
    expect(container.querySelector('progress')).toBeNull();
  });

  it('updates percentage fill while retaining the original accessible value and maximum', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture();
    cleanups.push(diagnostics.stop);
    const [state, setState] = createSignal({ value: 30, max: 100, label: 'Loading', hidden: true });
    const container = await mount(() => {
const binding2 = constructItem('test.ProgressBar', item => item.observe('value', () => (state().value)));
return (<ImplementationContext value={implementation}>
      <ProgressBar.View observable={binding2} surface={{ kind: 'inherit' }} hotkeys={[]}  max={state().max}
        label={state().label} aria-hidden={state().hidden} />
    </ImplementationContext>); });
    const vendor = container.querySelector<ProgressBarDouble>('wa-progress-bar')!;
    const semantic = container.querySelector('[data-ui-progress-wrapper]')!;
    setState({ value: 15, max: 20, label: 'Processing files', hidden: false });
    await settle();
    expect(vendor.value).toBe(75);
    expect(vendor.label).toBe('Processing files');
    expect(semantic.getAttribute('role')).toBe('progressbar');
    expect(semantic.getAttribute('aria-valuenow')).toBe('15');
    expect(semantic.getAttribute('aria-valuemax')).toBe('20');
    expect(semantic.getAttribute('aria-hidden')).toBe('false');
    expect(vendor.getAttribute('aria-hidden')).toBe('true');
    expect(vendor.indicator.hasAttribute('aria-hidden')).toBe(false);
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });

  it('bounds invalid input through the canonical renderer', async () => {
    const [value, setValue] = createSignal(150);
    const container = await mount(() => {
      const model = constructItem('progress.bounds', item => item.observe('value', value));
      return <ImplementationContext value={implementation}><ProgressBar.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]} max={0} /></ImplementationContext>;
    });
    const vendor = container.querySelector<ProgressBarDouble>('wa-progress-bar')!;
    expect(vendor.value).toBe(100); expect(vendor.parentElement!.getAttribute('aria-valuemax')).toBe('100');
    setValue(Number.NaN); await settle();
    expect(vendor.value).toBe(0); expect(vendor.parentElement!.getAttribute('aria-valuenow')).toBe('0');
  });

  it('keeps semantic progress and announcement policy when vendor preparation fails', async () => {
    ProgressBarDouble.failUpdate = true;
    const container = await mount(() => {
const binding5 = constructItem('test.ProgressBar', item => item.observe('value', () => (75)));
return (<ImplementationContext value={implementation}>
      <ProgressBar.View observable={binding5} surface={{ kind: 'inherit' }} hotkeys={[]}  label="Preparing analytics" aria-hidden="true" />
    </ImplementationContext>); });
    const visual = container.querySelector('wa-progress-bar')!;
    const semantic = visual.parentElement!;
    expect(container.querySelector('progress')).toBeNull();
    expect(semantic.getAttribute('aria-valuenow')).toBe('75');
    expect(semantic.getAttribute('aria-valuemax')).toBe('100');
    expect(semantic.getAttribute('aria-label')).toBe('Preparing analytics');
    expect(semantic.getAttribute('aria-hidden')).toBe('true');
    expect(semantic.getAttribute('data-ui-error')).toBe('update-failed');
    expect(semantic.hasAttribute('data-ui-ready')).toBe(false);
    expect(semantic.hasAttribute('inert')).toBe(false);
  });

  it('keeps contextual value text reactive on the sole named outer role', async () => {
    const [description, setDescription] = createSignal<string | undefined>('3 of 8 files');
    const container = await mount(() => {
      const value = constructItem('progress.units', item => item.constant('value', 3));
      return <ImplementationContext value={implementation}>
        <ProgressBar.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]}
          max={8} label="Uploading" valueText={description()} />
      </ImplementationContext>;
    });
    const vendor = container.querySelector<ProgressBarDouble>('wa-progress-bar')!;
    const semantic = container.querySelector('[data-ui-progress-wrapper]')!;
    expect(vendor.value).toBe(37.5);
    expect(semantic.getAttribute('aria-valuetext')).toBe('3 of 8 files');
    expect(semantic.getAttribute('aria-valuenow')).toBe('3');
    expect(semantic.getAttribute('aria-valuemax')).toBe('8');
    expect(vendor.getAttribute('aria-hidden')).toBe('true');
    expect(vendor.indicator.hasAttribute('aria-hidden')).toBe(false);
    setDescription(undefined); await settle();
    expect(semantic.hasAttribute('aria-valuetext')).toBe(false);
  });

  it('keeps semantics without depending on a vendor shadow role', async () => {
    const update = Object.getOwnPropertyDescriptor(ProgressBarDouble.prototype, 'updateComplete')!;
    Object.defineProperty(ProgressBarDouble.prototype, 'updateComplete', {
      configurable: true, get(this: ProgressBarDouble) { this.indicator.removeAttribute('role'); return Promise.resolve(true); },
    });
    try {
      const container = await mount(() => {
        const value = constructItem('progress.template', item => item.constant('value', 3));
        return <ImplementationContext value={implementation}>
          <ProgressBar.View observable={value} surface={{ kind: 'inherit' }} hotkeys={[]} max={8} label="Uploading" />
        </ImplementationContext>;
      });
      expect(container.querySelector('wa-progress-bar')?.getAttribute('aria-hidden')).toBe('true');
      expect(container.querySelector('progress')).toBeNull();
      const semantic = container.querySelector('[data-ui-progress-wrapper]')!;
      expect(semantic.getAttribute('role')).toBe('progressbar');
      expect(semantic.getAttribute('aria-label')).toBe('Uploading');
      expect(semantic.getAttribute('aria-valuenow')).toBe('3');
      expect(semantic.getAttribute('aria-valuemax')).toBe('8');
    } finally {
      Object.defineProperty(ProgressBarDouble.prototype, 'updateComplete', update);
    }
  });
});
