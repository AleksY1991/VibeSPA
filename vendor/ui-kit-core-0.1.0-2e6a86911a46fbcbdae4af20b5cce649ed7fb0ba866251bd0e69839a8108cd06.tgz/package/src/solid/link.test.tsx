/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { readFileSync } from 'node:fs';
import postcss from 'postcss';
import { constructItem } from '../infrastructure/construction';
import type { FocusHandle } from '../contracts/controls';
import { Link, type LinkProps, type LinkState } from './link';

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

function installStyles() {
  const style = document.createElement('style');
  const css = ['src/tokens.css', 'src/control-tokens.css', 'src/solid/button.css', 'src/solid/button-geometry.css', 'src/solid/link.css']
    .map(file => readFileSync(file, 'utf8').replace(/@import[^;]+;/g, '')
      // Happy DOM does not expose logical padding; retain the real rule cascade
      // while translating just that property into its physical equivalents.
      .replace(/(?<![-\w])padding-inline:\s*([^;}]+)/g, 'padding-left: $1; padding-right: $1')).join('\n');
  const sheet = postcss.parse(css);
  // A browser supports the vendor ::part branches. Happy DOM discards mixed
  // selector lists containing them, so keep the real native branches here.
  sheet.walkRules(rule => {
    if (!rule.selector.includes('::part')) return;
    rule.selectors = rule.selectors.filter(selector => !selector.includes('::part'));
    if (!rule.selectors.length) rule.remove();
  });
  style.textContent = sheet.toString();
  document.head.append(style);
  disposers.push(() => style.remove());
}

async function fixture(overrides: Partial<Omit<LinkProps, 'observable'>> = {}) {
  const host = document.createElement('div'); host.dataset.uiRoot = ''; document.body.append(host);
  const [state, setState] = createSignal<LinkState>({ href: '#first' });
  const onActivate = vi.fn();
  let captures = 0;
  const dispose = render(() => {
    const observable = constructItem('link.test', item => item.observe('model', state));
    const control = new Link({
      get observable() { captures++; return observable; },
      surface: { kind: 'inherit' }, hotkeys: [], onActivate, children: 'Destination', ...overrides,
    });
    return control.element;
  }, host);
  disposers.push(dispose);
  await Promise.resolve(); flush(); await Promise.resolve();
  return { host, element: host.querySelector('a')!, setState, onActivate, dispose, captures: () => captures };
}

describe('Link', () => {
  it('keeps native destination attributes, caller placement and one node through observable updates', async () => {
    const current = await fixture({ target: '_blank', rel: 'noopener noreferrer', download: 'report.csv', class: 'placed-link', style: { width: '123px' }, 'aria-label': 'Download report' });
    const { element } = current;
    expect(element.getAttribute('href')).toBe('#first');
    expect(element.target).toBe('_blank'); expect(element.rel).toBe('noopener noreferrer');
    expect(element.download).toBe('report.csv'); expect(element.classList.contains('placed-link')).toBe(true);
    expect(element.style.width).toBe('123px'); expect(element.getAttribute('aria-label')).toBe('Download report');
    current.setState({ href: '#second' }); flush();
    expect(current.host.firstElementChild).toBe(element); expect(element.getAttribute('href')).toBe('#second');
    expect(current.captures()).toBe(1);
  });

  it('keeps paragraph links inline and gives standalone links the explicit target recipe', async () => {
    installStyles();
    const inline = await fixture();
    const target = await fixture({ size: 'target' });
    expect(getComputedStyle(inline.element).display).not.toBe('inline-flex');
    const appearance = getComputedStyle(target.element);
    expect(appearance.display).toBe('inline-flex');
    expect(appearance.minHeight).toBe('36px');
    expect(appearance.fontSize).toBe('13px');
    expect(appearance.lineHeight).toBe('1.4');
    expect(appearance.fontWeight).toBe('400');
    expect(target.element.hasAttribute('size')).toBe(false);
  });

  it('shares action geometry without resizing arbitrary native anchor glyphs', async () => {
    installStyles();
    const glyphStyle = document.createElement('style');
    glyphStyle.textContent = 'svg { width: 31px; height: 21px; }';
    document.head.append(glyphStyle);
    disposers.push(() => glyphStyle.remove());
    const glyph = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    const { element } = await fixture({ appearance: 'action', controlSize: 'compact', children: glyph });
    expect(element.getAttribute('href')).toBe('#first');
    expect(element.contains(glyph)).toBe(true);
    expect(getComputedStyle(glyph).width).toBe('31px');
    expect(getComputedStyle(glyph).height).toBe('21px');
    expect(getComputedStyle(element).height).toBe('36px');
  });

  it('applies the declared control scale, text role and content spacing', async () => {
    installStyles();
    const { element } = await fixture({ size: 'target', controlSize: 'large', textSize: 'caption', gap: 'md', padding: 'md' });
    const appearance = getComputedStyle(element);
    expect(appearance.minHeight).toBe('44px');
    expect(appearance.fontSize).toBe('11px');
    expect(appearance.lineHeight).toBe('1.3');
    expect(appearance.gap).toBe('8px');
    expect(appearance.paddingLeft).toBe('12px');
    expect(appearance.paddingRight).toBe('12px');
    for (const attribute of ['size', 'controlSize', 'textSize', 'gap', 'padding']) expect(element.hasAttribute(attribute)).toBe(false);
  });

  it('uses the shared compact action geometry without replacing native navigation', async () => {
    installStyles();
    const { element } = await fixture({ appearance: 'action', controlSize: 'compact' });
    const appearance = getComputedStyle(element);
    expect(appearance.height).toBe('36px');
    expect(appearance.minWidth).toBe('36px');
    expect(appearance.paddingLeft).toBe('8px');
    expect(appearance.paddingRight).toBe('8px');
    expect(element.getAttribute('href')).toBe('#first');
    expect(element.hasAttribute('appearance')).toBe(false);
    const { element: unpadded } = await fixture({ appearance: 'action', padding: 'none', gap: 'none', textSize: 'caption' });
    const compact = getComputedStyle(unpadded);
    expect(compact.paddingLeft).toBe('0px');
    expect(compact.paddingRight).toBe('0px');
    expect(Number.parseFloat(compact.gap)).toBe(0);
    expect(compact.fontSize).toBe('11px');
  });

  it('wraps full-row resource labels and preserves an explicit underline', async () => {
    installStyles();
    const { element } = await fixture({ layout: 'block', wrap: true, padding: 'xs', underline: 'always' });
    const appearance = getComputedStyle(element);
    expect(appearance.display).toBe('block');
    expect(appearance.overflowWrap).toBe('break-word');
    expect(appearance.whiteSpace).toBe('normal');
    expect(appearance.paddingLeft).toBe('4px');
    expect(appearance.paddingRight).toBe('4px');
    expect(appearance.textDecorationLine).toBe('underline');
  });

  it('preserves modified native clicks and native Enter ownership', async () => {
    const { element, onActivate } = await fixture();
    const click = new MouseEvent('click', { bubbles: true, cancelable: true, ctrlKey: true });
    element.dispatchEvent(click);
    expect(click.defaultPrevented).toBe(false);
    expect(onActivate).toHaveBeenCalledExactlyOnceWith(expect.objectContaining({ ctrlKey: true }));
    const enter = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true });
    element.dispatchEvent(enter);
    expect(enter.defaultPrevented).toBe(false); expect(element.getAttribute('data-ui-keyboard-owner')).toBe('Enter');
    const middle = new MouseEvent('auxclick', { button: 1, bubbles: true, cancelable: true });
    element.dispatchEvent(middle); expect(middle.defaultPrevented).toBe(false);
    expect(onActivate).toHaveBeenCalledOnce();
  });

  it('lets a typed activation prevent navigation', async () => {
    const { element } = await fixture({ onActivate: intent => intent.preventDefault() });
    const click = new MouseEvent('click', { bubbles: true, cancelable: true });
    element.dispatchEvent(click); expect(click.defaultPrevented).toBe(true);
  });

  it('blocks disabled navigation and activation, retaining a discoverable link', async () => {
    const { element, setState, onActivate } = await fixture();
    setState({ href: '#second', disabled: true }); flush();
    expect(element.hasAttribute('href')).toBe(false); expect(element.getAttribute('aria-disabled')).toBe('true');
    expect(element.getAttribute('role')).toBe('link'); element.focus(); expect(document.activeElement).toBe(element);
    for (const type of ['click', 'auxclick']) {
      const event = new MouseEvent(type, { bubbles: true, cancelable: true }); element.dispatchEvent(event);
      expect(event.defaultPrevented).toBe(true);
    }
    expect(onActivate).not.toHaveBeenCalled();
    setState({ href: '#second' }); flush(); expect(element.getAttribute('href')).toBe('#second');
    expect(element.hasAttribute('aria-disabled')).toBe(false);
  });

  it('publishes a narrow focus handle and revokes it on removal', async () => {
    let saved: FocusHandle | undefined;
    const onHandle = vi.fn((handle: FocusHandle | undefined) => { if (handle) saved = handle; });
    const { element, dispose } = await fixture({ onHandle });
    expect(onHandle).toHaveBeenCalledOnce(); saved!.focus(); expect(document.activeElement).toBe(element);
    saved!.blur(); expect(document.activeElement).not.toBe(element);
    dispose(); expect(onHandle).toHaveBeenLastCalledWith(undefined); expect(() => saved!.focus()).toThrow(/disposed/);
  });

  it('does not activate an owner that has been removed while a native node is retained', async () => {
    const { element, dispose, onActivate } = await fixture();
    dispose();
    document.body.append(element);
    for (const type of ['click', 'auxclick']) {
      const event = new MouseEvent(type, { bubbles: true, cancelable: true });
      element.dispatchEvent(event);
    }
    expect(onActivate).not.toHaveBeenCalled();
  });
});
