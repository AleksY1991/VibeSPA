import { createEffect, onCleanup, onSettled, untrack, type Accessor } from 'solid-js';

/**
 * Media features that change field typography, padding or minimum height
 * (control-tokens.css, text-field.css and the `coarse:` variant). A flip re-wraps
 * the text without changing the field's width, so width observation misses it.
 */
const TYPOGRAPHY_MEDIA = ['(pointer: coarse)', '(max-width: 767px)'] as const;

export interface AutoHeightBounds {
  readonly minHeight?: number;
  readonly maxHeight?: number;
}

export interface AutoHeightSource {
  /** The textarea whose height is owned; undefined until it can be measured. */
  readonly element: Accessor<HTMLTextAreaElement | undefined>;
  /** Null when the field does not auto-size: the owned height is released. */
  readonly bounds: Accessor<AutoHeightBounds | null>;
  /** Reads every prop that lays the text out: value, rows, typography, padding. */
  readonly layout: Accessor<unknown>;
  /** Resolves once a vendor field has rendered the current props into its textarea. */
  readonly rendered?: () => Promise<unknown>;
}

export interface AutoHeight {
  /** Measure now. Edit events call it after their value has been normalized. */
  readonly measure: () => void;
}

/**
 * One owner of a textarea's automatic height. The height is the laid-out text's
 * height, so every cause of re-wrapping is a source: the layout props (including
 * a replaced controlled value), the field's width, a font face finishing its
 * load, and the typography media features. A missing source is a clipped field:
 * WA 3.12's own auto-resize ignores a replaced default value and a late font
 * swap, which left an editable heading cut to one line.
 */
export function createAutoHeight(source: AutoHeightSource): AutoHeight {
  let bounds: AutoHeightBounds | null = null;
  let owned = false;
  let settled = false;
  let disposed = false;
  onCleanup(() => { disposed = true; });

  const measure = () => {
    // The effect tracks the element, bounds and layout. Event-time measurement
    // samples the current element, including after an asynchronous vendor render.
    const target = untrack(source.element);
    if (!settled || disposed || !target) return;
    if (!bounds) {
      if (owned) target.style.removeProperty('height');
      owned = false;
      return;
    }
    if (!target.isConnected) return;
    owned = true;
    // Collapsing to measure clamps the scroll offset of a field at its maximum.
    const scrollTop = target.scrollTop;
    target.style.height = 'auto';
    const style = getComputedStyle(target);
    const px = (value: string) => Number.parseFloat(value) || 0;
    // scrollHeight covers content and padding: border-box adds the borders,
    // content-box removes the padding.
    const frame = style.boxSizing === 'border-box'
      ? px(style.borderTopWidth) + px(style.borderBottomWidth)
      : -(px(style.paddingTop) + px(style.paddingBottom));
    const height = Math.min(bounds.maxHeight ?? Infinity, Math.max(bounds.minHeight ?? 0, target.scrollHeight + frame));
    target.style.height = `${height}px`;
    target.scrollTop = scrollTop;
  };

  const remeasure = () => {
    const rendered = source.rendered;
    if (!rendered) { measure(); return; }
    // Read the vendor's pending render after every effect of this flush has
    // written its props, so the measured text is the text being displayed.
    void Promise.resolve().then(rendered).then(measure, measure);
  };

  createEffect(() => ({ element: source.element(), bounds: source.bounds(), layout: source.layout() }), next => {
    bounds = next.bounds;
    remeasure();
  });

  onSettled(() => {
    settled = true;
    remeasure();
    const fonts = 'fonts' in document ? document.fonts : undefined;
    fonts?.addEventListener('loadingdone', measure);
    const media = TYPOGRAPHY_MEDIA.map(query => window.matchMedia(query));
    for (const query of media) query.addEventListener('change', measure);
    return () => {
      fonts?.removeEventListener('loadingdone', measure);
      for (const query of media) query.removeEventListener('change', measure);
    };
  });

  createEffect(source.element, target => {
    if (!target || typeof ResizeObserver === 'undefined') return;
    let width = -1;
    // Only width re-wraps text; height changes are this owner's own writes.
    const observer = new ResizeObserver(() => {
      if (target.clientWidth === width) return;
      width = target.clientWidth;
      measure();
    });
    observer.observe(target);
    return () => observer.disconnect();
  });

  return { measure };
}
