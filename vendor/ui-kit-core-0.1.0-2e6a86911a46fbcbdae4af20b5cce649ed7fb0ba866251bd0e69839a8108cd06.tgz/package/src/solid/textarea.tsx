/** @jsxImportSource @solidjs/web */
import './textarea.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle, surfaceCommand } from '../infrastructure/activation';
import type { TextareaControlProps } from '../contracts/fields';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { assertControlPresentation } from '../infrastructure/presentation';
import { fieldRecipe } from '../field-presentation';
import { untrack } from 'solid-js';
import './control-geometry.css';

export interface TextareaProps extends Omit<TextareaControlProps, 'value'>, ElementConstruction<string> { }
export type { TextareaRecipe } from '../contracts/field-presentation';

function renderTextarea(props: TextareaProps) {
  assertControlPresentation('Textarea', props);
  untrack(() => fieldRecipe('Textarea', props.recipe, 'textarea'));
  const binding = new ElementBinding('Textarea', props, {
    nativeKeys: ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', 'Backspace', 'Delete', 'Enter', 'Space', 'Printable'],
    enabledWhen: () => !props.disabled,
  });
  const Implementation = requireControlImplementation('Textarea');
  const attach = (element: HTMLElement) => { binding.attach(element); props.onElement?.(element); };
  const writes = { canActivate: () => binding.canActivate() && !props.readonly };
  const change = surfaceCommand(writes, (value: string) => props.onValueChange(value));
  const commit = surfaceCommand(writes, (value: string) => props.onValueCommit?.(value));
  const activate: NonNullable<TextareaControlProps['onActivate']> = event => {
    if (allowActivation(binding, event)) props.onActivate?.(event);
  };
  const publishHandle = () => {
    const callback = props.onHandle;
    return callback ? (handle: Parameters<NonNullable<TextareaControlProps['onHandle']>>[0]) =>
      callback(handle ? guardFocusHandle(binding, handle) : undefined) : undefined;
  };
  return binding.provide(() => <Implementation {...props} value={binding.value()} onElement={attach}
    onValueChange={change} onValueCommit={commit} onActivate={activate} onHandle={publishHandle()} />);
}

export class Textarea extends RenderedElement<string> {
  readonly element: JSX.Element;
  constructor(props: TextareaProps) {
    super('Textarea', props);
    this.element = renderTextarea(this.capture(props));
  }
  static View = (props: TextareaProps): JSX.Element => new Textarea(props).element;
}
