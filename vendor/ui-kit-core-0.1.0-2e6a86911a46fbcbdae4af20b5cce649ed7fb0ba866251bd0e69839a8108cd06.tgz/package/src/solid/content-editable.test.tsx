/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush } from 'solid-js';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ContentEditable, type ContentEditableHandle, type ContentEditableProps, type ContentEditableState } from './content-editable';
import { Form } from './form';

const disposers: (() => void)[] = [];
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  document.body.replaceChildren();
  vi.restoreAllMocks();
});

async function fixture(overrides: Partial<Omit<ContentEditableProps, 'observable'>> = {}, initial: ContentEditableState = { text: 'Initial', editing: true }) {
  const host = document.createElement('div'); document.body.append(host);
  const [state, setState] = createSignal(initial);
  const onValueChange = vi.fn(); const onCommit = vi.fn(); const onCancel = vi.fn(); const onBlur = vi.fn();
  let handle: ContentEditableHandle | undefined;
  let savedHandle: ContentEditableHandle | undefined;
  const onHandle = vi.fn((next: ContentEditableHandle | undefined) => { handle = next; if (next) savedHandle = next; });
  const dispose = render(() => {
    const observable = constructItem('editable.test', item => item.observe('model', state));
    const control = new ContentEditable({
      observable, surface: { kind: 'inherit' }, hotkeys: [], label: 'Title',
      onValueChange, onCommit, onCancel, onBlur, onHandle, ...overrides,
    });
    return control.element;
  }, host);
  disposers.push(dispose);
  disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
    commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
  await Promise.resolve(); flush(); await Promise.resolve();
  const element = host.querySelector('[role="textbox"]')! as HTMLElement;
  const key = (key: string, init: KeyboardEventInit = {}) => {
    const event = new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true, ...init });
    element.dispatchEvent(event); return event;
  };
  const type = (text: string) => { element.innerText = text; element.dispatchEvent(new InputEvent('input', { bubbles: true })); };
  return { host, element, dispose, setState, key, type, onValueChange, onCommit, onCancel, onBlur, onHandle,
    handle: () => handle!, savedHandle: () => savedHandle! };
}

describe('ContentEditable construction and editing', () => {
  it('captures its registered observable once even when construction receives a getter', () => {
    const host = document.createElement('div'); document.body.append(host);
    let reads = 0;
    disposers.push(render(() => {
      const observable = constructItem('editable.capture', item => item.constant('model', { text: 'Stable', editing: false }));
      return new ContentEditable({
        get observable() { reads += 1; return observable; },
        surface: { kind: 'inherit' }, hotkeys: [], label: 'Stable', onValueChange: () => {},
      }).element;
    }, host));
    expect(reads).toBe(1);
  });

  it('preserves the requested host, class, geometry, and node identity through updates', async () => {
    const { host, element, setState } = await fixture({ as: 'span', class: 'h-4 px-0', style: { width: '123px' } });
    expect(element.tagName).toBe('SPAN'); expect(element.className).toBe('h-4 px-0');
    expect(element.style.width).toBe('123px'); expect(element.textContent).toBe('Initial');
    setState({ text: 'Updated', editing: false }); flush();
    expect(host.firstElementChild).toBe(element); expect(element.textContent).toBe('Updated');
  });

  it('publishes a connected handle once and revokes it on removal', async () => {
    const current = await fixture();
    expect(current.onHandle).toHaveBeenCalledOnce();
    current.handle().focus(); expect(document.activeElement).toBe(current.element);
    current.setState({ text: 'New', editing: true }); flush();
    expect(current.onHandle).toHaveBeenCalledOnce();
    current.dispose(); expect(current.onHandle).toHaveBeenLastCalledWith(undefined);
    expect(() => current.savedHandle().getText()).toThrow(/no longer available/);
  });

  it('keeps a dirty browser draft and its caret across external echoes, then accepts the next session', async () => {
    const { element, handle, type, onValueChange, setState } = await fixture();
    handle().focus(); type('My draft'); handle().caretEnd();
    const node = element.firstChild;
    setState({ text: 'Old server echo', editing: true }); flush();
    expect(element.firstChild).toBe(node); expect(handle().getText()).toBe('My draft');
    expect(document.getSelection()?.anchorOffset).toBe(1);
    expect(onValueChange).toHaveBeenLastCalledWith('My draft');
    setState({ text: 'Saved', editing: false }); flush();
    setState({ text: 'New session', editing: true }); flush();
    expect(element.textContent).toBe('New session');
  });

  it('commits the current browser text once on single-line Enter and ensuing blur', async () => {
    const { element, handle, key, onCommit, onBlur } = await fixture();
    handle().focus(); element.innerText = 'Direct DOM draft';
    expect(key('Enter').defaultPrevented).toBe(true);
    expect(onCommit).toHaveBeenCalledExactlyOnceWith('Direct DOM draft');
    expect(onBlur).toHaveBeenCalledExactlyOnceWith('Direct DOM draft');
    expect(document.activeElement).not.toBe(element);
  });

  it('retains a refused submission and retries once after correction', async () => {
    const save = vi.fn().mockReturnValueOnce(false).mockReturnValue(true);
    const current = await fixture({ onCommit: save });
    current.handle().focus(); current.type('Rejected'); current.key('Enter');
    expect(save).toHaveBeenCalledExactlyOnceWith('Rejected');
    await Promise.resolve();
    expect(current.handle().getText()).toBe('Rejected');
    current.handle().focus(); current.type('Corrected'); current.key('Enter');
    expect(save.mock.calls).toEqual([['Rejected'], ['Corrected']]);
  });

  it('deduplicates pending writes and rearms when newer input outlives an acknowledgement', async () => {
    let finish!: (accepted: boolean) => void;
    const save = vi.fn().mockImplementationOnce(() => new Promise<boolean>(resolve => { finish = resolve; }))
      .mockResolvedValue(true);
    const current = await fixture({ onCommit: save });
    current.handle().focus(); current.type('First'); current.key('Enter');
    current.handle().focus(); current.type('Newer'); current.key('Enter');
    expect(save).toHaveBeenCalledExactlyOnceWith('First');
    finish(true); await Promise.resolve();
    expect(current.handle().getText()).toBe('Newer');
    current.key('Enter');
    expect(save.mock.calls).toEqual([['First'], ['Newer']]);
  });

  it('retries rejected promises and ignores their result after cancellation', async () => {
    const save = vi.fn().mockRejectedValueOnce(new Error('Local write failed')).mockResolvedValue(true);
    const current = await fixture({ onCommit: save });
    current.handle().focus(); current.type('Keep draft'); current.key('Enter');
    await Promise.resolve(); current.handle().focus(); current.key('Enter');
    expect(save).toHaveBeenCalledTimes(2);
    current.key('Escape'); await Promise.resolve();
    current.handle().focus(); current.handle().blur();
    expect(save).toHaveBeenCalledTimes(2);
  });

  it('keeps a late refusal from completing or rearming a newer editing session', async () => {
    let finish!: (accepted: boolean) => void;
    const save = vi.fn().mockImplementationOnce(() => new Promise<boolean>(resolve => { finish = resolve; }))
      .mockReturnValue(undefined);
    const current = await fixture({ onCommit: save });
    current.type('Old'); current.key('Enter');
    current.setState({ text: 'Saved', editing: false }); flush();
    current.setState({ text: 'Next', editing: true }); flush();
    current.type('Next'); current.key('Enter');
    finish(false); await Promise.resolve();
    current.key('Enter');
    expect(save.mock.calls).toEqual([['Old'], ['Next']]);
  });

  it('cancels before a surrounding native dialog but leaves IME Escape native', async () => {
    const current = await fixture();
    current.host.setAttribute('data-ui-keyboard-owner', 'Escape');
    current.handle().focus(); current.type('Draft');
    current.element.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    expect(current.key('Escape', { isComposing: true }).defaultPrevented).toBe(false);
    expect(current.onCancel).not.toHaveBeenCalled();
    current.element.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
    expect(current.key('Escape').defaultPrevented).toBe(true);
    expect(current.onCancel).toHaveBeenCalledOnce();
    expect(current.onCommit).not.toHaveBeenCalled();
  });

  it('delegates idle Escape to its owner while cancel and composition stay inside the editor', async () => {
    const current = await fixture();
    const dismiss = vi.fn();
    disposers.push(surfaceRegistry.mountElement({
      name: 'editable.owner', element: current.host, layer: false, transparent: false,
      keys: { Escape: dismiss },
    }));
    current.element.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    expect(current.key('Escape').defaultPrevented).toBe(false);
    expect(dismiss).not.toHaveBeenCalled();
    expect(current.onCancel).not.toHaveBeenCalled();
    current.element.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
    expect(current.key('Escape').defaultPrevented).toBe(true);
    expect(current.onCancel).toHaveBeenCalledOnce();
    expect(dismiss).not.toHaveBeenCalled();
    current.setState({ text: 'Initial', editing: false }); flush();
    expect(current.key('Escape').defaultPrevented).toBe(true);
    expect(dismiss).toHaveBeenCalledOnce();
    expect(current.onCommit).not.toHaveBeenCalled();
  });

  it('cancels on Escape without committing on blur or requested disposal', async () => {
    const { handle, type, key, onCommit, onCancel, dispose } = await fixture({ commitOnDispose: true });
    handle().focus(); type('Canceled'); key('Escape'); dispose();
    expect(onCancel).toHaveBeenCalledOnce(); expect(onCommit).not.toHaveBeenCalled();
  });

  it('commits an unfinished removed editor only when explicitly requested', async () => {
    const current = await fixture({ commitOnDispose: true }); current.type('Pending'); current.dispose();
    expect(current.onCommit).toHaveBeenCalledExactlyOnceWith('Pending');
    const other = await fixture(); other.type('Not committed'); other.dispose();
    expect(other.onCommit).not.toHaveBeenCalled();
  });

  it('preserves native multiline Enter and composition keys', async () => {
    const { key, onCommit, onCancel } = await fixture({ multiline: true });
    expect(key('Enter').defaultPrevented).toBe(false);
    expect(key('Enter', { isComposing: true }).defaultPrevented).toBe(false);
    expect(key('Escape', { isComposing: true }).defaultPrevented).toBe(false);
    expect(onCommit).not.toHaveBeenCalled(); expect(onCancel).not.toHaveBeenCalled();
  });

  it.each([false, true])('owns inline Enter inside a Form only for a single-line session (multiline: %s)', async multiline => {
    const host = document.createElement('div'); document.body.append(host);
    const [editing, setEditing] = createSignal(multiline);
    const onCommit = vi.fn(); const onSubmit = vi.fn();
    const onActivate = vi.fn(() => setEditing(true));
    disposers.push(render(() => {
      const form = constructItem('editable.formOwner', item => item.constant('state', {}));
      const model = constructItem('editable.formChild', item => item.observe('state', () => ({ text: 'Title', editing: editing() })));
      return <Form.View observable={form} surface={{ kind: 'own', name: 'editable.form', transparent: false }} hotkeys={[]} onSubmit={onSubmit}>
        <ContentEditable.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
          label="Inline title" multiline={multiline} onValueChange={() => {}} onActivate={onActivate} onCommit={onCommit} />
      </Form.View>;
    }, host));
    disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
      commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
    await Promise.resolve(); flush(); await Promise.resolve();
    const element = host.querySelector<HTMLElement>('[role="textbox"]')!;
    const enter = (isComposing = false) => {
      const event = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true, isComposing });
      element.dispatchEvent(event); return event;
    };
    expect(enter(true).defaultPrevented).toBe(false);
    expect(onCommit).not.toHaveBeenCalled(); expect(onActivate).not.toHaveBeenCalled();
    expect(enter().defaultPrevented).toBe(!multiline); flush();
    expect(onActivate).toHaveBeenCalledTimes(multiline ? 0 : 1);
    element.innerText = 'Changed'; element.dispatchEvent(new InputEvent('input', { bubbles: true }));
    element.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    expect(enter().defaultPrevented).toBe(false);
    expect(onCommit).not.toHaveBeenCalled();
    element.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
    expect(enter().defaultPrevented).toBe(!multiline);
    expect(onCommit).toHaveBeenCalledTimes(multiline ? 0 : 1);
    if (!multiline) expect(onCommit).toHaveBeenCalledWith('Changed');
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('keeps native typing inside an editing session ahead of owner shortcuts', async () => {
    const current = await fixture(); const parent = vi.fn();
    disposers.push(surfaceRegistry.mountElement({
      name: 'editable.typing-owner', element: current.host, layer: false, transparent: false,
      keys: { A: parent, 'Shift+A': parent, '1': parent, 'Shift++': parent },
    }));
    expect(current.key('a').defaultPrevented).toBe(false);
    expect(current.key('A', { shiftKey: true }).defaultPrevented).toBe(false);
    expect(current.key('1').defaultPrevented).toBe(false);
    expect(current.key('+', { shiftKey: true }).defaultPrevented).toBe(false);
    expect(parent).not.toHaveBeenCalled();
  });

  it('rejects typed writes and activation from hidden or blocked retained editors', async () => {
    const onActivate = vi.fn(); const onDoubleActivate = vi.fn(); const onPressStart = vi.fn();
    const current = await fixture({ onActivate, onDoubleActivate, onPressStart });
    current.host.hidden = true;
    current.type('Hidden write');
    for (const type of ['mousedown', 'click', 'dblclick']) {
      const event = new MouseEvent(type, { bubbles: true, cancelable: true }); current.element.dispatchEvent(event);
      expect(event.defaultPrevented).toBe(true);
    }
    current.element.dispatchEvent(new FocusEvent('focusout', { bubbles: true }));
    expect(current.onValueChange).not.toHaveBeenCalled(); expect(current.onCommit).not.toHaveBeenCalled();
    expect(current.onBlur).not.toHaveBeenCalled(); expect(onActivate).not.toHaveBeenCalled();
    expect(onDoubleActivate).not.toHaveBeenCalled(); expect(onPressStart).not.toHaveBeenCalled();
    current.host.hidden = false;
    const blocker = document.createElement('div'); document.body.append(blocker);
    const release = surfaceRegistry.mountElement({ name: 'editable.blocker', element: blocker, layer: true, transparent: false, keys: {} });
    disposers.push(release);
    current.type('Blocked write');
    expect(current.onValueChange).not.toHaveBeenCalled();
    release(); current.type('Allowed write');
    expect(current.onValueChange).toHaveBeenCalledExactlyOnceWith('Allowed write');
  });

  it('permits an explicit custom override of native multiline Enter', async () => {
    const handler = vi.fn();
    const { key, onCommit } = await fixture({ multiline: true, hotkeys: [{ key: 'Enter', overrideNative: true, handler }] });
    expect(key('Enter').defaultPrevented).toBe(true);
    expect(handler).toHaveBeenCalledOnce(); expect(onCommit).not.toHaveBeenCalled();
  });

  it('holds composition text until the browser publishes the final value', async () => {
    const { element, setState, onValueChange } = await fixture();
    element.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    element.innerText = '日本'; setState({ text: 'Earlier', editing: true }); flush();
    expect(element.innerText).toBe('日本');
    element.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
    expect(onValueChange).toHaveBeenLastCalledWith('日本');
  });

  it('does not carry an interrupted composition into the next edit session', async () => {
    const current = await fixture();
    current.element.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
    current.setState({ text: 'Saved', editing: false }); flush();
    current.setState({ text: 'Next', editing: true }); flush();
    expect(current.element.textContent).toBe('Next');
    current.type('Next draft');
    expect(current.key('Enter').defaultPrevented).toBe(true);
    expect(current.onCommit).toHaveBeenCalledExactlyOnceWith('Next draft');
  });

  it('allows a custom Escape to keep focus and end the model session', async () => {
    let stop = () => {};
    const custom = vi.fn(() => stop());
    const current = await fixture({ hotkeys: [{ key: 'Escape', handler: custom }] });
    stop = () => current.setState({ text: 'Initial', editing: false });
    current.handle().focus(); current.type('Discard'); current.key('Escape'); flush();
    expect(current.element.textContent).toBe('Initial'); expect(document.activeElement).toBe(current.element);
    current.handle().blur(); expect(current.onCommit).not.toHaveBeenCalled(); expect(custom).toHaveBeenCalledOnce();
  });

  it('uses a display-only placeholder and focuses/selects the raw empty text on entry', async () => {
    const { element, handle, setState } = await fixture({ placeholder: 'Untitled', focusOnEdit: 'selectAll' }, { text: '', editing: false });
    expect(element.textContent).toBe('Untitled'); expect(handle().getText()).toBe('');
    setState({ text: '', editing: true }); flush(); await Promise.resolve();
    expect(element.textContent).toBe(''); expect(document.activeElement).toBe(element);
  });

  it('provides native read-only semantics and blocks built-in activation', async () => {
    const onActivate = vi.fn();
    const { element, key, onCommit } = await fixture({ onActivate }, { text: 'Read only', editing: true, readonly: true });
    expect(element.getAttribute('contenteditable')).toBe('false');
    expect(element.getAttribute('aria-readonly')).toBe('true'); expect(element.tabIndex).toBe(-1);
    key('Enter'); key(' '); expect(onActivate).not.toHaveBeenCalled(); expect(onCommit).not.toHaveBeenCalled();
  });

  it('leaves readonly text selectable without activating an edit by pointer', async () => {
    const onActivate = vi.fn(); const onDoubleActivate = vi.fn(); const onPressStart = vi.fn();
    const { element, host } = await fixture({ onActivate, onDoubleActivate, onPressStart },
      { text: 'Read only', editing: false, readonly: true });
    const rowClick = vi.fn(); host.addEventListener('click', rowClick);
    for (const type of ['mousedown', 'click', 'dblclick']) {
      const event = new MouseEvent(type, { bubbles: true, cancelable: true });
      element.dispatchEvent(event);
      expect(event.defaultPrevented).toBe(false);
    }
    expect(onActivate).not.toHaveBeenCalled(); expect(onDoubleActivate).not.toHaveBeenCalled();
    expect(onPressStart).not.toHaveBeenCalled(); expect(rowClick).toHaveBeenCalledOnce();
  });

  it('activates a nonediting textbox with Enter and Space and preserves pointer coordinates', async () => {
    const onActivate = vi.fn(); const onDoubleActivate = vi.fn(); const onPressStart = vi.fn();
    const { element, key } = await fixture({ onActivate, onDoubleActivate, onPressStart }, { text: 'Display', editing: false });
    key('Enter'); key(' '); expect(onActivate).toHaveBeenCalledTimes(2);
    element.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, clientX: 4, clientY: 8, detail: 2 }));
    expect(onDoubleActivate).toHaveBeenCalledWith(expect.objectContaining({ clientX: 4, clientY: 8, detail: 2 }));
    element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, detail: 2 }));
    expect(onPressStart).toHaveBeenCalledWith(expect.objectContaining({ detail: 2 }));
  });

  it('isolates editing presses while allowing display clicks to reach the row', async () => {
    const { host, element, setState } = await fixture(); const parent = vi.fn();
    host.addEventListener('click', parent); host.addEventListener('mousedown', parent); host.addEventListener('pointerdown', parent);
    element.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    element.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
    expect(parent).not.toHaveBeenCalled();
    setState({ text: 'Display', editing: false }); flush();
    element.dispatchEvent(new MouseEvent('click', { bubbles: true })); expect(parent).toHaveBeenCalledOnce();
  });

  it('selects a browser hit within its text and falls back safely for outside hits', async () => {
    const { element, handle } = await fixture();
    Object.defineProperty(document, 'caretPositionFromPoint', { configurable: true,
      value: vi.fn(() => ({ offsetNode: element.firstChild, offset: 3 })) });
    expect(handle().caretAtPoint({ x: 20, y: 40 })).toBe(true);
    expect(document.getSelection()?.anchorOffset).toBe(3);
    Object.defineProperty(document, 'caretPositionFromPoint', { configurable: true,
      value: vi.fn(() => ({ offsetNode: document.body, offset: 0 })) });
    expect(handle().caretAtPoint({ x: 0, y: 0 })).toBe(false);
    expect(document.getSelection()?.toString()).toBe('Initial');
    Reflect.deleteProperty(document, 'caretPositionFromPoint');
  });
});
