const TABBABLE_SELECTOR = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[contenteditable="true"]',
  '[tabindex]:not([tabindex="-1"])',
  '[data-ui-interactive]',
].join(',');

/** One-shot notice that descendant controls have finished preparing. Readiness
 * markers remain private to the core. An initially ready container completes
 * synchronously; mutation notices wait a microtask for focus-handle publication.
 * The caller owns whether its retained container is still active and connected. */
export function whenControlsReady(container: Element, onReady: () => void): () => void {
  if (!container.querySelector('[data-ui-ready="false"]')) {
    onReady();
    return () => {};
  }
  let active = true;
  let queued = false;
  const observer = new MutationObserver(() => {
    if (!active || queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; complete(); });
  });
  const cancel = () => {
    if (!active) return;
    active = false;
    observer.disconnect();
  };
  const complete = () => {
    if (!active || container.querySelector('[data-ui-ready="false"]')) return;
    cancel();
    onReady();
  };
  observer.observe(container, { attributes: true, attributeFilter: ['data-ui-ready'], childList: true, subtree: true });
  return cancel;
}

function composedParent(element: Element): Element | null {
  if (element.assignedSlot) return element.assignedSlot;
  if (element.parentElement) return element.parentElement;
  const root = element.getRootNode();
  return root instanceof ShadowRoot ? root.host : null;
}

function visibleForFocus(element: HTMLElement): boolean {
  for (let ancestor: Element | null = element; ancestor; ancestor = composedParent(ancestor)) {
    if (ancestor.hasAttribute('hidden') || ancestor.hasAttribute('inert')
      || ancestor.getAttribute('aria-hidden') === 'true' || ancestor.getAttribute('data-ui-ready') === 'false') return false;
    const style = ancestor.ownerDocument.defaultView?.getComputedStyle(ancestor);
    if (style?.display === 'none' || style?.visibility === 'hidden' || style?.visibility === 'collapse') return false;
  }
  return true;
}

const availableForFocus = (element: HTMLElement): boolean => visibleForFocus(element)
  && !element.matches(':disabled,[disabled],[tabindex="-1"],input[type="hidden"]');

/** Walk the composed tree once. Vendor hosts are the public focus target. */
export function tabbableElements(container: HTMLElement): HTMLElement[] {
  const items: HTMLElement[] = [];
  const seen = new Set<Element>();
  const visit = (element: Element) => {
    if (seen.has(element)) return;
    seen.add(element);
    if (!(element instanceof HTMLElement) || !visibleForFocus(element)) return;
    if (element.hasAttribute('data-ui-interactive') && !availableForFocus(element)) return;
    if (element.matches(TABBABLE_SELECTOR) && availableForFocus(element)) {
      if (element.hasAttribute('data-ui-interactive')) {
        // The adapter may delegate tabindex/disabled to its internal native control.
        const controls = element.shadowRoot?.querySelectorAll<HTMLElement>('button,input,select,textarea,[tabindex],[contenteditable="true"],[data-ui-interactive]');
        if (controls?.length && !Array.from(controls).some(availableForFocus)) return;
      }
      items.push(element);
      if (element.hasAttribute('data-ui-interactive')) return;
    }
    if (element instanceof HTMLSlotElement) {
      const assigned = element.assignedElements({ flatten: true });
      for (const child of assigned.length ? assigned : element.children) visit(child);
    } else {
      for (const child of element.shadowRoot?.children ?? element.children) visit(child);
    }
  };
  // A tabindex=-1 surface is a valid container, though it is not a tab stop.
  for (const child of container.shadowRoot?.children ?? container.children) visit(child);
  return items.sort((left, right) => {
    const leftOrder = left.tabIndex > 0 ? left.tabIndex : Infinity;
    const rightOrder = right.tabIndex > 0 ? right.tabIndex : Infinity;
    return leftOrder - rightOrder;
  });
}

export function containsFocus(container: HTMLElement, element: Element | null): boolean {
  for (let current = element; current; current = composedParent(current)) {
    if (current === container) return true;
  }
  return false;
}

export function focusedElement(ownerDocument: Document): Element | null {
  let active = ownerDocument.activeElement;
  while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
  return active;
}

export function focusInitialElement(
  container: HTMLElement,
  preferred?: HTMLElement | null,
): HTMLElement {
  const items = tabbableElements(container);
  // An explicit initial target may be a dialog/surface container with
  // tabindex="-1". Keep disabled and hidden targets out, but allow that
  // intentional programmatic focus destination.
  const preferredIsFocusable = preferred?.isConnected
    && visibleForFocus(preferred)
    && !preferred.matches(':disabled,[disabled],input[type="hidden"]');
  const target = preferredIsFocusable
    ? preferred
    : items.find((element) => element.matches('[autofocus],[data-autofocus]'))
      ?? items[0]
      ?? container;
  target.focus({ preventScroll: true });
  return target;
}

export function trapTabKey(event: KeyboardEvent, container: HTMLElement, fallback: HTMLElement = container): boolean {
  if (event.key !== 'Tab') return false;
  const items = tabbableElements(container);
  if (items.length === 0) {
    event.preventDefault();
    fallback.focus({ preventScroll: true });
    return true;
  }

  const active = focusedElement(container.ownerDocument);
  const current = items.find((item) => containsFocus(item, active));
  const first = items[0]!;
  const last = items[items.length - 1]!;
  // A dialog heading/container may receive initial focus with tabindex=-1.
  // It belongs to the surface, but is not a tab stop: reverse Tab must still
  // wrap instead of escaping to the background. Native editing keys stay free.
  if (event.shiftKey && (current === first || !current)) {
    event.preventDefault();
    last.focus({ preventScroll: true });
    return true;
  }
  if (!event.shiftKey && (current === last || !current)) {
    event.preventDefault();
    first.focus({ preventScroll: true });
    return true;
  }
  return false;
}

interface ScrollLockState {
  count: number;
  overflow: string;
  paddingRight: string;
}

const scrollLocks = new WeakMap<Document, ScrollLockState>();

export function lockDocumentScroll(ownerDocument: Document): () => void {
  const body = ownerDocument.body;
  let state = scrollLocks.get(ownerDocument);
  if (!state) {
    state = {
      count: 0,
      overflow: body.style.overflow,
      paddingRight: body.style.paddingRight,
    };
    scrollLocks.set(ownerDocument, state);
  }
  state.count += 1;

  if (state.count === 1) {
    const viewportWidth = ownerDocument.defaultView?.innerWidth ?? ownerDocument.documentElement.clientWidth;
    const scrollbarWidth = Math.max(0, viewportWidth - ownerDocument.documentElement.clientWidth);
    body.style.overflow = 'hidden';
    if (scrollbarWidth > 0) {
      const existingPadding = Number.parseFloat(ownerDocument.defaultView?.getComputedStyle(body).paddingRight ?? '0') || 0;
      body.style.paddingRight = `${existingPadding + scrollbarWidth}px`;
    }
  }

  let released = false;
  return () => {
    if (released) return;
    released = true;
    const current = scrollLocks.get(ownerDocument);
    if (!current) return;
    current.count -= 1;
    if (current.count > 0) return;
    body.style.overflow = current.overflow;
    body.style.paddingRight = current.paddingRight;
    scrollLocks.delete(ownerDocument);
  };
}

export interface FloatingPlacementOptions {
  side?: 'top' | 'bottom';
  align?: 'start' | 'center' | 'end';
  offset?: number;
  margin?: number;
}

export interface FloatingPlacement {
  left: number;
  top: number;
  side: 'top' | 'bottom';
}

export function placeFloatingBox(
  anchor: Pick<DOMRect, 'left' | 'right' | 'top' | 'bottom' | 'width'>,
  box: { width: number; height: number },
  viewport: { width: number; height: number },
  options: FloatingPlacementOptions = {},
): FloatingPlacement {
  const preferredSide = options.side ?? 'bottom';
  const align = options.align ?? 'center';
  const offset = options.offset ?? 4;
  const margin = options.margin ?? 8;

  const roomBelow = viewport.height - anchor.bottom - offset - margin;
  const roomAbove = anchor.top - offset - margin;
  const side = preferredSide === 'bottom'
    ? (roomBelow >= box.height || roomBelow >= roomAbove ? 'bottom' : 'top')
    : (roomAbove >= box.height || roomAbove >= roomBelow ? 'top' : 'bottom');

  const desiredLeft = align === 'start'
    ? anchor.left
    : align === 'end'
      ? anchor.right - box.width
      : anchor.left + (anchor.width - box.width) / 2;
  const maxLeft = Math.max(margin, viewport.width - margin - box.width);
  const left = Math.min(Math.max(desiredLeft, margin), maxLeft);
  const desiredTop = side === 'bottom'
    ? anchor.bottom + offset
    : anchor.top - offset - box.height;
  const maxTop = Math.max(margin, viewport.height - margin - box.height);
  const top = Math.min(Math.max(desiredTop, margin), maxTop);
  return { left, top, side };
}
