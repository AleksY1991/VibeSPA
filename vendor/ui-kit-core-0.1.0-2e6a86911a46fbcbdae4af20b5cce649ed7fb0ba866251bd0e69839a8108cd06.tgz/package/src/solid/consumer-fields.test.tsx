/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, expect, it, vi } from 'vitest';
import { createSignal, flush } from 'solid-js';
import { renderPrepared as render } from '../../tests/prepared';
import type { TextFieldElement, TextareaElement } from '../vendor/web-awesome/elements';
import { constructItem } from '../infrastructure/construction';
import { TextField } from './text-field';
import { Textarea } from './textarea';
const settle = async () => { for (let n = 0; n < 36; n++) { flush(); await Promise.resolve(); } };
let dispose: (() => void) | undefined;
afterEach(() => { dispose?.(); document.body.replaceChildren(); });
it('publishes editing hosts for host-owned checkpoints while retaining live shared field bindings', async () => {
  const host = document.createElement('div'); document.body.append(host);
  const attached = vi.fn();
  const [value, setValue] = createSignal('Saved draft');
  dispose = render(() => {
    const text = constructItem('consumer.fields', item => item.observe('text', value));
    return <><TextField.View observable={text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Title" onElement={attached} onValueChange={setValue} />
      <Textarea.View observable={text} surface={{ kind: 'inherit' }} hotkeys={[]} label="Document" fillHeight onElement={attached} onValueChange={setValue} /></>;
  }, host);
  await settle();
  expect(attached.mock.calls.map(([element]) => element.tagName)).toEqual(['WA-INPUT', 'WA-TEXTAREA']);
  const input = host.querySelector<TextFieldElement>('wa-input')!;
  const textarea = host.querySelector<TextareaElement>('wa-textarea')!;
  expect(textarea.hasAttribute('data-ui-fill-height')).toBe(true);
  setValue('Continued draft'); await settle();
  expect(input.value).toBe('Continued draft');
  expect(textarea.value).toBe('Continued draft');
  textarea.input.value = 'Edited draft'; textarea.input.dispatchEvent(new Event('input', { bubbles: true, composed: true })); await settle();
  expect(value()).toBe('Edited draft');
});
