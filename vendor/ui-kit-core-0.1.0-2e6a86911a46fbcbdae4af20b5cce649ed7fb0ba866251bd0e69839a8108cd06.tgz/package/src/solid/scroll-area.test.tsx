/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createSignal, flush, onCleanup, OBSERVE } from 'solid-js';
import { render } from '@solidjs/web';

import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ScrollArea, type ScrollAreaHandle } from './scroll-area';
import { Button } from './button';
import { ContentEditable, type ContentEditableState } from './content-editable';
import { useStyles } from '../../tests/styles';

useStyles('solid/scroll-area.css');

const cleanups: (() => void)[] = [];
const settle = async () => { flush(); await Promise.resolve(); flush(); };
const mount = (view: () => ReturnType<typeof ScrollArea.View>) => {
  const root = document.createElement('div');
  document.body.append(root);
  const dispose = render(view, root);
  cleanups.push(dispose);
  return { root, dispose };
};
const key = (element: Element, value: string, modifiers: KeyboardEventInit = {}) => {
  const event = new KeyboardEvent('keydown', { key: value, bubbles: true, composed: true, cancelable: true, ...modifiers });
  element.dispatchEvent(event);
  return event;
};
const captureResizeObservers = () => {
  const observers: ResizeObserverStub[] = [];
  class ResizeObserverStub {
    readonly targets = new Set<Element>();
    constructor(readonly callback: ResizeObserverCallback) { observers.push(this); }
    observe(target: Element) { this.targets.add(target); }
    unobserve(target: Element) { this.targets.delete(target); }
    disconnect() { this.targets.clear(); }
    notify() { this.callback([], this as ResizeObserver); }
  }
  vi.stubGlobal('ResizeObserver', ResizeObserverStub);
  return observers;
};

let detachDispatcher: (() => void) | undefined;
beforeEach(() => {
  detachDispatcher = attachDispatcher({
    window, document, registry: surfaceRegistry,
    commands: { dispatch: () => {} },
    runtime: () => ({ editing: false, keyboardLayer: null }),
  });
});
afterEach(() => {
  cleanups.splice(0).reverse().forEach(dispose => dispose());
  detachDispatcher?.();
  document.body.replaceChildren();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('ScrollArea construction', () => {
  it.each([
    ['vertical', 'scrollHeight'], ['horizontal', 'scrollWidth'],
    ['both', 'scrollHeight'], ['both', 'scrollWidth'],
  ] as const)('updates the %s keyboard tab stop when %s grows and releases content observers', async (orientation, overflowMetric) => {
    const observers = captureResizeObservers();
    const disconnectMutations = vi.spyOn(MutationObserver.prototype, 'disconnect');
    const { root, dispose } = mount(() => {
      const observable = constructItem('scroll.overflow', item => item.constant('visible', true));
      return <ScrollArea.View orientation={orientation} observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]}>
        <div data-editor-box=""><textarea aria-label="Growing editor" /></div>
      </ScrollArea.View>;
    });
    await settle();
    const region = root.firstElementChild as HTMLElement;
    const box = region.querySelector('[data-editor-box]')!;
    let extent = 80;
    Object.defineProperties(region, {
      scrollHeight: { configurable: true, get: () => overflowMetric === 'scrollHeight' ? extent : 80 },
      scrollWidth: { configurable: true, get: () => overflowMetric === 'scrollWidth' ? extent : 80 },
      clientHeight: { configurable: true, get: () => 100 },
      clientWidth: { configurable: true, get: () => 100 },
    });
    expect(observers.some(observer => observer.targets.has(region))).toBe(true);
    expect(observers.some(observer => observer.targets.has(box))).toBe(true);
    const refresh = async () => { for (const observer of observers) observer.notify(); await settle(); };
    await refresh(); expect(region.tabIndex).toBe(-1);
    extent = 240; await refresh(); expect(region.tabIndex).toBe(0);
    extent = 50; await refresh(); expect(region.tabIndex).toBe(-1);
    const added = document.createElement('div'); region.append(added);
    await new Promise(resolve => setTimeout(resolve, 0)); await settle();
    expect(observers.some(observer => observer.targets.has(added))).toBe(true);
    dispose();
    expect(observers.every(observer => observer.targets.size === 0)).toBe(true);
    expect(disconnectMutations).toHaveBeenCalled();
  });

  it.each([0, -1, 3])('preserves the explicit tabindex %s while overflow changes', async tabindex => {
    const observers = captureResizeObservers();
    const { root } = mount(() => {
      const observable = constructItem('scroll.explicitTabindex', item => item.constant('visible', true));
      return <ScrollArea.View tabindex={tabindex} observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]}>Content</ScrollArea.View>;
    });
    await settle();
    const region = root.firstElementChild as HTMLElement;
    expect(region.tabIndex).toBe(tabindex);
    Object.defineProperties(region, { scrollHeight: { configurable: true, value: 240 }, clientHeight: { configurable: true, value: 100 } });
    for (const observer of observers) observer.notify(); await settle();
    expect(region.tabIndex).toBe(tabindex);
  });

  it.each(['vertical', 'both'] as const)('owns %s attribute effects through semantic element replacement and disposal', async orientation => {
    const diagnostics = OBSERVE!.diagnostics.capture();
    cleanups.push(diagnostics.stop);
    const [as, setAs] = createSignal<'div' | 'main'>('div');
    const [tip, setTip] = createSignal('Initial');
    const shortcut = vi.fn();
    const { root, dispose } = mount(() => {
      const observable = constructItem('scroll.attributeLifetime', item => item.constant('visible', true));
      return <ScrollArea.View as={as()} orientation={orientation} data-tip={tip()}
        observable={observable} surface={{ kind: 'own', name: 'scroll.attributeLifetime', transparent: false }}
        hotkeys={[{ key: 'Alt+J', handler: shortcut }]}>Content</ScrollArea.View>;
    });
    await settle();
    const initial = root.firstElementChild!;
    expect(initial.getAttribute('data-tip')).toBe('Initial');
    setTip('Updated'); await settle();
    expect(initial.getAttribute('data-tip')).toBe('Updated');
    setAs('main'); await settle();
    const replacement = root.querySelector('main')!;
    expect(replacement.getAttribute('data-tip')).toBe('Updated');
    setTip('Replaced'); await settle();
    expect(replacement.getAttribute('data-tip')).toBe('Replaced');
    expect(initial.getAttribute('data-tip')).toBe('Updated');
    expect(key(replacement, 'j', { altKey: true }).defaultPrevented).toBe(true);
    expect(shortcut).toHaveBeenCalledExactlyOnceWith(expect.any(KeyboardEvent), replacement);
    dispose();
    setTip('Disposed'); await settle();
    expect(replacement.getAttribute('data-tip')).toBe('Replaced');
    key(replacement, 'j', { altKey: true });
    expect(shortcut).toHaveBeenCalledOnce();
    expect(diagnostics.events.filter(event => event.code === 'NO_OWNER_EFFECT' || event.code === 'NO_OWNER_CLEANUP')).toEqual([]);
  });

  it('keeps one editor owner and draft while orientation and semantic element change', async () => {
    const [orientation, setOrientation] = createSignal<'vertical' | 'both'>('vertical');
    const [as, setAs] = createSignal<'div' | 'main'>('div');
    const disposed = vi.fn();
    const Editor = () => { onCleanup(disposed); return <textarea aria-label="Draft" />; };
    const { root, dispose } = mount(() => {
      const observable = constructItem('scroll.retainedDraft', item => item.constant('visible', true));
      return <ScrollArea.View as={as()} orientation={orientation()} fill observable={observable}
        surface={{ kind: 'inherit' }} hotkeys={[]}><Editor /></ScrollArea.View>;
    });
    await settle();
    const editor = root.querySelector('textarea')!;
    editor.value = 'Keep me';
    setOrientation('both'); await settle();
    expect(getComputedStyle(root.firstElementChild!).overflow).toBe('auto');
    expect(root.querySelector('textarea')).toBe(editor);
    expect(editor.value).toBe('Keep me');
    setAs('main'); await settle();
    expect(root.firstElementChild?.localName).toBe('main');
    expect(root.querySelector('textarea')).toBe(editor);
    expect(editor.value).toBe('Keep me');
    expect(disposed).not.toHaveBeenCalled();
    expect(root.querySelector('wa-scroller')).toBeNull();
    dispose();
    expect(disposed).toHaveBeenCalledOnce();
  });

  it('keeps scroll events and accessibility references on the same native region', async () => {
    const onScroll = vi.fn();
    const { root } = mount(() => {
      const observable = constructItem('scroll.nativeRegion', item => item.constant('visible', true));
      return <><p id="scroll-heading">Activity</p><p id="scroll-description">Recent changes</p>
        <ScrollArea.View as="section" role="region" tabindex={0} aria-labelledby="scroll-heading"
          aria-describedby="scroll-description" onScroll={onScroll} observable={observable}
          surface={{ kind: 'inherit' }} hotkeys={[]}>Content</ScrollArea.View></>;
    });
    await settle();
    const region = root.querySelector('section')!;
    expect(region.getAttribute('role')).toBe('region');
    expect(region.getAttribute('aria-labelledby')).toBe('scroll-heading');
    expect(region.getAttribute('aria-describedby')).toBe('scroll-description');
    expect(region.tabIndex).toBe(0);
    const event = new Event('scroll');
    region.dispatchEvent(event);
    expect(onScroll).toHaveBeenCalledExactlyOnceWith(event);
  });

  it.each(['onScroll', 'onScrollEnd', 'onScrollSnapChange', 'onScrollSnapChanging'] as const)(
    'preserves the native event target for %s', async eventProp => {
      const listener = vi.fn();
      const { root } = mount(() => {
        const observable = constructItem(`scroll.event.${eventProp}`, item => item.constant('visible', true));
        return <ScrollArea.View {...{ [eventProp]: listener }} observable={observable}
          surface={{ kind: 'inherit' }} hotkeys={[]}>Content</ScrollArea.View>;
      });
      await settle();
      const native = root.firstElementChild!;
      expect(native.localName).toBe('div');
      expect(native.hasAttribute('data-ui-fallback')).toBe(false);
      const event = new Event(eventProp.slice(2).toLowerCase());
      native.dispatchEvent(event);
      expect(listener).toHaveBeenCalledExactlyOnceWith(event);
    },
  );

  it('preserves descendant editing keys and explicit native overrides without a vendor key interceptor', async () => {
    const shortcut = vi.fn(); const override = vi.fn();
    const { root } = mount(() => {
      const observable = constructItem('scroll.keys', item => item.constant('visible', true));
      const editing = constructItem('scroll.keys.editing', item => item.constant<ContentEditableState>('state', { text: 'Editable', editing: true }));
      return <ScrollArea.View observable={observable} surface={{ kind: 'inherit' }}
        hotkeys={[{ key: 'Alt+J', handler: shortcut }, { key: 'Home', overrideNative: true, handler: override }]}>
        <input aria-label="Title" data-ui-keyboard-owner="Home End" />
        <textarea aria-label="Description" data-ui-keyboard-owner="Home End" />
        <ContentEditable.View label="Inline description" observable={editing} surface={{ kind: 'inherit' }} hotkeys={[]}
          onValueChange={() => {}} />
      </ScrollArea.View>;
    });
    await settle();
    const region = root.firstElementChild!;
    for (const editor of region.querySelectorAll('input,textarea,[contenteditable]')) {
      for (const [value, modifiers] of [
        ['Home', {}], ['End', {}], ['Home', { shiftKey: true }], ['End', { ctrlKey: true }],
      ] as const) expect(key(editor, value, modifiers).defaultPrevented).toBe(false);
    }
    expect(override).not.toHaveBeenCalled();
    expect(key(region.querySelector('input')!, 'j', { altKey: true }).defaultPrevented).toBe(true);
    expect(shortcut).toHaveBeenCalledExactlyOnceWith(expect.any(KeyboardEvent), region);
    expect(key(region, 'Home').defaultPrevented).toBe(true);
    expect(override).toHaveBeenCalledExactlyOnceWith(expect.any(KeyboardEvent), region);
  });

  it('publishes actual scroll metrics and invalidates the handle when its owner ends', () => {
    const host = document.createElement('div'); document.body.append(host);
    let handle: ScrollAreaHandle | undefined;
    const dispose = render(() => {
      const visible = constructItem('scroll.handle', item => item.constant('visible', true));
      return <ScrollArea.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
        onHandle={value => { handle = value; }}>Content</ScrollArea.View>;
    }, host);
    flush();
    const region = host.firstElementChild as HTMLElement;
    Object.defineProperties(region, { scrollHeight: { value: 300 }, clientHeight: { value: 100 } });
    const scroll = vi.spyOn(region, 'scrollTo');
    expect(handle?.scrollPosition()).toMatchObject({ top: 0, height: 300, clientHeight: 100 });
    handle?.scrollTo({ top: 50, behavior: 'instant' });
    expect(scroll).toHaveBeenCalledWith({ top: 50, behavior: 'instant' });
    const retained = handle;
    dispose();
    expect(handle).toBeUndefined();
    expect(() => retained?.scrollPosition()).toThrow('Scroll area handle has been disposed');
  });

  it('suspends retained child owners with the scrolling host and restores their same DOM', () => {
    const host = document.createElement('div'); document.body.append(host);
    const [visible, setVisible] = createSignal(true);
    const dispose = render(() => {
      const model = constructItem('scroll.retained', item => ({
        visible: item.observe('visible', visible), button: item.constant('button', {}),
      }));
      return <ScrollArea.View observable={model.visible}
        surface={{ kind: 'own', name: 'scroll.retained', transparent: false }} hotkeys={[]}>
        <Button.View observable={model.button}
          surface={{ kind: 'own', name: 'scroll.retained.child', transparent: false }} hotkeys={[]}>Edit</Button.View>
      </ScrollArea.View>;
    }, host);
    try {
      flush();
      const child = host.querySelector('button');
      const owners = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name.startsWith('scroll.retained'));
      expect(owners()).toHaveLength(2);
      setVisible(false); flush();
      expect(host.querySelector('button')).toBe(child);
      expect(owners()).toHaveLength(0);
      setVisible(true); flush();
      expect(host.querySelector('button')).toBe(child);
      expect(owners()).toHaveLength(2);
    } finally { dispose(); }
  });

  it('binds visibility and keyboard registration to the same actual scrolling element', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const command = vi.fn();
    let setVisible!: (visible: boolean) => void;
    const dispose = render(() => {
      const [visible, writeVisible] = createSignal(true);
      setVisible = writeVisible;
      const observable = constructItem('test.scrollVisibility', item => item.observe('visible', visible));
      return <ScrollArea.View observable={observable}
        surface={{ kind: 'own', name: 'test.scrollVisibility', transparent: false }}
        hotkeys={[{ key: 'Alt+J', handler: command }]} as="main" tabindex={0}>Content</ScrollArea.View>;
    }, host);
    flush();
    const element = host.querySelector('main')!;
    element.focus();
    element.dispatchEvent(new KeyboardEvent('keydown', { key: 'j', altKey: true, bubbles: true, cancelable: true }));
    expect(command).toHaveBeenCalledExactlyOnceWith(expect.any(KeyboardEvent), element);
    expect(element.hidden).toBe(false);
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.scrollVisibility')).toHaveLength(1);

    setVisible(false); flush();
    expect(element.hidden).toBe(true);
    expect(element.getAttribute('aria-hidden')).toBe('true');
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.scrollVisibility')).toHaveLength(0);
    setVisible(true); flush();
    expect(host.querySelector('main')).toBe(element);
    expect(element.hidden).toBe(false);
    expect(element.hasAttribute('aria-hidden')).toBe(false);
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'test.scrollVisibility')).toHaveLength(1);
    dispose();
  });

  it('preserves native scrolling keys with an explicit empty custom hotkeys array', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const parentShortcut = vi.fn();
    const releaseParent = surfaceRegistry.mountElement({
      element: host, name: 'test.parentShortcuts', transparent: false, layer: false,
      keys: { ArrowDown: parentShortcut, Space: parentShortcut },
    });
    const dispose = render(() => {
      const observable = constructItem('test.nativeScrolling', item => item.constant('visible', true));
      return <ScrollArea.View observable={observable}
        surface={{ kind: 'inherit' }}
        hotkeys={[]} tabindex={0}>Content</ScrollArea.View>;
    }, host);
    flush();
    const element = host.firstElementChild as HTMLElement;
    element.focus();
    for (const key of ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End', ' ']) {
      const event = new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true });
      element.dispatchEvent(event);
      expect(event.defaultPrevented, key).toBe(false);
    }
    expect(parentShortcut).not.toHaveBeenCalled();
    dispose();
    releaseParent();
  });
});
