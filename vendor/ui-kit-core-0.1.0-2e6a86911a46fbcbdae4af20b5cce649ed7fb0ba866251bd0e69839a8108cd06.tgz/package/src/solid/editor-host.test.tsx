/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createSignal, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { EditorHost, type EditorHostController, type EditorHostProps, type EditorHostState } from './editor-host';
import { Card } from './controls';

let dispose: (() => void) | undefined;
afterEach(() => { dispose?.(); dispose = undefined; flush(); document.body.replaceChildren(); });

describe('Editor host lifetime', () => {
  it('guards adapter writes by editability, global authority and the effective mount lifetime', async () => {
    const [visible, setVisible] = createSignal(true);
    const [blocked, setBlocked] = createSignal(false);
    const [editable, setEditable] = createSignal(true);
    const changed = vi.fn(); const stopped = vi.fn();
    const commands: ((value: string) => void)[] = [];
    const mount: EditorHostProps['mount'] = (_element, context) => {
      commands.push(context.command(changed));
      return { update: () => {}, dispose: stopped };
    };
    const host = document.createElement('div'); document.body.append(host);
    dispose = render(() => {
      const model = constructItem('editor.authority', item => ({
        visible: item.observe('visible', visible), blocked: item.observe('blocked', blocked),
        editor: item.observe('editor', () => ({ visible: true, editable: editable() })),
      }));
      return <>
        <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>
          <EditorHost.View observable={model.editor} surface={{ kind: 'inherit' }} hotkeys={[]} label="Editor" mount={mount} onError={vi.fn()} />
        </Card.View>
        <Card.View observable={model.blocked} surface={{ kind: 'own', name: 'editor.blocker', transparent: false, layer: true }} hotkeys={[]}>Dialog</Card.View>
      </>;
    }, host);
    await vi.waitFor(() => expect(commands).toHaveLength(1));
    const initial = commands[0];
    const settle = async () => { for (let turn = 0; turn < 8; turn++) { flush(); await Promise.resolve(); } };
    initial('allowed'); expect(changed).toHaveBeenCalledExactlyOnceWith('allowed');
    setBlocked(true); await settle(); initial('blocked');
    setBlocked(false); setEditable(false); await settle(); initial('readonly');
    expect(changed).toHaveBeenCalledOnce();
    setEditable(true); setVisible(false); flush();
    await vi.waitFor(() => expect(stopped).toHaveBeenCalledOnce());
    initial('hidden'); expect(changed).toHaveBeenCalledOnce();
    setVisible(true); flush();
    await vi.waitFor(() => expect(commands).toHaveLength(2));
    initial('stale'); commands[1]('resumed');
    expect(changed.mock.calls.map(([value]) => value)).toEqual(['allowed', 'resumed']);
    dispose(); dispose = undefined; commands[1]('disposed');
    expect(changed).toHaveBeenCalledTimes(2);
  });

  it('never starts mounting after its owner is disposed at the microtask boundary', async () => {
    const mountedAfterAbort: boolean[] = [];
    const stop = vi.fn();
    const mount = vi.fn((_element: HTMLElement, context: { readonly signal: AbortSignal }) => {
      mountedAfterAbort.push(context.signal.aborted);
      return { update: vi.fn(), dispose: stop };
    });
    const host = document.createElement('div'); document.body.append(host);
    dispose = render(() => {
      const model = constructItem('editor.canceled', item => item.constant('state', { visible: true, editable: true }));
      return <EditorHost.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Editor" mount={mount} onError={vi.fn()} />;
    }, host);
    // Cleanup may run between the host's scheduling and a delayed adapter start.
    // An already-started adapter may finish, but it must never start aborted.
    flush();
    queueMicrotask(() => { dispose!(); dispose = undefined; });
    for (let index = 0; index < 5; index += 1) await Promise.resolve();
    expect(mountedAfterAbort).toEqual([false]);
    expect(stop).toHaveBeenCalledOnce();
  });

  it('reports a synchronous mount failure through the same error boundary as a rejected load', async () => {
    const error = new Error('Editor could not initialize'); const onError = vi.fn();
    const host = document.createElement('div'); document.body.append(host);
    dispose = render(() => {
      const model = constructItem('editor.failed', item => item.constant('state', { visible: true, editable: true }));
      return <EditorHost.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Editor" mount={() => { throw error; }} onError={onError} />;
    }, host);
    await vi.waitFor(() => expect(onError).toHaveBeenCalledExactlyOnceWith(error));
  });

  it('updates editability without remounting and disposes before hidden or detached surfaces can handle keys', async () => {
    const [state, setState] = createSignal<EditorHostState>({ visible: true, editable: true });
    const update = vi.fn(); const stop = vi.fn(); const onError = vi.fn();
    const mount = vi.fn(() => ({ update, dispose: stop }));
    const host = document.createElement('div'); document.body.append(host);
    dispose = render(() => {
      const model = constructItem('editor.test', item => item.observe('state', state));
      return <EditorHost.View observable={model} surface={{ kind: 'own', name: 'editor.test', transparent: true }}
        hotkeys={[]} label="Editor" mount={mount} onError={onError} />;
    }, host);
    await vi.waitFor(() => expect(update).toHaveBeenLastCalledWith({ visible: true, editable: true }));
    setState({ visible: true, editable: false }); flush();
    expect(update).toHaveBeenLastCalledWith({ visible: true, editable: false });
    expect(mount).toHaveBeenCalledOnce();
    setState({ visible: false, editable: false }); flush();
    expect(stop).toHaveBeenCalledOnce();
    expect(host.querySelector<HTMLElement>('[aria-label="Editor"]')!.hidden).toBe(true);
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'editor.test')).toBe(false);
    dispose!(); dispose = undefined;
    expect(stop).toHaveBeenCalledOnce();
    expect(onError).not.toHaveBeenCalled();
  });

  it('aborts a loading editor and disposes its eventual result without publishing it', async () => {
    let finish!: (controller: EditorHostController) => void;
    let signal!: AbortSignal;
    const update = vi.fn(); const stop = vi.fn(); const onError = vi.fn();
    const host = document.createElement('div'); document.body.append(host);
    dispose = render(() => {
      const model = constructItem('editor.deferred', item => item.constant('state', { visible: true, editable: true }));
      return <EditorHost.View observable={model} surface={{ kind: 'own', name: 'editor.deferred', transparent: true }}
        hotkeys={[]} label="Editor" onError={onError} mount={(_host, context) => {
          signal = context.signal; return new Promise(resolve => { finish = resolve; });
        }} />;
    }, host);
    await vi.waitFor(() => expect(signal).toBeDefined());
    dispose!(); dispose = undefined;
    expect(signal.aborted).toBe(true);
    finish({ update, dispose: stop });
    await vi.waitFor(() => expect(stop).toHaveBeenCalledOnce());
    expect(update).not.toHaveBeenCalled();
    expect(onError).not.toHaveBeenCalled();
  });
});
