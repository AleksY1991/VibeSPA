import { createSignal, getOwner, latest, onCleanup, runWithOwner, untrack } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { allowActivation, eventScope, pointerCancellation } from '../infrastructure/activation';
import { ElementBinding } from '../infrastructure/element';
import { readObservable } from '../infrastructure/construction';
import { RenderedElement } from '../infrastructure/rendered-element';

const isEventTarget = (target: unknown): target is EventTarget => target !== null && typeof target === 'object'
  && 'addEventListener' in target && typeof target.addEventListener === 'function'
  && 'removeEventListener' in target && typeof target.removeEventListener === 'function'
  && 'dispatchEvent' in target && typeof target.dispatchEvent === 'function';

type InteractionEventMap = GlobalEventHandlersEventMap & WindowEventMap & DocumentEventMap;
export type InteractionEventType = Exclude<keyof InteractionEventMap, 'keydown' | 'keyup' | 'keypress'>;
export type InteractionEvent = {
  [Type in InteractionEventType]: {
    readonly type: Type;
    readonly handler: (event: InteractionEventMap[Type]) => void;
    readonly options?: AddEventListenerOptions;
  }
}[InteractionEventType];

// Browser observations and cancellation release existing resources; they do
// not start another UI command. Everything else requires the surface's command
// authority, including non-passive wheel handlers and focus-driven dismissal.
const LIFECYCLE_EVENTS: ReadonlySet<InteractionEventType> = new Set<InteractionEventType>([
  'resize', 'scroll', 'scrollend', 'visibilitychange', 'pagehide', 'pageshow',
  'beforeunload', 'unload', 'blur', 'focusout', 'close',
  'pointercancel', 'lostpointercapture', 'touchcancel', 'dragend',
]);

export interface InteractionEventsProps extends ElementConstruction<boolean> {
  readonly target: EventTarget | { readonly kind: 'deferred' };
  readonly events: readonly InteractionEvent[];
}

export interface InteractionEventsHandle {
  attach(target: EventTarget): void;
  detach(): void;
}

/**
 * WA components emit DOM events; they do not own application pointer, selection,
 * resize or document listeners. This nonvisual boundary keeps those listeners
 * with the Solid/surface lifetime without wrapping content or adding a second
 * keyboard dispatcher. Every target has an explicit surface identity; global
 * targets inherit their logical owner without becoming a keyboard layer.
 * Effective surface lifetime gates delivery, not listener registration:
 * capture/passive/signal/once retain browser semantics (an inactive event can
 * consume once). Deferred attachment reuses the same handlers and detaches the
 * previous target before attaching a replacement. Commands additionally use
 * shared surface authority; observations and gesture cancellation keep their
 * browser lifecycle semantics while an unrelated modal owns commands.
 */
export class InteractionEvents extends RenderedElement<boolean> {
  readonly element: JSX.Element = null;
  readonly handle: InteractionEventsHandle;

  constructor(props: InteractionEventsProps) {
    super('InteractionEvents', props);
    props = this.capture(props);
    const owner = getOwner();
    const active = readObservable(props.observable);
    // Attachment is an imperative browser lifetime. It must take effect before
    // the next event, independently of Solid's deferred signal settlement.
    let attached = false;
    const [attachment, setAttachment] = createSignal(false, { ownedWrite: true });
    const binding = new ElementBinding('InteractionEvents', props, { active: () => {
      attachment();
      return attached && active();
    } });
    const definitions = untrack(() => props.events);
    if (!Array.isArray(definitions)) throw new TypeError('InteractionEvents requires explicit event definitions');
    const entries: readonly (InteractionEvent & { readonly listener: EventListener; readonly reset: () => void })[] = definitions.map(definition => {
      if (!definition || typeof definition.type !== 'string' || typeof definition.handler !== 'function'
        || ['keydown', 'keyup', 'keypress'].includes(definition.type)) {
        throw new TypeError('InteractionEvents requires typed non-keyboard events; declare keyboard actions in hotkeys');
      }
      let onceConsumed = false;
      const listener: EventListener = eventScope((event: Event) => {
        if (onceConsumed || definition.options?.signal?.aborted) return;
        if (definition.options?.once) onceConsumed = true;
        if (!alive || !latest(() => untrack(() => active() && binding.isLive()))) return;
        // A document/window listener must never cancel another control's event
        // merely because this observer lacks command authority.
        if (!LIFECYCLE_EVENTS.has(definition.type) && !allowActivation(binding)) {
          if (event.type === 'pointerup' && event instanceof PointerEvent) {
            // Completion may commit; loss of authority instead follows the
            // explicitly declared cancellation path for this pointer. Invoke
            // these listeners locally so unrelated controls receive no event.
            const cancelled = pointerCancellation(event);
            for (const entry of entries) if (entry.type === 'pointercancel') entry.listener(cancelled);
            if (target instanceof Element && target.hasPointerCapture?.(event.pointerId)) target.releasePointerCapture(event.pointerId);
          }
          return;
        }
        definition.handler(event as never);
      });
      return { ...definition, listener, reset: () => { onceConsumed = false; } };
    });
    let target: EventTarget | undefined;
    let alive = true;
    const detach = () => {
      if (target) for (const entry of entries) target.removeEventListener(entry.type, entry.listener, entry.options);
      target = undefined;
      attached = false;
      setAttachment(false);
      binding.detach();
    };
    const attach = (next: EventTarget) => {
      if (!alive) throw new Error('InteractionEvents has been disposed');
      if (!(isEventTarget(next))) throw new TypeError('InteractionEvents requires an EventTarget');
      if (!(next instanceof Element) && (props.surface.kind !== 'inherit' || props.hotkeys.length > 0)) {
        throw new TypeError('Global interaction events must inherit the application keyboard owner');
      }
      if (target === next) return;
      detach();
      target = next;
      attached = true;
      setAttachment(true);
      for (const entry of entries) {
        entry.reset();
        target.addEventListener(entry.type, entry.listener, entry.options);
      }
      // Deferred attachment can run in onSettled or a browser callback. The
      // constructed control owns its surface cleanup, not the caller's scope.
      runWithOwner(owner, () => {
        if (next instanceof Element) binding.attach(next);
        else binding.attachNonvisual(next);
      });
      binding.isLive();
    };
    this.handle = Object.freeze({ attach, detach });
    const initial = untrack(() => props.target);
    if (isEventTarget(initial)) attach(initial);
    else if (!initial || initial.kind !== 'deferred') throw new TypeError('InteractionEvents requires a target or explicit deferred attachment');
    onCleanup(() => { alive = false; detach(); });
  }

  static View = (props: InteractionEventsProps): JSX.Element => new InteractionEvents(props).element;
}
