import { onSettled } from 'solid-js';

import { placeFloatingBox, type FloatingPlacementOptions } from './overlay';

export interface FloatingPanelOptions extends FloatingPlacementOptions {
  /** Fixed panels escape a scrolling toolbar; ancestors must not transform. */
  readonly strategy?: 'absolute' | 'fixed';
  /** Scroll within the requested side instead of moving over the anchor. */
  readonly constrainToSide?: boolean;
  readonly overflowY?: 'auto' | 'hidden';
  readonly anchor?: (panel: HTMLElement) => HTMLElement | null;
  readonly layoutRoot?: (panel: HTMLElement) => Element | null;
}

/**
 * Toolbar panels stay inside their declared surface and can be covered by a
 * later dialog. WA 3.12 wa-popup always calls showPopover() when anchored and
 * active; its public API has no non-top-layer mode. That would lift this panel
 * above later body-portaled dialogs, irrespective of PORTAL_LAYERS. Keep local
 * geometry (including translated containing blocks and side-constrained scroll)
 * until wa-popup supports an in-place strategy or all layers share top-layer
 * ownership. This helper never owns focus, dismissal or native editing keys.
 */
export function floatingPanel(options: FloatingPanelOptions = {}): (element: HTMLElement) => void {
  let panel: HTMLElement | undefined;
  onSettled(() => {
    const target = panel;
    const anchor = target && (options.anchor?.(target) ?? target.parentElement);
    const ownerWindow = target?.ownerDocument.defaultView;
    if (!target || !anchor || !ownerWindow) return;
    const layoutRoot = options.layoutRoot?.(target) ?? anchor.parentElement ?? anchor;
    const properties = ['position', 'left', 'top', 'max-width', 'max-height', 'overflow-x', 'overflow-y', 'box-sizing', '--ui-floating-available-width', '--ui-floating-available-height'] as const;
    const previous = properties.map((property) => [property, target.style.getPropertyValue(property)] as const);
    // Sibling panels observe the same layout root. Rewriting an unchanged style
    // makes their mutation observers keep triggering each other indefinitely.
    const setStyle = (property: typeof properties[number], value: string) => {
      if (target.style.getPropertyValue(property) !== value) target.style.setProperty(property, value);
    };
    let active = true;
    const update = () => {
      if (!active || !target.isConnected || !anchor.isConnected) return;
      const viewport = ownerWindow.visualViewport;
      const width = viewport?.width ?? ownerWindow.innerWidth;
      const height = viewport?.height ?? ownerWindow.innerHeight;
      const originX = viewport?.offsetLeft ?? 0;
      const originY = viewport?.offsetTop ?? 0;
      const margin = options.margin ?? 16;
      const anchorRect = anchor.getBoundingClientRect();
      const side = options.side ?? 'bottom';
      const offset = options.offset ?? 4;
      const availableHeight = options.constrainToSide
        ? side === 'bottom'
          ? height - (anchorRect.bottom - originY) - offset - margin
          : anchorRect.top - originY - offset - margin
        : height - margin * 2;
      setStyle('position', options.strategy ?? 'absolute');
      setStyle('box-sizing', 'border-box');
      setStyle('max-width', `${Math.max(0, width - margin * 2)}px`);
      setStyle('max-height', `${Math.max(0, availableHeight)}px`);
      setStyle('--ui-floating-available-width', target.style.maxWidth);
      setStyle('--ui-floating-available-height', target.style.maxHeight);
      setStyle('overflow-x', 'auto');
      setStyle('overflow-y', options.overflowY ?? 'auto');
      const box = target.getBoundingClientRect();
      const placement = placeFloatingBox({
        left: anchorRect.left - originX,
        right: anchorRect.right - originX,
        top: anchorRect.top - originY,
        bottom: anchorRect.bottom - originY,
        width: anchorRect.width,
      }, box, { width, height }, { ...options, margin });
      if (options.constrainToSide) {
        placement.top = side === 'bottom'
          ? anchorRect.bottom - originY + offset
          : anchorRect.top - originY - offset - box.height;
      }
      const parent = options.strategy === 'fixed' ? null : target.offsetParent;
      const parentRect = parent instanceof HTMLElement ? parent.getBoundingClientRect() : null;
      // Absolute coordinates are relative to the parent's padding edge. This also
      // handles the translated toolbar without moving the panel into another tree.
      const parentX = parentRect && parent instanceof HTMLElement
        ? parentRect.left + parent.clientLeft - parent.scrollLeft : options.strategy === 'fixed' ? 0 : -ownerWindow.scrollX;
      const parentY = parentRect && parent instanceof HTMLElement
        ? parentRect.top + parent.clientTop - parent.scrollTop : options.strategy === 'fixed' ? 0 : -ownerWindow.scrollY;
      setStyle('left', `${placement.left + originX - parentX}px`);
      setStyle('top', `${placement.top + originY - parentY}px`);
    };
    const resizeObserver = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(update);
    resizeObserver?.observe(target);
    for (let ancestor: Element | null = anchor; ancestor; ancestor = ancestor.parentElement) {
      resizeObserver?.observe(ancestor);
      if (ancestor === layoutRoot) break;
    }
    const mutationObserver = typeof MutationObserver === 'undefined' ? undefined : new MutationObserver((records) => {
      if (records.some((record) => !target.contains(record.target))) update();
    });
    mutationObserver?.observe(layoutRoot, { childList: true, subtree: true, characterData: true, attributes: true });
    ownerWindow.addEventListener('resize', update);
    ownerWindow.addEventListener('scroll', update, true);
    ownerWindow.visualViewport?.addEventListener('resize', update);
    ownerWindow.visualViewport?.addEventListener('scroll', update);
    update();
    return () => {
      active = false;
      resizeObserver?.disconnect();
      mutationObserver?.disconnect();
      ownerWindow.removeEventListener('resize', update);
      ownerWindow.removeEventListener('scroll', update, true);
      ownerWindow.visualViewport?.removeEventListener('resize', update);
      ownerWindow.visualViewport?.removeEventListener('scroll', update);
      for (const [property, value] of previous) {
        if (value) target.style.setProperty(property, value);
        else target.style.removeProperty(property);
      }
      panel = undefined;
    };
  });
  return (element) => { panel = element; };
}
