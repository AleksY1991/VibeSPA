/** @jsxImportSource @solidjs/web */
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import type { SplitPanelControlProps, SplitPanelState } from '../contracts/split-panel';
import { ElementBinding } from '../infrastructure/element';
import { surfaceCommand } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import { SPLIT_KEYS } from './split-panel-interaction';
import './split-panel.css';

export interface SplitPanelProps extends Omit<SplitPanelControlProps, 'state' | 'onElement' | 'onNativeElement'>, ElementConstruction<SplitPanelState> {
  
}

function renderSplitPanel(props: SplitPanelProps) {
  const binding = new ElementBinding('SplitPanel', props, { nativeKeys: SPLIT_KEYS });
  const Implementation = requireControlImplementation('SplitPanel');
  const resize = surfaceCommand(binding, (size: number) => props.onEndSizeChange(size));
  // The control retains the end pane to preserve unsaved editor state. Its
  // logical scope follows the same collapsed value as the rendered hidden pane;
  // the containing host and the start pane remain live throughout.
  const End = () => binding.provide(() => props.end, { active: () => !binding.value().collapsed });
  return binding.provide(() => <Implementation {...props} end={<End />} state={binding.value()}
    onElement={binding.attach} onNativeElement={binding.attachNative} onEndSizeChange={resize} />);
}

export class SplitPanel extends RenderedElement<SplitPanelState> {
  readonly element: JSX.Element;
  constructor(props: SplitPanelProps) {
    super('SplitPanel', props);
    this.element = renderSplitPanel(this.capture(props));
  }
  static View = (props: SplitPanelProps): JSX.Element => new SplitPanel(props).element;
}
