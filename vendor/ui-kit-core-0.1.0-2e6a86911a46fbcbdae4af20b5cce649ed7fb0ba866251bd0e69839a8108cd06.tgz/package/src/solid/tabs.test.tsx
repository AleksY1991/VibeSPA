/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render, type JSX } from '@solidjs/web';
import { createSignal, flush, onCleanup, OBSERVE } from 'solid-js';
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import { attachDispatcher } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ImplementationContext } from '../infrastructure/implementation-context';
import type { TabsState } from '../contracts/tabs';
import type { FocusHandle } from '../contracts/controls';
import { importTabGroupElement, type TabElement, type TabGroupElement } from '../vendor/web-awesome/elements';
import { WebAwesomeTabs, WebAwesomeTabPanel } from '../vendor/web-awesome/tabs.adapter';
import { Tabs, TabPanel } from './tabs';

const items = [
  { value: 'one', label: 'One', id: 'tab-one', panelId: 'panel-one' },
  { value: 'two', label: 'Two', id: 'tab-two', panelId: 'panel-two' },
  { value: 'three', label: 'Three', id: 'tab-three', panelId: 'panel-three', disabled: true },
] as const;
const implementation = { Tabs: WebAwesomeTabs, TabPanel: WebAwesomeTabPanel };
const disposers: (() => void)[] = [];
const settle = async () => {
  for (let i = 0; i < 20; i++) { flush(); await Promise.resolve(); }
  await new Promise(resolve => setTimeout(resolve, 0));
  for (let i = 0; i < 10; i++) { flush(); await Promise.resolve(); }
};
beforeAll(async () => { await importTabGroupElement(); });
afterEach(() => {
  disposers.splice(0).reverse().forEach(dispose => dispose());
  vi.restoreAllMocks();
  document.body.replaceChildren();
});
async function mount(view: () => JSX.Element) {
  const container = document.createElement('div'); document.body.append(container);
  const View = view;
  const dispose = render(() => <ImplementationContext value={implementation}><View /></ImplementationContext>, container); disposers.push(dispose);
  await settle(); return { container, dispose };
}
// Happy DOM omits event propagation through assigned slots. Route events to the
// real vendor listener, preserving the light-DOM target seen by browser events.
const vendorEvent = (tab: HTMLElement, event: Event, modelSlotPath = false) => {
  Object.defineProperty(event, 'target', { value: tab, configurable: true });
  if (modelSlotPath) {
    const composedPath = event.composedPath.bind(event);
    Object.defineProperty(event, 'composedPath', { value: () => [tab, ...composedPath()] });
  }
  tab.closest('wa-tab-group')!.shadowRoot!.querySelector('[part="base tab-group"]')!.dispatchEvent(event);
};
const activate = (tab: HTMLElement) => vendorEvent(tab, new MouseEvent('click', { bubbles: true, composed: true }));

describe('shared tabs with installed Web Awesome elements', () => {
  it('denies tab navigation when another modal owns focus', async () => {
    const command = vi.fn();
    disposers.push(attachDispatcher({ window, document, registry: surfaceRegistry,
      commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) }));
    const { container } = await mount(() => {
      const state = constructItem('tabs.focusAuthority', item => item.constant('tabs', { value: 'one', tabs: items }));
      return <ImplementationContext value={implementation}><Tabs.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
         label="Sections" size="compact" onValueChange={command} /></ImplementationContext>;
    });
    const modal = document.createElement('div'); modal.tabIndex = -1; document.body.append(modal);
    const release = surfaceRegistry.mountElement({ name: 'tabs.focusBlocker', element: modal, transparent: false,
      layer: true, modal: true, keys: {} });
    disposers.push(() => { release(); modal.remove(); });
    modal.focus();
    const first = container.querySelector<HTMLElement>('#tab-one')!;
    const event = new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, composed: true, cancelable: true });
    vendorEvent(first, event, true);
    await settle();
    expect(event.defaultPrevented).toBe(true); expect(command).not.toHaveBeenCalled();
    expect(document.activeElement).toBe(modal);
  });

  it.each(['replace', 'clear'] as const)('denies vendor cursor restoration after %s when a new modal owns focus', async change => {
    const [state, setState] = createSignal<TabsState>({ value: 'two', tabs: items });
    const { container } = await mount(() => {
      const model = constructItem('tabs.restorationAuthority', item => item.observe('tabs', state));
      return <ImplementationContext value={implementation}><Tabs.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]} label="Sections" size="compact" onValueChange={() => {}} /></ImplementationContext>;
    });
    const previous = container.querySelector<HTMLElement>('#tab-two')!; previous.focus();
    const modal = document.createElement('div'); document.body.append(modal);
    const modalInput = document.createElement('input'); modal.append(modalInput); modalInput.focus();
    const release = surfaceRegistry.mountElement({ name: 'tabs.restorationBlocker', element: modal, transparent: false,
      layer: true, modal: true, keys: {} });
    disposers.push(() => { release(); modal.remove(); });
    setState({ value: change === 'clear' ? null : 'two', tabs: items.map(tab => ({ ...tab })) });
    await settle();
    if (change === 'clear') expect(container.querySelector('#tab-two')).not.toBe(previous);
    else expect(container.querySelector('#tab-two')).toBe(previous);
    expect(document.activeElement).toBe(modalInput);
    release(); await settle();
    expect(document.activeElement).toBe(modalInput);
  });

  it('supports vertical orientation and Up/Down navigation', async () => {
    const [orientation, setOrientation] = createSignal<'horizontal' | 'vertical'>('vertical');
    const [selected, setSelected] = createSignal('one');
    const { container } = await mount(() => {
      const state = constructItem('tabs.vertical', item => item.observe('tabs', () => ({ value: selected(), tabs: items })));
      return <ImplementationContext value={implementation}><Tabs.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]}
         label="Sections" size="compact"
        orientation={orientation()} onValueChange={setSelected} /></ImplementationContext>;
    });
    const first = container.querySelector<HTMLElement>('#tab-one')!;
    const second = container.querySelector<HTMLElement>('#tab-two')!;
    const tablist = container.querySelector('wa-tab-group')?.shadowRoot?.querySelector('[role="tablist"]')
      ?? container.querySelector('[role="tablist"]')!;
    expect(tablist.getAttribute('aria-orientation')).toBe('vertical');
    const press = (tab: HTMLElement, key: string) => {
      const event = new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true });
      vendorEvent(tab, event);
    };
    first.focus(); press(first, 'ArrowDown'); await settle();
    expect(selected()).toBe('two'); expect(document.activeElement).toBe(second);
    press(second, 'ArrowDown'); await settle();
    expect(selected()).toBe('one'); expect(document.activeElement).toBe(first);
    press(first, 'ArrowUp'); await settle(); expect(selected()).toBe('two');
    setOrientation('horizontal'); await settle();
    expect(tablist.getAttribute('aria-orientation')).toBe('horizontal');
    expect(container.querySelector('#tab-two')).toBe(second);
    press(second, 'ArrowLeft'); await settle(); expect(selected()).toBe('one');
  });

  it('keeps the controlled selection on a strip initially mounted disabled without emitting a command', async () => {
    const command = vi.fn();
    const options = items.map(tab => ({ ...tab, disabled: false }));
    const { container } = await mount(() => <WebAwesomeTabs state={{ value: 'three', tabs: options, disabled: true }}
      label="Disabled sections" size="compact" onValueChange={command} />);
    expect(container.querySelector('wa-tab-group')?.getAttribute('data-ui-ready')).toBe('true');
    expect([...container.querySelectorAll('[aria-selected="true"]')].map(tab => tab.id)).toEqual(['tab-three']);
    expect(container.querySelectorAll('wa-tab[disabled][aria-disabled="true"]')).toHaveLength(3);
    expect([...container.querySelectorAll<TabElement>('wa-tab')].every(tab => tab.disabled)).toBe(true);
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(0);
    activate(container.querySelector<HTMLElement>('#tab-one')!); await settle();
    expect(container.querySelector('[aria-selected="true"]')?.id).toBe('tab-three');
    expect(command).not.toHaveBeenCalled();
  });

  it('updates and retains an externally selected disabled strip, then restores enabled navigation', async () => {
    const options = items.map(tab => ({ ...tab, disabled: false }));
    const [state, setState] = createSignal<TabsState>({ value: 'one', tabs: options });
    const command = vi.fn((value: string) => setState(previous => ({ ...previous, value })));
    const { container } = await mount(() => <WebAwesomeTabs state={state()} label="Disabled sections"
      size="compact" onValueChange={command} />);
    setState({ value: 'one', tabs: options, disabled: true }); await settle();
    expect(container.querySelector('[aria-selected="true"]')?.id).toBe('tab-one');
    setState({ value: 'three', tabs: options, disabled: true }); await settle();
    expect([...container.querySelectorAll('[aria-selected="true"]')].map(tab => tab.id)).toEqual(['tab-three']);
    const previousThird = container.querySelector('#tab-three');
    setState(previous => ({ ...previous, tabs: options.map(tab => ({ ...tab })) })); await settle();
    expect(container.querySelector('#tab-three')).toBe(previousThird);
    expect(container.querySelector('[aria-selected="true"]')?.id).toBe('tab-three');
    expect(container.querySelectorAll('wa-tab[disabled][aria-disabled="true"]')).toHaveLength(3);
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(0);
    expect(command).not.toHaveBeenCalled();
    setState(previous => ({ ...previous, disabled: false })); await settle();
    const third = container.querySelector<HTMLElement>('#tab-three')!; third.focus();
    vendorEvent(third, new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true, composed: true, cancelable: true }));
    await settle();
    expect(state().value).toBe('two'); expect(document.activeElement?.id).toBe('tab-two');
    expect(command.mock.calls.map(call => call[0])).toEqual(['two']);
  });

  it('keeps disabled DOM semantics through external selection and clear before enabling keyboard entry', async () => {
    const options = items.map(tab => ({ ...tab, disabled: false }));
    const [state, setState] = createSignal<TabsState>({ value: 'one', tabs: options, disabled: true });
    const command = vi.fn(); const enabledDuringShow: string[] = [];
    let handle: FocusHandle | undefined;
    const { container } = await mount(() => <WebAwesomeTabs state={state()} label="Disabled sections"
      size="compact" onValueChange={command} onHandle={next => { handle = next; }}
      onElement={element => element.addEventListener('wa-tab-show', () => {
        for (const tab of element.querySelectorAll<HTMLElement>('wa-tab'))
          if (!tab.hasAttribute('disabled') || tab.getAttribute('aria-disabled') !== 'true') enabledDuringShow.push(tab.id);
      })} />);
    setState(previous => ({ ...previous, value: 'three' })); await settle();
    expect(enabledDuringShow).toEqual([]);
    const selectedGroup = container.querySelector('wa-tab-group');
    setState(previous => ({ ...previous, value: null })); await settle();
    expect(container.querySelector('wa-tab-group')).not.toBe(selectedGroup);
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(0);
    setState(previous => ({ ...previous, value: 'missing' })); await settle();
    setState(previous => ({ ...previous, disabled: false })); await settle();
    handle!.focus(); expect(document.activeElement?.id).toBe('tab-one');
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(command).not.toHaveBeenCalled();
  });

  it('restores a temporarily enabled property when public activation fails during readiness', async () => {
    const options = items.map(tab => ({ ...tab, disabled: false }));
    const command = vi.fn(); let targetAtFailure: TabElement | undefined;
    const { container } = await mount(() => <WebAwesomeTabs state={{ value: 'three', tabs: options, disabled: true }}
      label="Disabled recovery" size="compact" onValueChange={command} onElement={element => {
        if (element.localName !== 'wa-tab-group') return;
        const group = element as TabGroupElement;
        const activateTab = group.updateActiveTab.bind(group);
        vi.spyOn(group, 'updateActiveTab').mockImplementation(() => {
          const tab = group.querySelector<TabElement>('#tab-three');
          if (tab?.hasAttribute('disabled') && !tab.disabled) {
            targetAtFailure = tab;
            throw new Error('Activation failed');
          }
          activateTab();
        });
      }} />);
    expect(container.querySelector('wa-tab-group')!.getAttribute('data-ui-error')).toBe('update-failed');
    expect(targetAtFailure?.disabled).toBe(true);
    expect(container.querySelector('[aria-selected="true"]')?.id).toBe('tab-three');
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(0);
    expect(command).not.toHaveBeenCalled();
  });

  it('reconciles a deferred command before applying its eventual observable write', async () => {
    const [state, setState] = createSignal<TabsState>({ value: 'one', tabs: items });
    let pending: string | undefined;
    const command = vi.fn((value: string) => { pending = value; });
    const { container } = await mount(() => {
      const model = constructItem('tabs.deferred', item => item.observe('state', state));
      return <ImplementationContext value={implementation}><Tabs.View observable={model}
        surface={{ kind: 'inherit' }} hotkeys={[]} label="Deferred sections" size="compact"
        onValueChange={command} /></ImplementationContext>;
    });
    const second = container.querySelector<HTMLElement>('#tab-two')!;
    second.focus(); activate(second); await settle();
    expect(pending).toBe('two'); expect(state().value).toBe('one');
    expect(container.querySelector('[aria-selected="true"]')?.id).toBe('tab-one');
    expect(document.activeElement).toBe(second);
    setState(previous => ({ ...previous, value: pending!, tabs: items.map(tab => ({ ...tab })) })); await settle();
    expect(container.querySelector('[aria-selected="true"]')?.id).toBe('tab-two');
    expect(document.activeElement).toBe(container.querySelector('#tab-two'));
    expect(command.mock.calls.map(call => call[0])).toEqual(['two']);
  });

  it('keeps empty, removed and disabled selections keyboard reachable without inventing writes', async () => {
    const [state, setState] = createSignal<TabsState>({ value: null, tabs: items });
    const command = vi.fn((value: string) => setState(previous => ({ ...previous, value })));
    let handle: FocusHandle | undefined;
    const { container } = await mount(() => {
      const model = constructItem('tabs.empty', item => item.observe('state', state));
      const View = () => <Tabs.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]} label="Sections" size="compact" onValueChange={command} onHandle={next => { handle = next; }} />;
      return <ImplementationContext value={implementation}><View /></ImplementationContext>;
    });
    expect(command).not.toHaveBeenCalled();
    expect(container.querySelector('wa-tab-group')).not.toBeNull();
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelector('[tabindex="0"]')?.id).toBe('tab-one');
    const initialGroup = container.querySelector('wa-tab-group');
    handle!.focus(); expect(document.activeElement?.id).toBe('tab-one');
    const chooseFirst = () => {
      const first = container.querySelector<HTMLElement>('#tab-one')!;
      activate(first);
    };
    chooseFirst(); await settle();
    expect(state().value).toBe('one');
    expect(container.querySelector('wa-tab-group')).not.toBeNull();
    expect(document.activeElement?.id).toBe('tab-one');
    setState({ value: null, tabs: items }); await settle();
    expect(container.querySelector('wa-tab-group')).not.toBeNull();
    expect(container.querySelector('wa-tab-group')).not.toBe(initialGroup);
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(document.activeElement?.id).toBe('tab-one');
    handle!.focus(); expect(document.activeElement?.id).toBe('tab-one');
    chooseFirst(); await settle();
    expect(command.mock.calls.map(call => call[0])).toEqual(['one', 'one']);
    setState({ value: 'missing', tabs: items.slice(1) }); await settle();
    handle!.focus(); expect(document.activeElement?.id).toBe('tab-two');
    expect(container.querySelector('[tabindex="0"]')?.id).toBe('tab-two');
    setState({ value: 'three', tabs: items.slice(1) }); await settle();
    expect(container.querySelector('[tabindex="0"]')?.id).toBe('tab-two');
    setState({ value: null, tabs: items, disabled: true }); await settle();
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(0);
  });

  it('preserves RTL arrow direction and Home/End', async () => {
    const [selected, setSelected] = createSignal<string | null>(null);
    const { container } = await mount(() => {
      const model = constructItem('tabs.rtl', item => item.observe('state', () => ({ value: selected(), tabs: items })));
      return <Tabs.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Sections" size="compact" onValueChange={setSelected} />;
    });
    container.querySelector<HTMLElement>('wa-tab-group')!.dir = 'rtl';
    const press = (id: string, key: string) => {
      const tab = container.querySelector<HTMLElement>(id)!;
      tab.focus();
      vendorEvent(tab, new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true }));
    };
    press('#tab-one', 'ArrowLeft'); await settle();
    expect(selected()).toBe('two'); expect(document.activeElement?.id).toBe('tab-two');
    press('#tab-two', 'ArrowLeft'); await settle();
    expect(selected()).toBe('one');
    press('#tab-one', 'End'); await settle(); expect(selected()).toBe('two');
    press('#tab-two', 'Home'); await settle(); expect(selected()).toBe('one');
  });

  it('starts visible WA groups unselected even when option names resemble the empty-selection token', async () => {
    // Happy DOM does not report intersections. Deliver the browser's first-visible
    // callback so this exercises WA's actual eager-selection initialization.
    const Observer = globalThis.IntersectionObserver;
    class VisibleObserver extends Observer {
      readonly callback: IntersectionObserverCallback;
      constructor(callback: IntersectionObserverCallback, options?: IntersectionObserverInit) {
        super(callback, options); this.callback = callback;
      }
      observe(target: Element) {
        queueMicrotask(() => {
          const rect = target.getBoundingClientRect();
          this.callback([{ target, time: 0, rootBounds: null, boundingClientRect: rect,
            intersectionRect: rect, intersectionRatio: 1, isIntersecting: true }], this);
        });
      }
    }
    vi.stubGlobal('IntersectionObserver', VisibleObserver);
    disposers.push(() => vi.unstubAllGlobals());
    const options = [
      { ...items[0], value: '__ui_empty__' },
      { ...items[1], value: '__ui_empty___' },
    ];
    const [state, setState] = createSignal<TabsState>({ value: null, tabs: options });
    const command = vi.fn();
    const { container } = await mount(() => <WebAwesomeTabs state={state()} label="Sections" size="compact"
      onValueChange={command} />);
    const group = () => container.querySelector<TabGroupElement>('wa-tab-group')!;
    expect(group().active.length).toBeGreaterThan(0);
    expect(options.some(option => option.value === group().active)).toBe(false);
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(1);
    setState({ value: null, tabs: [...options, { ...items[2], value: group().active, disabled: false }] });
    await settle();
    expect(state().tabs.some(option => option.value === group().active)).toBe(false);
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(command).not.toHaveBeenCalled();
  });

  it('rebuilds empty WA headers after every rejected selection, retains the keyboard cursor and leaves editors mounted', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture(); disposers.push(diagnostics.stop);
    const command = vi.fn(); const released = vi.fn(); let mounts = 0;
    const Content = () => { mounts++; onCleanup(released); return <input aria-label="Retained empty draft" value="Unsaved" />; };
    const { container } = await mount(() => {
      const model = constructItem('tabs.emptyRejected', item => ({
        state: item.constant('state', { value: null, tabs: items }),
        active: item.constant('active', false),
      }));
      return <ImplementationContext value={implementation}>
        <Tabs.View observable={model.state} surface={{ kind: 'inherit' }} hotkeys={[]}
          label="Sections" size="compact" onValueChange={command} />
        <TabPanel.View observable={model.active} surface={{ kind: 'inherit' }} hotkeys={[]}
          id="panel-one" tabId="tab-one" value="one"><Content /></TabPanel.View>
        <input aria-label="Other control" />
      </ImplementationContext>;
    });
    const draft = container.querySelector<HTMLInputElement>('[aria-label="Retained empty draft"]')!;
    draft.value = 'Edited draft';
    for (let attempt = 0; attempt < 2; attempt++) {
      const previous = container.querySelector('wa-tab-group');
      const second = container.querySelector<HTMLElement>('#tab-two')!;
      second.focus(); activate(second); await settle();
      expect(container.querySelector('wa-tab-group')).not.toBe(previous);
      expect(container.querySelector('button[role="tab"]')).toBeNull();
      expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
      expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(1);
      expect(document.activeElement?.id).toBe('tab-two');
      expect(container.querySelector('#panel-one')!.hasAttribute('hidden')).toBe(true);
    }
    expect(command.mock.calls.map(call => call[0])).toEqual(['two', 'two']);
    expect(container.querySelector('[aria-label="Retained empty draft"]')).toBe(draft);
    expect(draft.value).toBe('Edited draft'); expect(mounts).toBe(1); expect(released).not.toHaveBeenCalled();
    const other = container.querySelector<HTMLInputElement>('[aria-label="Other control"]')!;
    command.mockImplementationOnce(() => other.focus());
    activate(container.querySelector<HTMLElement>('#tab-two')!); await settle();
    expect(document.activeElement).toBe(other);
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });

  it('keeps WA navigation from an empty selection and skips dynamically disabled tabs in RTL', async () => {
    const [state, setState] = createSignal<TabsState>({ value: null, tabs: items });
    const command = vi.fn((value: string) => setState(previous => ({ ...previous, value })));
    const { container } = await mount(() => <WebAwesomeTabs state={state()} label="Sections" size="compact"
      onValueChange={command} />);
    const press = (id: string, key: string) => {
      const tab = container.querySelector<HTMLElement>(id)!;
      tab.focus();
      vendorEvent(tab, new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true }));
    };
    container.querySelector<HTMLElement>('wa-tab-group')!.dir = 'rtl'; await settle();
    press('#tab-one', 'ArrowLeft'); await settle();
    expect(state().value).toBe('two'); expect(document.activeElement?.id).toBe('tab-two');
    setState({ value: 'two', tabs: items.map(tab => ({ ...tab, disabled: tab.value === 'two' })) }); await settle();
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelector('[tabindex="0"]')?.id).toBe('tab-one');
    press('#tab-one', 'End'); await settle();
    expect(state().value).toBe('three'); expect(document.activeElement?.id).toBe('tab-three');
    press('#tab-three', 'Home'); await settle(); expect(state().value).toBe('one');
    setState({ value: null, tabs: items.map(tab => ({ ...tab, disabled: true })) }); await settle();
    expect(container.querySelector('wa-tab-group')).not.toBeNull();
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(0);
    expect(command.mock.calls.map(call => call[0])).toEqual(['two', 'three', 'one']);
  });

  it('retains focus through same-value option replacement and settles rapid empty/valid changes without writes', async () => {
    const [state, setState] = createSignal<TabsState>({ value: 'two', tabs: items });
    const command = vi.fn();
    const { container } = await mount(() => <WebAwesomeTabs state={state()} label="Sections" size="compact"
      onValueChange={command} />);
    const oldTab = container.querySelector<HTMLElement>('#tab-two')!;
    oldTab.focus();
    setState({ value: 'two', tabs: items.map(tab => ({ ...tab, label: `${tab.label} updated` })) }); await settle();
    const replacement = container.querySelector<HTMLElement>('#tab-two')!;
    expect(replacement).toBe(oldTab); expect(document.activeElement).toBe(replacement);
    expect(replacement.textContent).toContain('updated');
    setState({ value: null, tabs: items }); flush();
    setState({ value: 'one', tabs: items.map(tab => ({ ...tab })) }); flush();
    setState({ value: 'missing', tabs: items.slice(1) }); await settle();
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelector('[tabindex="0"]')?.id).toBe('tab-two');
    expect(document.activeElement?.id).toBe('tab-two');
    expect(command).not.toHaveBeenCalled();
  });

  it('clears a transient selection before readiness and does not steal focus while the replacement settles', async () => {
    const [state, setState] = createSignal<TabsState>({ value: null, tabs: items });
    const command = vi.fn();
    let release!: (value: boolean) => void;
    const pending = new Promise<boolean>(resolve => { release = resolve; });
    let firstGroup: HTMLElement | undefined;
    const { container } = await mount(() => <>
      <WebAwesomeTabs state={state()} label="Sections" size="compact" onValueChange={command}
        onElement={element => {
          if (firstGroup) return;
          firstGroup = element;
          vi.spyOn(element as TabGroupElement, 'updateComplete', 'get').mockReturnValue(pending);
        }} />
      <input aria-label="Other control during readiness" />
    </>);
    expect(firstGroup!.getAttribute('data-ui-ready')).toBe('false');
    setState({ value: 'two', tabs: items }); await settle();
    setState({ value: null, tabs: items }); await settle();
    const other = container.querySelector<HTMLInputElement>('input')!; other.focus();
    release(true); await settle();
    expect(container.querySelector('wa-tab-group')).not.toBe(firstGroup);
    expect(document.activeElement).toBe(other);
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(command).not.toHaveBeenCalled();
    activate(container.querySelector<HTMLElement>('#tab-two')!); await settle();
    activate(container.querySelector<HTMLElement>('#tab-two')!); await settle();
    expect(command.mock.calls.map(call => call[0])).toEqual(['two', 'two']);
  });

  it('preserves the vendor keyboard destination when accepted commands replace every option object', async () => {
    const [value, setValue] = createSignal<string | null>('two');
    const { container } = await mount(() => <WebAwesomeTabs
      state={{ value: value(), tabs: items.map(tab => ({ ...tab, disabled: tab.value === 'one' })) }}
      label="Sections" size="compact" onValueChange={setValue} />);
    const second = container.querySelector<HTMLElement>('#tab-two')!;
    second.focus();
    vendorEvent(second, new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, composed: true, cancelable: true }));
    await settle();
    expect(value()).toBe('three');
    expect(container.querySelector('#tab-two')).toBe(second);
    expect(document.activeElement).toBe(container.querySelector('#tab-three'));
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(1);
  });

  it('forgets the cursor after a rejected valid selection so a later external clear respects intentional blur', async () => {
    const options = items.map(tab => ({ ...tab, disabled: false }));
    const [state, setState] = createSignal<TabsState>({ value: 'three', tabs: options });
    const command = vi.fn();
    const { container } = await mount(() => <WebAwesomeTabs state={state()} label="Sections" size="compact"
      onValueChange={command} />);
    const second = container.querySelector<HTMLElement>('#tab-two')!;
    second.focus(); activate(second); await settle();
    expect(command.mock.calls.map(call => call[0])).toEqual(['two']);
    expect(container.querySelector<TabGroupElement>('wa-tab-group')!.active).toBe('three');
    expect(document.activeElement).toBe(second);
    second.blur(); await settle(); expect(document.activeElement).toBe(document.body);
    setState({ value: null, tabs: options }); await settle();
    expect(container.querySelectorAll('[aria-selected="true"]')).toHaveLength(0);
    expect(container.querySelector('[tabindex="0"]')?.id).toBe('tab-one');
    expect(document.activeElement).toBe(document.body);
  });

  it('enables vendor overflow arrows for scrolling strips and suppresses them when wrapping', async () => {
    // Happy DOM has no form-associated internals; the arrow buttons need the
    // platform contract to render even though this test never submits a form.
    const buttonPrototype = customElements.get('wa-button')!.prototype;
    Object.defineProperty(buttonPrototype, 'attachInternals', { configurable: true, value: () => ({
      states: new Set(), validity: { valid: true }, validationMessage: '', willValidate: false,
      labels: [], form: null, setFormValue() {}, setValidity() {}, checkValidity: () => true,
    }) });
    disposers.push(() => { Reflect.deleteProperty(buttonPrototype, 'attachInternals'); });
    const [wrap, setWrap] = createSignal(false);
    const { container } = await mount(() => {
      const state = constructItem('tabs.overflow', item => item.constant('state', { value: 'one', tabs: items }));
      return <ImplementationContext value={implementation}><Tabs.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} label="Sections" size="compact" wrap={wrap()} onValueChange={() => {}} /></ImplementationContext>;
    });
    const group = container.querySelector<TabGroupElement>('wa-tab-group')!;
    expect(group.withoutScrollControls).toBe(false);
    Object.defineProperties(group.nav, { scrollWidth: { configurable: true, value: 800 }, clientWidth: { configurable: true, value: 300 } });
    group.updateScrollControls(); await settle();
    const end = group.shadowRoot!.querySelector<HTMLElement>('[part~="scroll-button-end"]')!;
    expect(end).not.toBeNull();
    const scroll = vi.spyOn(group.nav, 'scrollBy').mockImplementation(() => {});
    end.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true, cancelable: true }));
    expect(scroll).toHaveBeenCalledWith({ left: 300, behavior: 'instant' });
    setWrap(true); await settle();
    expect(group.withoutScrollControls).toBe(true);
    expect(group.shadowRoot!.querySelector('[part~="scroll-button-end"]')).toBeNull();
  });

  it('uses vendor navigation and explicitly relates independently placed panels without remounting them', async () => {
    const diagnostics = OBSERVE!.diagnostics.capture(); disposers.push(diagnostics.stop);
    const [selected, setSelected] = createSignal('one');
    const released = vi.fn(); let mounts = 0;
    const Content = () => { mounts++; onCleanup(released); return <input aria-label="Retained draft" value="Unsaved text" />; };
    const { container } = await mount(() => {
      const state = constructItem('tabs.retained', item => ({
        tabs: item.observe('tabs', () => ({ value: selected(), tabs: items })),
        one: item.observe('one', () => selected() === 'one'),
        two: item.observe('two', () => selected() === 'two'),
      }));
      return <ImplementationContext value={implementation}>
        <header><Tabs.View observable={state.tabs} surface={{ kind: 'own', name: 'tabs.retained', transparent: true }}
          hotkeys={[]} label="Sections" size="compact" onValueChange={setSelected} /></header>
        <main><TabPanel.View observable={state.one} surface={{ kind: 'inherit' }} hotkeys={[]}
          id="panel-one" tabId="tab-one" value="one"><Content /></TabPanel.View>
        <TabPanel.View observable={state.two} surface={{ kind: 'inherit' }} hotkeys={[]}
          id="panel-two" tabId="tab-two" value="two">Second panel</TabPanel.View></main>
      </ImplementationContext>;
    });
    const group = container.querySelector<TabGroupElement>('wa-tab-group')!;
    const first = container.querySelector<TabElement>('#tab-one')!;
    const second = container.querySelector<TabElement>('#tab-two')!;
    const original = container.querySelector('input');
    expect(group.dataset.uiReady).toBe('true');
    expect(group.shadowRoot!.querySelector('[role="tablist"]')!.getAttribute('aria-label')).toBe('Sections');
    expect(first.getAttribute('aria-controls')).toBe('panel-one');
    expect(container.querySelector('#panel-one')!.getAttribute('aria-labelledby')).toBe(first.id);
    expect(container.querySelector('#panel-two')!.hasAttribute('hidden')).toBe(true);
    activate(second); await settle();
    expect(selected()).toBe('two');
    expect(group.active).toBe('two');
    expect(second.active).toBe(true);
    expect(container.querySelector('#panel-one')!.hasAttribute('hidden')).toBe(true);
    expect(container.querySelector('#panel-two')!.hasAttribute('hidden')).toBe(false);
    expect(container.querySelector('input')).toBe(original);
    expect(mounts).toBe(1); expect(released).not.toHaveBeenCalled();
    expect(diagnostics.events.filter(event => event.code === 'STRICT_READ_UNTRACKED')).toEqual([]);
  });

  it('uses vendor arrow navigation, skips disabled tabs and retains focus with reactive selection', async () => {
    const [selected, setSelected] = createSignal('one');
    const { container } = await mount(() => {
      const state = constructItem('tabs.keyboard', item => item.observe('tabs', () => ({ value: selected(), tabs: items })));
      return <ImplementationContext value={implementation}><Tabs.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} label="Sections" size="compact" onValueChange={setSelected} /></ImplementationContext>;
    });
    const first = container.querySelector<TabElement>('#tab-one')!;
    const second = container.querySelector<TabElement>('#tab-two')!;
    first.focus();
    const press = (element: HTMLElement, key: string) => vendorEvent(element, new KeyboardEvent('keydown', { key, bubbles: true, composed: true, cancelable: true }));
    press(first, 'ArrowRight'); await settle();
    expect(selected()).toBe('two'); expect(document.activeElement).toBe(second);
    press(second, 'ArrowRight'); await settle();
    expect(selected()).toBe('one'); expect(document.activeElement).toBe(first);
    press(first, 'End'); await settle();
    expect(selected()).toBe('two');
    expect(container.querySelectorAll('[tabindex="0"]')).toHaveLength(1);
  });

  it('keeps vendor keyboard and controlled-selection scrolling immediate and restores the DOM method on disposal', async () => {
    // Mock call inference keeps only scrollTo's numeric overload. Record the
    // complete public input union to verify its options overload without a cast.
    const requests: Array<ScrollToOptions | number | undefined> = [];
    const nativeScroll = vi.spyOn(HTMLElement.prototype, 'scrollTo')
      .mockImplementation((optionsOrLeft?: ScrollToOptions | number) => { requests.push(optionsOrLeft); });
    const [selected, setSelected] = createSignal('one');
    const { container, dispose } = await mount(() => {
      const model = constructItem('tabs.motion', item => item.observe('state', () => ({ value: selected(), tabs: items })));
      return <ImplementationContext value={implementation}><Tabs.View observable={model} surface={{ kind: 'inherit' }} hotkeys={[]} label="Sections" size="compact" onValueChange={setSelected} /></ImplementationContext>;
    });
    const group = container.querySelector<TabGroupElement>('wa-tab-group')!;
    const nav = group.nav;
    const first = container.querySelector<TabElement>('#tab-one')!;
    const second = container.querySelector<TabElement>('#tab-two')!;
    Object.defineProperty(nav, 'offsetWidth', { configurable: true, value: 100 });
    Object.defineProperty(second, 'clientWidth', { configurable: true, value: 100 });
    vi.spyOn(second, 'getBoundingClientRect').mockReturnValue({ left: 200 } as DOMRect);
    first.focus();
    vendorEvent(first, new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, composed: true, cancelable: true }));
    await settle();
    expect(selected()).toBe('two');
    expect(nativeScroll).toHaveBeenCalledWith({ left: 200, behavior: 'instant' });
    setSelected('one'); await settle(); nativeScroll.mockClear(); requests.length = 0;
    setSelected('two'); await settle();
    expect(nativeScroll).toHaveBeenCalledWith({ left: 200, behavior: 'instant' });
    expect(requests.every(options => typeof options !== 'object' || options.behavior === 'instant')).toBe(true);
    dispose(); await settle();
    expect(Object.hasOwn(nav, 'scrollTo')).toBe(false);
  });

  it('keeps rejected selections controlled, handles dynamic options and releases handles and surfaces', async () => {
    const [state, setState] = createSignal<TabsState>({ value: 'one', tabs: items });
    const command = vi.fn(); let handle: FocusHandle | undefined;
    const { container, dispose } = await mount(() => {
      const model = constructItem('tabs.dynamic', item => item.observe('state', state));
      return <ImplementationContext value={implementation}><Tabs.View observable={model}
        surface={{ kind: 'own', name: 'tabs.dynamic', transparent: true }} hotkeys={[]}
        label="Sections" size="compact" onValueChange={command} onHandle={next => { handle = next; }} /></ImplementationContext>;
    });
    activate(container.querySelector<HTMLElement>('#tab-two')!); await settle();
    expect(command).toHaveBeenCalledWith('two');
    expect(container.querySelector<TabGroupElement>('wa-tab-group')!.active).toBe('one');
    expect(container.querySelector<TabElement>('#tab-one')!.active).toBe(true);
    setState({ value: 'two', tabs: items.slice(1) }); await settle();
    handle!.focus(); expect(document.activeElement?.id).toBe('tab-two');
    expect(container.querySelector('#tab-one')).toBeNull();
    setState({ value: 'two', tabs: items.slice(1), disabled: true }); await settle();
    expect([...container.querySelectorAll<TabElement>('wa-tab')].every(tab => tab.disabled)).toBe(true);
    expect(container.querySelectorAll('wa-tab[tabindex="0"]')).toHaveLength(0);
    const oldHandle = handle!; dispose(); await settle();
    expect(handle).toBeUndefined(); expect(() => oldHandle.focus()).toThrow();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'tabs.dynamic')).toBe(false);
  });

  it('keeps panel liveness tied to rendered visibility', async () => {
    const [active, setActive] = createSignal(true);
    const { container } = await mount(() => {
      const model = constructItem('tabs.visibility', item => ({
        state: item.constant('state', { value: 'one', tabs: items }), active: item.observe('active', active),
      }));
      return <ImplementationContext value={implementation}><Tabs.View observable={model.state} surface={{ kind: 'inherit' }} hotkeys={[]} label="Sections" size="compact" onValueChange={() => {}} />
        <TabPanel.View observable={model.active} surface={{ kind: 'own', name: 'tabs.nativePanel', transparent: true }} hotkeys={[]} id="panel-one" tabId="tab-one" value="one">Panel</TabPanel.View>
      </ImplementationContext>;
    });
    expect(container.querySelector('wa-tab-group')).not.toBeNull();
    expect(container.querySelector('wa-tab')).not.toBeNull();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'tabs.nativePanel')).toBe(true);
    setActive(false); await settle();
    expect(container.querySelector('#panel-one')!.hasAttribute('hidden')).toBe(true);
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'tabs.nativePanel')).toBe(false);
  });

  it('retains a failed tab group without allowing commands or gating independently placed panel content', async () => {
    const groupClass = customElements.get('wa-tab-group')!;
    const panelClass = customElements.get('wa-tab-panel')!;
    vi.spyOn(groupClass.prototype, 'updateComplete', 'get').mockReturnValue(Promise.resolve(false));
    vi.spyOn(panelClass.prototype, 'updateComplete', 'get').mockReturnValue(Promise.resolve(false));
    let mounts = 0; const released = vi.fn();
    const Content = () => { mounts++; onCleanup(released); return <span>Retained editor</span>; };
    const [selected, setSelected] = createSignal('one');
    const { container } = await mount(() => {
      const model = constructItem('tabs.recovery', item => ({
        state: item.observe('state', () => ({ value: selected(), tabs: items })),
        active: item.constant('active', true),
      }));
      return <ImplementationContext value={implementation}><Tabs.View observable={model.state}
        surface={{ kind: 'own', name: 'tabs.recovery', transparent: true }} hotkeys={[]} label="Sections" size="compact" onValueChange={setSelected} />
        <TabPanel.View observable={model.active} surface={{ kind: 'inherit' }} hotkeys={[]}
          id="panel-one" tabId="tab-one" value="one"><Content /></TabPanel.View>
      </ImplementationContext>;
    });
    expect(container.querySelector('wa-tab-group')).not.toBeNull();
    expect(container.querySelector('wa-tab-panel')).not.toBeNull();
    expect(container.querySelectorAll('[data-ui-error="update-failed"][inert]')).toHaveLength(1);
    expect(container.querySelector('wa-tab-panel')!.hasAttribute('inert')).toBe(false);
    expect(container.querySelector('wa-tab-panel')!.hasAttribute('data-ui-error')).toBe(false);
    expect(container.querySelector('[data-ui-fallback]')).toBeNull();
    expect(mounts).toBe(1); expect(released).not.toHaveBeenCalled();
    container.querySelector<HTMLElement>('#tab-two')!.click(); await settle();
    expect(selected()).toBe('one');
    expect(surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'tabs.recovery')).toHaveLength(0);
  });

  it('requires an explicit override before a custom binding can replace vendor navigation', async () => {
    expect(() => render(() => {
      const state = constructItem('tabs.keys', item => item.constant('state', { value: 'one', tabs: items }));
      return <Tabs.View observable={state} surface={{ kind: 'inherit' }} label="Sections" size="compact"
        hotkeys={[{ key: 'ArrowRight', handler: () => {} }]} onValueChange={() => {}} />;
    }, document.createElement('div'))).toThrow('ArrowRight is native-owned');
  });
});
