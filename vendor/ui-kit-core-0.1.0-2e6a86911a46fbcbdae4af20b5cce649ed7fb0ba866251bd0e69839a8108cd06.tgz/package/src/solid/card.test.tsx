/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createRoot, createSignal, flush, onSettled } from 'solid-js';
import { afterEach, expect, it, vi } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { Card, type CardProps } from './controls';
import { useStyles } from '../../tests/styles';

useStyles('solid/controls.css');

const disposers: (() => void)[] = [];
afterEach(() => { disposers.splice(0).reverse().forEach(dispose => dispose()); document.body.replaceChildren(); });

it('keeps one host, child owner and surface handle across recipes', () => {
  const container = document.createElement('div'); document.body.append(container);
  const [surface, setSurface] = createSignal(true);
  const mounted = vi.fn(); const cleaned = vi.fn(); const handles = vi.fn();
  const Child = () => { onSettled(() => { mounted(); return cleaned; }); return <span>Uncommitted editing content</span>; };
  const dispose = render(() => {
    const visible = constructItem('card.identity', item => item.constant('visible', true));
    return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe={surface() ? 'content' : 'plain'}
      attributes={{ role: 'region', 'aria-label': 'Confirmation' }} onHandle={handles}><Child /></Card.View>;
  }, container);
  disposers.push(dispose); flush();
  const host = container.firstElementChild!; const child = host.firstElementChild;
  expect(host.tagName).toBe('DIV');
  expect(host.classList.contains('ui-card-surface')).toBe(true);
  expect(host.getAttribute('aria-label')).toBe('Confirmation');
  expect(mounted).toHaveBeenCalledOnce();
  setSurface(false); flush();
  expect(container.firstElementChild).toBe(host);
  expect(host.firstElementChild).toBe(child);
  expect(host.classList.contains('ui-card-surface')).toBe(false);
  setSurface(true); flush();
  expect(container.firstElementChild).toBe(host); expect(host.firstElementChild).toBe(child);
  expect(host.classList.contains('ui-card-surface')).toBe(true);
  expect(mounted).toHaveBeenCalledOnce(); expect(cleaned).not.toHaveBeenCalled();
  const handle = handles.mock.calls.at(-1)![0];
  expect(handle.contains(child)).toBe(true);
  dispose();
  expect(cleaned).toHaveBeenCalledOnce(); expect(handles).toHaveBeenLastCalledWith(undefined);
  expect(() => handle.measure()).toThrow('disposed');
});

it('keeps status updates, native semantics and events on the same host', () => {
  const container = document.createElement('div'); document.body.append(container);
  const [warning, setWarning] = createSignal(false);
  const enter = vi.fn(); const leave = vi.fn();
  disposers.push(render(() => {
    const visible = constructItem('card.notice', item => item.constant('visible', true));
    return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe="notice" tone={warning() ? 'warning' : 'success'} placement={{ width: '320px' }}
      attributes={{ id: 'notice', role: 'status', 'aria-describedby': 'description', tabindex: -1,
        onPointerEnter: enter, onPointerLeave: leave }}>Saved</Card.View>;
  }, container));
  flush();
  const host = container.firstElementChild as HTMLElement;
  expect(host.id).toBe('notice');
  expect(host.getAttribute('role')).toBe('status');
  expect(host.getAttribute('aria-describedby')).toBe('description');
  expect(host.tabIndex).toBe(-1);
  expect(host.style.width).toBe('320px');
  host.dispatchEvent(new PointerEvent('pointerenter')); host.dispatchEvent(new PointerEvent('pointerleave'));
  expect(enter).toHaveBeenCalledOnce(); expect(leave).toHaveBeenCalledOnce();
  expect(host.classList.contains('ui-card-notice-success')).toBe(true);
  setWarning(true); flush();
  expect(container.firstElementChild).toBe(host);
  expect(host.classList.contains('ui-card-notice-warning')).toBe(true);
  expect(host.classList.contains('ui-card-notice-success')).toBe(false);
});

it('rejects forged paint, private markers, inner placement and unsupported recipes', () => {
  createRoot(dispose => {
    try {
      const visible = constructItem('card.presentation', item => item.constant('visible', true));
      const base = { observable: visible, surface: { kind: 'inherit' } as const, hotkeys: [] };
      for (const extra of [{ class: 'custom' }, { style: { color: 'red' } },
        { attributes: { style: { padding: '4px' } } }, { attributes: { 'attr:class': 'custom' } },
        { attributes: { 'data-ui-card': 'forged' } }, { attributes: { dataset: { uiCard: 'forged' } } },
        { recipe: 'custom' }, { recipe: 'content', tone: 'warning' }, { recipe: 'notice', tone: 'popover' }]) {
        expect(() => new Card({ ...base, ...extra } as CardProps)).toThrow(/Card/);
      }
      const host = document.createElement('div');
      expect(() => render(() => <Card.View {...base}
        placement={{ padding: '4px' } as never} />, host)).toThrow(/placement cannot override padding/);
    } finally { dispose(); }
  });
});

it('renders plain layout immediately without vendor definitions or readiness work', () => {
  const container = document.createElement('div'); document.body.append(container);
  disposers.push(render(() => {
    const visible = constructItem('card.plain', item => item.constant('visible', true));
    return <Card.View observable={visible} surface={{ kind: 'inherit' }} hotkeys={[]}><span>Layout</span></Card.View>;
  }, container));
  flush();
  expect(container.textContent).toBe('Layout');
  expect(container.querySelector('wa-card,[inert],[data-ui-ready]')).toBeNull();
});
