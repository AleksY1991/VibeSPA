/** @jsxImportSource @solidjs/web */
import { createEffect, createSignal, omit, onSettled, untrack } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { activationFrom, type Activation, type FocusHandle } from '../contracts/controls';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, guardFocusHandle } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';
import { cn } from '../lib/utils';
import type { ControlSize } from '../control-size';
import { buttonPresentationClasses } from './button-presentation';
import './link.css';

export interface LinkState {
  readonly href: string;
  readonly disabled?: boolean;
}

type NativeLinkAttributes = Omit<JSX.AnchorHTMLAttributes<HTMLAnchorElement>,
  'href' | 'ref' | 'aria-disabled' | Extract<keyof JSX.AnchorHTMLAttributes<HTMLAnchorElement>, `on${string}`>>;

export interface LinkProps extends NativeLinkAttributes, ElementConstruction<LinkState> {
  readonly size?: 'inline' | 'target';
  readonly appearance?: 'link' | 'action';
  readonly layout?: 'inline' | 'row' | 'block';
  readonly controlSize?: ControlSize;
  readonly textSize?: 'body' | 'caption';
  readonly gap?: 'none' | 'sm' | 'md';
  readonly padding?: 'none' | 'xs' | 'md';
  readonly wrap?: boolean;
  readonly underline?: 'hover' | 'always';
  readonly onActivate?: (activation: Activation) => void;
  readonly onHandle?: (handle: FocusHandle | undefined) => void;
}

function renderLink(props: LinkProps): JSX.Element {
  const binding = new ElementBinding('Link', props, { nativeKeys: ['Enter'], nativeActivation: true, enabledWhen: state => !state.disabled });
  const native = omit(props, 'observable', 'surface', 'hotkeys', 'onActivate', 'onHandle',
    'size', 'appearance', 'layout', 'controlSize', 'textSize', 'gap', 'padding', 'wrap', 'underline', 'class');
  let element!: HTMLAnchorElement;
  const [mounted, setMounted] = createSignal(false);
  onSettled(() => { setMounted(true); });
  createEffect(() => [mounted(), props.onHandle] as const, ([ready, callback]) => {
    if (!ready || !callback) return;
    let active = true;
    const current = () => { if (!active) throw new Error('Link focus handle has been disposed'); return element; };
    untrack(() => callback(guardFocusHandle(binding, Object.freeze({
      focus: (options?: FocusOptions) => current().focus(options),
      blur: () => current().blur(),
    }))));
    return () => { active = false; untrack(() => callback(undefined)); };
  });
  return binding.provide(() => <a {...native}
    class={cn('ui-link', (props.size === 'target' || props.appearance === 'action') && 'ui-link-target',
      props.appearance === 'action' && [buttonPresentationClasses({ variant: 'ghost', size: props.controlSize ?? 'compact' }), 'ui-link-action'],
      props.layout === 'row' && 'ui-link-row', props.layout === 'block' && 'ui-link-block',
      props.textSize === 'body' && 'ui-link-body', props.textSize === 'caption' && 'ui-link-caption',
      props.gap === 'none' && 'ui-link-gap-none', props.gap === 'sm' && 'ui-link-gap-sm', props.gap === 'md' && 'ui-link-gap-md',
      props.padding === 'none' && 'ui-link-padding-none', props.padding === 'xs' && 'ui-link-padding-xs', props.padding === 'md' && 'ui-link-padding-md',
      props.wrap && 'ui-link-wrap', props.underline === 'always' && 'ui-link-underline', props.class)}
    data-ui-control-size={props.size === 'target' || props.appearance === 'action' ? props.controlSize ?? 'compact' : undefined}
    ref={node => { element = node; binding.attach(node); }}
    data-ui-keyboard-owner="Enter"
    href={binding.value().disabled ? undefined : binding.value().href}
    role={props.role ?? (binding.value().disabled ? 'link' : undefined)}
    tabindex={props.tabindex ?? (binding.value().disabled ? 0 : undefined)}
    aria-disabled={binding.value().disabled ? 'true' : undefined}
    onClick={event => {
      if (!allowActivation(binding, event)) return;
      props.onActivate?.(activationFrom(event));
    }}
    onAuxClick={event => { allowActivation(binding, event); }}
  />);
}

/**
 * A real anchor preserves navigation, downloads, context menus and modifier clicks.
 * WA Button's href mode is a button-shaped action; replacing inline links with it
 * would change their inline geometry and add an unnecessary shadow host. Inline
 * links retain text flow; standalone navigation opts into an explicit target size.
 * The browser owns Enter
 * and navigation unless the typed command cancels it. Our only extra behavior is
 * discoverable disabled links and owner-scoped commands/focus handles.
 */
export class Link extends RenderedElement<LinkState> {
  readonly element: JSX.Element;
  constructor(props: LinkProps) {
    super('Link', props);
    this.element = renderLink(this.capture(props));
  }
  static View = (props: LinkProps): JSX.Element => new Link(props).element;
}
