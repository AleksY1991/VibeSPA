/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, expect, it } from 'vitest';
import { createSignal, flush, OBSERVE } from 'solid-js';
import { render } from '@solidjs/web';
import { constructItem } from '../infrastructure/construction';
import { useStyles } from '../../tests/styles';
import { Button } from './button';
import { captureArtifact, expectNoDiagnostics } from '@solidjs/diagnostics';
import type { FocusHandle } from '../contracts/controls';

useStyles('solid/button-geometry.css');

afterEach(() => document.body.replaceChildren());
const settle = async () => { for (let turn = 0; turn < 8; turn++) { flush(); await Promise.resolve(); } };

it('updates button semantics without reconstructing scalar prop computations', async () => {
  const [state, setState] = createSignal({ disabled: false, pressed: false, expanded: false, ariaDisabled: false });
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => {
    const control = constructItem('button.live-selection', item => item.observe('state', state));
    return <Button.View observable={control} surface={{ kind: 'inherit' }} hotkeys={[]} type="button" tabindex={0}>Action</Button.View>;
  }, host);
  try {
    await settle();
    const button = host.querySelector('button')!;
    const creations: string[] = [];
    const unsubscribe = OBSERVE!.records.subscribe('create', event => creations.push(event.nodeName ?? ''));
    const { artifact } = await captureArtifact(async () => {
      for (let index = 0; index < 30; index++) {
        const next = index % 2 === 0;
        setState({ disabled: next, pressed: next, expanded: next, ariaDisabled: next });
        await settle();
        expect(button.hasAttribute('disabled')).toBe(next);
        expect(button.getAttribute('data-ui-selected')).toBe(next ? '' : null);
      }
    }, { scenario: 'button-live-state' });
    unsubscribe();
    expect(creations).toEqual([]);
    expectNoDiagnostics(artifact);
  } finally { dispose(); }
});

it('moves between fixed action and menu recipes without replacing labels or decorations', async () => {
  const [recipe, setRecipe] = createSignal<'button' | 'menu-item'>('button');
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => {
    const state = constructItem('button.label', item => item.constant('state', {}));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} recipe={recipe()}
      start={<span data-decoration="start">Start</span>} end={<span data-decoration="end">End</span>}>
      <span data-content="">Label</span>
    </Button.View>;
  }, host);
  try {
    await settle();
    const child = host.querySelector('[data-content]')!;
    const start = host.querySelector('[data-decoration="start"]')!;
    const end = host.querySelector('[data-decoration="end"]')!;
    setRecipe('menu-item'); await settle();
    expect(host.querySelector('[data-content]')).toBe(child);
    expect(host.querySelector('[data-decoration="start"]')).toBe(start);
    expect(host.querySelector('[data-decoration="end"]')).toBe(end);
    const label = host.querySelector<HTMLElement>('[data-ui-button-label]')!;
    expect(label.contains(child)).toBe(true);
    expect(label.contains(start)).toBe(false);
    expect(label.contains(end)).toBe(false);
    const style = getComputedStyle(label);
    expect(style.display).toBe('flex');
    expect(style.flexGrow).toBe('1');
    expect(style.minWidth).toBe('0');
    setRecipe('button'); await settle();
    expect(host.querySelector('[data-content]')).toBe(child);
    expect(getComputedStyle(label).display).toBe('contents');
  } finally { dispose(); }
});

it('restricts pointer hits to the label while retaining button focus and activation', async () => {
  const [activations, setActivations] = createSignal(0);
  let handle!: FocusHandle;
  const host = document.createElement('div'); document.body.append(host);
  const dispose = render(() => {
    const state = constructItem('button.hit-target', item => item.constant('state', {}));
    return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="inline-action"
      onActivate={() => setActivations(value => value + 1)} onHandle={next => { if (next) handle = next; }}
      start={<span data-decoration="start">Start</span>} end={<span data-decoration="end">End</span>}>
      <span data-content="">Action</span>
    </Button.View>;
  }, host);
  try {
    await settle();
    const control = host.querySelector('button')!;
    expect(control.getAttribute('data-ui-keyboard-owner')).toBe('Enter Space');
    expect(getComputedStyle(control).pointerEvents).toBe('none');
    expect(control.textContent).toContain('Action');
    const label = host.querySelector('[data-ui-button-label]')!;
    expect(getComputedStyle(label).pointerEvents).toBe('auto');
    expect(getComputedStyle(label).display).toBe('inline');
    for (const decoration of host.querySelectorAll('[data-decoration]')) {
      expect(label.contains(decoration)).toBe(false);
      // Happy DOM leaves inherited pointer-events empty; neither decoration may
      // opt back into the pointer area disabled by its button ancestor.
      expect(['', 'none']).toContain(getComputedStyle(decoration).pointerEvents);
    }
    handle.focus();
    expect(document.activeElement).toBe(control);
    control.click(); flush();
    expect(activations()).toBe(1);
  } finally { dispose(); }
});
