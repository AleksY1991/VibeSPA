/** @jsxImportSource @solidjs/web */
import { Show } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import type { SpinnerAccessibility, SpinnerControlProps } from '../contracts/spinner';
import { ElementBinding } from '../infrastructure/element';
import { RenderedElement } from '../infrastructure/rendered-element';
import { requireControlImplementation } from '../infrastructure/implementation-context';
import './spinner.css';

export type SpinnerProps = Omit<SpinnerControlProps, 'onElement' | 'decorative' | 'label'>
  & SpinnerAccessibility
  & ElementConstruction<boolean>;

function renderSpinner(props: SpinnerProps) {
  const binding = new ElementBinding('Spinner', props, { activeWhen: busy => busy, nativeKeys: [] });
  const Implementation = requireControlImplementation('Spinner');
  return <Show when={binding.value()}>
    <Implementation {...props} onElement={binding.attach} />
  </Show>;
}

/** Busy visibility and surface lifetime consume the same registered boolean. */
export class Spinner extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: SpinnerProps) {
    super('Spinner', props);
    this.element = renderSpinner(this.capture(props));
  }
  static View = (props: SpinnerProps): JSX.Element => new Spinner(props).element;
}
