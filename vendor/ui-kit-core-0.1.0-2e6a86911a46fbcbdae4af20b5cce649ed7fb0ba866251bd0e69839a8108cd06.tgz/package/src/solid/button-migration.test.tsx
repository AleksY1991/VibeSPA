/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { constructItem } from '../infrastructure/construction';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createRoot, createSignal, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { Button, type ButtonProps } from './button';
import type { FocusHandle } from '../contracts/controls';
import { ImplementationContext } from '../infrastructure/implementation-context';
import { surfaceRegistry } from '../../tests/surface-host';
import { attachDispatcher } from '../../tests/surface-host';

const settle = async () => { await new Promise<void>((resolve) => setTimeout(resolve, 0)); };
afterEach(() => document.body.replaceChildren());

function mount(content: () => import('@solidjs/web').JSX.Element) {
  const host = document.createElement('div');
  document.body.append(host);
  return { host, dispose: render(content, host) };
}

describe('scoped control buttons', () => {
  it.each(['class', 'className', 'classList', 'style'])(
  'rejects the owned %s presentation even through an untyped caller', key => {
    createRoot(dispose => {
      try {
        const state = constructItem('button.closed-presentation', item => item.constant('state', {}));
        const props = { observable: state, surface: { kind: 'inherit' }, hotkeys: [], [key]: undefined } as unknown as ButtonProps;
        expect(() => new Button(props)).toThrow(`${key} is owned by the control`);
      } finally { dispose(); }
    });
  });

  it.each([
    [{ recipe: 'cell' }, 'unsupported recipe'],
    [{ recipe: 'action' }, 'unsupported recipe'],
    [{ recipe: 'menu' }, 'unsupported recipe'],
    [{ recipe: 'inline' }, 'unsupported recipe'],
    [{ recipe: 'content' }, 'require an explicit supported variant'],
    [{ shape: 'icon', 'aria-label': 'Apply' }, 'require an explicit supported variant'],
    [{ recipe: 'menu-item', variant: 'ghost' }, 'owns its paint'],
    [{ recipe: 'navigation', shape: 'icon', 'aria-label': 'Current view' }, 'owns its shape'],
    [{ recipe: 'inline-action', size: 'dense' }, 'content-sized geometry'],
    [{ shape: 'icon', variant: 'default', 'aria-label': 'Apply' }, 'cannot use default'],
    [{ shape: 'icon', variant: 'ghost' }, 'require an accessible name'],
  ] as const)('rejects unsupported recipe combinations %#', (presentation, message) => {
    expect(() => mount(() => {
        const state = constructItem('button.unsupported-recipe', item => item.constant('state', {}));
        const props = { observable: state, surface: { kind: 'inherit' }, hotkeys: [], ...presentation } as unknown as ButtonProps;
        return new Button(props).element;
    })).toThrow(message);
  });

  it('retains an opaque disabled surface while suppressing its custom commands', () => {
    const [disabled, setDisabled] = createSignal(true);
    const command = vi.fn();
    const { host, dispose } = mount(() => {
      const state = constructItem('disabled.surface', item => item.observe('state', () => ({ disabled: disabled() })));
      return <Button.View observable={state} surface={{ kind: 'own', name: 'disabled.surface', transparent: false }}
        hotkeys={[{ key: 'Ctrl+K', handler: command }]}>Apply</Button.View>;
    });
    const detach = attachDispatcher({ window, document, registry: surfaceRegistry,
      commands: { dispatch: vi.fn() }, runtime: () => ({ editing: false, keyboardLayer: null }) });
    try {
      flush();
      const button = host.querySelector('button')!;
      const lease = () => surfaceRegistry.read().activeSurfaces.find(surface => surface.name === 'disabled.surface');
      const id = lease()!.instanceId;
      const press = () => button.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', ctrlKey: true, bubbles: true, cancelable: true }));
      press(); expect(command).not.toHaveBeenCalled();
      expect(lease()?.transparent).toBe(false);
      setDisabled(false); flush();
      expect(lease()?.instanceId).toBe(id);
      press(); expect(command).toHaveBeenCalledOnce();
    } finally { detach(); dispose(); }
  });

  it('keeps an ordinary action out of form submission until explicitly declared submit', async () => {
    const [type, setType] = createSignal<'submit' | undefined>();
    const submitted = vi.fn((event: SubmitEvent) => event.preventDefault());
    const activated = vi.fn();
    const { host, dispose } = mount(() => {
      const binding = constructItem('test.ButtonFormAction', item => item.constant('state', {}));
      return <form onSubmit={submitted}><Button.View observable={binding} surface={{ kind: 'inherit' }}
        hotkeys={[]} type={type()} onActivate={activated}>Apply</Button.View></form>;
    });
    const button = host.querySelector('button')!;
    button.click();
    expect(activated).toHaveBeenCalledOnce();
    expect(submitted).not.toHaveBeenCalled();
    setType('submit');
    await settle();
    button.click();
    expect(activated).toHaveBeenCalledTimes(2);
    expect(submitted).toHaveBeenCalledOnce();
    dispose();
  });

  it('keeps an aria-disabled native action focusable while canceling commands and form submission', async () => {
    const [blocked, setBlocked] = createSignal<boolean | 'true' | 'false'>('true');
    const submitted = vi.fn((event: SubmitEvent) => event.preventDefault());
    const activated = vi.fn();
    const pressed = vi.fn();
    const { host, dispose } = mount(() => {
      const binding = constructItem('test.UnavailableButton', item => item.observe('state', () => ({ ariaDisabled: blocked() })));
      return <form onSubmit={submitted}><Button.View observable={binding} surface={{ kind: 'inherit' }}
        hotkeys={[]} type="submit" onActivate={activated} onPressStart={pressed}>Apply</Button.View></form>;
    });
    const button = host.querySelector('button')!;
    button.focus();
    expect(document.activeElement).toBe(button);
    expect(button.disabled).toBe(false);
    for (const state of ['true', true] as const) {
      setBlocked(state);
      await settle();
      button.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
      button.click();
    }
    expect(activated).not.toHaveBeenCalled();
    expect(pressed).not.toHaveBeenCalled();
    expect(submitted).not.toHaveBeenCalled();
    setBlocked('false');
    await settle();
    button.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    button.click();
    expect(activated).toHaveBeenCalledOnce();
    expect(pressed).toHaveBeenCalledOnce();
    expect(submitted).toHaveBeenCalledOnce();
    dispose();
  });

  it('keeps canonical native sizing and bridges one modifier-aware cancellable action', () => {
    const parent = vi.fn();
    const action = vi.fn((intent) => { intent.preventDefault(); intent.stopPropagation(); });
    const { host, dispose } = mount(() => {
const binding0 = constructItem('test.Button', item => item.observe('state', () => ({})));
return (<div onClick={parent}>
      <Button.View observable={binding0} surface={{ kind: 'inherit' }} hotkeys={[]} size="compact" type="button" placement={{ width: '100%' }} onActivate={action}>Apply</Button.View>
    </div>); });
    const button = host.querySelector('button')!;
    const event = new MouseEvent('click', { bubbles: true, cancelable: true, shiftKey: true });
    button.dispatchEvent(event);
    expect(button.style.width).toBe('100%');
    expect(button.classList).toContain('ui-button');
    expect(button.classList).toContain('ui-button-compact');
    expect(button.hasAttribute('uiScope')).toBe(false);
    expect(button.hasAttribute('onActivate')).toBe(false);
    expect(action).toHaveBeenCalledOnce();
    expect(action.mock.calls[0]![0]).toMatchObject({ shiftKey: true, ctrlKey: false });
    expect(event.defaultPrevented).toBe(true);
    expect(parent).not.toHaveBeenCalled();
    dispose();
  });

  it('preserves pointer-start timing separately from activation', () => {
    const events: string[] = [];
    const parent = vi.fn();
    const { host, dispose } = mount(() => {
const binding1 = constructItem('test.Button', item => item.observe('state', () => ({})));
return (<div onPointerDown={parent}>
      <Button.View observable={binding1} surface={{ kind: 'inherit' }} hotkeys={[]} type="button"
        onPressStart={(intent) => { events.push('press'); intent.stopPropagation(); }}
        onActivate={() => events.push('activate')}>Remove favorite</Button.View>
    </div>); });
    const button = host.querySelector('button')!;
    button.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
    expect(events).toEqual(['press']);
    button.click();
    expect(events).toEqual(['press', 'activate']);
    expect(parent).not.toHaveBeenCalled();
    dispose();
  });

  it('always exposes an ordinary action selection through the canonical selected state', () => {
    const { host, dispose } = mount(() => {
      const binding = constructItem('test.ButtonSelectionPaint', item => item.observe('state', () => ({ pressed: true })));
      return <Button.View observable={binding} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="ghost" size="compact" type="button">Selected</Button.View>;
    });
    const button = host.querySelector('button')!;
    expect(button.getAttribute('aria-pressed')).toBe('true');
    expect(button.hasAttribute('data-ui-selected')).toBe(true);
    dispose();
  });

  it('tracks navigation selection separately from focus and keeps its marker decorative', async () => {
    const [current, setCurrent] = createSignal(false);
    const { host, dispose } = mount(() => {
      const binding = constructItem('test.NavigationSelection', item => item.constant('state', {}));
      return <Button.View observable={binding} surface={{ kind: 'inherit' }} hotkeys={[]}
        recipe="navigation" aria-current={current() ? 'page' : undefined} onActivate={() => setCurrent(!current())}>
        Overview
      </Button.View>;
    });
    const button = host.querySelector('button')!;
    expect(button.hasAttribute('data-ui-selected')).toBe(false);
    button.focus();
    expect(button.hasAttribute('data-ui-selected')).toBe(false);
    button.click();
    await settle();
    expect(button.getAttribute('aria-current')).toBe('page');
    expect(button.hasAttribute('data-ui-selected')).toBe(true);
    expect(button.querySelector('.ui-navigation-marker')?.getAttribute('aria-hidden')).toBe('true');
    button.click();
    await settle();
    expect(button.hasAttribute('data-ui-selected')).toBe(false);
    dispose();
  });

  it('unpublishes and revokes old focus handles on callback replacement and disposal', async () => {
    const first = vi.fn<(handle: FocusHandle | undefined) => void>();
    const second = vi.fn<(handle: FocusHandle | undefined) => void>();
    const [callback, setCallback] = createSignal(() => first);
    const { host, dispose } = mount(() => {
const binding2 = constructItem('test.Button', item => item.observe('state', () => ({})));
return (<Button.View observable={binding2} surface={{ kind: 'inherit' }} hotkeys={[]} type="button" onHandle={callback()}>View</Button.View>); });
    await settle();
    const old = first.mock.calls[0]![0]!;
    old.focus();
    expect(document.activeElement).toBe(host.querySelector('button'));
    setCallback(() => second);
    await settle();
    expect(first.mock.calls).toHaveLength(2);
    expect(first.mock.calls[1]![0]).toBeUndefined();
    expect(() => old.focus()).toThrow('disposed');
    const current = second.mock.calls[0]![0]!;
    current.blur();
    dispose();
    expect(second.mock.calls).toHaveLength(2);
    expect(second.mock.calls[1]![0]).toBeUndefined();
    expect(() => current.focus()).toThrow('disposed');
  });

  it('keeps its native renderer across prepared and absent contexts and accessible description changes', async () => {
    const [description, setDescription] = createSignal<string | undefined>('Available offline');
    const { host, dispose } = mount(() => {
const binding3 = constructItem('test.Button', item => item.observe('state', () => ({})));
const binding4 = constructItem('test.Button', item => item.observe('state', () => ({})));
return (<ImplementationContext value={{}}>
      <Button.View observable={binding3} surface={{ kind: 'inherit' }} hotkeys={[]} type="button" aria-checked="false" aria-description={description()}>Settings</Button.View>
      <ImplementationContext value={null}>
        <Button.View observable={binding4} surface={{ kind: 'inherit' }} hotkeys={[]} type="button">Filter</Button.View>
      </ImplementationContext>
    </ImplementationContext>); });
    for (const button of host.querySelectorAll('button')) {
      expect(button.classList).toContain('ui-button');
      expect(button.classList).toContain('ui-button-dense');
    }
    const button = host.querySelector('button')!;
    expect(button.getAttribute('aria-checked')).toBe('false');
    expect(button.getAttribute('aria-description')).toBe('Available offline');
    setDescription(undefined);
    await settle();
    expect(button.hasAttribute('aria-description')).toBe(false);
    expect(host.querySelector('button')).toBe(button);
    expect(host.querySelectorAll('button')).toHaveLength(2);
    dispose();
  });
});
