// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';

import {
  focusInitialElement,
  lockDocumentScroll,
  placeFloatingBox,
  tabbableElements,
  trapTabKey,
} from './overlay';

afterEach(() => {
  document.body.replaceChildren();
  document.body.removeAttribute('style');
  vi.restoreAllMocks();
});

describe('Solid overlay mechanics', () => {
  it('keeps floating content inside the viewport and flips when the preferred side is full', () => {
    const placement = placeFloatingBox(
      { left: 270, right: 310, top: 170, bottom: 194, width: 40 },
      { width: 120, height: 80 },
      { width: 320, height: 240 },
      { side: 'bottom', align: 'start', margin: 8, offset: 4 },
    );
    expect(placement).toEqual({ left: 192, top: 86, side: 'top' });
  });

  it('cycles Tab and Shift+Tab inside the active surface', () => {
    const surface = document.createElement('section');
    surface.tabIndex = -1;
    surface.innerHTML = '<button id="first">First</button><button disabled>Skip</button><button id="last">Last</button>';
    document.body.append(surface);
    const [first, last] = tabbableElements(surface);
    expect([first.id, last.id]).toEqual(['first', 'last']);

    last.focus();
    const forward = new KeyboardEvent('keydown', { key: 'Tab', cancelable: true });
    expect(trapTabKey(forward, surface)).toBe(true);
    expect(forward.defaultPrevented).toBe(true);
    expect(document.activeElement).toBe(first);

    first.focus();
    const backward = new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, cancelable: true });
    expect(trapTabKey(backward, surface)).toBe(true);
    expect(document.activeElement).toBe(last);
  });

  it('reference-counts body scroll locks across nested dialogs', () => {
    document.body.style.overflow = 'auto';
    const releaseOuter = lockDocumentScroll(document);
    const releaseInner = lockDocumentScroll(document);
    expect(document.body.style.overflow).toBe('hidden');
    releaseInner();
    expect(document.body.style.overflow).toBe('hidden');
    releaseOuter();
    expect(document.body.style.overflow).toBe('auto');
  });

  it('keeps reverse Tab inside a dialog whose heading received initial focus', () => {
    const surface = document.createElement('section');
    surface.innerHTML = '<h2 tabindex="-1">Review</h2><button>First</button><button>Last</button>';
    document.body.append(surface);
    surface.querySelector<HTMLElement>('h2')!.focus();
    const event = new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, cancelable: true });
    expect(trapTabKey(event, surface)).toBe(true);
    expect(document.activeElement?.textContent).toBe('Last');
  });

  it('adds scrollbar compensation to existing body padding and restores it once', () => {
    vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(1000);
    vi.spyOn(document.documentElement, 'clientWidth', 'get').mockReturnValue(985);
    document.body.style.paddingRight = '12px';
    const outer = lockDocumentScroll(document);
    const inner = lockDocumentScroll(document);
    expect(document.body.style.paddingRight).toBe('27px');
    outer();
    expect(document.body.style.paddingRight).toBe('27px');
    inner();
    inner();
    expect(document.body.style.paddingRight).toBe('12px');
  });

  it('includes ready shadow controls once and wraps focus at their public hosts', () => {
    const surface = document.createElement('section');
    surface.tabIndex = -1;
    const first = document.createElement('button');
    const last = document.createElement('test-action');
    last.setAttribute('data-ui-interactive', '');
    last.setAttribute('data-ui-ready', 'true');
    const native = document.createElement('button');
    last.attachShadow({ mode: 'open' }).append(native);
    last.focus = (options) => native.focus(options);
    surface.append(first, last);
    document.body.append(surface);
    expect(tabbableElements(surface)).toEqual([first, last]);
    native.focus();
    expect(document.activeElement).toBe(last);
    expect(trapTabKey(new KeyboardEvent('keydown', { key: 'Tab', cancelable: true }), surface)).toBe(true);
    expect(document.activeElement).toBe(first);
    expect(trapTabKey(new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, cancelable: true }), surface)).toBe(true);
    expect(last.shadowRoot?.activeElement).toBe(native);
  });

  it('skips unavailable hosts and internally disabled or excluded controls', () => {
    const surface = document.createElement('section');
    const createControl = () => {
      const host = document.createElement('test-field');
      host.setAttribute('data-ui-interactive', '');
      const input = document.createElement('input');
      host.attachShadow({ mode: 'open' }).append(input);
      surface.append(host);
      return { host, input };
    };
    createControl().host.setAttribute('data-ui-ready', 'false');
    createControl().host.setAttribute('inert', '');
    createControl().input.disabled = true;
    createControl().input.tabIndex = -1;
    const explained = createControl().host;
    explained.setAttribute('aria-disabled', 'true');
    const valid = document.createElement('button');
    surface.append(valid);
    document.body.append(surface);
    expect(tabbableElements(surface)).toEqual([explained, valid]);
  });

  it('traverses shadow slots and non-tabbable wrappers without duplicate stops', () => {
    const surface = document.createElement('section');
    const wrapper = document.createElement('test-panel');
    wrapper.tabIndex = -1;
    wrapper.attachShadow({ mode: 'open' }).append(document.createElement('slot'));
    const action = document.createElement('button');
    action.setAttribute('autofocus', '');
    wrapper.append(action);
    surface.append(wrapper);
    document.body.append(surface);
    expect(tabbableElements(surface)).toEqual([action]);
    expect(focusInitialElement(surface)).toBe(action);
  });

});
