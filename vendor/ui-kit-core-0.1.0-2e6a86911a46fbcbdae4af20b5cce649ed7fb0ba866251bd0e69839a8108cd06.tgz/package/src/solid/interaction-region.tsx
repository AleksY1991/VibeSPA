/** @jsxImportSource @solidjs/web */
import { omit, createEffect, createSignal, onCleanup, onSettled, untrack } from 'solid-js';
import { Dynamic, type JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { activationFrom, type Activation } from '../contracts/controls';
import { ElementBinding } from '../infrastructure/element';
import { allowActivation, deliverEvent, eventScope, guardFocusHandle, guardNativeEvents, pointerCancellation, surfaceEvent } from '../infrastructure/activation';
import { RenderedElement } from '../infrastructure/rendered-element';
import type { SurfaceHandle } from './controls';
import type { ButtonState } from './button';
import { HOTKEY_PASS } from '../contracts/platform';

type RegionEvent<EventType extends Event> = EventType & { currentTarget: HTMLElement; target: Element };

export interface InteractionHandle extends SurfaceHandle {
  scrollIntoView(options?: ScrollIntoViewOptions): void;
  scrollPosition(): { readonly top: number; readonly left: number; readonly height: number; readonly width: number; readonly clientHeight: number; readonly clientWidth: number };
  scrollTo(options: ScrollToOptions): void;
  capturePointer(pointerId: number): void;
  releasePointer(pointerId: number): void;
}
export interface InteractionActivation extends Activation {
  readonly clientX: number;
  readonly clientY: number;
  readonly button: number;
  readonly buttons: number;
  readonly detail: number;
  readonly ownTarget: boolean;
  readonly targetIsInteractive: boolean;
  readonly pointerId: number | undefined;
  capturePointer(): void;
  releasePointer(): void;
  measure(): DOMRectReadOnly;
  isWithin(handle: SurfaceHandle): boolean;
}

export interface InteractionRegionProps extends Omit<JSX.HTMLAttributes<HTMLElement>,
  'ref' | 'onClick' | 'onDblClick' | 'onDoubleClick' | 'onPointerDown' | 'onKeyDown' | 'onKeyUp' | 'onKeyPress'
  | 'aria-disabled' | 'aria-pressed' | 'aria-expanded'>, ElementConstruction<ButtonState> {
  readonly ownTargetOnly?: boolean;
  readonly onHandle?: (handle: InteractionHandle | undefined) => void;
  readonly onSizeChange?: (size: { readonly width: number; readonly height: number }) => void;
  readonly as?: 'div' | 'section' | 'article' | 'li' | 'span';
  readonly onActivate?: (activation: InteractionActivation) => void;
  readonly onDoubleActivate?: (activation: InteractionActivation) => void;
  readonly onPressStart?: (activation: InteractionActivation) => void;
}

function renderInteractionRegion(props: InteractionRegionProps): JSX.Element {
  const explicitEnter = untrack(() => Array.isArray(props.hotkeys) && props.hotkeys.some(key => key?.key === 'Enter'));
  const semanticEnter = untrack(() => !explicitEnter && props.role === 'button'
    && (typeof props.tabindex === 'number' || typeof props.tabindex === 'string')
    && Number(props.tabindex) >= 0 && typeof props.onActivate === 'function');
  const binding = new ElementBinding('InteractionRegion', props, {
    enabledWhen: state => !state.disabled,
    activationWhen: state => state.ariaDisabled !== true && state.ariaDisabled !== 'true',
    // A role-button container has no browser Enter activation. Supply it only
    // for its own focus target; explicit caller policies take complete precedence.
    builtins: !semanticEnter ? undefined : { Enter: eventScope((event: KeyboardEvent, target: Element) => {
      if ((event.composedPath()[0] ?? event.target) !== target || target.getAttribute('role') !== 'button'
        || element.tabIndex < 0 || !props.onActivate) {
        return HOTKEY_PASS;
      }
      if (event.isComposing || event.keyCode === 229 || !allowActivation(binding, event)) return HOTKEY_PASS;
      element.click();
    }) },
    // The self-target semantic action precedes a containing Form's Enter marker.
    // A native descendant is resolved first and never reaches this override.
    nativeOverrides: semanticEnter ? ['Enter'] : undefined,
  });
  let element!: HTMLElement;
  let alive = true;
  const pointers = new Set<number>();
  const capturePointer = (id: number) => {
    if (!alive) throw new Error('Interaction handle has been disposed');
    element.setPointerCapture(id);
    pointers.add(id);
  };
  const releasePointer = (id: number) => {
    if (!alive) throw new Error('Interaction handle has been disposed');
    if (element.hasPointerCapture(id)) element.releasePointerCapture(id);
    pointers.delete(id);
  };
  onCleanup(() => {
    alive = false;
    for (const id of pointers) if (element.hasPointerCapture(id)) element.releasePointerCapture(id);
    pointers.clear();
  });
  const [mounted, setMounted] = createSignal(false);
  const [renderedHost, setRenderedHost] = createSignal<HTMLElement>();
  onSettled(() => { if (alive) setMounted(true); });
  createEffect(() => [mounted(), renderedHost(), props.onHandle, props.onSizeChange] as const, ([ready, host, callback, sizeChanged]) => {
    // A constructor may prepare a deferred child before its Dynamic host is
    // rendered. Owner settlement alone is not evidence that a DOM host exists.
    if (!ready || !host) return;
    let active = true;
    const current = () => { if (!active) throw new Error('Interaction handle has been disposed'); return host; };
    // Handle delivery samples initial focus/scroll state; updates have their own effects.
    untrack(() => callback?.(guardFocusHandle(binding, Object.freeze({
      measure: () => current().getBoundingClientRect(),
      contains: (target: Node | null) => active && host.contains(target),
      isConnected: () => active && host.isConnected,
      focus: (options?: FocusOptions) => current().focus(options),
      blur: () => current().blur(),
      scrollIntoView: (options?: ScrollIntoViewOptions) => current().scrollIntoView(options),
      scrollPosition: () => { const node = current(); return { top: node.scrollTop, left: node.scrollLeft, height: node.scrollHeight, width: node.scrollWidth, clientHeight: node.clientHeight, clientWidth: node.clientWidth }; },
      scrollTo: (options: ScrollToOptions) => current().scrollTo(options),
      capturePointer: (id: number) => { current(); capturePointer(id); },
      releasePointer: (id: number) => { current(); releasePointer(id); },
    }))));
    const report = () => { if (active && sizeChanged) { const rect = host.getBoundingClientRect(); untrack(() => sizeChanged({ width: rect.width, height: rect.height })); } };
    const observer = sizeChanged && typeof ResizeObserver !== 'undefined' ? new ResizeObserver(report) : undefined;
    observer?.observe(host);
    report();
    return () => { active = false; observer?.disconnect(); untrack(() => callback?.(undefined)); };
  });
  const intent = (event: MouseEvent): InteractionActivation => ({
    ...activationFrom(event), clientX: event.clientX, clientY: event.clientY,
    button: event.button, buttons: event.buttons, detail: event.detail,
    ownTarget: event.target === element,
    // The composed path sees a WA control's native shadow target as well as its
    // host. Stop at this region so an ancestor action cannot classify its plain
    // content as a nested control; keyboard semantics still belong to the child.
    targetIsInteractive: event.composedPath().slice(0, event.composedPath().indexOf(element)).some(target =>
      target instanceof Element && target.matches('button,input,textarea,select,a[href],summary,[contenteditable=""],[contenteditable="true"],[contenteditable="plaintext-only"],[data-ui-text-entry="true"],[data-ui-interactive],[role="button"],[role="link"],[role="checkbox"],[role="radio"],[role="switch"],[role="menuitem"],[role="tab"],[role="option"],[role="combobox"],[role="slider"],[role="spinbutton"],[role="textbox"]')),
    pointerId: event instanceof PointerEvent ? event.pointerId : undefined,
    capturePointer: () => { if (event instanceof PointerEvent) capturePointer(event.pointerId); },
    releasePointer: () => { if (event instanceof PointerEvent) releasePointer(event.pointerId); },
    measure: () => { if (!alive) throw new Error('Interaction handle has been disposed'); return element.getBoundingClientRect(); },
    isWithin: (handle: SurfaceHandle) => event.composedPath().some(target => target instanceof Node && handle.contains(target)),
  });
  const allowed = (event: MouseEvent) => (!props.ownTargetOnly || event.target === element) && allowActivation(binding, event);
  const native = guardNativeEvents(binding, omit(props, 'onHandle', 'onSizeChange', 'ownTargetOnly', 'observable', 'surface', 'hotkeys', 'as', 'onActivate', 'onDoubleActivate', 'onPressStart', 'onDrop', 'onPointerUp', 'onPointerMove'));
  const continuePointer = eventScope((event: RegionEvent<PointerEvent>, handler: JSX.EventHandlerUnion<HTMLElement, PointerEvent> | undefined) => {
    if (allowActivation(binding, event)) deliverEvent(handler, event);
    else {
      if (binding.isDisposed()) return;
      deliverEvent(props.onPointerCancel, pointerCancellation(event));
      if (alive && pointers.has(event.pointerId)) releasePointer(event.pointerId);
    }
  });
  return binding.provide(() => <Dynamic component={props.as ?? 'div'} {...native} ref={(node: HTMLElement) => { element = node; setRenderedHost(node); binding.attach(node); }}
    data-ui-interaction-region=""
    data-ui-highlighted={binding.value().highlighted ? '' : undefined}
    aria-disabled={binding.value().disabled || binding.value().ariaDisabled === true || binding.value().ariaDisabled === 'true' ? 'true' : undefined}
    aria-pressed={binding.value().pressed === undefined ? undefined : String(binding.value().pressed) as 'true' | 'false' | 'mixed'}
    aria-expanded={binding.value().expanded === undefined ? undefined : String(binding.value().expanded) as 'true' | 'false'}
    onClick={props.onActivate && eventScope((event: MouseEvent) => { if (allowed(event)) props.onActivate?.(intent(event)); })}
    onDblClick={props.onDoubleActivate && eventScope((event: MouseEvent) => { if (allowed(event)) props.onDoubleActivate?.(intent(event)); })}
    onDrop={props.onDrop && eventScope((event: RegionEvent<DragEvent>) => surfaceEvent(binding, props.onDrop)(event))}
    onPointerUp={props.onPointerUp && eventScope((event: RegionEvent<PointerEvent>) => continuePointer(event, props.onPointerUp))}
    onPointerMove={props.onPointerMove && eventScope((event: RegionEvent<PointerEvent>) => continuePointer(event, props.onPointerMove))}
    onPointerDown={props.onPressStart && eventScope((event: PointerEvent) => { if (allowed(event)) props.onPressStart?.(intent(event)); })} />);
}

/**
 * Rows, canvases and editor regions can contain independent controls. Wrapping
 * them in WA Button (or a native button) would nest actions and lose the region's
 * list/article semantics. Keep the native container and expose typed gestures,
 * measurement and owner-scoped pointer capture. The tradeoff is explicit caller
 * responsibility for its role and focusability. An explicit highlighted state
 * paints one shared outline around the region's complete content, so composites
 * can include independent trailing actions.
 * A focusable role-button with an activation command owns Enter on itself;
 * explicit Enter hotkeys may replace, delegate or release it. Structural regions
 * and native descendants retain their
 * declared/browser behavior. Ordinary actions should use Button instead.
 */
export class InteractionRegion extends RenderedElement<ButtonState> {
  readonly element: JSX.Element;
  constructor(props: InteractionRegionProps) {
    super('InteractionRegion', props);
    this.element = renderInteractionRegion(this.capture(props));
  }
  static View = (props: InteractionRegionProps): JSX.Element => new InteractionRegion(props).element;
}
