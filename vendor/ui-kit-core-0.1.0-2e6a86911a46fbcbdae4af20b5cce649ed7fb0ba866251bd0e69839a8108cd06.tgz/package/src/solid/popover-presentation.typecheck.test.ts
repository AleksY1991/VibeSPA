/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import { Popover, type PopoverProps, type PopoverRecipe } from './popover';
import { paint, shape, anchor } from './__popover_imported_presentation__';
declare const construction: Pick<PopoverProps, 'observable' | 'surface' | 'hotkeys'>;
const base: PopoverProps = { ...construction, onOpenChange: () => {}, trigger: () => 'Open', children: () => 'Content' };
const recipes: PopoverRecipe[] = ['popover', 'picker', 'content', 'form', 'actions'];
for (const recipe of recipes) new Popover({ ...base, recipe });
const behavior: PopoverProps = { ...base, fitContentWidth: true, matchTriggerWidth: true, side: 'top', align: 'end', offset: 8, margin: 12, layer: 60, role: 'listbox', 'aria-label': 'Choices', closeOnEscape: false, closeOnOutsidePointerDown: false, closeOnMouseLeave: true };
new Popover(behavior);
// @ts-expect-error recipes are closed compositions
new Popover({ ...base, recipe: 'custom' });
// @ts-expect-error spacing belongs to the recipe
new Popover({ ...base, padding: 'none' });
// @ts-expect-error layout belongs to the recipe
new Popover({ ...base, layout: 'column' });
// @ts-expect-error spacing belongs to the recipe
new Popover({ ...base, gap: 'sm' });
// @ts-expect-error clipping belongs to the recipe
new Popover({ ...base, overflow: 'auto' });
// @ts-expect-error a popup cannot accept arbitrary appearance classes
new Popover({ ...base, class: 'p-12' });
// @ts-expect-error aliases cannot reopen appearance
new Popover({ ...base, className: 'p-12' });
// @ts-expect-error no arbitrary inline appearance
new Popover({ ...base, style: { padding: '8px' } });
// @ts-expect-error private root markers cannot bypass ownership
new Popover({ ...base, 'data-ui-popup': 'custom' });
// @ts-expect-error namespaced style is also owned
new Popover({ ...base, 'style:padding': '8px' });
// @ts-expect-error imported objects cannot escape closed presentation
new Popover({ ...base, ...paint });
// @ts-expect-error imported shape knobs cannot reopen the recipe
new Popover({ ...base, ...shape });
// @ts-expect-error the trigger is placed by its parent rather than a class override
new Popover({ ...base, ...anchor });
`;

it('keeps Popover behavior public while rejecting direct and imported presentation escapes', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/solid/__popover_presentation_typecheck__.ts');
  const importedFilename = path.join(root, 'src/solid/__popover_imported_presentation__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  const fixtures = new Map([[filename, source], [importedFilename, `
    export const paint = { class: 'p-12' };
    export const shape = { padding: 'none' as const, layout: 'column' as const };
    export const anchor = { anchorClass: 'flex-1' };
  `]]);
  host.readFile = file => fixtures.get(path.resolve(file)) ?? read(file);
  host.fileExists = file => fixtures.has(path.resolve(file)) || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30_000);
