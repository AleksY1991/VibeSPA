// @vitest-environment happy-dom
import { createComponent, createEffect, createMemo, createRoot, createSignal, flush, onSettled, untrack } from 'solid-js';
import { render } from '@solidjs/web';
import { describe, expect, it, onTestFinished, vi } from 'vitest';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from '../infrastructure/construction';
import { ElementBinding } from '../infrastructure/element';
import { InteractionEvents } from './interaction-events';

describe('InteractionEvents construction', () => {
  it.each(['effect', 'memo'] as const)('delivers synchronous browser observations without inheriting an outer %s', scope => {
    const snapshots: number[] = [];
    let runs = 0;
    const release = createRoot(dispose => {
      onTestFinished(dispose);
      const [value, setValue] = createSignal(1, { ownedWrite: true });
      const [trigger, setTrigger] = createSignal(false, { ownedWrite: true });
      const observable = constructItem('reentrant observations', item => item.constant('active', true));
      new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [], target: document,
        events: [{ type: 'focusout', handler: () => { snapshots.push(value()); } }] });
      const dispatch = () => { runs++; if (trigger()) document.dispatchEvent(new FocusEvent('focusout')); return runs; };
      const computation = scope === 'memo' ? createMemo(dispatch) : undefined;
      if (scope === 'effect') createEffect(trigger, ready => { if (ready) { runs++; document.dispatchEvent(new FocusEvent('focusout')); } });
      setTrigger(true); flush();
      if (computation) untrack(computation);
      expect(snapshots).toEqual([1]);
      const before = runs;
      setValue(2); flush();
      if (computation) untrack(computation);
      expect(runs).toBe(before);
      return dispose;
    });
    try { expect(snapshots).toEqual([1]); } finally { release(); }
    document.dispatchEvent(new FocusEvent('focusout'));
    expect(snapshots).toEqual([1]);
  });

  it.each(['element', 'document'] as const)('attaches deferred %s events during settled startup and disposes with the control', targetKind => {
    const element = document.createElement('div');
    document.body.append(element);
    const target = targetKind === 'element' ? element : document;
    const delivered = vi.fn();
    let failure: unknown;
    const release = createRoot(dispose => {
      const observable = constructItem('settled events', item => item.constant('active', true));
      const events = new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [],
        target: { kind: 'deferred' }, events: [{ type: 'pointermove', handler: delivered }] });
      onSettled(() => {
        try { events.handle.attach(target); } catch (error) { failure = error; }
        return () => events.handle.detach();
      });
      return dispose;
    });
    try {
      flush();
      expect(failure).toBeUndefined();
      target.dispatchEvent(new PointerEvent('pointermove'));
      expect(delivered).toHaveBeenCalledOnce();
    } finally { release(); element.remove(); }
    target.dispatchEvent(new PointerEvent('pointermove'));
    expect(delivered).toHaveBeenCalledOnce();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'InteractionEvents')).toBe(false);
  });

  it('registers once, observes current activation, and removes the listener with its owner', () => {
    const add = vi.spyOn(document, 'addEventListener');
    const remove = vi.spyOn(document, 'removeEventListener');
    const delivered = vi.fn();
    let setActive!: (active: boolean) => void;
    const release = createRoot(dispose => {
      const [active, write] = createSignal(false); setActive = write;
      const observable = constructItem('events', item => item.observe('active', active));
      new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [], target: document,
        events: [{ type: 'pointerdown', handler: delivered, options: { capture: true } }] });
      return dispose;
    });
    const registrations = () => add.mock.calls.filter(call => call[0] === 'pointerdown');
    expect(registrations()).toHaveLength(1);
    document.dispatchEvent(new PointerEvent('pointerdown')); expect(delivered).not.toHaveBeenCalled();
    setActive(true);
    document.dispatchEvent(new PointerEvent('pointerdown')); expect(delivered).not.toHaveBeenCalled();
    flush();
    document.dispatchEvent(new PointerEvent('pointerdown')); expect(delivered).toHaveBeenCalledOnce();
    for (let count = 0; count < 20; count++) { setActive(false); flush(); setActive(true); flush(); }
    expect(registrations()).toHaveLength(1);
    release();
    expect(remove.mock.calls.some(call => call[0] === 'pointerdown')).toBe(true);
    document.dispatchEvent(new PointerEvent('pointerdown')); expect(delivered).toHaveBeenCalledOnce();
    add.mockRestore(); remove.mockRestore();
  });

  it('reattaches the same deferred handlers without constructing new bindings', () => {
    const first = document.createElement('div'); const second = document.createElement('div');
    document.body.append(first, second);
    const delivered = vi.fn();
    let events!: InteractionEvents;
    const release = createRoot(dispose => {
      const observable = constructItem('deferred events', item => item.constant('active', true));
      events = new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [],
        target: { kind: 'deferred' }, events: [{ type: 'pointermove', handler: delivered }] });
      return dispose;
    });
    try {
      events.handle.attach(first); first.dispatchEvent(new PointerEvent('pointermove'));
      events.handle.attach(second); first.dispatchEvent(new PointerEvent('pointermove'));
      second.dispatchEvent(new PointerEvent('pointermove'));
      expect(delivered).toHaveBeenCalledTimes(2);
      events.handle.detach(); second.dispatchEvent(new PointerEvent('pointermove'));
      expect(delivered).toHaveBeenCalledTimes(2);
    } finally { release(); first.remove(); second.remove(); }
    expect(() => events.handle.attach(first)).toThrow('disposed');
  });

  it('owns one local nonvisual identity for global targets and releases it on detach', () => {
    let events!: InteractionEvents;
    const release = createRoot(dispose => {
      const observable = constructItem('global identity', item => item.constant('active', true));
      events = new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [],
        target: window, events: [{ type: 'resize', handler: () => {} }] });
      return dispose;
    });
    const identities = () => surfaceRegistry.read().activeSurfaces.filter(surface => surface.name === 'InteractionEvents');
    try {
      flush();
      expect(identities()).toHaveLength(1);
      expect(identities()[0]).toMatchObject({ layer: false, keys: [] });
      events.handle.attach(document); flush();
      expect(identities()).toHaveLength(1);
      const element = document.createElement('div');
      document.body.append(element);
      events.handle.attach(element); flush();
      expect(identities()).toHaveLength(1);
      events.handle.attach(window); flush();
      expect(identities()).toHaveLength(1);
      element.remove();
      events.handle.detach();
      expect(identities()).toHaveLength(0);
      flush();
      expect(identities()).toHaveLength(0);
    } finally { release(); }
  });

  it('suspends a retained global observer with its logical parent and restores the same listeners', () => {
    const host = document.createElement('div');
    document.body.append(host);
    const delivered = vi.fn();
    const add = vi.spyOn(window, 'addEventListener');
    const [visible, setVisible] = createSignal(true);
    const release = render(() => {
      const observable = constructItem('parent visibility', item => item.observe('visible', visible));
      const parent = new ElementBinding('event parent', { observable,
        surface: { kind: 'own', name: 'event parent', transparent: false }, hotkeys: [] }, { activeWhen: open => open });
      parent.attach(host);
      const Observer = () => {
        const live = constructItem('child observer', item => item.constant('active', true));
        new InteractionEvents({ observable: live, surface: { kind: 'inherit' }, hotkeys: [],
          target: window, events: [{ type: 'resize', handler: delivered }] });
        return null;
      };
      return parent.provide(() => createComponent(Observer, {}));
    }, host);
    try {
      flush();
      const parent = surfaceRegistry.read().activeSurfaces.find(surface => surface.name === 'event parent');
      expect(surfaceRegistry.read().activeSurfaces.find(surface => surface.name === 'InteractionEvents')?.parentId).toBe(parent?.instanceId);
      window.dispatchEvent(new Event('resize'));
      expect(delivered).toHaveBeenCalledOnce();
      setVisible(false);
      window.dispatchEvent(new Event('resize'));
      expect(delivered).toHaveBeenCalledTimes(2);
      flush();
      window.dispatchEvent(new Event('resize'));
      expect(delivered).toHaveBeenCalledTimes(2);
      setVisible(true);
      window.dispatchEvent(new Event('resize'));
      expect(delivered).toHaveBeenCalledTimes(2);
      flush();
      window.dispatchEvent(new Event('resize'));
      expect(delivered).toHaveBeenCalledTimes(3);
      expect(add.mock.calls.filter(call => call[0] === 'resize')).toHaveLength(1);
    } finally { release(); host.remove(); add.mockRestore(); }
  });

  it('blocks global commands behind a modal while preserving observations and cancellation', () => {
    const command = vi.fn(); const observed = vi.fn(); const cancelled = vi.fn();
    const release = createRoot(dispose => {
      const observable = constructItem('global policies', item => item.constant('active', true));
      new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [], target: document,
        events: [
          { type: 'pointerdown', handler: command },
          { type: 'pointerup', handler: command },
          { type: 'pointercancel', handler: cancelled },
          { type: 'scroll', handler: observed },
        ] });
      return dispose;
    });
    flush();
    document.dispatchEvent(new PointerEvent('pointerdown', { pointerId: 7 }));
    expect(command).toHaveBeenCalledOnce();
    const modal = document.createElement('div'); document.body.append(modal);
    const lease = surfaceRegistry.mountElementLease({ name: 'unrelated modal', element: modal,
      transparent: false, layer: true, modal: true, keys: {} });
    try {
      const blocked = new PointerEvent('pointerup', { pointerId: 7, cancelable: true });
      document.dispatchEvent(blocked);
      document.dispatchEvent(new PointerEvent('pointerdown', { pointerId: 8, cancelable: true }));
      document.dispatchEvent(new Event('scroll'));
      expect(command).toHaveBeenCalledOnce();
      expect(observed).toHaveBeenCalledOnce();
      expect(cancelled).toHaveBeenCalledOnce();
      expect(cancelled.mock.calls[0][0]).toMatchObject({ type: 'pointercancel', pointerId: 7, target: document, currentTarget: document });
      expect(blocked.defaultPrevented).toBe(false);
    } finally { lease.dispose(); modal.remove(); release(); }
  });

  it('keeps once and abort semantics when a denied completion follows its cancellation listener', () => {
    const cancelled = vi.fn(); const aborted = vi.fn();
    const controller = new AbortController();
    const release = createRoot(dispose => {
      const observable = constructItem('cancel policies', item => item.constant('active', true));
      new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [], target: document,
        events: [
          { type: 'pointerup', handler: () => {} },
          { type: 'pointercancel', handler: cancelled, options: { once: true } },
          { type: 'pointercancel', handler: aborted, options: { signal: controller.signal } },
        ] });
      return dispose;
    });
    flush();
    controller.abort();
    const modal = document.createElement('div'); document.body.append(modal);
    const lease = surfaceRegistry.mountElementLease({ name: 'cancel blocking modal', element: modal,
      transparent: false, layer: true, modal: true, keys: {} });
    try {
      document.dispatchEvent(new PointerEvent('pointerup', { pointerId: 1 }));
      document.dispatchEvent(new PointerEvent('pointerup', { pointerId: 1 }));
      document.dispatchEvent(new PointerEvent('pointercancel', { pointerId: 1 }));
      expect(cancelled).toHaveBeenCalledOnce();
      expect(aborted).not.toHaveBeenCalled();
    } finally { lease.dispose(); modal.remove(); release(); }
  });

  it('denies retained hidden or removed element delivery before observer publication', () => {
    const host = document.createElement('div'); document.body.append(host);
    const delivered = vi.fn();
    const release = createRoot(dispose => {
      const observable = constructItem('element lifetime', item => item.constant('active', true));
      new InteractionEvents({ observable, surface: { kind: 'inherit' }, hotkeys: [], target: host,
        events: [{ type: 'pointermove', handler: delivered }, { type: 'scroll', handler: delivered }] });
      return dispose;
    });
    try {
      host.dispatchEvent(new PointerEvent('pointermove'));
      expect(delivered).toHaveBeenCalledOnce();
      host.hidden = true;
      host.dispatchEvent(new PointerEvent('pointermove')); host.dispatchEvent(new Event('scroll'));
      expect(delivered).toHaveBeenCalledOnce();
      host.hidden = false;
      host.dispatchEvent(new Event('scroll'));
      expect(delivered).toHaveBeenCalledTimes(2);
      host.remove();
      host.dispatchEvent(new PointerEvent('pointermove')); host.dispatchEvent(new Event('scroll'));
      expect(delivered).toHaveBeenCalledTimes(2);
    } finally { release(); host.remove(); }
  });
});
