/** @jsxImportSource @solidjs/web */
import './scroll-area.css';

import { RenderedElement } from '../infrastructure/rendered-element';
import { children, createEffect, createSignal, omit, onSettled, untrack } from 'solid-js';
import { Dynamic, type JSX } from '@solidjs/web';

import { cn } from '../lib/utils';
import type { ElementConstruction } from '../contracts/construction';
import type { ScrollAreaControlProps } from '../contracts/scroll-area';
import { ElementBinding } from '../infrastructure/element';
import { guardFocusHandle } from '../infrastructure/activation';
import type { FocusHandle } from '../contracts/controls';

export interface ScrollAreaHandle extends FocusHandle {
  scrollPosition(): { readonly top: number; readonly left: number; readonly height: number; readonly width: number; readonly clientHeight: number; readonly clientWidth: number };
  scrollTo(options: ScrollToOptions): void;
}

export interface ScrollAreaProps extends Omit<ScrollAreaControlProps, 'visible' | 'onElement' | 'onScrollElement'>, ElementConstruction<boolean> {
  readonly onHandle?: (handle: ScrollAreaHandle | undefined) => void;
}

export const SCROLL_KEYS = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End', 'Space', 'Shift+Space'] as const;

/**
 * One native scrolling element owns semantics, references, events and both axes.
 * WA 3.12 exposes a separate shadow scroll region and one orientation; adapting
 * that region cannot preserve every explicit single-element contract. Native
 * overflow keeps descendant text selection and keyboard defaults browser-owned.
 */
function NativeScrollArea(props: ScrollAreaControlProps) {
  const native = omit(props, 'as', 'orientation', 'fill', 'class', 'className', 'children', 'visible', 'onElement', 'onScrollElement');
  // Resolve the child owner outside Dynamic so replacing the semantic host moves
  // the same editor DOM instead of disposing its unsaved browser state.
  const content = children(() => props.children);
  const [host, setHost] = createSignal<HTMLElement>();
  const [mounted, setMounted] = createSignal(false);
  const [overflowing, setOverflowing] = createSignal(false);
  onSettled(() => { setMounted(true); });
  createEffect(() => ({ element: mounted() ? host() : undefined, orientation: props.orientation ?? 'vertical', automatic: props.tabindex === undefined }),
    ({ element, orientation, automatic }) => {
      if (!element || !automatic) return;
      // Keyboard users must be able to enter a scrolling region even without a
      // caller-supplied tab stop. Watch editor growth as well as host resizing.
      const refresh = () => setOverflowing((orientation !== 'horizontal' && element.scrollHeight > element.clientHeight)
        || (orientation !== 'vertical' && element.scrollWidth > element.clientWidth));
      const sizes = new ResizeObserver(refresh);
      const observeContent = () => {
        sizes.disconnect();
        sizes.observe(element);
        for (const child of element.children) sizes.observe(child);
        refresh();
      };
      const changes = new MutationObserver(observeContent);
      changes.observe(element, { childList: true, subtree: true, characterData: true });
      observeContent();
      return () => { sizes.disconnect(); changes.disconnect(); };
    });
  return (
    <Dynamic
      component={props.as ?? 'div'}
      {...native}
      ref={(element: HTMLElement) => { setHost(element); props.onElement?.(element); props.onScrollElement?.(element); }}
      data-ui-scroll-area=""
      data-ui-keyboard-owner={SCROLL_KEYS.join(' ')}
      tabindex={props.tabindex ?? (overflowing() ? 0 : -1)}
      hidden={!props.visible}
      aria-hidden={!props.visible ? 'true' : undefined}
      class={cn(
        props.orientation === 'horizontal'
          ? "ui-scroll-area-horizontal"
          : props.orientation === 'both'
            ? "ui-scroll-area-both"
            : "ui-scroll-area-vertical",
        props.fill && "ui-scroll-area-fill",
        props.class,
        props.className,
      )}
    >
      {content()}
    </Dynamic>
  );
}

function renderScrollArea(props: ScrollAreaProps) {
  const binding = new ElementBinding('ScrollArea', props, {
    nativeKeys: SCROLL_KEYS,
    activeWhen: visible => visible,
  });
  const [scrollElement, setScrollElement] = createSignal<HTMLElement>();
  const [mounted, setMounted] = createSignal(false);
  onSettled(() => { setMounted(true); });
  createEffect(() => [mounted(), scrollElement(), props.onHandle] as const, ([ready, element, callback]) => {
    if (!ready || !element || !callback) return;
    let active = true;
    const current = () => { if (!active) throw new Error('Scroll area handle has been disposed'); return element; };
    untrack(() => callback(guardFocusHandle(binding, Object.freeze({
      focus: (options?: FocusOptions) => current().focus(options),
      blur: () => current().blur(),
      scrollPosition: () => { const node = current(); return { top: node.scrollTop, left: node.scrollLeft, height: node.scrollHeight, width: node.scrollWidth, clientHeight: node.clientHeight, clientWidth: node.clientWidth }; },
      scrollTo: (options: ScrollToOptions) => current().scrollTo(options),
    }))));
    return () => { active = false; untrack(() => callback(undefined)); };
  });
  const presentation = omit(props, 'observable', 'surface', 'hotkeys', 'onHandle');
  return binding.provide(() => <NativeScrollArea {...presentation} visible={binding.active()} onElement={binding.attach} onScrollElement={element => { setScrollElement(element); }} />);
}

export class ScrollArea extends RenderedElement<boolean> {
  readonly element: JSX.Element;
  constructor(props: ScrollAreaProps) {
    super('ScrollArea', props);
    this.element = renderScrollArea(this.capture(props));
  }
  static View = (props: ScrollAreaProps): JSX.Element => new ScrollArea(props).element;
}
