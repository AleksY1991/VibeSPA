import './grid-tooltips.css';

/** Shared AG Grid options; consumers retain ownership of grid data and renderers. */
export const gridTooltipOptions = {
  tooltipShowMode: 'whenTruncated',
  tooltipShowDelay: 300,
  tooltipInteraction: true,
} as const;

export interface GridTooltipValueParams {
  valueFormatted?: unknown;
  value?: unknown;
}

/** Prefer the complete displayed value, including intentional empty formatting. */
export function gridTooltipText(params: GridTooltipValueParams, detail?: string): string {
  const text = String(params.valueFormatted ?? params.value ?? '');
  return detail ? [text, detail].filter(Boolean).join(' ') : text;
}

export interface GridCellTooltipParams {
  setTooltip(value: string, shouldDisplayTooltip?: () => boolean): void;
  eGridCell?: HTMLElement;
}

function isVisible(element: HTMLElement): boolean {
  if (!element.isConnected || element.closest('[hidden], [inert]')) return false;
  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return false;
  const style = element.ownerDocument.defaultView?.getComputedStyle(element);
  return style?.display !== 'none' && style?.visibility !== 'hidden' && style?.visibility !== 'collapse';
}

function isTruncated(element: HTMLElement): boolean {
  return isVisible(element) && (
    element.clientWidth > 0 && element.scrollWidth > element.clientWidth
    || element.clientHeight > 0 && element.scrollHeight > element.clientHeight
  );
}

/**
 * AG Grid 36.2's whenTruncated checks its own text container, including the group
 * wrapper; a custom renderer can truncate a nested span while that container
 * fits. Use AG's public setTooltip predicate to measure the actual
 * rendered text at hover, trading a small subtree measurement for correct group,
 * multiline and resized-cell behavior. Remove this helper when AG can measure
 * arbitrary renderer text descendants through its public truncation option.
 * AG owns hover delay, popup placement, interaction, and renderer lifetime.
 */
export function setGridCellTooltip(
  params: GridCellTooltipParams,
  element: HTMLElement,
  value: string,
  always = false,
): void {
  params.setTooltip(value, () => !params.eGridCell?.matches('.ag-cell-inline-editing, .ag-cell-popup-editing') && isVisible(element) && (
    always || isTruncated(element) || Array.from(element.querySelectorAll<HTMLElement>('*')).some(isTruncated)
  ));
}

/**
 * AG owns construction and lifetime of this passive tooltip component and passes
 * a fresh value through init; there is no independently reactive control or
 * keyboard surface. The stock tooltip limits multiline content, while data-tip
 * is an optional control hint rather than a grid-managed content popup. A native
 * text-only div preserves AG placement and interaction and allows full values to
 * wrap and scroll; the tradeoff is this small, vendor-compatible presentation.
 */
export class GridTooltip {
  private readonly gui = document.createElement('div');

  init(params: { value: unknown }): void {
    this.gui.setAttribute('data-ui-root', '');
    this.gui.setAttribute('data-ui-grid-tooltip', '');
    this.gui.setAttribute('role', 'tooltip');
    // AG has resolved the tooltip value; valueFormatted still describes the cell.
    this.gui.textContent = String(params.value ?? '');
  }

  getGui(): HTMLElement {
    return this.gui;
  }
}
