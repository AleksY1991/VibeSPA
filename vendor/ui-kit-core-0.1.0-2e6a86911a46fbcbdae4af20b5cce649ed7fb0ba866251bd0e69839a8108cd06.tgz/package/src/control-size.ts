/** One size vocabulary for every interactive control. Dimensions live only in
 * control-tokens.css; content layout never selects another ordinary density. */
export const CONTROL_SIZES = ['dense', 'compact', 'standard', 'large'] as const;
export type ControlSize = typeof CONTROL_SIZES[number];

/** Ordinary controls share one default; Settings explicitly selects compact.
 * Coarse pointers and narrow viewports increase only the activation target. */
export const DEFAULT_CONTROL_SIZE: ControlSize = 'dense';
export function controlSize(size?: ControlSize | null): ControlSize {
  return size ?? DEFAULT_CONTROL_SIZE;
}
