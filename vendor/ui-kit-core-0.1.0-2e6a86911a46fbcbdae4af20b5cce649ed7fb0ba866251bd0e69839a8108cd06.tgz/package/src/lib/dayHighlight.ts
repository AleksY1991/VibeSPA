/**
 * THE selection model both range pickers use.
 *
 *   1. Click point A -> unhighlight everything previously highlighted, highlight A
 *   2. Click point B -> highlight B
 *   3. ...and highlight every day between A and B
 *   4. Next click is a first click again
 *
 * All four lines are `clickHighlight()`. It is a pure function of (current
 * highlight, days this click contributes) -> new highlight, so the whole
 * feature is unit-testable without rendering anything. See dayHighlight.test.ts.
 *
 * Day keys are 'yyyy-mm-dd', so `<` and `>` on the raw string IS chronological
 * comparison — no comparator, no Date identity, no timezone arithmetic. It is
 * also the exact shape the date filter already stores, so seeding and
 * committing convert nothing.
 */

import { dayKey, keyToDate, type DayKey } from '../contracts/calendar';
export { dayKey, keyToDate, type DayKey } from '../contracts/calendar';

/**
 * `days` is the highlighted set. `pending` is the one bit the set provably
 * CANNOT encode: click A, then click A again, and the set is `{A}` both times —
 * but the first time the next click must extend, and the second time it must
 * start over. Cardinality cannot tell those apart.
 */
export interface Highlight {
  days: Record<DayKey, true>;
  pending: boolean;
}

/** Earliest and latest of the given keys; ['', ''] for none. */
function extent(keys: DayKey[]): [DayKey, DayKey] {
  if (keys.length === 0) return ['', ''];
  let lo = keys[0];
  let hi = keys[0];
  for (const k of keys) {
    if (k < lo) lo = k;
    if (k > hi) hi = k;
  }
  return [lo, hi];
}

/** Every day from the earliest to the latest key given, inclusive. */
export function spanBetween(keys: DayKey[]): Record<DayKey, true> {
  const days: Record<DayKey, true> = {};
  const [lo, hi] = extent(keys);
  if (!lo) return days;
  // setDate() is calendar arithmetic, so leap days and DST are the platform's job.
  for (const d = keyToDate(lo); ; d.setDate(d.getDate() + 1)) {
    const k = dayKey(d);
    days[k] = true;
    if (k >= hi) return days;
  }
}

/** A finished selection covering the given keys and everything between them. */
export const completed = (keys: DayKey[]): Highlight => ({
  days: spanBetween(keys),
  pending: false,
});

/**
 * Endpoints of the highlight; ['', ''] when nothing is highlighted. '' is not a
 * valid day key, so callers never need an empty-state branch.
 */
export const bounds = (h: Highlight): [DayKey, DayKey] => extent(Object.keys(h.days));

/**
 * THE FEATURE. `clicked` is the days this ONE click contributes: a single key
 * for a day picker, [monday, sunday] for a week picker.
 */
export function clickHighlight(current: Highlight, clicked: DayKey[]): Highlight {
  // Mid-cycle: `current.days` is exactly what the first click contributed, so
  // the union's extent is the span — a backwards second click needs no swap.
  if (current.pending) return completed([...Object.keys(current.days), ...clicked]);
  // New cycle. This value REPLACES the old one, so nothing can survive it.
  return { days: spanBetween(clicked), pending: true };
}
