/**
 * Keeping a floating box inside the window.
 *
 * Every hover popup in the app is `position: fixed` at coordinates the page computed
 * itself — a trigger's `getBoundingClientRect()`, or the raw pointer position. Neither
 * number knows where the window ENDS, so a tooltip on the right-hand properties panel
 * ran off the right edge, one on the bottom-left status pill ran off the bottom, and a
 * three-line hint on a row near the top ran off the top. `overflow` cannot save them:
 * they are portalled to `<body>` precisely so no ancestor can clip them.
 *
 * TWO SHAPES, TWO FUNCTIONS — and the difference is whether the box's size is known.
 *
 *   `fitCenteredBox` — the box is CENTRED on a trigger, so its left edge is
 *     `centre - width/2` and you cannot clamp that without the width. Callers measure
 *     the rendered box once and pass it in.
 *
 *   `fitCursorBox` — the box hangs off the POINTER, so it is anchored by an edge, and
 *     the space available on each side is `cursor → window edge`: exactly computable
 *     with no measurement at all. It returns `right`/`bottom` (not a left computed from
 *     a width) when it flips, plus the `maxWidth`/`maxHeight` that make the flip
 *     truthful. Nothing to measure means nothing to re-measure on a mousemove.
 *
 * Pure functions of numbers in, numbers out — the window is a parameter, never a global
 * read — so the whole edge-of-screen behaviour is unit-testable without a DOM. See
 * viewportFit.test.ts.
 */

/** A measured box. */
export interface FitSize {
  width: number;
  height: number;
}

/** The window, passed in rather than read from `window` so tests can be a table. */
export interface FitViewport {
  width: number;
  height: number;
}

/** A trigger's viewport rect — the `DOMRect` fields actually used, nothing more. */
export interface FitRect {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

export interface FitOptions {
  /** Keep-out band at every window edge. */
  margin?: number;
  /** Distance between the trigger and the box. */
  gap?: number;
}

const DEFAULT_MARGIN = 8;
const DEFAULT_GAP = 8;

const clamp = (v: number, lo: number, hi: number): number => Math.min(Math.max(v, lo), hi);

export interface CenteredPlacement {
  left: number;
  top: number;
  /** Which side of the trigger it ended up on. Callers use it for the arrow/offset. */
  above: boolean;
}

/**
 * Place `box` centred over `anchor`, above it when there is room, below when there is
 * not — and inside the window either way.
 *
 * The old heuristic was `above = rect.top > 44`: a constant standing in for the box's
 * height, which is only right for a one-line tooltip. A three-line hint on a row 60px
 * down passed the test and then drew its top 20px off-screen. Height is a parameter
 * here, so "is there room" is a fact rather than a guess.
 *
 * When NEITHER side fits — a short window, a tall box — it takes the roomier side and
 * clamps into the window rather than honouring the gap. A box pinned to the edge is
 * readable; one hanging off it is not. The horizontal clamp has the same fallback: a box
 * wider than the window sits at `margin` (its overflow is then the caller's `maxWidth`
 * problem, which is why both callers cap theirs at `window - 2 * margin`).
 */
export function fitCenteredBox(
  box: FitSize,
  anchor: FitRect,
  viewport: FitViewport,
  options: FitOptions = {},
): CenteredPlacement {
  const margin = options.margin ?? DEFAULT_MARGIN;
  const gap = options.gap ?? DEFAULT_GAP;

  const centre = (anchor.left + anchor.right) / 2;
  // `Math.max(margin, …)` keeps the range non-empty when the box is wider than the
  // window: clamp(v, 8, 4) would otherwise return the HI bound and push it left of 8.
  const left = clamp(
    centre - box.width / 2,
    margin,
    Math.max(margin, viewport.width - margin - box.width),
  );

  const roomAbove = anchor.top - gap - margin;
  const roomBelow = viewport.height - anchor.bottom - gap - margin;
  const above = roomAbove >= box.height || roomAbove >= roomBelow;

  const top = clamp(
    above ? anchor.top - gap - box.height : anchor.bottom + gap,
    margin,
    Math.max(margin, viewport.height - margin - box.height),
  );

  return { left, top, above };
}

/**
 * A box hanging off the pointer. Exactly one of `left`/`right` and one of `top`/`bottom`
 * is a number; the other is `undefined` so it can be spread straight into a style object.
 */
export interface CursorPlacement {
  left?: number;
  right?: number;
  top?: number;
  bottom?: number;
  maxWidth: number;
  maxHeight: number;
}

export interface CursorFitOptions extends FitOptions {
  /** How far from the pointer the near edge sits. */
  offset?: number;
  /** The box's own preferred cap, before the window has its say. */
  maxWidth?: number;
  maxHeight?: number;
}

/**
 * Place a box next to `(x, y)` — down-right of the pointer by default, flipped to the
 * other side of it on either axis when that side is roomier.
 *
 * NO MEASUREMENT. The near edge is pinned to the pointer, so the far edge is bounded by
 * `maxWidth`/`maxHeight` — and those are returned as the space actually available on the
 * chosen side. The box therefore cannot overflow even on the first frame, which matters
 * because this one moves with the mouse and a measure-then-correct pass would be a
 * visible wobble at 60fps.
 *
 * Flipping is by ROOM, not by screen half: at `x = 300` in a 1600px window the pointer is
 * left of centre but the right side still has 1290px, so it stays put. The flip fires
 * only when the far side genuinely holds more.
 */
export function fitCursorBox(
  x: number,
  y: number,
  viewport: FitViewport,
  options: CursorFitOptions = {},
): CursorPlacement {
  const margin = options.margin ?? DEFAULT_MARGIN;
  const offset = options.offset ?? 12;
  const capW = options.maxWidth ?? Infinity;
  const capH = options.maxHeight ?? Infinity;

  const roomRight = viewport.width - x - offset - margin;
  const roomLeft = x - offset - margin;
  const flipX = roomRight < Math.min(capW, roomLeft);

  const roomBelow = viewport.height - y - offset - margin;
  const roomAbove = y - offset - margin;
  const flipY = roomBelow < Math.min(capH, roomAbove);

  return {
    left: flipX ? undefined : x + offset,
    right: flipX ? viewport.width - (x - offset) : undefined,
    top: flipY ? undefined : y + offset,
    bottom: flipY ? viewport.height - (y - offset) : undefined,
    // `Math.max(0, …)` rather than a negative width: a pointer parked in the margin
    // itself makes both rooms negative, and a negative max-width is ignored by CSS —
    // i.e. it would silently restore the unbounded box this call exists to bound.
    maxWidth: Math.max(0, Math.min(capW, flipX ? roomLeft : roomRight)),
    maxHeight: Math.max(0, Math.min(capH, flipY ? roomAbove : roomBelow)),
  };
}
