import { describe, it, expect } from 'vitest';
import { fitCenteredBox, fitCursorBox, type FitRect } from './viewportFit';

/** A 1280x800 window, the app's design size. */
const VP = { width: 1280, height: 800 };

/** A trigger rect from its top-left corner and size — DOMRect's four used fields. */
const rect = (left: number, top: number, width: number, height: number): FitRect => ({
  left,
  top,
  right: left + width,
  bottom: top + height,
});

/** The invariant the whole module exists for: nothing crosses a window edge. */
const inside = (
  left: number,
  top: number,
  size: { width: number; height: number },
  margin = 8,
) => {
  expect(left).toBeGreaterThanOrEqual(margin);
  expect(top).toBeGreaterThanOrEqual(margin);
  expect(left + size.width).toBeLessThanOrEqual(VP.width - margin);
  expect(top + size.height).toBeLessThanOrEqual(VP.height - margin);
};

describe('fitCenteredBox — a tooltip centred on its trigger', () => {
  const box = { width: 200, height: 28 };

  it('centres above the trigger when nothing is in the way', () => {
    const p = fitCenteredBox(box, rect(600, 400, 80, 24), VP);
    expect(p).toEqual({ left: 540, top: 364, above: true }); // 640 - 100, 400 - 8 - 28
    inside(p.left, p.top, box);
  });

  it('clamps at the RIGHT edge instead of running off it', () => {
    // Trigger 20px from the right edge: centred would be left = 1250 - 100 = 1150,
    // whose right edge is 1350 — 70px past the window.
    const p = fitCenteredBox(box, rect(1220, 400, 60, 24), VP);
    expect(p.left).toBe(1072); // 1280 - 8 - 200
    inside(p.left, p.top, box);
  });

  it('clamps at the LEFT edge instead of running off it', () => {
    const p = fitCenteredBox(box, rect(0, 400, 60, 24), VP);
    expect(p.left).toBe(8);
    inside(p.left, p.top, box);
  });

  it('flips BELOW when the trigger is against the top', () => {
    const p = fitCenteredBox(box, rect(600, 4, 80, 24), VP);
    expect(p.above).toBe(false);
    expect(p.top).toBe(36); // 28 + 8
    inside(p.left, p.top, box);
  });

  it('flips below for a TALL box the old `top > 44` heuristic would have kept above', () => {
    const tall = { width: 200, height: 90 }; // a three-line hint
    const p = fitCenteredBox(tall, rect(600, 60, 80, 24), VP);
    expect(p.above).toBe(false); // 60 - 8 - 8 = 44px of room, box needs 90
    expect(p.top).toBe(92);
    inside(p.left, p.top, tall);
  });

  it('stays above a trigger near the BOTTOM — the status pill case', () => {
    const p = fitCenteredBox(box, rect(12, 742, 64, 50), VP);
    expect(p.above).toBe(true);
    expect(p.top).toBe(706); // 742 - 8 - 28
    expect(p.left).toBe(8); // clamped: centre 44 would put it at -56
    inside(p.left, p.top, box);
  });

  it('takes the roomier side and clamps when NEITHER side fits', () => {
    const huge = { width: 200, height: 700 };
    const p = fitCenteredBox(huge, rect(600, 300, 80, 24), VP);
    expect(p.above).toBe(false); // 476 below vs 284 above
    expect(p.top).toBe(92); // clamped: 332 would overflow the bottom
    inside(p.left, p.top, huge);
  });

  it('pins a box WIDER than the window to the left margin, never past it', () => {
    const wide = { width: 1400, height: 28 };
    const p = fitCenteredBox(wide, rect(600, 400, 80, 24), VP);
    expect(p.left).toBe(8); // not the negative HI bound of the clamp
  });

  it('honours a custom margin and gap', () => {
    const p = fitCenteredBox(box, rect(1220, 400, 60, 24), VP, { margin: 16, gap: 4 });
    expect(p.left).toBe(1064); // 1280 - 16 - 200
    expect(p.top).toBe(368); // 400 - 4 - 28
  });
});

describe('fitCursorBox — a box hanging off the pointer', () => {
  const opts = { maxWidth: 320, maxHeight: 200 };

  it('sits down-right of the pointer with room to spare', () => {
    const p = fitCursorBox(400, 300, VP, opts);
    expect(p.left).toBe(412);
    expect(p.top).toBe(312);
    expect(p.right).toBeUndefined();
    expect(p.bottom).toBeUndefined();
    expect(p.maxWidth).toBe(320); // its own cap, not the 860px of room
    expect(p.maxHeight).toBe(200);
  });

  it('flips to the LEFT of the pointer near the right edge', () => {
    const p = fitCursorBox(1240, 300, VP, opts);
    expect(p.left).toBeUndefined();
    expect(p.right).toBe(52); // 1280 - (1240 - 12)
    expect(p.maxWidth).toBe(320); // 1220 of room on the left, capped
  });

  it('flips ABOVE the pointer near the bottom edge', () => {
    const p = fitCursorBox(400, 780, VP, opts);
    expect(p.top).toBeUndefined();
    expect(p.bottom).toBe(32); // 800 - (780 - 12)
    expect(p.maxHeight).toBe(200);
  });

  it('flips both axes in the bottom-right corner', () => {
    const p = fitCursorBox(1270, 795, VP, opts);
    expect(p.left).toBeUndefined();
    expect(p.top).toBeUndefined();
    expect(p.right).toBe(22);
    expect(p.bottom).toBe(17);
  });

  it('narrows rather than flipping when the near side is still the roomier one', () => {
    // A 600px window with the pointer just left of centre: 290px of room right, 270 left.
    // The right side no longer holds the 320px cap, but flipping would make it WORSE.
    const p = fitCursorBox(290, 300, { width: 600, height: 800 }, opts);
    expect(p.left).toBe(302);
    expect(p.right).toBeUndefined();
    expect(p.maxWidth).toBe(290); // 600 - 290 - 12 - 8
  });

  it('does not flip merely because the pointer is past the screen centre', () => {
    const p = fitCursorBox(900, 300, VP, opts);
    expect(p.left).toBe(912); // 360px of room right ≥ the 320 cap
    expect(p.maxWidth).toBe(320);
  });

  it('reports maxWidth 0 — never a negative CSS value — with the pointer in the margin', () => {
    const p = fitCursorBox(1279, 799, VP, opts);
    expect(p.maxWidth).toBeGreaterThanOrEqual(0);
    expect(p.maxHeight).toBeGreaterThanOrEqual(0);
  });

  it('keeps the box inside the window on every axis, swept across it', () => {
    for (let x = 0; x <= VP.width; x += 37) {
      for (let y = 0; y <= VP.height; y += 41) {
        const p = fitCursorBox(x, y, VP, opts);
        const left = p.left ?? VP.width - (p.right ?? 0) - p.maxWidth;
        const top = p.top ?? VP.height - (p.bottom ?? 0) - p.maxHeight;
        expect(left + p.maxWidth).toBeLessThanOrEqual(VP.width);
        expect(top + p.maxHeight).toBeLessThanOrEqual(VP.height);
      }
    }
  });
});
