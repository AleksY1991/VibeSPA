import { describe, it, expect } from 'vitest';
import {
  bounds,
  clickHighlight,
  completed,
  dayKey,
  keyToDate,
  spanBetween,
  type Highlight,
} from './dayHighlight';

/** Assert on the COMPLETE key set, so leftover highlight is a failure rather
 *  than something you have to go looking for. */
const keys = (h: Highlight) => Object.keys(h.days).sort();

/** What one week click contributes: [monday, sunday]. */
const week = (mon: string, sun: string) => [mon, sun];

describe('clickHighlight — the four rules', () => {
  it('1. click A unhighlights everything previous, then highlights A', () => {
    const previous = completed(['2026-01-01', '2026-01-31']);
    expect(keys(previous)).toHaveLength(31);

    const h = clickHighlight(previous, ['2026-07-06']);
    expect(keys(h)).toEqual(['2026-07-06']); // exact set: no residue possible
    expect(h.pending).toBe(true);
  });

  it('2 + 3. click B highlights B and every day between A and B', () => {
    let h = clickHighlight(completed([]), ['2026-07-06']);
    h = clickHighlight(h, ['2026-07-09']);

    expect(keys(h)).toEqual(['2026-07-06', '2026-07-07', '2026-07-08', '2026-07-09']);
    expect(h.pending).toBe(false);
    expect(bounds(h)).toEqual(['2026-07-06', '2026-07-09']);
  });

  it('4. the next click starts over', () => {
    let h = clickHighlight(completed([]), ['2026-07-06']);
    h = clickHighlight(h, ['2026-07-09']);
    h = clickHighlight(h, ['2026-07-20']);

    expect(keys(h)).toEqual(['2026-07-20']);
    expect(h.pending).toBe(true);
  });

  it('a backwards second click swaps instead of rejecting', () => {
    let h = clickHighlight(completed([]), ['2026-07-20']);
    h = clickHighlight(h, ['2026-07-18']);
    expect(keys(h)).toEqual(['2026-07-18', '2026-07-19', '2026-07-20']);
  });

  it('clicking A twice completes a one-day span; the third click restarts', () => {
    // The set is {A} after both clicks — only `pending` tells them apart, which
    // is why the phase cannot be derived from set size.
    let h = clickHighlight(completed([]), ['2026-07-06']);
    h = clickHighlight(h, ['2026-07-06']);
    expect(h.pending).toBe(false);

    h = clickHighlight(h, ['2026-07-09']);
    expect(keys(h)).toEqual(['2026-07-09']);
  });
});

describe('week granularity — same function, [monday, sunday] per click', () => {
  it('one click highlights the whole week', () => {
    const h = clickHighlight(completed([]), week('2026-06-29', '2026-07-05'));
    expect(keys(h)).toHaveLength(7);
    expect(bounds(h)).toEqual(['2026-06-29', '2026-07-05']);
  });

  it('two clicks span whole weeks, in either direction', () => {
    let fwd = clickHighlight(completed([]), week('2026-06-29', '2026-07-05'));
    fwd = clickHighlight(fwd, week('2026-07-13', '2026-07-19'));

    let back = clickHighlight(completed([]), week('2026-07-13', '2026-07-19'));
    back = clickHighlight(back, week('2026-06-29', '2026-07-05'));

    expect(keys(fwd)).toHaveLength(21);
    expect(keys(back)).toEqual(keys(fwd));
    expect(bounds(fwd)).toEqual(['2026-06-29', '2026-07-19']);
  });

  it('a third week click wipes the previous window', () => {
    let h = clickHighlight(completed([]), week('2026-06-29', '2026-07-05'));
    h = clickHighlight(h, week('2026-07-13', '2026-07-19'));
    h = clickHighlight(h, week('2026-07-27', '2026-08-02'));

    expect(keys(h)).toHaveLength(7);
    expect(bounds(h)).toEqual(['2026-07-27', '2026-08-02']);
  });
});

describe('hybrid — day clicks and week clicks in the SAME cycle', () => {
  // The ONLY difference between the two click targets is what they contribute.
  const W28 = week('2026-07-06', '2026-07-12');
  const W29 = week('2026-07-13', '2026-07-19');

  it('day -> day: an exact span, no week snapping', () => {
    let h = clickHighlight(completed([]), ['2026-07-08']);
    h = clickHighlight(h, ['2026-07-10']);
    expect(keys(h)).toEqual(['2026-07-08', '2026-07-09', '2026-07-10']);
    expect(bounds(h)).toEqual(['2026-07-08', '2026-07-10']);
  });

  it('day -> week number: exact start, week-aligned end', () => {
    let h = clickHighlight(completed([]), ['2026-07-08']);
    h = clickHighlight(h, W29);
    expect(bounds(h)).toEqual(['2026-07-08', '2026-07-19']);
    expect(keys(h)).toHaveLength(12);
  });

  it('week number -> day: week-aligned start, exact end', () => {
    let h = clickHighlight(completed([]), W28);
    expect(keys(h)).toHaveLength(7); // one tap already covers the week
    h = clickHighlight(h, ['2026-07-22']);
    expect(bounds(h)).toEqual(['2026-07-06', '2026-07-22']);
    expect(keys(h)).toHaveLength(17);
  });

  it('week number -> week number: whole weeks, exactly as before', () => {
    let h = clickHighlight(completed([]), W28);
    h = clickHighlight(h, W29);
    expect(bounds(h)).toEqual(['2026-07-06', '2026-07-19']);
    expect(keys(h)).toHaveLength(14);
  });

  it('a week click cannot be shortened from inside — it CONTRIBUTED the Sunday', () => {
    // The one non-obvious combination, pinned so it cannot drift by accident:
    // clicking a week asserts the whole week is in, so a day inside adds nothing.
    let h = clickHighlight(completed([]), W28);
    h = clickHighlight(h, ['2026-07-08']); // Wednesday of W28
    expect(bounds(h)).toEqual(['2026-07-06', '2026-07-12']);
  });

  it('a day click is absorbed by a following week click that contains it', () => {
    let h = clickHighlight(completed([]), ['2026-07-08']);
    h = clickHighlight(h, W28);
    expect(bounds(h)).toEqual(['2026-07-06', '2026-07-12']);
  });

  it('mixed clicks span backwards without a swap', () => {
    let h = clickHighlight(completed([]), ['2026-07-22']);
    h = clickHighlight(h, W28);
    expect(bounds(h)).toEqual(['2026-07-06', '2026-07-22']);
  });

  it('a third click starts over regardless of which target it was', () => {
    let h = clickHighlight(completed([]), W28);
    h = clickHighlight(h, ['2026-07-22']);
    h = clickHighlight(h, ['2026-08-03']);
    expect(keys(h)).toEqual(['2026-08-03']);
    expect(h.pending).toBe(true);
  });
});

describe('spanBetween — calendar arithmetic', () => {
  it('crosses a year boundary', () => {
    expect(Object.keys(spanBetween(['2026-12-30', '2027-01-02']))).toEqual([
      '2026-12-30',
      '2026-12-31',
      '2027-01-01',
      '2027-01-02',
    ]);
  });

  it('crosses DST transitions without dropping or duplicating a day', () => {
    expect(Object.keys(spanBetween(['2026-03-06', '2026-03-10']))).toHaveLength(5);
    expect(Object.keys(spanBetween(['2026-10-30', '2026-11-03']))).toHaveLength(5);
  });

  it('includes a leap day', () => {
    expect(Object.keys(spanBetween(['2028-02-27', '2028-03-01']))).toEqual([
      '2028-02-27',
      '2028-02-28',
      '2028-02-29',
      '2028-03-01',
    ]);
  });

  it('is empty for no keys, and bounds() reports that as ["", ""]', () => {
    expect(spanBetween([])).toEqual({});
    expect(bounds(completed([]))).toEqual(['', '']);
  });

  it('round-trips Date <-> key', () => {
    expect(dayKey(keyToDate('2026-07-06'))).toBe('2026-07-06');
  });
});
