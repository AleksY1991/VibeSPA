/** Read-only integration capability for owned application compositions. */
export { controlImplementation } from './implementation-context';
export type { PreparedImplementation } from './implementation-context';
