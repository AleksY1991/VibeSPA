/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createRoot, flush } from 'solid-js';
import { afterEach, expect, it, vi } from 'vitest';
import type { Observable } from '../contracts/construction';
import { Button, type ButtonState } from '../solid/button';
import { Card } from '../solid/controls';
import { TextField } from '../solid/text-field';
import { attachDispatcher, surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from './construction';
import { ImplementationContext, type PreparedImplementation } from './implementation-context';

const disposers: Array<() => void> = [];
afterEach(() => {
  for (const dispose of disposers.splice(0).reverse()) dispose();
  document.body.replaceChildren();
});

it('rejects an unprepared vendor control with an actionable bootstrap error', () => {
  createRoot(dispose => {
    try {
      const observable = constructItem('canonical.unprepared', item => item.constant('value', 'Current text'));
      expect(() => new TextField({
        observable, surface: { kind: 'inherit' }, hotkeys: [], label: 'Name', onValueChange: vi.fn(),
      })).toThrow('TextField: prepare the application implementation before rendering this control');
      flush();
      expect(surfaceRegistry.read().activeSurfaces).toEqual([]);
    } finally { dispose(); }
  });
});

it('keeps native controls independent of vendor preparation while preserving their contracts', () => {
  const implementation: PreparedImplementation = {};
  const activated = vi.fn();
  const shortcut = vi.fn();
  const releaseSource = vi.fn();
  let publish!: (state: ButtonState) => void;
  const subscribe = vi.fn((listener: (state: ButtonState) => void) => {
    publish = listener;
    return releaseSource;
  });
  const host = document.createElement('div');
  document.body.append(host);
  function Controls() {
    const values = constructItem('canonical.native', item => ({
      visible: item.constant('visible', true),
      state: item.source<ButtonState>('state', { peek: () => ({ pressed: false }), subscribe }),
    }));
    return <Card.View observable={values.visible}
      surface={{ kind: 'own', name: 'canonical.parent', transparent: false }} hotkeys={[]}>
      <Button.View observable={values.state} surface={{ kind: 'inherit' }}
        hotkeys={[{ key: 'Ctrl+Enter', handler: shortcut }]} onActivate={activated}>Save</Button.View>
    </Card.View>;
  }
  const dispose = render(() => <ImplementationContext value={implementation}><Controls /></ImplementationContext>, host);
  disposers.push(dispose, attachDispatcher({
    window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
    runtime: () => ({ editing: false, keyboardLayer: null }),
  }));
  flush();
  const button = host.querySelector<HTMLButtonElement>('button')!;
  expect(button).not.toBeNull();
  expect(host.querySelector('wa-button, wa-card')).toBeNull();
  expect(subscribe).toHaveBeenCalledOnce();
  expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'canonical.parent')).toBe(true);
  button.click();
  expect(activated).toHaveBeenCalledOnce();
  const key = new KeyboardEvent('keydown', { key: 'Enter', ctrlKey: true, bubbles: true, composed: true, cancelable: true });
  button.dispatchEvent(key);
  expect(shortcut).toHaveBeenCalledOnce();
  expect(key.defaultPrevented).toBe(true);

  publish({ disabled: true, pressed: true });
  flush();
  expect(host.querySelector('button')).toBe(button);
  expect(button.disabled).toBe(true);
  expect(button.getAttribute('aria-pressed')).toBe('true');
  button.click();
  expect(activated).toHaveBeenCalledOnce();
  expect(subscribe).toHaveBeenCalledOnce();

  dispose();
  flush();
  expect(releaseSource).toHaveBeenCalledOnce();
  expect(surfaceRegistry.read().activeSurfaces).toEqual([]);
  publish({ pressed: false });
  flush();
  expect(button.getAttribute('aria-pressed')).toBe('true');
});

it('requires a registered observable even for native controls', () => {
  createRoot(dispose => {
    try {
      expect(() => new Button({
        observable: { read: () => ({}) } as Observable<ButtonState>,
        surface: { kind: 'inherit' }, hotkeys: [],
      })).toThrow('registered observable');
    } finally { dispose(); }
  });
});
