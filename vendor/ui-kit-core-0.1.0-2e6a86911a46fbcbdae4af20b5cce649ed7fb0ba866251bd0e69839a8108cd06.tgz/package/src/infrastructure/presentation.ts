import { untrack } from 'solid-js';
import type { ControlPlacement } from '../contracts/presentation';

const stylingProps = ['class', 'className', 'classList', 'style'] as const;
const placementKeys = new Set([
  'width', 'min-width', 'max-width', 'inline-size', 'min-inline-size', 'max-inline-size', 'margin', 'margin-left', 'margin-right', 'margin-top', 'margin-bottom',
  'margin-inline', 'margin-inline-start', 'margin-inline-end', 'margin-block', 'margin-block-start', 'margin-block-end',
  'position', 'left', 'right', 'top', 'bottom', 'inset', 'inset-inline', 'inset-inline-start', 'inset-inline-end',
  'inset-block', 'inset-block-start', 'inset-block-end', 'z-index', 'flex', 'flex-grow', 'flex-shrink', 'flex-basis',
  'align-self', 'justify-self', 'order', 'grid-column', 'grid-row', 'grid-area',
]);

/** Public controls own their presentation, including untyped or forged input. */
export function assertControlPresentation(name: string, props: object, reserved: readonly string[] = []): void {
  // Merged Solid props can evaluate a dynamic spread during structural inspection.
  // This construction check must not consume or subscribe to presentation values.
  untrack(() => {
    for (const key of [...stylingProps, ...reserved]) {
      if (key in props) throw new TypeError(`${name}: ${key} is owned by the control's presentation; use a recipe or outer placement`);
    }
    for (const key of Object.keys(props)) {
      if (/^(?:(?:attr|prop):)?(?:class|className|classList|style)(?::|$)/.test(key)
        || /^(?:(?:attr|prop):)?data-(?:ui|wa)-/.test(key) || /^(?:prop:)?dataset$/.test(key)) {
        throw new TypeError(`${name}: ${key} cannot bypass the closed presentation contract`);
      }
    }
  });
}

/** Validate outer placement without converting presentation getters into snapshots. */
export function controlPlacement(name: string, placement: ControlPlacement | undefined): ControlPlacement | undefined {
  return untrack(() => {
    if (placement === undefined) return undefined;
    if (!placement || typeof placement !== 'object' || Array.isArray(placement)) {
      throw new TypeError(`${name}: placement must be an outer-placement object`);
    }
    for (const key of Object.keys(placement)) {
      if (!placementKeys.has(key)) throw new TypeError(`${name}: placement cannot override ${key}; control appearance belongs to its recipe`);
    }
    return placement;
  });
}
