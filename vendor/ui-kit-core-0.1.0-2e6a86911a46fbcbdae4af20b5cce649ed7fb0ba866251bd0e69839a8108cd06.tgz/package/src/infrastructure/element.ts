import { createComponent, createEffect, createMemo, getOwner, latest, onCleanup, untrack, type Accessor } from 'solid-js';
import type { JSX } from '@solidjs/web';
import { HOTKEY_DELEGATE, HOTKEY_PASS, type SurfaceAuthority, type SurfaceHotkeyHandler } from '../contracts/platform';
import { nativeOwnsCombo } from '../contracts/platform';
import { hotkeys, type HotkeyBinding } from '../runtime/hotkeys';
import { HotkeyElementContext, type HotkeyElementContextValue } from '../runtime/context';
import type { ElementConstruction } from '../contracts/construction';
import { elementConstruction } from './element-construction';
import { surfaceLineage } from './surface-lineage';
import { allowNativeActivation, eventScope } from './activation';

export interface ElementBindingOptions<T> {
  readonly nativeKeys?: readonly string[];
  readonly builtins?: Readonly<Record<string, SurfaceHotkeyHandler>>;
  /** Built-in behavior that takes precedence over an ancestor's native keys. */
  readonly nativeOverrides?: readonly string[];
  readonly active?: Accessor<boolean>;
  readonly activeWhen?: (value: T) => boolean;
  /** Disabled controls remain surfaces but cannot execute custom commands. */
  readonly enabledWhen?: (value: T) => boolean;
  /** Activation may be read-only while inspection/navigation keys remain enabled. */
  readonly activationWhen?: (value: T) => boolean;
  /** Cancel native click activation when this actionable control lacks authority. */
  readonly nativeActivation?: boolean;
  /** Switching modality changes arbitration without rebuilding the control. */
  readonly layer?: Accessor<boolean>;
  readonly dismissable?: boolean | Accessor<boolean>;
  readonly modal?: boolean | Accessor<boolean>;
  /** External triggers explicitly related to this surface's activation policy. */
  readonly activationRoots?: Accessor<readonly Element[]>;
  /** Focus containment is independent of descendant dismissal/key ownership. */
  readonly focusKeys?: Readonly<Record<string, SurfaceHotkeyHandler>>;
}

export interface ElementScopeOptions {
  /** A retained subsection can be hidden independently of its owning host. */
  readonly active?: Accessor<boolean>;
  /** Declare direct child controls to be this composite's native internals. */
  readonly nativeChildren?: boolean;
}

/** A control captures its read binding and keyboard policy once, during construction. */
export class ElementBinding<T> {
  readonly value: Accessor<T>;
  readonly attach: (element: Element) => void;
  readonly attachNative: (element: Element) => void;
  readonly attachNonvisual: (target: EventTarget) => void;
  readonly detach: () => void;
  readonly active: Accessor<boolean>;
  /** Actual rendered host lifetime; use for browser effects, never its Show gate. */
  readonly lifetime: Accessor<boolean>;
  readonly context: HotkeyElementContextValue;
  readonly authority: () => SurfaceAuthority | undefined;
  readonly canActivate: () => boolean;
  readonly isLive: () => boolean;
  readonly isDisposed: () => boolean;
  readonly provide: (render: () => JSX.Element, options?: ElementScopeOptions) => JSX.Element;

  constructor(name: string, props: ElementConstruction<T>, options: ElementBindingOptions<T> = {}) {
    const construction = elementConstruction(name, props);
    this.value = construction.read;
    const surface = construction.surface;
    const bindings = construction.hotkeys;
    // Escape leaves a control through its declared owner. Native controls that
    // own Escape explicitly reserve it; Enter/Space keep their native semantics.
    const handlers: Record<string, SurfaceHotkeyHandler> = { ...options.builtins };
    const nativeOverrides: string[] = [...options.nativeOverrides ?? []];
    for (const binding of bindings) {
      if (nativeOwnsCombo(binding.key, options.nativeKeys ?? []) && !binding.overrideNative) {
        throw new Error(`${name}: ${binding.key} is native-owned; overriding it must be explicit`);
      }
      if (binding.overrideNative) nativeOverrides.push(binding.key);
      const builtin = handlers[binding.key];
      const custom: SurfaceHotkeyHandler = eventScope((event: KeyboardEvent, element: Element) => {
        if (!options.enabledWhen || options.enabledWhen(this.value())) return binding.handler(event, element);
        return !builtin && binding.key === 'Escape' && !options.nativeKeys?.includes('Escape')
          ? HOTKEY_DELEGATE : HOTKEY_PASS;
      });
      handlers[binding.key] = builtin
        ? eventScope((event: KeyboardEvent, element: Element) => {
          const result = custom(event, element);
          return result === HOTKEY_PASS ? builtin(event, element) : result;
        })
        : custom;
    }
    if (!handlers.Escape && !options.nativeKeys?.includes('Escape')) handlers.Escape = () => HOTKEY_DELEGATE;
    const names = surfaceLineage(surface, name);
    const registrations: HotkeyBinding[] = [];
    for (const [index, publicName] of names.entries()) {
      const outermost = index === 0;
      const terminal = index === names.length - 1;
      registrations.push(hotkeys({
        name: outermost && surface.kind === 'own' ? surface.name : publicName,
        // Forwarding keeps the caller's unhandled-key policy at every identity,
        // including the terminal that owns global layer arbitration.
        transparent: surface.kind === 'own' && surface.transparent,
        delegate: surface.kind === 'inherit' || (!outermost && !surface.transparent) ? 'all' : undefined,
        layer: terminal ? options.layer ?? (surface.kind === 'own' ? surface.layer : undefined) : false,
        dismissable: terminal ? options.dismissable : false,
        modal: terminal ? options.modal : false,
        activationRoots: terminal ? options.activationRoots : undefined,
        active: outermost && (options.activeWhen || options.active)
          ? () => (options.active?.() ?? true) && (options.activeWhen?.(this.value()) ?? true)
          : undefined,
        keys: terminal ? handlers : { Escape: () => HOTKEY_DELEGATE },
        nativeOverrides: terminal ? nativeOverrides : undefined,
        focusKeys: terminal ? options.focusKeys : undefined,
        parent: registrations.at(-1)?.context,
      }));
    }
    const register = registrations.at(-1)!;
    let nativeActivationHost: Element | undefined;
    const guardNativeActivation: EventListener = eventScope((event: Event) => { allowNativeActivation(this, event); });
    onCleanup(() => { nativeActivationHost?.removeEventListener('click', guardNativeActivation, true); });
    this.attach = element => {
      for (const registration of registrations) registration(element);
      if (options.nativeActivation && nativeActivationHost !== element) {
        nativeActivationHost?.removeEventListener('click', guardNativeActivation, true);
        nativeActivationHost = element;
        element.addEventListener('click', guardNativeActivation, true);
      }
    };
    this.attachNonvisual = target => {
      nativeActivationHost?.removeEventListener('click', guardNativeActivation, true);
      nativeActivationHost = undefined;
      for (const registration of registrations) registration.attachNonvisual(target);
    };
    this.detach = () => {
      nativeActivationHost?.removeEventListener('click', guardNativeActivation, true);
      nativeActivationHost = undefined;
      for (const registration of registrations) registration.detach();
    };
    this.active = registrations[0]!.active;
    this.lifetime = register.lifetime;
    this.context = register.context;
    this.authority = register.authority;
    this.isLive = register.isLive;
    this.isDisposed = register.isDisposed;
    this.canActivate = () => register.canActivate() && latest(() => untrack(() =>
      (options.enabledWhen?.(this.value()) ?? true) && (options.activationWhen?.(this.value()) ?? true)));
    this.attachNative = element => {
      const release = register.registerNative(element);
      if (getOwner()) onCleanup(release);
    };
    this.provide = (render, scope = {}) => {
      const listeners = new Set<() => void>();
      let scopeActive = untrack(() => scope.active?.() ?? true);
      let currentActive = register.context.peekActive() && scopeActive;
      // Rendered readers derive directly from both inputs. The imperative cache
      // and notifications below keep surface leases current between flushes.
      const derivedActive = createMemo(() => register.context.active() && (scope.active?.() ?? true), { name: `${name}.scope.active` });
      const active = () => register.active() && derivedActive();
      const publish = () => {
        currentActive = register.context.peekActive() && scopeActive;
        for (const listener of listeners) listener();
      };
      const stop = register.context.subscribe(publish);
      onCleanup(() => { stop(); listeners.clear(); });
      if (scope.active) createEffect(scope.active, next => { scopeActive = next; publish(); });
      const context: HotkeyElementContextValue = {
        active,
        peekActive: () => currentActive,
        instanceId: register.context.instanceId,
        refresh: () => {
          register.context.refresh?.();
          scopeActive = untrack(() => scope.active?.() ?? true);
          publish();
        },
        subscribe(listener) {
          listeners.add(listener);
          return () => { listeners.delete(listener); };
        },
        registerNative: scope.nativeChildren ? register.registerNative : undefined,
      };
      return createComponent(HotkeyElementContext, { value: context, get children() { return render(); } });
    };
  }
}
