import { createEffect, untrack, type Accessor } from 'solid-js';
import type { ElementBinding } from './element';

/** Explicit ownership for a manually positioned popup and its related controls. */
export interface SurfaceInteraction {
  readonly relatedRoots?: (host: HTMLElement) => readonly Element[];
  readonly onOutsideDismiss?: (event: PointerEvent) => void;
}

/**
 * Manual popup frames keep their existing placement while sharing the same
 * dismissal authority as Dialog and Popover. Related roots are an explicit
 * construction declaration; ancestry alone never admits unrelated commands.
 */
export function bindSurfaceInteraction(
  binding: ElementBinding<boolean>,
  host: Accessor<HTMLElement | undefined>,
  interaction: Accessor<SurfaceInteraction | undefined>,
  relatedRoots: Accessor<readonly Element[]>,
): void {
  createEffect(() => ({ live: binding.lifetime(), host: host(), interaction: interaction() }), state => {
    const panel = state.host;
    const dismiss = state.interaction?.onOutsideDismiss;
    if (!state.live || !panel || !dismiss) return;
    const outside = (event: PointerEvent) => {
      const target = event.target;
      const path = event.composedPath();
      if ([panel, ...untrack(relatedRoots)].some(root => path.includes(root) || target instanceof Node && root.contains(target))) return;
      if (binding.authority()?.claimDismissal(event)) dismiss(event);
    };
    panel.ownerDocument.addEventListener('pointerdown', outside, true);
    return () => panel.ownerDocument.removeEventListener('pointerdown', outside, true);
  });
}
