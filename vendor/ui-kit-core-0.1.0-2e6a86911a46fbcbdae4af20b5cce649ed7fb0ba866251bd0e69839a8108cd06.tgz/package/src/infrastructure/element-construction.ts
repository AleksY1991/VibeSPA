import { untrack, type Accessor } from 'solid-js';
import type { ElementConstruction, ElementHotkey } from '../contracts/construction';
import { readObservable } from './construction';
import { captureSurface } from './surface-lineage';

interface CapturedConstruction<T> extends ElementConstruction<T> {
  readonly read: Accessor<T>;
}

// Only immutable construction snapshots enter this registry. Raw caller props
// stay uncached so reusing a mutated container cannot bypass checks.
const surfaces = new WeakMap<object, CapturedConstruction<unknown>>();

function validate<T>(name: string, props: ElementConstruction<T>, appendIdentity = true): CapturedConstruction<T> {
  return untrack(() => {
    const observable = props.observable;
    const read = readObservable(observable);
    const source = props.surface;
    if (!source) throw new TypeError(`${name}: explicit surface ownership is required`);
    // A concrete binding can replace its observable or shortcuts without adding
    // another public identity. Only a previously captured immutable surface may
    // retain its lineage here; every supplied value is still validated below.
    const surface = !appendIdentity && surfaces.has(source) ? source : Object.freeze(captureSurface(source, name));
    if (surface.kind !== 'inherit' && surface.kind !== 'own') {
      throw new TypeError(`${name}: explicit surface ownership is required`);
    }
    if (surface.kind === 'own' && (!surface.name?.trim() || typeof surface.transparent !== 'boolean')) {
      throw new TypeError(`${name}: an owned surface requires a name and unhandled-key policy`);
    }
    const declared = props.hotkeys;
    if (!Array.isArray(declared)) throw new TypeError(`${name}: an explicit hotkeys array is required`);
    const keys = new Set<string>();
    const hotkeys = declared.map(binding => {
      const captured: ElementHotkey = { key: binding?.key, handler: binding?.handler, overrideNative: binding?.overrideNative };
      if (!captured.key?.trim() || typeof captured.handler !== 'function' || keys.has(captured.key)) {
        throw new TypeError(`${name}: custom hotkeys require unique keys and handlers`);
      }
      keys.add(captured.key);
      return Object.freeze(captured);
    });
    return Object.freeze({ observable, read, surface, hotkeys: Object.freeze(hotkeys) });
  });
}

function previousConstruction<T>(props: ElementConstruction<T>): { previous?: CapturedConstruction<T>; inputs: ElementConstruction<T> } {
  // JSX forwarding can assemble a new props object. Trust only the exact three
  // immutable construction values, not the identity of that mutable container.
  const inputs = untrack(() => ({ observable: props.observable, surface: props.surface, hotkeys: props.hotkeys }));
  const inherited = surfaces.get(inputs.surface) as CapturedConstruction<T> | undefined;
  return { inputs, previous: inherited && inherited.observable === inputs.observable && inherited.hotkeys === inputs.hotkeys ? inherited : undefined };
}

/** Read a validated capture, or validate fresh inputs for direct binding users. */
export function elementConstruction<T>(name: string, props: ElementConstruction<T>): CapturedConstruction<T> {
  const { previous, inputs } = previousConstruction(props);
  return previous ?? validate(name, inputs, false);
}

/** Each public wrapper extends surface identity without validating a capture twice. */
export function captureElementConstruction<T>(name: string, props: ElementConstruction<T>): ElementConstruction<T> {
  const { previous, inputs } = previousConstruction(props);
  const captured = previous
    ? Object.freeze({ ...previous, surface: Object.freeze(captureSurface(previous.surface, name)) })
    : validate(name, inputs);
  surfaces.set(captured.surface, captured as CapturedConstruction<unknown>);
  return Object.freeze({ observable: captured.observable, surface: captured.surface, hotkeys: captured.hotkeys });
}
