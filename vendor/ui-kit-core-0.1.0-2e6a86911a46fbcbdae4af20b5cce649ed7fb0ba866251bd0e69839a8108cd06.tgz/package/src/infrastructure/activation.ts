import type { JSX } from '@solidjs/web';
import { merge, untrack } from 'solid-js';
import type { SurfaceAuthority } from '../contracts/platform';
import type { FocusHandle } from '../contracts/controls';

/** The binding supplies live surface authority, including declared ownership. */
export interface ActivationOwner {
  canActivate(): boolean;
}

interface NativeActivationOwner extends ActivationOwner {
  isDisposed(): boolean;
}

interface NativeAdmission {
  readonly owner: NativeActivationOwner;
  readonly event: Event;
  readonly origin: EventTarget;
  readonly boundary: EventTarget;
}

const nativeAdmissions = new WeakMap<object, NativeAdmission>();

/** Only the native capture boundary may admit an originating browser default. */
export function allowNativeActivation(owner: NativeActivationOwner, event: Event): boolean {
  nativeAdmissions.delete(event);
  if (!allowActivation(owner, event)) return false;
  const origin = event.composedPath()[0];
  const boundary = event.currentTarget;
  if (origin && boundary) {
    const admission: NativeAdmission = { owner, event, origin, boundary };
    nativeAdmissions.set(event, admission);
    // Native browser dispatch may run microtasks between capture and bubbling
    // listeners. Keep admission on the weak event key through that dispatch;
    // phase/origin/ancestry checks prevent its use outside the admitted path.
  }
  return true;
}

function hasAdmittedDescendant(owner: ActivationOwner, event: CancellableActivation | undefined): boolean {
  const admission = event && nativeAdmissions.get(event);
  if (!admission || admission.owner === owner || admission.owner.isDisposed()
    || admission.event.eventPhase !== Event.BUBBLING_PHASE) return false;
  const path = admission.event.composedPath();
  const boundaryIndex = path.indexOf(admission.boundary);
  const currentIndex = admission.event.currentTarget ? path.indexOf(admission.event.currentTarget) : -1;
  return path[0] === admission.origin && boundaryIndex >= 0 && currentIndex > boundaryIndex;
}

interface NativeEventOwner extends ActivationOwner {
  isLive(): boolean;
  isDisposed(): boolean;
}

const OBSERVED_EVENTS = new Set(['focus', 'focusin', 'scroll', 'scrollend', 'resize', 'load', 'error',
  'animationstart', 'animationiteration', 'transitionrun', 'transitionstart']);
const CLEANUP_EVENTS = new Set(['blur', 'focusout', 'pointercancel', 'lostpointercapture', 'pointerleave',
  'mouseleave', 'dragleave', 'dragend', 'touchcancel', 'animationend', 'animationcancel', 'transitionend', 'transitioncancel']);

/** Browser focus/cancellation events can fire synchronously during a render or
 * effect. The entire dispatch, including live handler and authority lookup,
 * observes imperative snapshots without inheriting the caller's tracking scope. */
export function eventScope<Args extends readonly unknown[], Result>(
  callback: (...args: Args) => Result,
): (...args: Args) => Result {
  return (...args) => untrack(() => callback(...args));
}

/** Preserve native attributes/reactivity while routing every accepted raw event. */
export function guardNativeEvents<Props extends object>(owner: NativeEventOwner, props: Props): Props {
  const handlers = new Map<PropertyKey, JSX.EventHandler<Element, Event>>();
  // A public attribute facade preserves getters without forwarding Solid's
  // private proxy identity, which would let optimized spreads unwrap the guard.
  return merge(() => {
    const guardedProps = {} as Props;
    for (const property of Object.keys(props)) Object.defineProperty(guardedProps, property, {
      enumerable: true,
      configurable: true,
      get() {
        const value: unknown = Reflect.get(props, property);
        if (!property.startsWith('on') || value == null) return value;
        let guarded = handlers.get(property);
        if (!guarded) {
          guarded = eventScope((event: Event & { currentTarget: Element; target: Element }) => {
            if (owner.isDisposed()) return;
            const handler = Reflect.get(props, property) as JSX.EventHandlerUnion<Element, Event> | undefined;
            if (CLEANUP_EVENTS.has(event.type)) { deliverEvent(handler, event); return; }
            if (OBSERVED_EVENTS.has(event.type)) { if (owner.isLive()) deliverEvent(handler, event); return; }
            if (allowActivation(owner, event)) { deliverEvent(handler, event); return; }
            if (event instanceof PointerEvent && (event.type === 'pointerup' || event.type === 'pointermove')) {
              const cancel = Reflect.get(props, 'onPointerCancel') as JSX.EventHandlerUnion<Element, PointerEvent> | undefined;
              deliverEvent(cancel, pointerCancellation(event));
            }
          });
          handlers.set(property, guarded);
        }
        return guarded;
      },
    });
    return guardedProps;
  }) as Props;
}

export interface FocusOwner {
  isLive(): boolean;
  isDisposed(): boolean;
  authority(): Pick<SurfaceAuthority, 'canMoveFocus'> | undefined;
}

/** Explicit handle focus has the same authority as initial and restored focus. */
export function allowFocus(owner: FocusOwner): boolean {
  return owner.isLive() && (owner.authority()?.canMoveFocus() ?? false);
}

/** Handle delivery observes state; only explicit focus consumes live authority. */
export function guardFocusHandle<Handle extends FocusHandle>(owner: FocusOwner, handle: Handle): Handle {
  return Object.freeze({
    ...handle,
    focus(options?: FocusOptions) {
      if (owner.isDisposed()) throw new Error('Focus handle has been disposed');
      if (allowFocus(owner)) handle.focus(options);
    },
  });
}

interface CancellableActivation {
  preventDefault(): void;
  stopPropagation(): void;
}

/**
 * Native and vendor callbacks share the keyboard surface's command authority.
 * Browsers keep activation, form submission and editing defaults when allowed;
 * an unavailable owner cancels the originating default as well as its command.
 */
export function allowActivation(owner: ActivationOwner, event?: CancellableActivation): boolean {
  if (owner.canActivate()) return true;
  // A denied ancestor command cannot roll back an already admitted child's
  // native toggle/submission. This exception never authorizes that command.
  if (hasAdmittedDescendant(owner, event)) return false;
  event?.preventDefault();
  event?.stopPropagation();
  return false;
}

/** Value-only vendor events retain the same owner check as native DOM events. */
export function surfaceCommand<Args extends readonly unknown[], Result>(
  owner: ActivationOwner,
  command: (...args: Args) => Result,
): (...args: Args) => Result | undefined {
  return eventScope((...args: Args) => allowActivation(owner) ? command(...args) : undefined);
}

/** Native gesture commands retain Solid's function and bound-data handler forms. */
export function surfaceEvent<T extends Element, E extends Event>(
  owner: ActivationOwner,
  handler: JSX.EventHandlerUnion<T, E> | undefined,
): JSX.EventHandler<T, E> {
  return eventScope((event: E & { currentTarget: T; target: Element }) => {
    if (!allowActivation(owner, event)) return;
    deliverEvent(handler, event);
  });
}

/** Cleanup listeners accept the same native handler forms without new admission. */
export function deliverEvent<T extends Element, E extends Event>(
  handler: JSX.EventHandlerUnion<T, E> | undefined,
  event: E & { currentTarget: T; target: Element },
): void {
  untrack(() => {
    if (typeof handler === 'function') handler(event);
    else handler?.[0](handler[1], event);
  });
}

/** A denied gesture completion cancels its draft without delivering a commit. */
export function pointerCancellation<E extends PointerEvent>(event: E): E {
  const cancellation = new PointerEvent('pointercancel', event);
  // This is delivered to an existing owner, not dispatched through the document.
  // Preserve its target identity so cleanup has the same native event contract.
  Object.defineProperties(cancellation, {
    currentTarget: { value: event.currentTarget }, target: { value: event.target },
  });
  return cancellation as E;
}
