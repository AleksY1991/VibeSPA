/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it } from 'vitest';
import { render } from '@solidjs/web';
import { createSignal, flush, useContext } from 'solid-js';
import { surfaceRegistry } from '../../tests/surface-host';

import { ImplementationContext, type PreparedImplementation } from './implementation-context';
import { UiRootImplementation, renderUiRoot, scopedUiMount } from './renderUiRoot';
import { constructItem } from './construction';
import { ModalPortalContext, type ModalPortalScope } from '../solid/portal';
import { ElementBinding } from './element';
import { Button } from '../solid/button';

const cleanups: Array<() => void> = [];
afterEach(() => {
  for (const dispose of cleanups.splice(0).reverse()) dispose();
  document.body.replaceChildren();
});

const implementation: PreparedImplementation = {};

function ScopeProbe() {
  const scope = useContext(ImplementationContext);
  const modal = useContext(ModalPortalContext);
  return <span data-implementation={scope ? 'prepared' : 'native'} data-modal={modal?.mount?.id ?? 'none'} />;
}

function host(): HTMLDivElement {
  const element = document.createElement('div');
  document.body.append(element);
  return element;
}

describe('independent UI root implementation scope', () => {
  it('preserves logical ownership and visibility through an independently owned deferred root', () => {
    const application = host();
    const portal = host();
    const [visible, setVisible] = createSignal(true);
    let mount!: (element: HTMLElement) => () => void;
    function Contribution() {
      mount = scopedUiMount(element => renderUiRoot(() => constructItem('root.child', item => (
        <Button.View observable={item.constant('state', {})}
          surface={{ kind: 'own', name: 'root.child', transparent: false }} hotkeys={[]}>Child</Button.View>
      )), element));
      return null;
    }
    cleanups.push(render(() => constructItem('root.parent', item => {
      const binding = new ElementBinding('root.parent', {
        observable: item.observe('visible', visible), surface: { kind: 'inherit' }, hotkeys: [],
      }, { activeWhen: value => value });
      return binding.provide(() => <section ref={binding.attach}><Contribution /></section>);
    }), application));
    flush();
    cleanups.push(mount(portal));
    flush();
    const parent = surfaceRegistry.read().activeSurfaces.find(surface => surface.name === 'root.parent');
    expect(surfaceRegistry.read().activeSurfaces.find(surface => surface.name === 'root.child')?.parentId)
      .toBe(parent?.instanceId);
    setVisible(false); flush();
    expect(portal.querySelector('button')).not.toBeNull();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'root.child')).toBe(false);
    setVisible(true); flush();
    expect(surfaceRegistry.read().activeSurfaces.some(surface => surface.name === 'root.child')).toBe(true);
  });

  it('constructs a root component outside reactive getters', () => {
    const target = host();
    function Control() {
      const value = constructItem('root.control', item => item.constant('value', 'ready'));
      return <span>{value.read()}</span>;
    }
    cleanups.push(renderUiRoot(Control, target));
    expect(target.textContent).toBe('ready');
  });
  it('inherits prepared controls inside the application host without activating a sibling root', () => {
    const application = host();
    cleanups.push(render(() => <UiRootImplementation host={application} implementation={implementation}>
      <div data-child-host />
    </UiRootImplementation>, application));
    const child = application.querySelector<HTMLElement>('[data-child-host]')!;
    const sibling = host();
    cleanups.push(renderUiRoot(ScopeProbe, child), renderUiRoot(ScopeProbe, sibling));
    expect(child.querySelector('span')?.dataset.implementation).toBe('prepared');
    expect(sibling.querySelector('span')?.dataset.implementation).toBe('native');
    expect(child.querySelector('span')?.dataset.modal).toBe('none');
  });

  it('carries only the prepared scope through a deferred mount outside the application DOM tree', async () => {
    const application = host();
    const portal = host();
    let mount: ((element: HTMLElement) => () => void) | undefined;
    function Contribution() {
      mount = scopedUiMount((element) => renderUiRoot(ScopeProbe, element));
      return null;
    }
    cleanups.push(render(() => <UiRootImplementation host={application} implementation={implementation}>
      <Contribution />
    </UiRootImplementation>, application));
    await Promise.resolve();
    expect(mount).toBeDefined();
    const dispose = mount!(portal);
    cleanups.push(dispose);
    expect(portal.querySelector('span')?.dataset.implementation).toBe('prepared');
    dispose();
    dispose();
    cleanups.push(renderUiRoot(ScopeProbe, portal));
    expect(portal.querySelector('span')?.dataset.implementation).toBe('native');
  });

  it('releases the application host scope when its owner is disposed', () => {
    const application = host();
    const dispose = render(() => <UiRootImplementation host={application} implementation={implementation}>
      <ScopeProbe />
    </UiRootImplementation>, application);
    expect(application.querySelector('span')?.dataset.implementation).toBe('prepared');
    dispose();
    cleanups.push(renderUiRoot(ScopeProbe, application));
    expect(application.querySelector('span')?.dataset.implementation).toBe('native');
  });

  it('keeps deferred cell parameters and prepared scopes independent across detached hosts', () => {
    const application = host();
    const first = document.createElement('div');
    const second = document.createElement('div');
    let mount!: (element: HTMLElement, record: { label: string }) => () => void;
    function Columns() {
      mount = scopedUiMount((element, record: { label: string }) => renderUiRoot(() => (
        <><ScopeProbe /><span data-cell-label>{record.label}</span></>
      ), element));
      return null;
    }
    cleanups.push(render(() => <UiRootImplementation host={application} implementation={implementation}>
      <Columns />
    </UiRootImplementation>, application));
    const releaseFirst = mount(first, { label: 'First cell' });
    const releaseSecond = mount(second, { label: 'Second cell' });
    cleanups.push(releaseFirst, releaseSecond);
    expect(first.querySelector('[data-cell-label]')?.textContent).toBe('First cell');
    expect(second.querySelector('[data-cell-label]')?.textContent).toBe('Second cell');
    expect(first.querySelector('[data-implementation]')?.getAttribute('data-implementation')).toBe('prepared');
    expect(second.querySelector('[data-implementation]')?.getAttribute('data-implementation')).toBe('prepared');
    releaseFirst();
    releaseFirst();
    expect(second.querySelector('[data-cell-label]')?.textContent).toBe('Second cell');
    cleanups.push(renderUiRoot(ScopeProbe, first));
    expect(first.querySelector('[data-implementation]')?.getAttribute('data-implementation')).toBe('native');
  });

  it('releases a contributed host scope if its mount throws', () => {
    const application = host();
    const portal = host();
    let mount: ((element: HTMLElement) => () => void) | undefined;
    function Contribution() {
      mount = scopedUiMount(() => { throw new Error('mount failed'); });
      return null;
    }
    cleanups.push(render(() => <UiRootImplementation host={application} implementation={implementation}>
      <Contribution />
    </UiRootImplementation>, application));
    expect(() => mount!(portal)).toThrow('mount failed');
    cleanups.push(renderUiRoot(ScopeProbe, portal));
    expect(portal.querySelector('span')?.dataset.implementation).toBe('native');
  });

  it('carries a modal scope into a deferred contribution and releases it without affecting another root', () => {
    const application = host();
    const portal = host();
    const modalContent = host(); modalContent.id = 'modal-content';
      const modal: ModalPortalScope = { mount: modalContent, open: () => true };
    let mount: ((element: HTMLElement) => () => void) | undefined;
    function Contribution() {
      mount = scopedUiMount(element => renderUiRoot(ScopeProbe, element));
      return null;
    }
    cleanups.push(render(() => <ModalPortalContext value={modal}>
      <UiRootImplementation host={application} implementation={implementation}><Contribution /></UiRootImplementation>
    </ModalPortalContext>, application));
    const dispose = mount!(portal); cleanups.push(dispose);
    expect(portal.querySelector('span')?.dataset.modal).toBe('modal-content');
    const sibling = host(); cleanups.push(renderUiRoot(ScopeProbe, sibling));
    expect(sibling.querySelector('span')?.dataset.modal).toBe('none');
    dispose(); cleanups.push(renderUiRoot(ScopeProbe, portal));
    expect(portal.querySelector('span')?.dataset.modal).toBe('none');
  });
});
