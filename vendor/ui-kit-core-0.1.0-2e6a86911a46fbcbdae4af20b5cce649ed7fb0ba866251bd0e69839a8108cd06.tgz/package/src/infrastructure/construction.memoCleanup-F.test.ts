import { createEffect, createMemo, createRenderEffect, createRoot, createSignal, flush, isPending } from 'solid-js';
import { describe, expect, it } from 'vitest';
import { constructItem, ItemCollection } from './construction';

describe('item adapter ownership', () => {
  it('retains an explicit field equality boundary while ambient reads follow the consumer hold', async () => {
    let update!: (value: { disabled: boolean; revision: number }) => void;
    let resolve!: (value: number) => void;
    const buttons: boolean[] = [];
    const frames: (readonly number[])[] = [];
    let pending = false;
    const dispose = createRoot(release => {
      const [state, setState] = createSignal({ disabled: false, revision: 0 }); update = setState;
      const result = createMemo(() => state().disabled ? new Promise<number>(done => { resolve = done; }) : 0);
      const values = constructItem('test.adapterHold', item => ({
        button: item.observe('button', () => ({ disabled: state().disabled }), {
          equals: (left, right) => left.disabled === right.disabled,
        }),
        revision: item.observe('revision', () => state().revision),
        result: item.source('result', { tracking: 'ambient', peek: result, subscribe: () => { throw new Error('Ambient source subscribed'); } }),
      }));
      createEffect(() => values.button.read().disabled, value => { buttons.push(value); });
      createRenderEffect(() => [values.revision.read(), values.result.read()], frame => { frames.push(frame); });
      createEffect(() => isPending(result), value => { pending = value; });
      return release;
    });
    try {
      flush();
      update({ disabled: false, revision: 1 }); flush();
      expect(buttons).toEqual([false]);
      expect(frames).toEqual([[0, 0], [1, 0]]);
      update({ disabled: true, revision: 2 }); flush();
      expect(pending).toBe(true);
      expect(frames).toEqual([[0, 0], [1, 0]]);
      resolve(7); await Promise.resolve(); flush();
      expect(frames).toEqual([[0, 0], [1, 0], [2, 7]]);
      expect(buttons).toEqual([false, true]);
    } finally { dispose(); }
  });

  it('releases newly constructed item resources when a later item fails construction', () => {
    let subscribed = 0;
    let released = 0;
    createRoot(dispose => {
      const ids = constructItem('test.failedItems', item => item.constant('ids', ['first', 'failed']));
      const rows = new ItemCollection('test.failedItems.rows', ids, (id, item) => {
        const value = item.source('value', {
          peek: () => id,
          subscribe: () => { subscribed++; return () => { released++; }; },
        });
        if (id === 'failed') throw new Error('Construction failed');
        return value;
      });
      expect(() => rows.ids()).toThrow('Construction failed');
      expect(subscribed).toBe(2);
      expect(released).toBe(2);
      dispose();
      expect(released).toBe(2);
    });
  });
});
