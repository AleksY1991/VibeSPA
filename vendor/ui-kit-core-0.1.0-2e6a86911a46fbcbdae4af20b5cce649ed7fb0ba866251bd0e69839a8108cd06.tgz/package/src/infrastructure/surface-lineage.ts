import type { ElementSurface } from '../contracts/construction';

const lineage = new WeakMap<ElementSurface, readonly string[]>();

/** Forwarded construction preserves each public element without adding DOM. */
export function captureSurface(surface: ElementSurface, name: string): ElementSurface {
  const captured = { ...surface };
  lineage.set(captured, [...lineage.get(surface) ?? [], name]);
  return captured;
}

export function surfaceLineage(surface: ElementSurface, name: string): readonly string[] {
  return lineage.get(surface) ?? [name];
}
