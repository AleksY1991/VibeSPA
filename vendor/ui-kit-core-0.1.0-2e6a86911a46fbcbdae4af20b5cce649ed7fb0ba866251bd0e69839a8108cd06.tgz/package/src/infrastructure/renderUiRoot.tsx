/** @jsxImportSource @solidjs/web */
import { createComponent, getOwner, onCleanup, useContext } from 'solid-js';
import { render, type JSX } from '@solidjs/web';
import { HotkeyElementContext, HotkeyRendererContext, type HotkeyElementContextValue, type HotkeyRendererContextValue } from '../runtime/context';

import { ImplementationContext, type PreparedImplementation } from './implementation-context';
import { ModalPortalContext, type ModalPortalScope } from '../solid/portal';

interface RootScope {
  readonly implementation: PreparedImplementation | null;
  readonly modal: ModalPortalScope | null;
  readonly element: HotkeyElementContextValue | null;
  readonly renderer: HotkeyRendererContextValue | null;
}

// Scope belongs to a mounted host, never to the page or current account. A
// detached portal can carry the same scope without changing other UI roots.
const rootScopes = new WeakMap<HTMLElement, RootScope[]>();
const rootMarkers = new WeakMap<HTMLElement, string | null>();

function registerRootScope(host: HTMLElement, scope: RootScope): () => void {
  const scopes = rootScopes.get(host) ?? [];
  if (!scopes.length) {
    rootMarkers.set(host, host.getAttribute('data-ui-root'));
    host.setAttribute('data-ui-root', '');
  }
  scopes.push(scope);
  rootScopes.set(host, scopes);
  return () => {
    const position = scopes.indexOf(scope);
    if (position !== -1) scopes.splice(position, 1);
    if (!scopes.length) {
      rootScopes.delete(host);
      const initialMarker = rootMarkers.get(host);
      rootMarkers.delete(host);
      if (initialMarker == null) host.removeAttribute('data-ui-root');
      else host.setAttribute('data-ui-root', initialMarker);
    }
  };
}

function inheritedScope(host: HTMLElement): RootScope | undefined {
  for (let element: HTMLElement | null = host; element; element = element.parentElement) {
    const scopes = rootScopes.get(element);
    if (scopes?.length) return scopes[scopes.length - 1];
  }
  return undefined;
}

/** Provide prepared controls and expose only their scope to separately owned roots. */
export function UiRootImplementation(props: {
  readonly host: HTMLElement;
  readonly implementation: PreparedImplementation;
  readonly children: JSX.Element;
}) {
  onCleanup(registerRootScope(props.host, {
    implementation: props.implementation,
    modal: useContext(ModalPortalContext),
    element: useContext(HotkeyElementContext),
    renderer: useContext(HotkeyRendererContext),
  }));
  return <ImplementationContext value={props.implementation}>{props.children}</ImplementationContext>;
}

/** Mounted UI roots and the catalog share one prepared control implementation. */
export function hasPreparedUi(): boolean {
  return useContext(ImplementationContext) !== null;
}

/**
 * Capture the design-system scope before a portal contribution defers its mount.
 * The account/data owner is deliberately not transferred to the independent root.
 */
export function scopedUiMount<Args extends unknown[]>(mount: (host: HTMLElement, ...args: Args) => () => void): (host: HTMLElement, ...args: Args) => () => void {
  const implementation = useContext(ImplementationContext);
  const modal = useContext(ModalPortalContext);
  const element = useContext(HotkeyElementContext);
  const renderer = useContext(HotkeyRendererContext);
  return (host, ...args) => {
    const release = registerRootScope(host, { implementation, modal, element, renderer });
    let dispose: () => void;
    try {
      dispose = mount(host, ...args);
    } catch (error) {
      release();
      throw error;
    }
    let active = true;
    return () => {
      if (!active) return;
      active = false;
      try {
        dispose();
      } finally {
        release();
      }
    };
  };
}

/** Mount a separately owned Solid tree with the prepared controls of its host. */
export function renderUiRoot(code: () => JSX.Element, host: HTMLElement): () => void {
  const inherited = inheritedScope(host);
  const implementation = getOwner() ? useContext(ImplementationContext) : inherited?.implementation ?? null;
  const modal = getOwner() ? useContext(ModalPortalContext) : inherited?.modal ?? null;
  const element = getOwner() ? useContext(HotkeyElementContext) : inherited?.element ?? null;
  const renderer = getOwner() ? useContext(HotkeyRendererContext) : inherited?.renderer ?? null;
  const release = registerRootScope(host, { implementation, modal, element, renderer });
  let dispose: () => void;
  try {
    dispose = render(() => <ImplementationContext value={implementation}><ModalPortalContext value={modal}>
      <HotkeyRendererContext value={renderer}><HotkeyElementContext value={element}>
        {createComponent(code, {})}
      </HotkeyElementContext></HotkeyRendererContext>
    </ModalPortalContext></ImplementationContext>, host);
  } catch (error) {
    release();
    throw error;
  }
  let active = true;
  return () => {
    if (!active) return;
    active = false;
    try {
      dispose();
    } finally {
      release();
    }
  };
}
