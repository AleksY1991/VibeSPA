import { createSignal, onSettled } from 'solid-js';

export interface ViewportGeometry {
  readonly width: number;
  readonly height: number;
  readonly coarse: boolean;
}

const readViewport = (): ViewportGeometry => ({
  width: typeof window === 'undefined' ? Infinity : window.innerWidth,
  height: typeof window === 'undefined' ? Infinity : window.innerHeight,
  coarse: typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches,
});
const [viewport, setViewport] = createSignal(readViewport(), {
  ownedWrite: true,
  equals: (previous, next) => previous.width === next.width && previous.height === next.height && previous.coarse === next.coarse,
});
let owners = 0;
let release = () => {};

/** Current platform geometry; this private source never contains application data. */
export const viewportGeometry = viewport;

/**
 * Shared controls already own their size tokens. Floating frames also need the
 * viewport for placement and reserved space; native geometry observation lives
 * here so views only consume measurements. Concurrent mounted frames share one
 * observer, and the last rendered owner releases every platform listener.
 */
export function ownViewportGeometry(): void {
  onSettled(() => {
    if (owners++ === 0) {
      const changed = () => { setViewport(readViewport()); };
      const coarse = window.matchMedia('(pointer: coarse)');
      changed();
      window.addEventListener('resize', changed);
      coarse.addEventListener('change', changed);
      release = () => {
        window.removeEventListener('resize', changed);
        coarse.removeEventListener('change', changed);
      };
    }
    return () => { if (--owners === 0) release(); };
  });
}
