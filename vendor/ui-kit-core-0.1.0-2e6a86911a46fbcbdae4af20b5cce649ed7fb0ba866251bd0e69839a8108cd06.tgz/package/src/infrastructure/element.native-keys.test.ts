// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createRoot, flush } from 'solid-js';
import { attachDispatcher } from '../../tests/surface-host';
import { surfaceRegistry } from '../../tests/surface-host';
import { constructItem } from './construction';
import { ElementBinding } from './element';

const disposers: (() => void)[] = [];
afterEach(() => {
  for (const dispose of disposers.splice(0).reverse()) dispose();
  document.body.replaceChildren();
});

function construct(nativeKey: string, combo: string, overrideNative = false) {
  const host = document.createElement('button');
  host.setAttribute('data-ui-keyboard-owner', nativeKey);
  document.body.append(host);
  const handler = vi.fn();
  createRoot(dispose => {
    disposers.push(dispose);
    constructItem('native.matcher', item => {
      new ElementBinding('native.matcher', {
        observable: item.constant('value', true),
        surface: { kind: 'own', name: 'native.matcher', transparent: false },
        hotkeys: [{ key: combo, handler, overrideNative }],
      }, { nativeKeys: [nativeKey] }).attach(host);
    });
  });
  flush();
  disposers.push(attachDispatcher({
    window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
    runtime: () => ({ editing: false, keyboardLayer: null }),
  }));
  return { host, handler };
}

function press(host: Element, options: KeyboardEventInit) {
  const event = new KeyboardEvent('keydown', { bubbles: true, composed: true, cancelable: true, ...options });
  host.dispatchEvent(event);
  return event;
}

describe('construction and dispatch share native key claims', () => {
  it.each(['input', 'div'])('protects printable %s keys before delegating to ancestor actions', tag => {
    const parent = document.createElement('div');
    const host = document.createElement(tag);
    host.setAttribute('data-ui-keyboard-owner', 'Printable');
    parent.append(host);
    document.body.append(parent);
    const background = vi.fn();
    disposers.push(surfaceRegistry.mountElement({
      name: 'native.background', element: parent, transparent: true, layer: false,
      keys: { Digit1: background, 'Shift++': background, 'Shift+A': background },
    }));
    createRoot(dispose => {
      disposers.push(dispose);
      constructItem('native.printable', item => {
        new ElementBinding('native.printable', {
          observable: item.constant('value', true), surface: { kind: 'inherit' }, hotkeys: [],
        }, { nativeKeys: ['Printable'] }).attach(host);
      });
    });
    flush();
    disposers.push(attachDispatcher({
      window, document, registry: surfaceRegistry, commands: { dispatch: vi.fn() },
      runtime: () => ({ editing: false, keyboardLayer: null }),
    }));
    for (const event of [
      { key: '1', code: 'Digit1' },
      { key: '+', shiftKey: true },
      { key: 'A', shiftKey: true },
    ]) expect(press(host, event).defaultPrevented).toBe(false);
    expect(background).not.toHaveBeenCalled();
  });

  it.each([
    { nativeKey: 'Enter', combo: 'Shift+Enter', event: { key: 'Enter', shiftKey: true } },
    { nativeKey: 'ArrowLeft', combo: 'Shift+ArrowLeft', event: { key: 'ArrowLeft', shiftKey: true } },
    { nativeKey: 'Printable', combo: 'Shift+A', event: { key: 'A', shiftKey: true } },
    { nativeKey: 'Printable', combo: 'Shift++', event: { key: '+', shiftKey: true } },
    { nativeKey: 'Printable', combo: 'Shift+Digit1', event: { key: '!', code: 'Digit1', shiftKey: true } },
    { nativeKey: 'Printable', combo: 'Space', event: { key: ' ' } },
  ])('requires and honors the native override for $combo', ({ nativeKey, combo, event }) => {
    expect(() => construct(nativeKey, combo)).toThrow(/native-owned/u);
    const { host, handler } = construct(nativeKey, combo, true);
    expect(press(host, event).defaultPrevented).toBe(true);
    expect(handler).toHaveBeenCalledOnce();
  });

  it.each([
    { combo: 'Ctrl+Enter', event: { key: 'Enter', ctrlKey: true } },
    { combo: 'Ctrl+Shift+Enter', event: { key: 'Enter', ctrlKey: true, shiftKey: true } },
    { combo: 'Alt+Enter', event: { key: 'Enter', altKey: true } },
  ])('accepts and dispatches $combo without a native override', ({ combo, event }) => {
    const { host, handler } = construct('Enter', combo);
    expect(press(host, event).defaultPrevented).toBe(true);
    expect(handler).toHaveBeenCalledOnce();
  });
});
