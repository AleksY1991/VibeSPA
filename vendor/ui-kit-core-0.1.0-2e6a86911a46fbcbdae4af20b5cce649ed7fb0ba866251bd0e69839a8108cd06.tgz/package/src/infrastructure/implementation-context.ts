import { createContext, useContext, type Component } from 'solid-js';
import type { ChoiceGroupControlProps, ToggleControlProps, TextFieldControlProps } from '../contracts/controls';
import type { SelectControlProps, TextareaControlProps } from '../contracts/fields';
import type { SurfaceControlProps } from '../contracts/surfaces';
import type { CheckboxControlProps } from '../contracts/checkbox';
import type { ProgressBarControlProps } from '../contracts/progress';
import type { TooltipSurfaceControlProps } from '../contracts/tooltip';
import type { SpinnerControlProps } from '../contracts/spinner';
import type { BadgeControlProps } from '../contracts/badge';
import type { AvatarControlProps } from '../contracts/avatar';
import type { DividerControlProps } from '../contracts/divider';
import type { TabsControlProps, TabPanelControlProps } from '../contracts/tabs';
import type { TagControlProps } from '../contracts/tag';
import type { SplitPanelControlProps } from '../contracts/split-panel';

export interface PreparedImplementation {
  readonly Toggle?: Component<ToggleControlProps>;
  readonly ChoiceGroup?: Component<ChoiceGroupControlProps>;
  readonly TextField?: Component<TextFieldControlProps>;
  readonly Select?: Component<SelectControlProps>;
  readonly Textarea?: Component<TextareaControlProps>;
  readonly PopoverSurface?: Component<SurfaceControlProps>;
  readonly Checkbox?: Component<CheckboxControlProps>;
  readonly ProgressBar?: Component<ProgressBarControlProps>;
  readonly TooltipSurface?: Component<TooltipSurfaceControlProps>;
  readonly Spinner?: Component<SpinnerControlProps>;
  readonly Badge?: Component<BadgeControlProps>;
  readonly Avatar?: Component<AvatarControlProps>;
  readonly Divider?: Component<DividerControlProps>;
  readonly Tabs?: Component<TabsControlProps>;
  readonly TabPanel?: Component<TabPanelControlProps>;
  readonly Tag?: Component<TagControlProps>;
  readonly SplitPanel?: Component<SplitPanelControlProps>;
}

export type ControlFamily = keyof PreparedImplementation;

export function controlImplementation<Key extends ControlFamily>(
  family: Key,
): PreparedImplementation[Key] | undefined {
  const implementation = useContext(ImplementationContext);
  return implementation?.[family];
}

/** Missing preparation is an integration error, never a choice of renderer. */
export function requireControlImplementation<Key extends ControlFamily>(
  family: Key,
): NonNullable<PreparedImplementation[Key]> {
  const implementation = controlImplementation(family);
  if (!implementation) throw new Error(`${family}: prepare the application implementation before rendering this control`);
  return implementation as NonNullable<PreparedImplementation[Key]>;
}

/** One prepared implementation belongs to each mounted UI root. */
export const ImplementationContext = createContext<PreparedImplementation | null>(null);
