import { createMemo, createSignal, getObserver, getOwner, mapArray, onCleanup, untrack, type Accessor } from 'solid-js';
import type { Observable } from '../contracts/construction';

const registered = new WeakSet<object>();

class RegisteredObservable<T> {
  readonly read: Accessor<T>;
  constructor(read: Accessor<T>) {
    this.read = read;
    registered.add(this);
    Object.freeze(this);
  }
}

function register<T>(read: Accessor<T>): Observable<T> {
  return new RegisteredObservable(read) as unknown as Observable<T>;
}

/** Runtime validation also rejects handles forged through type assertions. */
export function readObservable<T>(value: Observable<T>): Accessor<T> {
  if (!value || !registered.has(value)) throw new TypeError('Element construction requires a registered observable');
  return value.read;
}

export interface ObservableSource<T> {
  readonly tracking?: 'ambient' | 'explicit';
  peek(): T;
  subscribe(listener: (value: T) => void): () => void;
}

export interface ObserveOptions<T> {
  readonly equals?: (previous: T, next: T) => boolean;
}

/** Only constructItem can issue this short-lived binding capability. */
export class ItemConstruction {
  readonly #name: string;
  readonly #slots = new Set<string>();
  #open = true;

  constructor(name: string, token: symbol) {
    if (token !== constructionToken) throw new Error('Use constructItem to construct reactive items');
    this.#name = name;
  }

  #claim(slot: string): void {
    if (!this.#open) throw new Error(`${this.#name}: subscriptions may only be declared during construction`);
    if (!slot.trim() || this.#slots.has(slot)) throw new Error(`${this.#name}: duplicate or empty binding slot "${slot}"`);
    this.#slots.add(slot);
  }

  observe<T>(slot: string, read: Accessor<T>, options: ObserveOptions<T> = {}): Observable<T> {
    this.#claim(slot);
    return register(options.equals
      ? createMemo(read, { name: `${this.#name}.${slot}`, equals: options.equals })
      : read);
  }

  constant<T>(slot: string, value: T): Observable<T> {
    this.#claim(slot);
    return register(() => value);
  }

  /** Bind a neutral data source exactly once, under this item's existing Solid owner. */
  source<T>(slot: string, source: ObservableSource<T>): Observable<T> {
    this.#claim(slot);
    if (source.tracking === 'ambient') return register(() => source.peek());
    const [value, setValue] = createSignal<T>(source.peek() as never, { name: `${this.#name}.${slot}`, ownedWrite: true });
    onCleanup(source.subscribe(next => setValue(() => next)));
    return register(value);
  }

  /** Read an external-source factory once; consumers receive only its stable observable. */
  bind<T>(slot: string, factory: () => Accessor<T>): Observable<T> {
    this.#claim(slot);
    return register(untrack(factory, `${this.#name}.${slot}`));
  }

  seal(): void { this.#open = false; }
}

const constructionToken = Symbol('item construction');

/** Construction is synchronous; subsequent updates can only read existing handles. */
export function constructItem<T>(name: string, build: (item: ItemConstruction) => T): T {
  if (!getOwner()) throw new Error(`${name}: constructItem requires a Solid construction owner`);
  if (getObserver()) throw new Error(`${name}: item construction cannot run inside a reactive computation`);
  const item = new ItemConstruction(name, constructionToken);
  try {
    // Construction must not subscribe its caller, but accidental snapshots in
    // builders (including imported helpers) must still reach Solid diagnostics.
    const result = untrack(() => build(item), name);
    if (result instanceof Promise) throw new Error(`${name}: item construction cannot be asynchronous`);
    return result;
  } finally {
    item.seal();
  }
}

/** One item instance per source key. Ordering changes never reconstruct existing items. */
export class ItemCollection<T> {
  /** Immutable record snapshots share row owners by key, while each row reads its
   * latest record. The returned mapping belongs to the current construction owner. */
  static map<Row, Result>(
    name: string,
    rows: Observable<readonly Row[]>,
    keyBy: (row: Row) => string | number,
    build: (row: Observable<Row>, index: Accessor<number>) => Result,
  ): Accessor<Result[]> {
    if (!getOwner()) throw new Error(`${name}: ItemCollection requires a construction owner`);
    if (getObserver()) throw new Error(`${name}: item collection construction cannot run inside a reactive computation`);
    const read = readObservable(rows);
    return mapArray(() => {
      const next = read();
      const keys = new Set<string | number>();
      for (const row of next) {
        const key = keyBy(row);
        if ((typeof key !== 'string' && typeof key !== 'number')
          || (typeof key === 'number' && !Number.isFinite(key))) {
          throw new TypeError(`${name}: item keys must be strings or finite numbers`);
        }
        if (keys.has(key)) throw new Error(`${name}: duplicate item key "${key}"`);
        keys.add(key);
      }
      return next;
    }, (row, index) => build(register(row), index), { keyed: keyBy, name });
  }

  readonly ids: Accessor<readonly string[]>;
  readonly #items = new Map<string, T>();

  constructor(name: string, ids: Observable<readonly string[]>, build: (id: string, item: ItemConstruction) => T) {
    if (!getOwner()) throw new Error(`${name}: ItemCollection requires a construction owner`);
    if (getObserver()) throw new Error(`${name}: item collection construction cannot run inside a reactive computation`);
    const readIds = readObservable(ids);
    this.ids = mapArray(() => {
      const next = readIds();
      const keys = new Set(next);
      if (keys.size !== next.length) throw new Error(`${name}: duplicate item keys`);
      return next;
    }, id => {
      const value = constructItem(`${name}[${id}]`, item => build(id, item));
      this.#items.set(id, value);
      onCleanup(() => { this.#items.delete(id); });
      return id;
    }, { name: `${name}.ids` });
  }

  get(id: string): T {
    untrack(this.ids);
    if (!this.#items.has(id)) throw new Error(`Item "${id}" is not registered in this collection`);
    return this.#items.get(id)!;
  }
}
