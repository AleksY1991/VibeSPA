import { createComponent, createEffect, createMemo, createRoot, createSignal, flush, onCleanup, untrack } from 'solid-js';
import { describe, expect, it, vi } from 'vitest';
import type { Observable } from '../contracts/construction';
import { constructItem, ItemCollection, readObservable, type ItemConstruction } from './construction';

describe('item construction contract', () => {
  it('reads ambient sources directly without an effect relay or duplicate subscription', () => {
    const subscribe = vi.fn(() => () => {});
    const frames: (readonly number[])[] = [];
    let update!: (next: number) => void;
    const stop = createRoot(dispose => {
      const [value, setValue] = createSignal(0); update = setValue;
      const item = constructItem('test.ambient', construction => construction.source('value', {
        tracking: 'ambient', peek: value, subscribe,
      }));
      createEffect(() => [value(), item.read()], frame => { frames.push(frame); });
      return dispose;
    });
    try {
      flush();
      for (let index = 1; index <= 20; index++) { update(index); flush(); }
      expect(frames).toEqual(Array.from({ length: 21 }, (_, index) => [index, index]));
      expect(subscribe).not.toHaveBeenCalled();
    } finally { stop(); }
  });

  it('keeps observed and bound values live while explicit snapshots stay fixed, and disposes with the component', () => {
    const [read, write] = createSignal(1);
    const release = vi.fn();
    const publish = vi.fn();
    const build = vi.fn();
    let stop!: () => void;
    function ItemProbe() {
      const values = constructItem('test.live', item => {
        build();
        const observed = item.observe('observed', read);
        const bound = item.bind('bound', () => { onCleanup(release); return read; });
        const initial = item.constant('initial', untrack(read));
        return { observed, bound, initial };
      });
      createEffect(() => [values.observed.read(), values.bound.read(), values.initial.read()], publish);
      return null;
    }
    createRoot(dispose => { stop = dispose; createComponent(ItemProbe, {}); });
    try {
      flush();
      expect(publish).toHaveBeenLastCalledWith([1, 1, 1], undefined);
      write(2);
      flush();
      expect(publish.mock.calls.at(-1)?.[0]).toEqual([2, 2, 1]);
      expect(build).toHaveBeenCalledOnce();
      stop();
      expect(release).toHaveBeenCalledOnce();
      publish.mockClear();
      write(3);
      flush();
      expect(publish).not.toHaveBeenCalled();
    } finally { stop(); }
  });

  it('seals binding capability and rejects forged observables and duplicate slots', () => {
    createRoot(dispose => {
      let retained!: ItemConstruction;
      const value = constructItem('test.item', item => {
        retained = item;
        const registered = item.constant('value', 3);
        expect(() => item.constant('value', 4)).toThrow('duplicate');
        return registered;
      });
      expect(readObservable(value)()).toBe(3);
      expect(() => retained.constant('late', 4)).toThrow('during construction');
      expect(() => retained.source('late', { peek: () => 0, subscribe: () => () => {} })).toThrow('during construction');
      expect(() => readObservable({ read: () => 3 } as Observable<number>)).toThrow('registered observable');
      dispose();
    });
    expect(() => constructItem('ownerless', item => item.constant('value', 0))).toThrow('construction owner');
  });

  it('never registers more source observers when a value is read or changes', async () => {
    let publish!: (next: number) => void;
    const release = vi.fn();
    const subscribe = vi.fn((callback: (next: number) => void) => { publish = callback; return release; });
    let stop!: () => void;
    const values: number[] = [];
    createRoot(dispose => {
      stop = dispose;
      const item = constructItem('test.source', c => c.source('value', { peek: () => 0, subscribe }));
      createEffect(item.read, next => { values.push(next); });
      for (let i = 0; i < 100; i++) expect(item.read()).toBe(0);
    });
    await Promise.resolve();
    publish(1);
    await Promise.resolve();
    expect(values).toEqual([0, 1]);
    expect(subscribe).toHaveBeenCalledTimes(1);
    stop();
    expect(release).toHaveBeenCalledTimes(1);
  });

  it('rejects item factories in reactive computations and asynchronous construction', () => {
    createRoot(dispose => {
      const invalid = createMemo(() => {
        expect(() => constructItem('nested', item => item.constant('x', 1))).toThrow('reactive computation');
        return true;
      });
      expect(invalid()).toBe(true);
      expect(() => constructItem('async', async () => 1)).toThrow('asynchronous');
      dispose();
    });
  });

  it('retains 3000 item bindings across reordered keys and isolates row changes', async () => {
    let stop!: () => void;
    let setIds!: (ids: readonly string[]) => void;
    const keys = Array.from({ length: 3000 }, (_, i) => String(i));
    const publishes = new Map<string, (value: number) => void>();
    let registrations = 0;
    let releases = 0;
    const updates = new Map<string, number>();
    let items!: ItemCollection<Observable<number>>;
    createRoot(dispose => {
      stop = dispose;
      const [ids, writeIds] = createSignal<readonly string[]>(keys);
      setIds = writeIds;
      const source = constructItem('test.list', item => item.observe('ids', ids));
      items = new ItemCollection('test.rows', source, (id, item) => item.source('row', {
        peek: () => 0,
        subscribe: publish => {
          registrations++;
          publishes.set(id, publish);
          return () => { releases++; publishes.delete(id); };
        },
      }));
      for (const id of items.ids()) {
        const item = items.get(id);
        createEffect(item.read, () => { updates.set(id, (updates.get(id) ?? 0) + 1); });
      }
    });
    await Promise.resolve();
    const first = items.get('0');
    for (let i = 0; i < 5; i++) {
      setIds(i % 2 ? keys : [...keys].reverse());
      await Promise.resolve();
      items.ids();
    }
    expect(items.get('0')).toBe(first);
    expect(registrations).toBe(3000);
    expect(releases).toBe(0);
    updates.clear();
    publishes.get('1')!(1);
    await Promise.resolve();
    expect([...updates]).toEqual([['1', 1]]);
    stop();
    expect(releases).toBe(3000);
  });
});
