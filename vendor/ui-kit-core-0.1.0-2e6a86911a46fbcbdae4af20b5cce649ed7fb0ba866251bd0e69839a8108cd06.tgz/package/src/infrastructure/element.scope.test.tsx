/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { captureArtifact } from '@solidjs/diagnostics';
import { createEffect, createRoot, createSignal, flush, onCleanup, untrack } from 'solid-js';
import { afterEach, expect, it, vi } from 'vitest';
import { constructItem } from './construction';
import { ElementBinding } from './element';
import { HotkeyRendererContext, useHotkeyElementContext, type HotkeyElementContextValue } from '../runtime/context';

let dispose: (() => void) | undefined;
afterEach(() => { dispose?.(); dispose = undefined; document.body.replaceChildren(); });

it('derives retained scope activity in the source flush while notifying descendant leases', async () => {
  const frames: (readonly [boolean, boolean])[] = [];
  let write!: (state: { collapsed: boolean }) => void;
  let child!: ElementBinding<boolean>;
  let context!: HotkeyElementContextValue;
  const notified = vi.fn();
  const container = document.createElement('div'); document.body.append(container);
  const { artifact } = await captureArtifact(() => {
    dispose = render(() => {
      const [state, setState] = createSignal({ collapsed: false }); write = setState;
      const observable = constructItem('scope.test', item => item.constant('value', true));
      const parent = new ElementBinding('scope.parent', { observable, surface: { kind: 'inherit' }, hotkeys: [] });
      parent.attachNonvisual(new EventTarget());
      return parent.provide(() => {
        context = useHotkeyElementContext()!;
        onCleanup(context.subscribe(notified));
        createEffect(() => [state().collapsed, context.active()] as const, next => { frames.push(next); });
        child = new ElementBinding('scope.child', { observable, surface: { kind: 'inherit' }, hotkeys: [] });
        child.attachNonvisual(new EventTarget());
        return null;
      }, { active: () => !state().collapsed });
    }, container);
    flush();
    for (const collapsed of [true, false, true, false]) {
      write({ collapsed }); flush();
      expect(untrack(context.active)).toBe(!collapsed);
      expect(context.peekActive()).toBe(!collapsed);
      expect(child.isLive()).toBe(!collapsed);
    }
  });
  expect(frames).toEqual([[false, true], [true, false], [false, true], [true, false], [false, true]]);
  expect(notified).toHaveBeenCalled();
  expect(artifact.diagnostics.filter(event => event.code === 'EFFECT_RELAY_TEAR')).toEqual([]);
  const escaped: (readonly boolean[])[] = [];
  const stopObserver = createRoot(stop => {
    createEffect(() => [child.active(), child.lifetime(), context.active()], next => { escaped.push(next); });
    return stop;
  });
  flush();
  dispose(); dispose = undefined;
  flush();
  expect(escaped).toEqual([[true, true, true], [false, false, false]]);
  stopObserver();
  notified.mockClear();
  write({ collapsed: true }); flush();
  expect(notified).not.toHaveBeenCalled();
  expect(child.isDisposed()).toBe(true);
  expect(untrack(child.active)).toBe(false);
  expect(untrack(child.lifetime)).toBe(false);
  expect(untrack(context.active)).toBe(false);
});

it('tracks renderer identity publications when the renderer has no reactive activity accessor', () => {
  let rendererId: string | null = null;
  const listeners = new Set<() => void>();
  let binding!: ElementBinding<boolean>;
  const renderer = {
    instanceId: () => rendererId,
    subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
  };
  const container = document.createElement('div'); document.body.append(container);
  const Probe = () => {
    const observable = constructItem('renderer.test', item => item.constant('value', true));
    binding = new ElementBinding('renderer.child', { observable, surface: { kind: 'inherit' }, hotkeys: [] });
    binding.attachNonvisual(new EventTarget());
    return null;
  };
  dispose = render(() => <HotkeyRendererContext value={renderer}><Probe /></HotkeyRendererContext>, container);
  flush(); expect(untrack(binding.active)).toBe(false);
  for (const next of ['renderer:1', null, 'renderer:2']) {
    rendererId = next;
    for (const listener of listeners) listener();
    flush();
    expect(untrack(binding.active)).toBe(next !== null);
    expect(untrack(binding.lifetime)).toBe(next !== null);
  }
  dispose(); dispose = undefined;
  expect(listeners.size).toBe(0);
});

it('derives logical parent activity with its source while preserving actual mount readiness', async () => {
  const frames: (readonly [boolean, boolean])[] = [];
  let write!: (value: boolean) => void;
  let parent!: ElementBinding<boolean>;
  const container = document.createElement('div'); document.body.append(container);
  const { artifact } = await captureArtifact(() => {
    dispose = render(() => {
      const [enabled, setEnabled] = createSignal(true); write = setEnabled;
      const observable = constructItem('scope.intent', item => item.observe('value', enabled));
      parent = new ElementBinding('scope.intent', { observable, surface: { kind: 'inherit' }, hotkeys: [] }, { activeWhen: value => value });
      parent.attachNonvisual(new EventTarget());
      createEffect(() => [enabled(), parent.active()] as const, next => { frames.push(next); });
      return null;
    }, container);
    flush();
    for (const enabled of [false, true, false, true, false, true]) {
      write(enabled); flush();
      expect(untrack(parent.active)).toBe(enabled);
      expect(untrack(parent.lifetime)).toBe(enabled);
    }
  });
  expect(frames).toEqual([[true, true], [false, false], [true, true], [false, false], [true, true], [false, false], [true, true]]);
  expect(artifact.diagnostics.filter(event => event.code === 'EFFECT_RELAY_TEAR')).toEqual([]);
});

it('preserves immediate parent and refreshed scope lifetimes across detach and reattachment', () => {
  let write!: (state: { collapsed: boolean }) => void;
  let parent!: ElementBinding<boolean>;
  let child!: ElementBinding<boolean>;
  let context!: HotkeyElementContextValue;
  const container = document.createElement('div'); document.body.append(container);
  dispose = render(() => {
    const [state, setState] = createSignal({ collapsed: false }); write = setState;
    const observable = constructItem('scope.lifetime', item => item.constant('value', true));
    parent = new ElementBinding('scope.parent', { observable, surface: { kind: 'inherit' }, hotkeys: [] });
    parent.attachNonvisual(new EventTarget());
    return parent.provide(() => {
      context = useHotkeyElementContext()!;
      child = new ElementBinding('scope.child', { observable, surface: { kind: 'inherit' }, hotkeys: [] });
      child.attachNonvisual(new EventTarget());
      return null;
    }, { active: () => !state().collapsed });
  }, container);
  flush();
  parent.detach();
  expect(context.peekActive()).toBe(false);
  expect(child.isLive()).toBe(false);
  flush(); expect(untrack(context.active)).toBe(false);
  parent.attachNonvisual(new EventTarget());
  expect(context.peekActive()).toBe(true);
  expect(child.isLive()).toBe(true);
  flush(); expect(untrack(context.active)).toBe(true);
  write({ collapsed: true });
  flush(); context.refresh?.();
  expect(child.isLive()).toBe(false);
  expect(context.peekActive()).toBe(false);
  expect(untrack(context.active)).toBe(false);
  write({ collapsed: false });
  flush(); context.refresh?.();
  expect(child.isLive()).toBe(true);
  expect(context.peekActive()).toBe(true);
  expect(untrack(context.active)).toBe(true);
});
