import { getObserver, getOwner, merge } from 'solid-js';
import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from '../contracts/construction';
import { captureElementConstruction } from './element-construction';

/** Shared construction validation; the concrete element alone owns DOM binding. */
export abstract class RenderedElement<T> {
  abstract readonly element: JSX.Element;
  readonly #construction: ElementConstruction<T>;

  protected constructor(name: string, props: ElementConstruction<T>) {
    if (!getOwner()) throw new Error(`${name}: construct the element under a Solid owner`);
    if (getObserver()) throw new Error(`${name}: element construction cannot run inside a reactive computation`);
    this.#construction = captureElementConstruction(name, props);
  }

  /** Reactive presentation getters remain live; construction inputs are captured once. */
  protected capture<Props extends ElementConstruction<T>>(props: Props): Props {
    return merge(props, this.#construction) as Props;
  }
}
