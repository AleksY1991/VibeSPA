/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createEffect, createMemo, createRoot, createSignal, flush, untrack } from 'solid-js';
import type { JSX } from '@solidjs/web';
import { renderPrepared as render } from '../../tests/prepared';
import { Button } from '../solid/button';
import { Card, ChoiceGroup } from '../solid/controls';
import { Form } from '../solid/form';
import { Link } from '../solid/link';
import { InteractionRegion } from '../solid/interaction-region';
import { constructItem } from './construction';
import type { FocusHandle } from '../contracts/controls';
import { mountElementSurfaceLease } from '../../tests/surface-host';
import { allowActivation, allowNativeActivation } from './activation';
import type { ChoiceElement } from '../vendor/web-awesome/elements';

const disposers: (() => void)[] = [];
afterEach(() => { for (const dispose of disposers.splice(0).reverse()) dispose(); document.body.replaceChildren(); });
const settle = async () => { for (let turn = 0; turn < 60; turn += 1) { flush(); await Promise.resolve(); } };
function mount(renderContent: () => JSX.Element) {
  const host = document.createElement('div');
  document.body.append(host);
  const dispose = render(renderContent, host);
  disposers.push(dispose);
  return { host, dispose };
}
function click(element: Element) {
  const event = new MouseEvent('click', { bubbles: true, composed: true, cancelable: true });
  element.dispatchEvent(event);
  return event;
}

describe('surface-owned activation', () => {
  it.each(['button', 'region'] as const)('isolates synchronous %s commands from effects and memo dependencies', async kind => {
    const [value, setValue] = createSignal(1);
    const snapshots: number[] = [];
    const { host } = mount(() => {
      const observable = constructItem('reentrant command', item => item.constant('state', {}));
      const activate = () => { snapshots.push(value()); };
      return <>
        {kind === 'region'
          ? <InteractionRegion.View data-testid="reentrant" observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={activate}>Run</InteractionRegion.View>
          : <Button.View data-testid="reentrant" observable={observable} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={activate}>Run</Button.View>}
      </>;
    });
    await settle();
    const target = host.querySelector<HTMLElement>('[data-testid="reentrant"]')!;
    let read!: () => number;
    let runs = 0;
    disposers.push(createRoot(dispose => {
      read = createMemo(() => { runs++; click(target); return runs; });
      createEffect(() => true, () => { click(target); });
      return dispose;
    }));
    untrack(read); flush();
    expect(snapshots).toEqual([1, 1]);
    setValue(2); flush();
    expect(untrack(read)).toBe(1);
    expect(snapshots).toEqual([1, 1]);
    click(target);
    expect(snapshots).toEqual([1, 1, 2]);
  });

  it('keeps native admission across a browser microtask checkpoint between capture and delegated bubbling', async () => {
    const native = { canActivate: () => true, isDisposed: () => false };
    const ancestor = { canActivate: () => false };
    const input = document.createElement('input');
    const boundary = document.createElement('fieldset');
    const parent = document.createElement('div');
    let currentTarget: Element = boundary;
    let phase: number = Event.CAPTURING_PHASE;
    let path: EventTarget[] = [input, boundary, parent, document];
    const event = new MouseEvent('click', { bubbles: true, cancelable: true });
    Object.defineProperties(event, {
      currentTarget: { get: () => currentTarget },
      eventPhase: { get: () => phase },
      composedPath: { value: () => path },
    });
    expect(allowNativeActivation(native, event)).toBe(true);
    await Promise.resolve();
    currentTarget = parent; phase = Event.BUBBLING_PHASE;
    expect(allowActivation(ancestor, event)).toBe(false);
    expect(event.defaultPrevented).toBe(false);
    path = [parent, document];
    expect(allowActivation(ancestor, event)).toBe(false);
    expect(event.defaultPrevented).toBe(true);
  });

  it.each([false, true])('preserves an admitted radio default beneath an unavailable region (ancestor command: %s)', async withCommand => {
    const [selected, setSelected] = createSignal<'one' | 'two'>('one');
    const ancestor = vi.fn();
    const changed = vi.fn();
    const { host } = mount(() => {
      const states = constructItem('activation.admitted.radio', item => ({
        region: item.constant('region', {}), visible: item.constant('visible', true),
        selected: item.observe('selected', selected),
      }));
      return <InteractionRegion.View data-testid="ancestor" observable={states.region} surface={{ kind: 'inherit' }} hotkeys={[]}
        onActivate={withCommand ? ancestor : undefined}>
        <Card.View observable={states.visible} surface={{ kind: 'own', name: 'activation.radio.popup', transparent: false, layer: true }} hotkeys={[]}>
          <ChoiceGroup.View observable={states.selected} surface={{ kind: 'inherit' }} hotkeys={[]} label="Choice"
            options={[{ value: 'one', label: 'One' }, { value: 'two', label: 'Two' }]}
            onValueChange={next => { changed(next); setSelected(next); }} />
        </Card.View>
      </InteractionRegion.View>;
    });
    await settle();
    const radio = host.querySelectorAll<ChoiceElement>('wa-radio')[1]!;
    const event = new MouseEvent('click', { bubbles: true, composed: true, cancelable: true });
    // Happy DOM leaves target inside a shadow root for outside listeners.
    // Supply the browser's retargeted host while retaining the real origin/path.
    Object.defineProperty(event, 'target', { configurable: true, value: radio });
    radio.shadowRoot!.querySelector('[part="control"]')!.dispatchEvent(event);
    await settle();
    expect(event.defaultPrevented).toBe(false);
    expect(radio.checked).toBe(true);
    expect(changed).toHaveBeenCalledExactlyOnceWith('two');
    expect(ancestor).not.toHaveBeenCalled();
    if (withCommand) {
      // Admission does not exempt unrelated activation on the denied ancestor.
      const denied = click(host.querySelector('[data-testid="ancestor"]')!);
      expect(denied.defaultPrevented).toBe(true);
      expect(ancestor).not.toHaveBeenCalled();
    }
  });

  it('commands stop with retained hidden owners and resume on show', async () => {
    const [visible, setVisible] = createSignal(true);
    const command = vi.fn();
    const { host } = mount(() => {
      const states = constructItem('activation.visibility', item => ({
        visible: item.observe('visible', visible), button: item.constant('button', {}),
      }));
      return <>
        <Card.View observable={states.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>
          <Button.View observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]}
            onActivate={command}>Run</Button.View>
        </Card.View>
      </>;
    });
    await settle();
    const button = host.querySelector('button')!;
    click(button); expect(command).toHaveBeenCalledOnce();
    setVisible(false); await settle();
    expect(click(button).defaultPrevented).toBe(true);
    expect(command).toHaveBeenCalledOnce();
    setVisible(true); await settle();
    click(button); expect(command).toHaveBeenCalledTimes(2);
  });

  it('allows local siblings and blocks background actions beneath an opaque global layer', async () => {
    const [global, setGlobal] = createSignal(false);
    const background = vi.fn();
    const local = vi.fn();
    const modal = vi.fn();
    const { host } = mount(() => {
      const states = constructItem('activation.layers', item => ({
        visible: item.constant('visible', true), global: item.observe('global', global), button: item.constant('button', {}),
      }));
      return <>
        <Button.View data-testid="background" observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={background}>Background</Button.View>
        <Card.View observable={states.visible} surface={{ kind: 'own', name: 'activation.local', transparent: false }} hotkeys={[]}>
          <Button.View data-testid="local" observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={local}>Local</Button.View>
        </Card.View>
        <Card.View observable={states.global} surface={{ kind: 'own', name: 'activation.modal', transparent: false, layer: true }} hotkeys={[]}>
          <Button.View data-testid="modal" observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={modal}>Modal</Button.View>
        </Card.View>
      </>;
    });
    await settle();
    click(host.querySelector('[data-testid="background"]')!);
    click(host.querySelector('[data-testid="local"]')!);
    expect(background).toHaveBeenCalledOnce(); expect(local).toHaveBeenCalledOnce();
    setGlobal(true); await settle();
    expect(click(host.querySelector('[data-testid="background"]')!).defaultPrevented).toBe(true);
    expect(click(host.querySelector('[data-testid="local"]')!).defaultPrevented).toBe(true);
    click(host.querySelector('[data-testid="modal"]')!);
    expect(background).toHaveBeenCalledOnce(); expect(local).toHaveBeenCalledOnce(); expect(modal).toHaveBeenCalledOnce();
    setGlobal(false); await settle();
    click(host.querySelector('[data-testid="background"]')!); expect(background).toHaveBeenCalledTimes(2);
  });

  it('rejects detached and disposed native controls synchronously', async () => {
    const command = vi.fn();
    const { host, dispose } = mount(() => {
      const state = constructItem('activation.stale', item => item.constant('button', {}));
      return <Button.View observable={state} surface={{ kind: 'inherit' }} hotkeys={[]} onActivate={command}>Action</Button.View>;
    });
    await settle();
    const button = host.querySelector('button')!;
    button.remove();
    expect(click(button).defaultPrevented).toBe(true);
    expect(command).not.toHaveBeenCalled();
    host.append(button);
    click(button); expect(command).toHaveBeenCalledOnce();
    dispose();
    host.append(button);
    click(button);
    expect(command).toHaveBeenCalledOnce();
  });
  it('guards callback-free defaults while leaving allowed forms and links native', async () => {
    const [visible, setVisible] = createSignal(true);
    const submitted = vi.fn((intent: { preventDefault(): void }) => intent.preventDefault());
    const { host } = mount(() => {
      const states = constructItem('activation.defaults', item => ({
        visible: item.observe('visible', visible), button: item.constant('button', {}),
        link: item.constant('link', { href: '#destination' }),
      }));
      return <>
        <Card.View observable={states.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>
        <Form.View observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} onSubmit={submitted}>
          <Button.View data-testid="submit" observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} type="submit">Submit</Button.View>
        </Form.View>
        <Link.View observable={states.link} surface={{ kind: 'inherit' }} hotkeys={[]}>Destination</Link.View>
        </Card.View>
      </>;
    });
    await settle();
    const button = host.querySelector('[data-testid="submit"]')!;
    const anchor = host.querySelector('a')!;
    click(button); await settle(); expect(submitted).toHaveBeenCalledOnce();
    expect(click(anchor).defaultPrevented).toBe(false);
    setVisible(false); await settle();
    expect(click(button).defaultPrevented).toBe(true);
    expect(click(anchor).defaultPrevented).toBe(true);
    const submission = new SubmitEvent('submit', { bubbles: true, cancelable: true });
    host.querySelector('form')!.dispatchEvent(submission);
    expect(submission.defaultPrevented).toBe(true); expect(submitted).toHaveBeenCalledOnce();
  });

  it('cancels a gesture when a new global layer blocks its completion, releasing capture without committing', async () => {
    const [blocked, setBlocked] = createSignal(false);
    const commit = vi.fn();
    const move = vi.fn();
    const cancel = vi.fn();
    const drop = vi.fn();
    const { host } = mount(() => {
      const states = constructItem('activation.gesture', item => ({
        button: item.constant('button', {}), blocker: item.observe('blocker', blocked),
      }));
      return <>
        <InteractionRegion.View data-testid="region" observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]}
          onPressStart={event => event.capturePointer()} onPointerUp={commit} onPointerMove={move} onPointerCancel={cancel} onDrop={drop} />
        <Card.View observable={states.blocker} surface={{ kind: 'own', name: 'activation.gesture.modal', transparent: false, layer: true }} hotkeys={[]} />
      </>;
    });
    await settle();
    const region = host.querySelector('[data-testid="region"]') as HTMLElement;
    const captured = new Set<number>();
    region.setPointerCapture = id => { captured.add(id); };
    region.hasPointerCapture = id => captured.has(id);
    region.releasePointerCapture = id => { captured.delete(id); };
    region.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 12 }));
    expect(captured.has(12)).toBe(true);
    setBlocked(true); await settle();
    region.dispatchEvent(new PointerEvent('pointermove', { bubbles: true, cancelable: true, pointerId: 12 }));
    expect(move).not.toHaveBeenCalled(); expect(cancel).toHaveBeenCalledOnce(); expect(captured.size).toBe(0);
    const completion = new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerId: 12 });
    region.dispatchEvent(completion);
    expect(completion.defaultPrevented).toBe(true);
    expect(commit).not.toHaveBeenCalled();
    expect(cancel).toHaveBeenCalledTimes(2);
    expect(cancel.mock.calls[0][0]).toMatchObject({ type: 'pointercancel', pointerId: 12, currentTarget: region });
    expect(captured.size).toBe(0);
    region.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 99 }));
    region.dispatchEvent(new Event('drop', { bubbles: true, cancelable: true }));
    expect(commit).not.toHaveBeenCalled(); expect(drop).not.toHaveBeenCalled();
    setBlocked(false); await settle();
    region.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 12 }));
    region.dispatchEvent(new Event('drop', { bubbles: true, cancelable: true }));
    expect(commit).toHaveBeenCalledOnce(); expect(drop).toHaveBeenCalledOnce();
  });

  it.each(['button', 'link', 'region'] as const)('%s focus handles ask the live surface before moving focus', async kind => {
    const [visible, setVisible] = createSignal(true);
    let handle!: FocusHandle;
    const receive = (next: FocusHandle | undefined) => { if (next) handle = next; };
    const { host, dispose } = mount(() => {
      const states = constructItem('activation.focus', item => ({
        visible: item.observe('visible', visible), button: item.constant('button', {}),
        link: item.constant('link', { href: '#destination' }),
      }));
      return <>
        <Card.View observable={states.visible} surface={{ kind: 'inherit' }} hotkeys={[]}>
          {kind === 'link' ? <Link.View data-testid="focus" observable={states.link} surface={{ kind: 'inherit' }} hotkeys={[]} onHandle={receive}>Link</Link.View>
            : kind === 'region' ? <InteractionRegion.View data-testid="focus" tabindex={0} observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} onHandle={receive} />
              : <Button.View data-testid="focus" observable={states.button} surface={{ kind: 'inherit' }} hotkeys={[]} onHandle={receive}>Button</Button.View>}
        </Card.View>
      </>;
    });
    await settle();
    const element = host.querySelector('[data-testid="focus"]') as HTMLElement;
    const focused = vi.spyOn(element, 'focus');
    const stale = handle;
    handle.focus(); expect(focused).toHaveBeenCalledOnce();
    const modal = document.createElement('div'); document.body.append(modal);
    const blocker = mountElementSurfaceLease({ name: 'activation.focus.modal', element: modal,
      transparent: false, layer: true, modal: true, keys: {} });
    disposers.push(blocker.dispose);
    handle.focus(); expect(focused).toHaveBeenCalledOnce();
    blocker.dispose(); modal.remove();
    setVisible(false); await settle();
    handle.focus(); expect(focused).toHaveBeenCalledOnce();
    setVisible(true); await settle();
    handle.focus(); expect(focused).toHaveBeenCalledTimes(2);
    dispose();
    expect(() => stale.focus()).toThrow(/disposed/);
  });
});
