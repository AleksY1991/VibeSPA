/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import type { JSX } from '@solidjs/web';
import { createEffect, createRoot, createSignal, flush, merge, untrack } from 'solid-js';
import { describe, expect, it, vi } from 'vitest';
import type { ElementConstruction, ElementHotkey, ElementSurface, Observable } from '../contracts/construction';
import { constructItem } from './construction';
import * as registered from './construction';
import { ElementBinding } from './element';
import { RenderedElement } from './rendered-element';
import { surfaceLineage } from './surface-lineage';
import { surfaceRegistry } from '../../tests/surface-host';

class Wrapper extends RenderedElement<boolean> {
  readonly element: JSX.Element = null;
  readonly props: ElementConstruction<boolean> & { readonly title?: string };
  constructor(name: string, props: ElementConstruction<boolean> & { readonly title?: string }) {
    super(name, props);
    this.props = this.capture(props);
  }
}

describe('shared element construction capture', () => {
  it('validates captured inputs once, preserves wrapper lineage and leaves presentation reactive', () => {
    const reads = vi.spyOn(registered, 'readObservable');
    const setup = createRoot(dispose => {
      const [selected, setSelected] = createSignal(false);
      const [title, setTitle] = createSignal('Initial');
      const observable = constructItem('capture.test', item => item.observe('selected', selected));
      const getObservable = vi.fn(() => observable);
      const getSurface = vi.fn((): ElementSurface => ({ kind: 'inherit' }));
      const getKey = vi.fn(() => 'Ctrl+Enter');
      const handler = vi.fn();
      const getHotkeys = vi.fn((): readonly ElementHotkey[] => [{ get key() { return getKey(); }, handler }]);
      const outer = new Wrapper('capture.outer', {
        get observable() { return getObservable(); },
        get surface() { return getSurface(); },
        get hotkeys() { return getHotkeys(); },
        get title() { return title(); },
      });
      const inner = new Wrapper('capture.inner', merge(outer.props));
      const binding = new ElementBinding('capture.inner', inner.props);
      binding.attachNonvisual(new EventTarget());
      const frames: (readonly [string | undefined, boolean])[] = [];
      createEffect(() => [inner.props.title, binding.value()] as const, value => { frames.push(value); });
      return { dispose, setTitle, setSelected, getObservable, getSurface, getHotkeys, getKey, frames, props: inner.props };
    });
    try {
      flush();
      setup.setTitle('Updated'); setup.setSelected(true); flush();
      expect(setup.getObservable).toHaveBeenCalledOnce();
      expect(setup.getSurface).toHaveBeenCalledOnce();
      expect(setup.getHotkeys).toHaveBeenCalledOnce();
      expect(setup.getKey).toHaveBeenCalledOnce();
      expect(reads).toHaveBeenCalledOnce();
      expect(setup.frames).toEqual([['Initial', false], ['Updated', true]]);
      expect(surfaceLineage(setup.props.surface, 'unused')).toEqual(['capture.outer', 'capture.inner']);
      expect(Object.isFrozen(setup.props.surface)).toBe(true);
      expect(Object.isFrozen(setup.props.hotkeys)).toBe(true);
      expect(Object.isFrozen(setup.props.hotkeys[0])).toBe(true);
    } finally { setup.dispose(); reads.mockRestore(); }
  });

  it('captures immutable construction values without treating mutable raw props as previously validated', () => {
    createRoot(dispose => {
      try {
        const observable = constructItem('capture.mutable', item => item.constant('visible', true));
        const shortcut = { key: 'Ctrl+Enter', handler: vi.fn() };
        const raw = { observable, surface: { kind: 'own', name: 'original', transparent: false } as const, hotkeys: [shortcut] };
        const wrapper = new Wrapper('capture.mutable', raw);
        shortcut.key = '';
        raw.hotkeys.push({ key: 'Ctrl+Enter', handler: vi.fn() });
        expect(() => new ElementBinding('capture.snapshot', wrapper.props)).not.toThrow();
        expect(wrapper.props.hotkeys).toHaveLength(1);
        expect(wrapper.props.hotkeys[0].key).toBe('Ctrl+Enter');
        expect(() => new ElementBinding('capture.raw', raw)).toThrow('custom hotkeys require unique keys and handlers');
        expect(() => new ElementBinding('capture.forged', {
          ...wrapper.props, hotkeys: [{ key: '', handler: vi.fn() }],
        })).toThrow('custom hotkeys require unique keys and handlers');
      } finally { dispose(); }
    });
  });

  it.each(['wrapper', 'binding'] as const)('rejects missing, forged and malformed construction inputs through %s', path => {
    createRoot(dispose => {
      try {
        const observable = constructItem('capture.invalid', item => item.constant('visible', true));
        const valid: ElementConstruction<boolean> = { observable, surface: { kind: 'inherit' }, hotkeys: [] };
        const construct = (overrides: object) => {
          const props = { ...valid, ...overrides } as ElementConstruction<boolean>;
          return path === 'wrapper' ? new Wrapper('capture.invalid', props) : new ElementBinding('capture.invalid', props);
        };
        for (const value of [undefined, { read: () => true } as unknown as Observable<boolean>]) {
          expect(() => construct({ observable: value })).toThrow('registered observable');
        }
        for (const surface of [undefined, { kind: 'unknown' }, { kind: 'own', name: '', transparent: false }, { kind: 'own', name: 'missing-policy' }]) {
          expect(() => construct({ surface })).toThrow(/surface|owned surface/);
        }
        for (const hotkeys of [undefined, {}, [{ key: '', handler: vi.fn() }], [{ key: 'Ctrl+Enter' }],
          [{ key: 'Ctrl+Enter', handler: vi.fn() }, { key: 'Ctrl+Enter', handler: vi.fn() }]]) {
          expect(() => construct({ hotkeys })).toThrow(/hotkeys|hotkeys array/);
        }
      } finally { dispose(); }
    });
  });

  it('still checks native-key conflicts at the concrete binding after shared capture', () => {
    createRoot(dispose => {
      try {
        const observable = constructItem('capture.native', item => item.constant('visible', true));
        const input = { observable, surface: { kind: 'inherit' } as const, hotkeys: [{ key: 'Space', handler: vi.fn() }] };
        const wrapper = new Wrapper('capture.native', input);
        expect(() => new ElementBinding('capture.native', wrapper.props, { nativeKeys: ['Space'] })).toThrow('native-owned');
        const explicit = new Wrapper('capture.override', { ...input, hotkeys: [{ ...input.hotkeys[0], overrideNative: true }] });
        const binding = new ElementBinding('capture.override', explicit.props, { nativeKeys: ['Space'] });
        expect(untrack(binding.value)).toBe(true);
      } finally { dispose(); }
    });
  });

  it('keeps one public identity when an internal binding delegates shortcuts to a child', () => {
    const dispose = createRoot(stop => {
      const observable = constructItem('capture.calendar', item => item.constant('visible', true));
      const wrapper = new Wrapper('CalendarField', {
        observable, surface: { kind: 'inherit' }, hotkeys: [{ key: 'Ctrl+Enter', handler: vi.fn() }],
      });
      const binding = new ElementBinding('CalendarField', {
        observable: wrapper.props.observable,
        surface: wrapper.props.surface,
        hotkeys: [],
      });
      binding.attachNonvisual(new EventTarget());
      return stop;
    });
    try {
      flush();
      expect(surfaceRegistry.read().activeSurfaces.map(surface => surface.name)).toEqual(['CalendarField']);
    } finally { dispose(); }
    flush();
    expect(surfaceRegistry.read().activeSurfaces).toEqual([]);
  });

  it('revalidates changed hotkeys and observables without duplicating a captured identity', () => {
    createRoot(dispose => {
      try {
        const values = constructItem('capture.rebound', item => ({
          first: item.constant('first', true), second: item.constant('second', false),
        }));
        const wrapper = new Wrapper('CalendarField', { observable: values.first, surface: { kind: 'inherit' }, hotkeys: [] });
        const binding = new ElementBinding('CalendarField', {
          ...wrapper.props, observable: values.second, hotkeys: [{ key: 'Ctrl+Enter', handler: vi.fn() }],
        });
        binding.attachNonvisual(new EventTarget());
        expect(untrack(binding.value)).toBe(false);
        expect(surfaceRegistry.read().activeSurfaces.map(surface => surface.name)).toEqual(['CalendarField']);
        expect(() => new ElementBinding('CalendarField', {
          ...wrapper.props, observable: { read: () => true } as Observable<boolean>, hotkeys: [],
        })).toThrow('registered observable');
        for (const hotkeys of [
          [{ key: '', handler: vi.fn() }],
          [{ key: 'Ctrl+Enter', handler: vi.fn() }, { key: 'Ctrl+Enter', handler: vi.fn() }],
        ]) {
          expect(() => new ElementBinding('CalendarField', { ...wrapper.props, hotkeys }))
            .toThrow('custom hotkeys require unique keys and handlers');
        }
        expect(() => new ElementBinding('CalendarField', {
          ...wrapper.props, hotkeys: [{ key: 'Space', handler: vi.fn() }],
        }, { nativeKeys: ['Space'] })).toThrow('native-owned');
      } finally { dispose(); }
    });
  });

  it('still appends a public wrapper identity when its forwarded hotkeys change', () => {
    createRoot(dispose => {
      try {
        const observable = constructItem('capture.forward', item => item.constant('visible', true));
        const outer = new Wrapper('CalendarField', { observable, surface: { kind: 'inherit' }, hotkeys: [] });
        const inner = new Wrapper('TextField', {
          ...outer.props, hotkeys: [{ key: 'Ctrl+Enter', handler: vi.fn() }],
        });
        expect(surfaceLineage(inner.props.surface, 'unused')).toEqual(['CalendarField', 'TextField']);
      } finally { dispose(); }
    });
  });
});
