/** @jsxImportSource @solidjs/web */
// @vitest-environment happy-dom
import { render } from '@solidjs/web';
import { createEffect, createMemo, createRoot, createSignal, flush, untrack } from 'solid-js';
import { afterEach, expect, it, vi } from 'vitest';
import { deliverEvent, guardNativeEvents, surfaceCommand, surfaceEvent } from './activation';

const cleanups: (() => void)[] = [];
afterEach(() => {
  for (const cleanup of cleanups.splice(0).reverse()) cleanup();
  document.body.replaceChildren();
  flush();
});

it.each(['effect', 'memo'] as const)('isolates synchronous focusout, handler getters and admission from an outer %s', scope => {
  const host = document.createElement('div');
  document.body.append(host);
  let focus!: HTMLButtonElement;
  const snapshots: number[] = [];
  let runs = 0;
  createRoot(dispose => {
    cleanups.push(dispose);
    const [value, setValue] = createSignal(1, { ownedWrite: true });
    const [trigger, setTrigger] = createSignal(false, { ownedWrite: true });
    const owner = { canActivate: () => value() > 0, isLive: () => value() > 0, isDisposed: () => false };
    const handler = () => { snapshots.push(value()); };
    const guarded = guardNativeEvents(owner, { get onFocusOut() { value(); return handler; } });
    const release = render(() => <div {...guarded}><button ref={node => { focus = node; }}>Focus</button></div>, host);
    cleanups.push(release);
    focus.focus();
    const dispatch = () => { runs++; if (trigger()) focus.blur(); return runs; };
    const computation = scope === 'memo' ? createMemo(dispatch) : undefined;
    if (scope === 'effect') createEffect(trigger, ready => { if (ready) { runs++; focus.blur(); } });
    setTrigger(true);
    flush();
    if (computation) untrack(computation);
    expect(snapshots).toEqual([1]);
    const before = runs;
    setValue(2);
    flush();
    if (computation) untrack(computation);
    expect(runs).toBe(before);
    expect(snapshots).toEqual([1]);
  });
});

it.each(['command', 'event', 'bound-data'] as const)('isolates %s delivery while preserving return values and live authority', kind => {
  createRoot(dispose => {
    cleanups.push(dispose);
    const [value, setValue] = createSignal(1, { ownedWrite: true });
    const handler = vi.fn((prefix: number) => prefix + value());
    const owner = { canActivate: () => value() > 0 };
    const event = new FocusEvent('focusout') as FocusEvent & { currentTarget: HTMLDivElement; target: Element };
    const command = surfaceCommand(owner, handler);
    const accepted = surfaceEvent(owner, () => { handler(10); });
    let runs = 0;
    const result = createMemo(() => {
      runs++;
      if (kind === 'command') return command(10);
      if (kind === 'event') accepted(event);
      else deliverEvent([(prefix: number) => { handler(prefix); }, 10], event);
      return 11;
    });
    expect(untrack(result)).toBe(11);
    expect(handler).toHaveBeenCalledOnce();
    setValue(2);
    flush();
    expect(untrack(result)).toBe(11);
    expect(runs).toBe(1);
    if (kind === 'command') expect(command(10)).toBe(12);
    setValue(0);
    flush();
    expect(command(10)).toBeUndefined();
    const before = handler.mock.calls.length;
    accepted(event);
    expect(handler).toHaveBeenCalledTimes(before);
  });
});
