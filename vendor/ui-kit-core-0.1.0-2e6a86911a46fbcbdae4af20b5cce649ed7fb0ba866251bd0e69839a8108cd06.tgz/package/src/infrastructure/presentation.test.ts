import { describe, expect, it } from 'vitest';
import type { ControlPlacement } from '../contracts/presentation';
import { assertControlPresentation, controlPlacement } from './presentation';

describe('closed control presentation boundary', () => {
  it.each(['class', 'className', 'classList', 'style', 'style:color', 'class:custom',
    'attr:class', 'attr:style', 'prop:className', 'prop:classList', 'prop:style', 'data-ui-recipe',
    'data-wa-size', 'attr:data-ui-selected', 'prop:data-ui-control-size', 'dataset', 'prop:dataset'])('rejects a JavaScript styling escape: %s', key => {
    expect(() => assertControlPresentation('Button', { [key]: 'override' })).toThrow(/presentation|public presentation/);
  });

  it('rejects reserved composition inputs even when undefined and leaves semantic props alone', () => {
    expect(() => assertControlPresentation('SearchField', { recipe: undefined }, ['recipe', 'size', 'type'])).toThrow('recipe');
    expect(() => assertControlPresentation('Button', { id: 'save', recipe: 'button', 'aria-label': 'Save' })).not.toThrow();
  });

  it('accepts outer layout placement without copying its reactive property getters', () => {
    let width = '100%';
    const placement: ControlPlacement = { get width() { return width; }, 'grid-column': '2', 'align-self': 'start' };
    const checked = controlPlacement('Button', placement);
    expect(checked).toBe(placement);
    width = '50%';
    expect(checked?.width).toBe('50%');
    expect(controlPlacement('Button', undefined)).toBeUndefined();
  });

  it.each(['height', 'padding', 'gap', 'color', 'font-size', 'border', '--ui-button-height'])('rejects an asserted/imported placement override: %s', key => {
    const imported = { width: '100%', [key]: '12px' } as unknown as ControlPlacement;
    expect(() => controlPlacement('Button', imported)).toThrow(key);
  });

  it.each(['width:100%;color:red', [], null])('rejects a non-object placement value', value => {
    expect(() => controlPlacement('Button', value as unknown as ControlPlacement)).toThrow('outer-placement object');
  });
});
