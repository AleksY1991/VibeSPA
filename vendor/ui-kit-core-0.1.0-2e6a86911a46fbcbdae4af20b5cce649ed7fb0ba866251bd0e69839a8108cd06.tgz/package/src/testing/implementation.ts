/** Test-only provider seam for preparing the canonical vendor controls. */
export { ImplementationContext } from '../infrastructure/implementation-context';
export type { PreparedImplementation } from '../infrastructure/implementation-context';
