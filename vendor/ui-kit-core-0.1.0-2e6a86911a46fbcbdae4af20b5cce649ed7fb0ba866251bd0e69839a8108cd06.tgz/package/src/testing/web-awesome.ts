/** Test-only vendor controls and definition loaders for application integration tests. */
export { WebAwesomeProgressBar } from '../vendor/web-awesome/progress-bar.adapter';
export { WebAwesomeAvatar } from '../vendor/web-awesome/avatar.adapter';
export { importButtonElement, importDialogElement, importPopoverElement, importTextFieldElement, importTextareaElement, importChoiceElement, importChoiceGroupElement } from '../vendor/web-awesome/elements';
export type { ButtonElement, DialogElement, TextareaElement, ChoiceElement, ChoiceGroupElement, TextFieldElement } from '../vendor/web-awesome/elements';
export { WebAwesomePopoverSurface } from '../vendor/web-awesome/surfaces.adapter';
export { WebAwesomeDivider } from '../vendor/web-awesome/divider.adapter';
export { WebAwesomeTextField } from '../vendor/web-awesome/text-field.adapter';
export { WebAwesomeToggle, WebAwesomeChoiceGroup } from '../vendor/web-awesome/controls.adapter';
export { WebAwesomeCheckbox } from '../vendor/web-awesome/checkbox.adapter';
