import './typography.css';
export { TEXT_METRICS, TEXT_WEIGHT, type TextWeight } from './typography-metrics';

/** Enlarged reading uses the existing 17px step without turning prose into a heading. */
export const READING_TEXT = Object.freeze({
  default: "ui-typography-default-1",
  large: "ui-typography-large-2",
});
