/** Hit boxes on coarse pointers and the dense-row visual floor. */
export const TAP_MIN = 44;
export const TAP_VISUAL_MIN = 36;
export const TAP_VISUAL_FORBIDDEN_BELOW = 32;
