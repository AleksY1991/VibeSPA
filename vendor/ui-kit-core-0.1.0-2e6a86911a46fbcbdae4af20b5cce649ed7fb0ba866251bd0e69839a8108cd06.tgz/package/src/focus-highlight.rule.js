// Focus styling has one fixed policy. Selection, text carets, and skip-link
// positioning are independent and remain available.
const FOCUS = /(?:^|[^a-z])focus(?:-visible|-within)?(?=[:\]_)])/;
const PAINT = /^(?:outline|ring|shadow|border|bg|text|fill|stroke|opacity|decoration)(?:-|$)|^\[(?:outline|box-shadow|border|background|color|opacity)[:\]]/;
const RESET = /^(?:outline-none|outline-0|ring-0|ring-offset-0|shadow-none)$/;

export function focusClassProblems(text) {
  return text.split(/\s+/).filter(token => {
    if (!FOCUS.test(token)) return false;
    let depth = 0;
    let start = 0;
    for (let index = 0; index < token.length; index += 1) {
      if (token[index] === '[') depth += 1;
      else if (token[index] === ']') depth -= 1;
      else if (token[index] === ':' && depth === 0) start = index + 1;
    }
    const utility = token.slice(start).replace(/^!/, '');
    return PAINT.test(utility) && !RESET.test(utility);
  });
}

export function focusDeclarationProblem(property, value, selector = '') {
  const neutral = /^(?:none|transparent|0(?:px)?)(?:\s*!important)?$/.test(value.trim());
  if (/^--wa-(?:focus-ring(?:-.+)?|color-focus)$/.test(property)) return !neutral;
  if (!/:focus(?:-visible|-within)?\b/.test(selector)) return false;
  return /^(?:outline(?:-.+)?|box-shadow|border(?:-.+)?|background(?:-.+)?|color|opacity|fill|stroke|--.+)$/.test(property) && !neutral;
}

export const FOCUS_HIGHLIGHT = {
  meta: { type: 'problem', schema: [], messages: {
    paint: 'Focus never paints a highlight in the control library. Remove {{value}}; keep native keyboard behavior and explicit selection states. There is no focus-ring opt-in.',
  } },
  create(context) {
    // Regression fixtures must be able to spell forbidden examples.
    if (/\.(?:test|spec)\.[jt]sx?$/.test(context.filename)) return {};
    const inspect = (node, text) => {
      for (const value of focusClassProblems(text)) context.report({ node, messageId: 'paint', data: { value } });
    };
    return {
      Property(node) {
        const property = node.key.name ?? node.key.value;
        const selectors = [];
        for (let parent = node.parent; parent; parent = parent.parent) {
          if (parent.type === 'Property' && typeof parent.key.value === 'string') selectors.push(parent.key.value);
        }
        if (typeof property === 'string' && node.value.type === 'Literal'
          && focusDeclarationProblem(property.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`), String(node.value.value), selectors.join(' '))) {
          context.report({ node, messageId: 'paint', data: { value: property } });
        }
      },
      Literal(node) { if (typeof node.value === 'string') inspect(node, node.value); },
      TemplateElement(node) { inspect(node, node.value.raw); },
      Identifier(node) {
        if (/^(?:FOCUS_RING(?:_NONE)?|FIELD_FOCUS|focusRing)$/.test(node.name)) {
          context.report({ node, messageId: 'paint', data: { value: node.name } });
        }
      },
    };
  },
};
