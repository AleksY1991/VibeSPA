import { describe, expect, it } from 'vitest';
import { createRoot } from 'solid-js';
import { constructItem } from './infrastructure/construction';
import { dialogContentClass, dialogFrameClass, resolveDialogPresentation, type DialogPresentation } from './dialog-presentation';

describe('closed Dialog presentation recipes', () => {
  it('keeps the ordinary dialog contract when no presentation is requested', () => {
    const frame = resolveDialogPresentation({});
    expect(frame).toEqual({ recipe: 'dialog', size: 'default', placement: 'center',
      variant: 'default', overflow: 'visible', layout: 'grid', padding: 'md', gap: 'md', height: 'content', backdrop: 'default' });
    expect(dialogFrameClass(frame)).toContain('ui-dialog-size-default');
    expect(dialogContentClass(frame)).toBe('ui-dialog-content ui-dialog-layout-grid ui-dialog-padding-md ui-dialog-gap-md');
  });

  it('keeps bounded editor geometry together instead of accepting independently tuned layout', () => {
    const frame = resolveDialogPresentation({ recipe: 'editor', size: 'sm', placement: 'corner' });
    expect(frame).toMatchObject({ recipe: 'editor', size: 'sm', placement: 'corner', variant: 'default',
      overflow: 'hidden', layout: 'column', padding: 'none', gap: 'none', height: 'viewport', backdrop: 'default' });
    expect(dialogFrameClass(frame)).toContain('ui-dialog-height-viewport');
    expect(dialogContentClass(frame)).toBe('ui-dialog-content ui-dialog-layout-column ui-dialog-padding-none ui-dialog-gap-none');
  });

  it('uses one viewport editor recipe without bounded width or placement input', () => {
    const frame = resolveDialogPresentation({ recipe: 'fullscreen' });
    expect(frame).toMatchObject({ variant: 'fullscreen', overflow: 'hidden', layout: 'column',
      padding: 'none', gap: 'none', backdrop: 'default' });
    expect(dialogFrameClass(frame)).toContain('ui-dialog-variant-fullscreen');
  });

  it('retains the detached frame and gap-dismissal composition', () => {
    const frame = resolveDialogPresentation({ recipe: 'detached' });
    expect(frame).toMatchObject({ variant: 'detached', overflow: 'visible', layout: 'grid',
      padding: 'md', gap: 'md', backdrop: 'transparent' });
    expect(dialogFrameClass(frame)).toContain('ui-dialog-variant-detached');
    expect(dialogContentClass(frame)).toBe('ui-dialog-content ui-dialog-layout-grid ui-dialog-padding-md ui-dialog-gap-md');
  });

  it('owns content-sized form and media frame compositions', () => {
    expect(resolveDialogPresentation({ recipe: 'form', size: 'md' })).toMatchObject({
      layout: 'column', padding: 'none', gap: 'none', height: 'content', overflow: 'hidden', size: 'md',
    });
    expect(resolveDialogPresentation({ recipe: 'media' })).toMatchObject({
      layout: 'block', padding: 'none', gap: 'none', height: 'content', overflow: 'hidden',
    });
  });

  it('reads drawer width and expansion from a registered panel model', () => {
    createRoot(dispose => {
      try {
        const drawer = constructItem('dialog.drawer.model', item => item.constant('panel', { width: 640, expanded: false }));
        expect(resolveDialogPresentation({ recipe: 'drawer', drawer })).toMatchObject({
          variant: 'default', placement: 'corner', height: 'viewport', layout: 'column',
          backdrop: 'transparent', padding: 'none', gap: 'none', overflow: 'hidden', panelWidth: 640, expanded: false,
        });
        const fullscreen = constructItem('dialog.drawer.expanded', item => item.constant('panel', { width: 640, expanded: true }));
        expect(resolveDialogPresentation({ recipe: 'drawer', drawer: fullscreen })).toMatchObject({
          variant: 'fullscreen', placement: 'center', backdrop: 'transparent', expanded: true,
        });
      } finally { dispose(); }
    });
  });

  it.each([0, -1, Infinity, NaN])('rejects an invalid live drawer width: %s', width => {
    createRoot(dispose => {
      try {
        const drawer = constructItem('dialog.drawer.invalid', item => item.constant('panel', { width }));
        expect(() => resolveDialogPresentation({ recipe: 'drawer', drawer })).toThrow('finite positive');
      } finally { dispose(); }
    });
  });

  it.each([
    ['class', 'p-4'], ['className', 'p-4'], ['classList', { padded: true }], ['style', { width: '777px' }],
  ])('rejects owned %s presentation even when an untyped caller bypasses TypeScript', (key, value) => {
    const imported = { [key]: value };
    const props = { ...imported } as unknown as DialogPresentation;
    expect(() => resolveDialogPresentation(props)).toThrow(TypeError);
    expect(() => resolveDialogPresentation(props)).toThrow(key);
  });

  it.each([
    { recipe: 'fullscreen', size: 'sm' }, { recipe: 'detached', size: 'md' }, { recipe: 'media', size: 'sm' },
    { recipe: 'fullscreen', placement: 'corner' }, { recipe: 'detached', placement: 'start' },
    { recipe: 'form', dock: 'end' }, { recipe: 'dialog', dock: 'end' },
    { recipe: 'custom' }, { size: 'wide' }, { placement: 'bottom-right' },
  ])('rejects an unsupported recipe combination: %j', props => {
    expect(() => resolveDialogPresentation(props as unknown as DialogPresentation)).toThrow(TypeError);
  });

  it('keeps end docking explicit and releases it when a drawer expands', () => {
    createRoot(dispose => {
      try {
        const drawer = constructItem('dialog.end', item => item.constant('panel', { width: 420 }));
        const end = resolveDialogPresentation({ recipe: 'drawer', drawer, dock: 'end' });
        expect(dialogFrameClass(end)).toContain('ui-dialog-dock-end');
        expect(dialogFrameClass(resolveDialogPresentation({ recipe: 'drawer', drawer }))).not.toContain('ui-dialog-dock-end');
        expect(() => resolveDialogPresentation({ recipe: 'drawer', drawer, dock: 'start' } as unknown as DialogPresentation)).toThrow('end docking');
        const expanded = constructItem('dialog.end.expanded', item => item.constant('panel', { width: 420, expanded: true }));
        expect(dialogFrameClass(resolveDialogPresentation({ recipe: 'drawer', drawer: expanded, dock: 'end' }))).not.toContain('ui-dialog-dock-end');
      } finally { dispose(); }
    });
  });

  it('cannot smuggle styling through an inherited composition object', () => {
    const props = Object.assign(Object.create({ style: { width: '777px' } }), { recipe: 'dialog' });
    expect(() => resolveDialogPresentation(props)).toThrow(TypeError);
    expect(() => resolveDialogPresentation(props)).toThrow('style');
  });
});
