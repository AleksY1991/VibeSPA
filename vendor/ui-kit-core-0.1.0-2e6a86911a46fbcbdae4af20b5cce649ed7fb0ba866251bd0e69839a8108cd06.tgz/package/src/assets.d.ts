/** Styles are bundled by the consuming application; no host ambient types needed. */
declare module '*.css';
