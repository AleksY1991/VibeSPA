/** CSS-free numeric metrics for build tools, canvas, and editor adapters. */
export const TEXT_METRICS = Object.freeze({
  caption: { size: 11, leading: 1.3, weight: 400 },
  body: { size: 13, leading: 1.4, weight: 400 },
  heading: { size: 17, leading: 1.4, weight: 600 },
  title: { size: 22, leading: 1.3, weight: 600 },
  field: { size: 16, leading: 1.4, weight: 400 },
} as const);

export const TEXT_WEIGHT = Object.freeze({ normal: 400, emphasis: 600 } as const);

export type TextWeight = typeof TEXT_WEIGHT[keyof typeof TEXT_WEIGHT];
