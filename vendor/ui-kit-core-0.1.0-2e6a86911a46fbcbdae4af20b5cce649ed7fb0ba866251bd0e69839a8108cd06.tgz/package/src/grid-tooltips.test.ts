// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { GridTooltip, gridTooltipOptions, gridTooltipText, setGridCellTooltip } from '@ui-kit/core/grid-tooltips';
import { authoredStyle, useStyles } from '../tests/styles';

useStyles('grid-tooltips.css');

afterEach(() => { document.body.replaceChildren(); });

function dimensions(element: HTMLElement, width: number, height = 20, contentWidth = width, contentHeight = height): void {
  Object.defineProperties(element, {
    clientWidth: { configurable: true, value: width },
    clientHeight: { configurable: true, value: height },
    scrollWidth: { configurable: true, value: contentWidth },
    scrollHeight: { configurable: true, value: contentHeight },
    getBoundingClientRect: { configurable: true, value: () => new DOMRect(0, 0, width, height) },
  });
}

function tooltipFor(element: HTMLElement, always = false): () => boolean {
  const setTooltip = vi.fn();
  setGridCellTooltip({ setTooltip }, element, 'Full displayed text', always);
  expect(setTooltip).toHaveBeenCalledWith('Full displayed text', expect.any(Function));
  return setTooltip.mock.calls[0][1] as () => boolean;
}

describe('grid content tooltips', () => {
  it('uses formatted display text without clipping or losing empty and scalar values', () => {
    expect(gridTooltipText({ value: 'raw', valueFormatted: 'Full displayed text\nnext line' }, '(detail)'))
      .toBe('Full displayed text\nnext line (detail)');
    expect(gridTooltipText({ value: 'raw', valueFormatted: '' })).toBe('');
    expect(gridTooltipText({ value: 0 })).toBe('0');
    expect(gridTooltipText({ value: false })).toBe('false');
    expect(gridTooltipText({}, 'detail')).toBe('detail');
    expect(gridTooltipText({ value: null })).toBe('');
  });

  it('finds a truncated nested span even when its renderer container fits', () => {
    const container = document.createElement('div');
    const text = document.createElement('span');
    container.append(text);
    document.body.append(container);
    dimensions(container, 200);
    dimensions(text, 120, 20, 400);
    expect(tooltipFor(container)()).toBe(true);
  });

  it('remeasures horizontal and vertical clipping after a column or row resize', () => {
    const text = document.createElement('div');
    document.body.append(text);
    dimensions(text, 100, 20, 300);
    const shouldShow = tooltipFor(text);
    expect(shouldShow()).toBe(true);
    dimensions(text, 320);
    expect(shouldShow()).toBe(false);
    dimensions(text, 320, 20, 320, 60);
    expect(shouldShow()).toBe(true);
    dimensions(text, 320, 60);
    expect(shouldShow()).toBe(false);
  });

  it('excludes hidden, detached and zero-size content, including forced tooltips', () => {
    const container = document.createElement('div');
    const text = document.createElement('span');
    container.append(text);
    document.body.append(container);
    dimensions(container, 200);
    dimensions(text, 100, 20, 400);
    const shouldShow = tooltipFor(container);
    text.hidden = true;
    expect(shouldShow()).toBe(false);
    text.hidden = false;
    text.style.visibility = 'hidden';
    expect(shouldShow()).toBe(false);
    text.style.visibility = '';
    dimensions(text, 0, 0, 400, 20);
    expect(shouldShow()).toBe(false);
    const alwaysShow = tooltipFor(container, true);
    expect(alwaysShow()).toBe(true);
    container.hidden = true;
    expect(alwaysShow()).toBe(false);
    container.hidden = false;
    container.remove();
    expect(alwaysShow()).toBe(false);
  });

  it('suppresses custom renderer tooltips while the cell is being edited', () => {
    const cell = document.createElement('div');
    const text = document.createElement('span');
    cell.append(text);
    document.body.append(cell);
    dimensions(text, 100, 20, 400);
    const setTooltip = vi.fn();
    setGridCellTooltip({ setTooltip, eGridCell: cell }, text, 'Full text');
    const shouldShow = setTooltip.mock.calls[0][1] as () => boolean;
    expect(shouldShow()).toBe(true);
    for (const editingClass of ['ag-cell-inline-editing', 'ag-cell-popup-editing']) {
      cell.classList.add(editingClass);
      expect(shouldShow()).toBe(false);
      cell.classList.remove(editingClass);
      expect(shouldShow()).toBe(true);
    }
  });

  it('renders complete multiline text safely in an owned grid tooltip surface', () => {
    const tooltip = new GridTooltip();
    const value = '<img src=x onerror=alert(1)>\n' + 'long-unbroken-content'.repeat(80);
    tooltip.init({ value });
    const gui = tooltip.getGui();
    document.body.append(gui);
    expect(gui.textContent).toBe(value);
    expect(gui.querySelector('img')).toBeNull();
    expect(gui.hasAttribute('data-ui-root')).toBe(true);
    expect(gui.hasAttribute('data-ui-grid-tooltip')).toBe(true);
    expect(gui.getAttribute('role')).toBe('tooltip');
    const style = getComputedStyle(gui);
    expect(style.whiteSpace).toBe('pre-wrap');
    expect(style.overflowWrap).toBe('anywhere');
    expect(style.overflow).toBe('auto');
    expect(authoredStyle(gui, 'max-width')).toContain('100vw');
    expect(authoredStyle(gui, 'max-height')).toContain('100vh');
  });

  it('renders the resolved tooltip value instead of the cell formatter summary', () => {
    const tooltip = new GridTooltip();
    const params = { value: 'Full details', valueFormatted: 'summary' };
    tooltip.init(params);
    expect(tooltip.getGui().textContent).toBe('Full details');
  });

  it('shares a short hover delay, truncation default and selectable tooltip interaction', () => {
    expect(gridTooltipOptions).toEqual({
      tooltipShowMode: 'whenTruncated', tooltipShowDelay: 300, tooltipInteraction: true,
    });
  });
});
