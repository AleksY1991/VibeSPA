// @vitest-environment happy-dom
import { readFileSync } from 'node:fs';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import type { Window } from 'happy-dom';
import { CONTROL_SIZES, controlSize, type ControlSize } from './control-size';

const browser = window as unknown as Window;
const sheets = ['control-tokens.css', 'solid/control-geometry.css', 'solid/tabs.css', 'vendor/web-awesome/controls.css', 'vendor/web-awesome/text-field.css', 'vendor/web-awesome/tabs.css']
  .map(file => readFileSync(`src/${file}`, 'utf8')).join('\n');

beforeEach(() => {
  browser.happyDOM.setWindowSize({ width: 1200, height: 900 });
  const style = document.createElement('style');
  style.dataset.controlTest = '';
  // Browser checks exercise the real shadow parts. Happy DOM resolves shared
  // host/native geometry, with the narrow-screen arm of the same media query.
  style.textContent = sheets.replace(/@import[^;]+;/g, '').replaceAll('(pointer: coarse), (max-width: 767px)', '(max-width: 767px)');
  document.head.append(style);
});
afterEach(() => {
  document.body.replaceChildren();
  document.querySelector('[data-control-test]')?.remove();
});

function element(tag: string, size: ControlSize, className = '', attribute?: string) {
  const host = document.createElement(tag);
  host.dataset.uiRoot = '';
  host.dataset.uiControlSize = size;
  host.className = className;
  if (attribute) host.setAttribute(attribute, '');
  document.body.append(host);
  return host;
}

describe('shared control size scale', () => {
  it.each([1200, 600])('aligns field and selection targets at viewport width %i', width => {
    browser.happyDOM.setWindowSize({ width, height: 900 });
    CONTROL_SIZES.forEach((size, index) => {
      const height = `${width === 600 ? 44 : 32 + index * 4}px`;
      expect(getComputedStyle(element('input', size, 'ui-native-field')).height).toBe(height);
      for (const [tag, attribute] of [['wa-input', 'data-ui-text-field'], ['wa-select', 'data-ui-select']]) {
        expect(getComputedStyle(element(tag, size, '', attribute)).getPropertyValue('--wa-form-control-height')).toBe(height);
      }
      for (const [tag, attribute] of [['wa-switch', 'data-ui-toggle'], ['wa-checkbox', 'data-ui-checkbox']]) {
        expect(getComputedStyle(element(tag, size, '', attribute)).minHeight).toBe(height);
      }
      for (const [tag, childTag] of [['wa-tab-group', 'wa-tab']]) {
        const tabs = element(tag, size, '', 'data-ui-tabs');
        const tab = document.createElement(childTag);
        tab.setAttribute('data-ui-tab', '');
        tabs.append(tab);
        expect(getComputedStyle(tab).height).toBe(height);
      }
    });
  });

  it.each([1200, 600])('keeps selection graphics independent of the hit target at width %i', width => {
    browser.happyDOM.setWindowSize({ width, height: 900 });
    CONTROL_SIZES.forEach((size, index) => {
      const vendor = getComputedStyle(element('wa-switch', size, '', 'data-ui-toggle'));
      expect(vendor.getPropertyValue('--width')).toBe(`${28 + index * 8}px`);
      expect(vendor.getPropertyValue('--height')).toBe(`${16 + index * 4}px`);
      expect(vendor.getPropertyValue('--thumb-size')).toBe(`${12 + index * 4}px`);
      const mark = ['16px', '16px', '20px', '24px'][index];
      const checkbox = getComputedStyle(element('wa-checkbox', size, '', 'data-ui-checkbox'));
      expect(checkbox.getPropertyValue('--wa-form-control-toggle-size')).toBe(mark);
    });
  });

  it('uses dense by default and keeps explicit sizes independent of content layout', () => {
    expect(controlSize()).toBe('dense');
    for (const size of CONTROL_SIZES) {
      expect(controlSize(size)).toBe(size);
    }
  });
});
