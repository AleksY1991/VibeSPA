import { spread } from '@solidjs/web';
import type { SelectRecipe, TextareaRecipe, TextFieldRecipe } from './contracts/field-presentation';
import type { ControlPlacement } from './contracts/presentation';
import { controlPlacement } from './infrastructure/presentation';

type FieldRecipe = TextFieldRecipe | TextareaRecipe | SelectRecipe;
type FieldFamily = 'text' | 'textarea' | 'select';
const fieldRecipes: Record<FieldRecipe, { appearance: 'outlined' | 'filled'; families: readonly FieldFamily[] }> = {
  form: { appearance: 'outlined', families: ['text', 'textarea', 'select'] },
  inline: { appearance: 'outlined', families: ['text', 'textarea'] },
  filled: { appearance: 'filled', families: ['text', 'textarea'] },
  code: { appearance: 'outlined', families: ['text', 'textarea'] },
  entry: { appearance: 'outlined', families: ['text', 'textarea', 'select'] },
  title: { appearance: 'outlined', families: ['text'] },
  'search-action': { appearance: 'outlined', families: ['text'] },
  reading: { appearance: 'outlined', families: ['textarea'] },
  composer: { appearance: 'outlined', families: ['textarea'] },
  'compact-composer': { appearance: 'outlined', families: ['textarea'] },
};

/** A recipe is closed; callers cannot combine its internal decisions. */
export function fieldRecipe(name: string, recipe: FieldRecipe | undefined, family: FieldFamily = 'text'): FieldRecipe {
  const resolved = recipe ?? 'form';
  if (typeof resolved !== 'string' || !Object.hasOwn(fieldRecipes, resolved) || !fieldRecipes[resolved].families.includes(family)) {
    throw new TypeError(`${name}: unsupported field recipe "${resolved}"`);
  }
  return resolved;
}

export function fieldAppearance(recipe: FieldRecipe | undefined): 'outlined' | 'filled' {
  return fieldRecipes[recipe ?? 'form'].appearance;
}

/** Placement updates remain separate from the field's private geometry styles. */
export function placeField(host: HTMLElement, read: () => ControlPlacement | undefined): void {
  spread(host, { get style() { return controlPlacement('Field', read()); } });
}

export type { TextFieldRecipe, TextareaRecipe };
