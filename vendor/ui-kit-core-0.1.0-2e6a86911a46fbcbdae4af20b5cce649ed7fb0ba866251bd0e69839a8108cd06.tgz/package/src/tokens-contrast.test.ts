import { readFileSync } from 'node:fs';
import postcss from 'postcss';
import { describe, expect, it } from 'vitest';

const themes = { light: new Map<string, string>(), dark: new Map<string, string>() };
postcss.parse(readFileSync('src/tokens.css', 'utf8')).walkRules(rule => {
  const theme = rule.selector.includes('.dark') ? themes.dark : themes.light;
  rule.walkDecls(declaration => { theme.set(declaration.prop, declaration.value); });
});

const luminance = (hsl: string): number => {
  const match = /^([\d.]+) ([\d.]+)% ([\d.]+)%$/.exec(hsl);
  if (!match) throw new Error(`Expected a concrete HSL token, received ${hsl}`);
  const hue = Number(match[1]) / 60;
  const saturation = Number(match[2]) / 100;
  const lightness = Number(match[3]) / 100;
  const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation;
  const second = chroma * (1 - Math.abs(hue % 2 - 1));
  const channels = hue < 1 ? [chroma, second, 0] : hue < 2 ? [second, chroma, 0]
    : hue < 3 ? [0, chroma, second] : hue < 4 ? [0, second, chroma]
      : hue < 5 ? [second, 0, chroma] : [chroma, 0, second];
  const linear = channels.map(channel => {
    const value = channel + lightness - chroma / 2;
    return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return linear[0]! * 0.2126 + linear[1]! * 0.7152 + linear[2]! * 0.0722;
};

describe('semantic control-boundary contrast', () => {
  it.each(['light', 'dark'] as const)('keeps enabled control edges visible on %s surfaces', theme => {
    const values = themes[theme];
    const boundary = luminance(values.get('--ui-input')!);
    for (const surface of ['--ui-background', '--ui-card', '--ui-popover']) {
      const background = luminance(values.get(surface)!);
      const ratio = (Math.max(boundary, background) + 0.05) / (Math.min(boundary, background) + 0.05);
      expect(ratio, `${theme} control boundary against ${surface}`).toBeGreaterThanOrEqual(3);
    }
    // Separators and control edges are separate roles, not one overloaded gray.
    expect(values.get('--ui-input')).not.toBe(values.get('--ui-border'));
  });
});
