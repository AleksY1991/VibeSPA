import type { SurfaceHotkeyHandler } from './platform';

declare const observableType: unique symbol;

/** A registered read handle. Reading it never creates an upstream binding. */
export interface Observable<T> {
  readonly [observableType]: T;
  readonly read: () => T;
}

export type ElementSurface =
  /** An actual local identity that delegates unresolved keys only to its owner. */
  | { readonly kind: 'inherit' }
  | { readonly kind: 'own'; readonly name: string; readonly transparent: boolean; readonly layer?: true };

export interface ElementHotkey {
  readonly key: string;
  readonly handler: SurfaceHotkeyHandler;
  /** Deliberately replace a browser/vendor-owned key; omission preserves native behavior. */
  readonly overrideNative?: boolean;
}

/** Required at every public element constructor, including forwarding wrappers. */
export interface ElementConstruction<T> {
  readonly observable: Observable<T>;
  readonly surface: ElementSurface;
  readonly hotkeys: readonly ElementHotkey[];
}
