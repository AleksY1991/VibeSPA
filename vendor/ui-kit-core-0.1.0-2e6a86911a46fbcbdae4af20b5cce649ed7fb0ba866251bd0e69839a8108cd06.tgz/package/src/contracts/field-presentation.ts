import type { ControlSize } from '../control-size';
import type { ClosedControlPresentation, ControlPlacement } from './presentation';

type FormFieldRecipe = 'form' | 'inline' | 'filled' | 'code';

/** Complete field compositions own paint, typography and internal spacing. */
export type TextFieldRecipe = FormFieldRecipe | 'entry' | 'title' | 'search-action';
export type TextareaRecipe = FormFieldRecipe | 'entry' | 'reading' | 'composer' | 'compact-composer';
export type SelectRecipe = 'form' | 'entry';

export interface FieldPresentation extends ClosedControlPresentation {
  readonly recipe?: TextFieldRecipe;
  readonly size?: ControlSize;
  readonly placement?: ControlPlacement;
  readonly appearance?: never;
  readonly visualStyle?: never;
  readonly textSize?: never;
  readonly font?: never;
  readonly tabular?: never;
  readonly paddingInline?: never;
  readonly paddingBlock?: never;
  readonly paddingEnd?: never;
  readonly lineHeight?: never;
  readonly textAlign?: never;
}
