import type { JSX } from '@solidjs/web';

export interface ScrollAreaControlProps extends Omit<JSX.HTMLAttributes<HTMLDivElement>,
  'ref' | 'onKeyDown' | 'onKeyUp' | 'onKeyPress' | 'hidden' | 'aria-hidden'> {
  readonly as?: 'div' | 'main' | 'section';
  readonly orientation?: 'vertical' | 'horizontal' | 'both';
  readonly fill?: boolean;
  readonly class?: string;
  readonly className?: string;
  readonly visible: boolean;
  readonly onElement?: (element: HTMLElement) => void;
  readonly onScrollElement?: (element: HTMLElement) => void;
}
