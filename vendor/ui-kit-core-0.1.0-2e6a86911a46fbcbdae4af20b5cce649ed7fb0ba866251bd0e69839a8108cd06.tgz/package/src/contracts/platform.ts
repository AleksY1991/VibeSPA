/** Browser surface bridge for bootstrap/platform adapters and private UI runtime only. */

export type Dispose = () => void;

export interface SurfaceLease {
  readonly instanceId: string;
  readonly dispose: Dispose;
}

/** Permission comes from the surface tree; components execute DOM focus work. */
export interface SurfaceAuthority {
  subscribe(listener: () => void): Dispose;
  canDismiss(target?: EventTarget | null): boolean;
  claimDismissal(event: Event): boolean;
  canMoveFocus(): boolean;
  canRestoreFocus(target?: Element | null): boolean;
  hasDismissableChild(): boolean;
  dispatchChildEscape(event: KeyboardEvent): ElementSurfaceResolution;
  canActivate(): boolean;
}

export interface ElementSurfaceLease extends SurfaceLease {
  readonly authority: SurfaceAuthority;
  /** Policy/internal-control updates retain this mounted lifetime's identity and order. */
  update(definition: ElementSurfaceUpdate): void;
}

export interface ElementSurfaceUpdate {
  readonly layer?: boolean;
  readonly modal?: boolean;
  readonly dismissable?: boolean;
  readonly nativeOwners?: readonly Element[];
  readonly activationRoots?: readonly Element[];
}

/** A listener-only public element owns its target and lifetime without a DOM layer. */
export interface NonvisualSurfaceDefinition {
  readonly name: string;
  readonly target: EventTarget;
  readonly parentId?: string | null;
}

/** Return HOTKEY_PASS to release the browser while this surface still blocks ancestors. */
export const HOTKEY_PASS = Symbol('HOTKEY_PASS');

/** Delegate this key to the declared owner, without exposing unrelated shortcuts. */
export const HOTKEY_DELEGATE = Symbol('HOTKEY_DELEGATE');

export type SurfaceHotkeyHandler = (
  event: KeyboardEvent,
  currentTarget: Element,
) => void | typeof HOTKEY_PASS | typeof HOTKEY_DELEGATE;

/** One currently live renderer, popup, menu, row, or other keyboard owner. */
export interface ActiveSurface {
  /** Stable definition name; instances may share it. */
  readonly name: string;
  /** Unique for this open/mount lifetime. */
  readonly instanceId: string;
  /** Declared logical owner or a nearer registered DOM ancestor within it. */
  readonly parentId: string | null;
  /** Canonical key combinations this instance handles directly. */
  readonly keys: readonly string[];
  /** Whether an unhandled combination may continue to its parent. */
  readonly transparent: boolean;
  /** Open layers arbitrate globally; ordinary elements arbitrate only on their DOM path. */
  readonly layer: boolean;
  /** Monotonic registry sequence: larger means opened later. */
  readonly openedAt: number;
}

/** Runtime definition used by Solid's hotkeys ref factory. */
export interface ElementSurfaceDefinition {
  readonly name: string;
  readonly element: Element;
  readonly transparent: boolean;
  readonly layer: boolean;
  readonly keys: Readonly<Record<string, SurfaceHotkeyHandler>>;
  /** This owner, rather than delegated child controls, can dismiss its surface. */
  readonly dismissable?: boolean;
  /** Focus modality is independent of shortcut/dismissal layer scope. */
  readonly modal?: boolean;
  /** Unhandled combinations explicitly delegated to this instance's owner. */
  readonly delegate?: readonly string[] | 'all';
  /** Explicit exceptions to a control's native-key ownership, valid for this lease only. */
  readonly nativeOverrides?: readonly string[];
  /** Native controls implemented by this composite, never arbitrary descendants. */
  readonly nativeOwners?: readonly Element[];
  /** Related trigger subtrees that may activate while this owner's layer is open. */
  readonly activationRoots?: readonly Element[];
  /** Focus containment runs independently of dismissal and opaque key ownership. */
  readonly focusKeys?: Readonly<Record<string, SurfaceHotkeyHandler>>;
  /** Logical element owner, or renderer fallback when no DOM element owner exists. */
  readonly parentId?: string | null;
}

export type ElementSurfaceResolution =
  | { readonly kind: 'handled'; readonly name: string }
  | { readonly kind: 'blocked'; readonly name: string }
  | { readonly kind: 'action'; readonly name: string; readonly actionId: string }
  | { readonly kind: 'unclaimed' };

/**
 * How Escape leaves a surface. Escape is never an ordinary action key: every
 * surface declares one exit, and the registry derives its binding.
 *
 * `stack` (default): Escape binds to `<id>.exit` in this surface's scope, so
 * resolution order decides which live surface leaves first.
 * `element`: the surface's own DOM layer (dialog, menu, editor) delivers Escape.
 * Required for a transparent overlay without a view: a stack binding would
 * shadow the underlying content while focus is outside the overlay.
 */
export interface SurfaceExitPolicy {
  readonly label: string;
  readonly via?: 'stack' | 'element';
}

/** Renderer identities are semantic application keys, never component constructors. */
export interface UiRendererDefinition {
  readonly id: string;
  readonly transparent: boolean;
  readonly viewMode?: string;
  readonly exit?: SurfaceExitPolicy;
}

/** The application owns arbitration; the UI owns rendered hosts and their lifetimes. */
export interface UiSurfacePlatform {
  registerRenderer(definition: UiRendererDefinition): void;
  mountRenderer(id: string): SurfaceLease;
  mountElement(definition: ElementSurfaceDefinition): ElementSurfaceLease;
  mountNonvisual(definition: NonvisualSurfaceDefinition): ElementSurfaceLease;
  onAction(actionId: string, listener: () => void, rendererInstanceId?: string): Dispose;
}

/** Match native keys identically at construction and in the app dispatcher. */
export function nativeOwnsCombo(combo: string, nativeKeys: readonly string[]): boolean {
  if (nativeKeys.includes(combo)) return true;
  const key = combo.startsWith('Shift+') ? combo.slice('Shift+'.length) : combo;
  if (/^(?:Ctrl|Alt|Meta)\+/u.test(key)) return false;
  if (nativeKeys.includes(key)) return true;
  return nativeKeys.includes('Printable')
    && (key.length === 1 || key === 'Space' || /^Digit\d$/u.test(key));
}

/** DOM node kinds work across realms without relying on the current window. */
export function isSurfaceElement(target: unknown): target is Element {
  return typeof target === 'object' && target !== null && 'nodeType' in target && target.nodeType === 1;
}

export function surfaceShadowHost(root: Node): Element | null {
  return root.nodeType === 11 && 'host' in root && isSurfaceElement(root.host) ? root.host : null;
}

