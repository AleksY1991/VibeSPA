import type { JSX } from '@solidjs/web';
import type { ControlSize } from '../control-size';
import type { FieldPresentation } from './field-presentation';
import type { ClosedControlPresentation, ControlPlacement } from './presentation';

/** An action intent; no native or vendor element crosses the boundary. */
export interface Activation {
  readonly altKey: boolean;
  readonly ctrlKey: boolean;
  readonly metaKey: boolean;
  readonly shiftKey: boolean;
  preventDefault(): void;
  stopPropagation(): void;
}

export interface FocusHandle {
  focus(options?: FocusOptions): void;
  blur(): void;
}

export interface ToggleControlProps {
  readonly onElement?: (element: HTMLElement) => void;
  readonly label: string;
  readonly labelHidden?: boolean;
  readonly labelPosition?: 'start' | 'end';
  readonly description?: string;
  readonly descriptionId?: string;
  readonly id?: string;
  readonly 'aria-labelledby'?: string;
  readonly 'aria-describedby'?: string;
  readonly 'aria-disabled'?: 'true' | 'false';
  readonly checked: boolean;
  readonly onCheckedChange: (checked: boolean) => void;
  readonly disabled?: boolean;
  readonly size?: ControlSize;
  readonly layout?: 'inline' | 'row';
  readonly class?: string;
  readonly onHandle?: (handle: FocusHandle | undefined) => void;
}

export interface ChoiceOption<T extends string = string> {
  readonly value: T;
  readonly label: string;
  readonly disabled?: boolean;
  readonly icon?: JSX.Element;
  /**
   * A mouse hint for this option alone. A visible row of choices names each
   * option but cannot say what it does, and the group's single
   * `aria-describedby` describes the whole row. WA 3.12's `wa-radio` carries no
   * hint of its own and its `wa-tooltip` would claim the option's accessible
   * name, so the option carries the text and the control library's delegated `data-tip` owner
   * renders it under DESIGN.md's rules: never the accessible name, never on
   * touch or a disabled control. Remove this when the vendor gains a hint that
   * leaves the accessible name alone.
   */
  readonly tip?: string;
}

export interface ChoiceGroupControlProps<T extends string = string> {
  readonly 'aria-describedby'?: string;
  readonly size?: ControlSize;
  readonly onElement?: (element: HTMLElement) => void;
  /** Explicit radio owners implemented by this composite's renderer. */
  readonly onNativeElement?: (element: HTMLElement) => void;
  readonly label: string;
  readonly labelPosition?: 'above' | 'inline' | 'hidden';
  readonly prefix?: JSX.Element;
  readonly layout?: 'natural' | 'equal';
  readonly value: T;
  readonly options: readonly ChoiceOption<NoInfer<T>>[];
  readonly onValueChange: (value: NoInfer<T>) => void;
  readonly disabled?: boolean;
  readonly class?: string;
}

export type CardRecipe = 'plain' | 'content' | 'panel' | 'popover' | 'notice';

/** Native semantics and events cannot reopen control paint or visibility. */
export type CardAttributes = Omit<JSX.HTMLAttributes<HTMLElement>,
  'children' | 'class' | 'className' | 'classList' | 'style' | 'ref' | 'hidden' | 'aria-hidden' | 'onKeyDown' | 'onKeyUp' | 'onKeyPress'>
  & ClosedControlPresentation & {
    readonly hidden?: never;
    readonly 'aria-hidden'?: never;
    readonly onKeyDown?: never;
    readonly onKeyUp?: never;
    readonly onKeyPress?: never;
  };

interface CardBehavior extends ClosedControlPresentation {
  readonly attributes?: CardAttributes;
  readonly onElement?: (element: HTMLElement) => void;
  readonly placement?: ControlPlacement;
  readonly variant?: never;
  readonly appearance?: never;
  readonly height?: never;
  readonly layout?: never;
  readonly overflow?: never;
  readonly padding?: never;
  readonly radius?: never;
  readonly border?: never;
  readonly children?: JSX.Element;
}

/** Each composition owns its complete geometry; only notices carry status paint. */
export type CardControlProps = CardBehavior & (
  | { readonly recipe?: Exclude<CardRecipe, 'notice'>; readonly tone?: never }
  | { readonly recipe: 'notice'; readonly tone?: 'default' | 'warning' | 'error' | 'success' }
);

export function activationFrom(event: MouseEvent): Activation {
  return Object.freeze({
    altKey: event.altKey,
    ctrlKey: event.ctrlKey,
    metaKey: event.metaKey,
    shiftKey: event.shiftKey,
    preventDefault: () => event.preventDefault(),
    stopPropagation: () => event.stopPropagation(),
  });
}

export interface InputFocusHandle extends FocusHandle {
  select(): void;
  selection(): { readonly start: number; readonly end: number };
  setSelectionRange(start: number, end: number): void;
}

export type TextFieldSize = ControlSize;

export interface TextFieldControlProps extends FieldPresentation, Pick<JSX.AriaAttributes,
  'aria-activedescendant' | 'aria-autocomplete' | 'aria-controls' | 'aria-expanded'
  | 'aria-haspopup' | 'aria-invalid' | 'aria-labelledby'> {
  readonly onElement?: (element: HTMLElement) => void;
  readonly label: string;
  readonly value: string;
  readonly onValueChange: (value: string) => void;
  /** Calendar dates use CalendarField/RangeCalendar; native time editing stays here. */
  readonly type?: 'text' | 'search' | 'email' | 'password' | 'number' | 'tel' | 'url' | 'time';
  readonly role?: JSX.HTMLAttributes<HTMLInputElement>['role'];
  readonly start?: JSX.Element;
  readonly end?: JSX.Element;
  readonly id?: string;
  readonly name?: string;
  readonly form?: string;
  readonly required?: boolean;
  readonly readonly?: boolean;
  readonly autocomplete?: string;
  readonly autofocus?: boolean;
  /** Display the component's own label instead of an external Field label. */
  readonly labelVisible?: boolean;
  /** Optional native suggestions remain free-form; the browser owns their popup and keys. */
  readonly suggestions?: readonly string[];
  readonly min?: string | number;
  readonly max?: string | number;
  readonly step?: number | 'any';
  readonly minLength?: number;
  readonly maxLength?: number;
  readonly inputMode?: 'none' | 'text' | 'decimal' | 'numeric' | 'tel' | 'search' | 'email' | 'url';
  readonly pattern?: string;
  readonly spellcheck?: boolean;
  readonly 'aria-describedby'?: string;
  readonly placeholder?: string;
  readonly disabled?: boolean;
  readonly 'data-tip'?: string;
  readonly onActivate?: (activation: Activation) => void;
  readonly onFocus?: () => void;
  readonly onBlur?: () => void;
  /** The browser's change event: an edited value has been committed. */
  readonly onValueCommit?: (value: string) => void;
  /** Normalize input and its DOM value, including rejected edits of an unchanged value. */
  readonly normalizeValue?: (value: string) => string;
  readonly onHandle?: (handle: InputFocusHandle | undefined) => void;
}
