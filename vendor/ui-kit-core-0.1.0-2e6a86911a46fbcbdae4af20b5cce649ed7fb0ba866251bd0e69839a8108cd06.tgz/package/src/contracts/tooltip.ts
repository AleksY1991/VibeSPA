/** The control layer owns hint discovery; the surface owns placement and paint, with native recovery measurement. */
export interface TooltipSurfaceControlProps {
  readonly anchor: HTMLElement;
  readonly text: string;
  readonly left: number;
  readonly top: number;
  readonly maxWidth: number;
  readonly layer: number;
  readonly visible: boolean;
  readonly onMeasure: (element: HTMLElement) => void;
}
