import type { ControlSize } from '../control-size';

/** Only the identity that this avatar presents, never a complete profile document. */
export interface AvatarValue {
  readonly label: string;
  readonly initials: string;
  readonly image?: string;
  readonly symbol?: string;
}

const AVATAR_SIZE_ALIASES = { xs: 'dense', sm: 'standard' } as const satisfies Record<string, ControlSize>;
export type AvatarSize = ControlSize | keyof typeof AVATAR_SIZE_ALIASES;

/** Legacy avatar names resolve to the same scale as their enclosing controls. */
export function avatarControlSize(size: AvatarSize): ControlSize {
  return size in AVATAR_SIZE_ALIASES ? AVATAR_SIZE_ALIASES[size as keyof typeof AVATAR_SIZE_ALIASES] : size as ControlSize;
}

export interface AvatarControlProps {
  readonly value: AvatarValue;
  readonly size: AvatarSize;
  /** An enclosing control supplies the surface and selection frame. */
  readonly appearance?: 'plain' | 'icon';
  /** Symbol geometry can differ from the avatar tile or its containing control. */
  readonly symbolSize?: 'default' | 'lg';
  /** The surrounding named action already describes this person. */
  readonly decorative?: boolean;
  readonly class?: string;
  readonly 'data-tip'?: string;
  readonly onElement?: (element: HTMLElement) => void;
}
