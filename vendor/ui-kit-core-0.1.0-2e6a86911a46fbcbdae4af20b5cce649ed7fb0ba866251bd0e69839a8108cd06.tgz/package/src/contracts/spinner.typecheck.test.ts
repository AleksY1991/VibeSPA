/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import { Spinner, type SpinnerProps } from '../solid/spinner';
import type { Observable } from './construction';
declare const busy: Observable<boolean>;
declare const text: Observable<string>;
const valid: SpinnerProps = { observable: busy, surface: { kind: 'inherit' }, hotkeys: [], size: 'sm', label: 'Loading preview' };
const decorative: SpinnerProps = { observable: busy, surface: { kind: 'inherit' }, hotkeys: [], size: 'md', decorative: true };
new Spinner(valid);
new Spinner(decorative);
// @ts-expect-error busy must be a registered boolean, never a copied value
const raw: SpinnerProps = { ...valid, observable: true };
// @ts-expect-error arbitrary accessors cannot bypass construction
const accessor: SpinnerProps = { ...valid, observable: () => true };
// @ts-expect-error a different registered payload is not a boolean
const wrong: SpinnerProps = { ...valid, observable: text };
// @ts-expect-error an explicit surface must be declared
const noSurface: SpinnerProps = { observable: busy, hotkeys: [], size: 'sm', label: 'Loading' };
// @ts-expect-error custom keys must be declared even when empty
const noKeys: SpinnerProps = { observable: busy, surface: { kind: 'inherit' }, size: 'sm', label: 'Loading' };
// @ts-expect-error accessibility must explicitly be decorative or named
const noLabel: SpinnerProps = { observable: busy, surface: { kind: 'inherit' }, hotkeys: [], size: 'sm' };
// @ts-expect-error decorative icons cannot create duplicate names
const duplicate: SpinnerProps = { ...valid, decorative: true, label: 'Loading' };
// @ts-expect-error no silent size defaults
const noSize: SpinnerProps = { observable: busy, surface: { kind: 'inherit' }, hotkeys: [], label: 'Loading' };
// @ts-expect-error undefined is not a registered binding
const undefinedBusy: SpinnerProps = { ...valid, observable: undefined };
// @ts-expect-error undefined is not a surface declaration
const undefinedSurface: SpinnerProps = { ...valid, surface: undefined };
// @ts-expect-error undefined is not an empty key declaration
const undefinedKeys: SpinnerProps = { ...valid, hotkeys: undefined };
// @ts-expect-error generic controls do not accept feature rollout switches
const undefinedScope: SpinnerProps = { ...valid, uiScope: undefined };
`;

it('requires exact registered state, scope, surfaces, hotkeys, geometry and announcement ownership', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/contracts/__spinner_typecheck__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  host.readFile = file => path.resolve(file) === filename ? source : read(file);
  host.fileExists = file => path.resolve(file) === filename || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30000);
