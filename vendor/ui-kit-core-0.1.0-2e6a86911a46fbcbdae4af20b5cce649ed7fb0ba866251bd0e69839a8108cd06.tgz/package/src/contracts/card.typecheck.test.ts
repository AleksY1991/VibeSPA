/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const owned = {
  class: "'custom'", className: "'custom'", classList: '{ custom: true }', style: "{ color: 'red' }",
  variant: "'surface'", appearance: "'tonal'", height: "'fill'", layout: "'column'",
  overflow: "'hidden'", padding: "'none'", radius: "'none'", border: "'top'",
} as const;
const source = `
import { Card, type CardProps, type CardRecipe } from '../solid/controls';
import type { Observable } from './construction';
// @ts-expect-error a renderer is not a public construction path
import { NativeCard } from '../solid/controls';
// @ts-expect-error a private class factory cannot bypass recipes
import { cardClass } from '../solid/controls';
// @ts-expect-error a private composite layout cannot bypass construction
import { ChoiceGroupLayout } from '../solid/controls';
declare const visible: Observable<boolean>;
const base = { observable: visible, surface: { kind: 'inherit' } as const, hotkeys: [] };
const plain: CardProps = { ...base };
const content: CardProps = { ...base, recipe: 'content', attributes: { id: 'summary', role: 'region', 'aria-label': 'Summary' } };
const panel: CardProps = { ...base, recipe: 'panel', placement: { width: '100%', flex: '1 1 0' } };
const popup: CardProps = { ...base, recipe: 'popover', attributes: { role: 'menu', tabindex: -1, onPointerLeave: () => {} } };
const notice: CardProps = { ...base, recipe: 'notice', tone: 'warning', attributes: { role: 'status', onFocusIn: () => {}, onFocusOut: () => {} } };
const recipe: CardRecipe = 'plain';
new Card(plain); new Card(content); new Card(panel); new Card(popup); new Card(notice);
${Object.entries(owned).flatMap(([key, value]) => [
  `// @ts-expect-error public card presentation belongs to its recipe`,
  `const direct_${key}: CardProps = { ...base, ${key}: ${value} };`,
  `// @ts-expect-error wider imported/spread objects cannot reopen presentation`,
  `const spread_${key}: CardProps = { ...base, ...{ ${key}: ${value} } };`,
]).join('\n')}
// @ts-expect-error plain surfaces do not carry semantic status paint
const plainTone: CardProps = { ...base, tone: 'warning' };
// @ts-expect-error content panels do not carry status paint
const contentTone: CardProps = { ...base, recipe: 'content', tone: 'warning' };
// @ts-expect-error popover is a structural recipe rather than a status tone
const popupTone: CardProps = { ...base, recipe: 'notice', tone: 'popover' };
// @ts-expect-error arbitrary geometry cannot become a recipe
const custom: CardProps = { ...base, recipe: 'custom' };
// @ts-expect-error the observable remains required
const noObservable: CardProps = { surface: { kind: 'inherit' }, hotkeys: [] };
// @ts-expect-error surface authority remains required
const noSurface: CardProps = { observable: visible, hotkeys: [] };
// @ts-expect-error hotkeys remain explicit
const noHotkeys: CardProps = { observable: visible, surface: { kind: 'inherit' } };
// @ts-expect-error attributes do not bypass paint ownership
const attributePaint: CardProps = { ...base, attributes: { style: { color: 'red' } } };
const importedPaint = { style: { color: 'red' } };
// @ts-expect-error wider attribute bags also retain paint ownership
const attributeSpread: CardProps = { ...base, attributes: importedPaint };
// @ts-expect-error private markers cannot be forged through attributes
const privateMarker: CardProps = { ...base, attributes: { 'data-ui-card': 'forged' } };
// @ts-expect-error DOM aliases cannot bypass presentation ownership
const aliasedPaint: CardProps = { ...base, attributes: { 'attr:class': 'custom' } };
// @ts-expect-error lifetime visibility belongs to the observable
const hidden: CardProps = { ...base, attributes: { hidden: true } };
// @ts-expect-error owned keyboard handling cannot bypass the surface
const keys: CardProps = { ...base, attributes: { onKeyDown: () => {} } };
// @ts-expect-error the DOM construction attachment is private
const ref: CardProps = { ...base, onElement: () => {} };
// @ts-expect-error placement cannot alter inner geometry
const padded: CardProps = { ...base, placement: { padding: '4px' } };
const widerPlacement = { width: '100%', color: 'red' };
// @ts-expect-error wider placement objects cannot alter paint
const placedPaint: CardProps = { ...base, placement: widerPlacement };
`;

it('keeps Card recipes and native semantic attributes closed through structural assignment', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/contracts/__card_typecheck__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  host.readFile = file => path.resolve(file) === filename ? source : read(file);
  host.fileExists = file => path.resolve(file) === filename || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30_000);
