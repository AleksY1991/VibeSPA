export type SpinnerSize = 'sm' | 'md';

/** A neighboring status or button name owns announcements for decorative spinners. */
export type SpinnerAccessibility =
  | { readonly decorative: true; readonly label?: never }
  | { readonly decorative?: false; readonly label: string };

export type SpinnerControlProps = SpinnerAccessibility & {
  readonly size: SpinnerSize;
  readonly class?: string;
  readonly onElement?: (element: HTMLElement) => void;
};
