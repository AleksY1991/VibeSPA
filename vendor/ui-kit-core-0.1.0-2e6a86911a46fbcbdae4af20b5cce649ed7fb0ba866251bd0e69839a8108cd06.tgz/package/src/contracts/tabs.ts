import type { JSX } from '@solidjs/web';
import type { FocusHandle } from './controls';
import type { ControlSize } from '../control-size';

export interface TabOption<Value extends string = string> {
  readonly value: Value;
  readonly label: string;
  readonly id: string;
  readonly panelId: string;
  readonly disabled?: boolean;
  readonly icon?: () => JSX.Element;
}

export interface TabsState<Value extends string = string> {
  /** No available selection keeps keyboard entry on the first enabled tab; it never emits an automatic write. */
  readonly value: Value | null;
  readonly tabs: readonly TabOption<Value>[];
  readonly disabled?: boolean;
}

export interface TabsControlProps {
  readonly state: TabsState;
  readonly label: string;
  readonly onValueChange: (value: string) => void;
  readonly size: ControlSize;
  readonly orientation?: 'horizontal' | 'vertical';
  readonly textSize?: 'body' | 'caption';
  readonly gap?: 'none' | 'sm';
  readonly wrap?: boolean;
  readonly class?: string;
  readonly onElement?: (element: HTMLElement) => void;
  /** Internal tab controls explicitly delegate native overrides to the tablist. */
  readonly onNativeElement?: (element: HTMLElement) => void;
  /** Surface authority gates navigation and readiness-driven cursor restoration. */
  readonly canMoveFocus?: () => boolean;
  readonly onHandle?: (handle: FocusHandle | undefined) => void;
}

export interface TabPanelControlProps {
  readonly active: boolean;
  readonly id: string;
  readonly tabId: string;
  readonly value: string;
  readonly class?: string;
  readonly layout?: 'block' | 'column';
  readonly overflow?: 'visible' | 'hidden';
  readonly children: JSX.Element;
  readonly onElement?: (element: HTMLElement) => void;
}
