/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';

const source = `
import type { Observable } from './construction';
import { ChoiceGroup, type ChoiceGroupProps } from '../solid/controls';
type Mode = 'priority' | 'status';
declare const selection: Observable<Mode>;
declare const text: Observable<string>;
const valid: ChoiceGroupProps<Mode> = {
  observable: selection, surface: { kind: 'inherit' }, hotkeys: [], label: 'Sort',
  options: [{ value: 'priority', label: 'Priority' }, { value: 'status', label: 'Status' }],
  onValueChange: value => { const mode: Mode = value; },
};
ChoiceGroup.View(valid);
new ChoiceGroup(valid);
// @ts-expect-error a general string source cannot satisfy a specific domain
const wrongSource: ChoiceGroupProps<Mode> = { ...valid, observable: text };
// @ts-expect-error options cannot widen the observable's domain through inference
ChoiceGroup.View({ ...valid, options: [{ value: 'newest', label: 'Newest' }] });
// @ts-expect-error the callback cannot widen or change the observed domain
ChoiceGroup.View({ ...valid, onValueChange: (value: 'newest') => {} });
// @ts-expect-error writes retain the exact domain
valid.onValueChange('newest');
// @ts-expect-error explicit undefined cannot bypass the required read binding
ChoiceGroup.View({ ...valid, observable: undefined });
// @ts-expect-error explicit undefined cannot bypass the required write command
ChoiceGroup.View({ ...valid, onValueChange: undefined });
// @ts-expect-error explicit surface ownership remains required
ChoiceGroup.View({ ...valid, surface: undefined });
// @ts-expect-error explicit hotkeys remain required
ChoiceGroup.View({ ...valid, hotkeys: undefined });
const { onValueChange, ...withoutWrite } = valid;
// @ts-expect-error omission cannot bypass the required write command
ChoiceGroup.View(withoutWrite);
`;

describe('choice group domain construction', () => {
  it('infers the domain from its observable and rejects missing or incompatible construction', () => {
    const root = process.cwd();
    const filename = path.join(root, 'src/contracts/__choice_typecheck__.ts');
    const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
    const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
    const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false, noUnusedLocals: false, noUnusedParameters: false };
    const host = ts.createCompilerHost(options);
    const read = host.readFile.bind(host);
    const exists = host.fileExists.bind(host);
    host.readFile = file => path.resolve(file) === filename ? source : read(file);
    host.fileExists = file => path.resolve(file) === filename || exists(file);
    const program = ts.createProgram([filename], options, host);
    const fixture = program.getSourceFile(filename)!;
    const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
    expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
  }, 30000);
});
