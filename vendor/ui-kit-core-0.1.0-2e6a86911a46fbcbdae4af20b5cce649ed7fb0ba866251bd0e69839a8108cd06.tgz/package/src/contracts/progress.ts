export interface ProgressBarControlProps {
  readonly onElement?: (element: HTMLElement) => void;
  readonly value: number;
  readonly max?: number;
  readonly label?: string;
  readonly variant?: 'brand' | 'success' | 'warning' | 'danger';
  readonly valueText?: string;
  readonly 'aria-hidden'?: boolean | 'true' | 'false';
  readonly class?: string;
}

/** Native progress and percentage-based vendors share one bounded value contract. */
export function progressValues(value: number, max = 100) {
  const maximum = Number.isFinite(max) && max > 0 ? max : 100;
  const current = Number.isFinite(value) ? Math.max(0, Math.min(value, maximum)) : 0;
  return { value: current, max: maximum, percent: current / maximum * 100 };
}

export function progressHidden(value: ProgressBarControlProps['aria-hidden']): 'true' | 'false' | undefined {
  return value === true || value === 'true' ? 'true' : value === false || value === 'false' ? 'false' : undefined;
}
