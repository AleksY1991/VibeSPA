/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const forbidden = {
  class: "'paint-overwrite'", className: "'paint-overwrite'", classList: '{ painted: true }',
  style: "{ color: 'red' }", visualStyle: "'standard'", appearance: "'plain'",
  textSize: "'caption'", font: "'mono'", tabular: 'true', paddingInline: "'none'",
  paddingBlock: "'lg'", paddingEnd: "'action'", lineHeight: "'tight'", textAlign: "'end'",
} as const;

const source = `
import type { Observable } from './construction';
import { TextField, SearchField, type TextFieldProps, type SearchFieldProps } from '../solid/text-field';
import { Textarea, type TextareaProps } from '../solid/textarea';
import { Select, type SelectProps } from '../solid/select';
import { importedPaint, importedSpacing } from './__field_presentation_import__';
declare const text: Observable<string>;
const base = { observable: text, surface: { kind: 'inherit' } as const, hotkeys: [], label: 'Name', onValueChange: (_next: string) => {} };
const field: TextFieldProps = { ...base, recipe: 'form', size: 'compact', placement: { width: '100%', 'grid-column': 'span 2' } };
const inline: TextFieldProps = { ...base, recipe: 'inline', size: 'dense' };
const code: TextFieldProps = { ...base, recipe: 'code', size: 'large' };
const filled: TextFieldProps = { ...base, recipe: 'filled', size: 'standard' };
const entry: TextFieldProps = { ...base, recipe: 'entry', size: 'large' };
const title: TextFieldProps = { ...base, recipe: 'title', size: 'dense' };
const searchAction: TextFieldProps = { ...base, recipe: 'search-action', size: 'standard' };
const search: SearchFieldProps = { ...base };
const area: TextareaProps = { ...base, recipe: 'composer', rows: 1, resize: 'auto', minHeight: 46, maxHeight: 130 };
const message: TextareaProps = { ...base, recipe: 'entry', rows: 2 };
const document: TextareaProps = { ...base, recipe: 'reading', size: 'standard', fillHeight: true };
const conversation: TextareaProps = { ...base, recipe: 'compact-composer', size: 'compact', rows: 1, resize: 'auto', maxHeight: 130 };
const select: SelectProps = { ...base, recipe: 'form', options: [{ value: 'a', label: 'Alpha' }] };
const entrySelect: SelectProps = { ...base, recipe: 'entry', options: [{ value: 'a', label: 'Alpha' }] };
new TextField(field); new TextField(inline); new TextField(code); new TextField(filled);
new TextField(entry); new TextField(title); new TextField(searchAction);
new SearchField(search); new Textarea(area); new Textarea(message); new Textarea(document); new Textarea(conversation);
new Select(select); new Select(entrySelect);
${Object.entries(forbidden).flatMap(([key, value]) => [
  `// @ts-expect-error public field appearance is owned by a finite recipe`,
  `const field_${key}: TextFieldProps = { ...base, ${key}: ${value} };`,
  `// @ts-expect-error imported/spread objects cannot bypass field presentation ownership`,
  `const spread_${key}: TextFieldProps = { ...base, ...{ ${key}: ${value} } };`,
  `// @ts-expect-error textarea shares the same closed presentation boundary`,
  `const area_${key}: TextareaProps = { ...base, ${key}: ${value} };`,
  `// @ts-expect-error select exposes no free presentation overrides`,
  `const select_${key}: SelectProps = { ...base, options: [], ${key}: ${value} };`,
]).join('\n')}
// @ts-expect-error an imported class/style object cannot bypass structural checking
const importedField: TextFieldProps = { ...base, ...importedPaint };
// @ts-expect-error an imported spacing object cannot bypass structural checking
const importedArea: TextareaProps = { ...base, ...importedSpacing };
// @ts-expect-error there is no custom catch-all field recipe
const customField: TextFieldProps = { ...base, recipe: 'custom' };
// @ts-expect-error a textarea-only composition is not a single-line field recipe
const composerField: TextFieldProps = { ...base, recipe: 'composer' };
// @ts-expect-error select has no inline/text/code composition
const codeSelect: SelectProps = { ...base, options: [], recipe: 'code' };
// @ts-expect-error long-form reading belongs to a multiline editing owner
const readingField: TextFieldProps = { ...base, recipe: 'reading' };
// @ts-expect-error a title is a single-line text-field composition
const titleArea: TextareaProps = { ...base, recipe: 'title' };
// @ts-expect-error the reserved search action slot belongs to a text input
const actionArea: TextareaProps = { ...base, recipe: 'search-action' };
// @ts-expect-error a select does not expose title or document typography
const readingSelect: SelectProps = { ...base, options: [], recipe: 'reading' };
// @ts-expect-error search composition owns its size
const searchSize: SearchFieldProps = { ...base, size: 'large' };
// @ts-expect-error search composition owns its browser input type
const searchType: SearchFieldProps = { ...base, type: 'password' };
// @ts-expect-error a recipe does not reopen arbitrary appearance combinations
const mixedRecipe: TextFieldProps = { ...base, recipe: 'code', appearance: 'plain' };
// @ts-expect-error placement cannot become an inner-padding override
const paddingPlacement: TextFieldProps = { ...base, placement: { width: '100%', padding: '4px' } };
const widerPlacement = { width: '100%', color: 'red' };
// @ts-expect-error wider imported-style objects cannot bypass placement ownership
const paintPlacement: TextFieldProps = { ...base, placement: widerPlacement };
// @ts-expect-error reading does not grant a write command
const readOnlyContract: TextFieldProps = { observable: text, surface: { kind: 'inherit' }, hotkeys: [], label: 'Name' };
`;

it('keeps public field recipes closed through direct, imported and spread props', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/contracts/__field_presentation_typecheck__.ts');
  const imported = path.join(root, 'src/contracts/__field_presentation_import__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  const virtual = new Map([
    [filename, source],
    [imported, `export const importedPaint = { class: 'overwritten', style: { color: 'red' } };\nexport const importedSpacing = { paddingInline: 'none' as const };`],
  ]);
  host.readFile = file => virtual.get(path.resolve(file)) ?? read(file);
  host.fileExists = file => virtual.has(path.resolve(file)) || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30_000);
