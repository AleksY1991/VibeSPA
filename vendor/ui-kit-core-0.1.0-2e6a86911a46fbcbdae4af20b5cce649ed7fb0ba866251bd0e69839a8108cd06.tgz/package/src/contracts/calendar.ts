/** Pure local-time calendar keys and ISO-week arithmetic. date-fns keeps day and week conversions consistent across timezone and daylight-saving boundaries. */

import {
  getISOWeek,
  getISOWeekYear,
  startOfISOWeek,
  endOfISOWeek,
  addWeeks,
  format,
} from 'date-fns';
/** Local calendar keys intentionally carry no timezone or rendering capability. */
export type DayKey = string;

export const dayKey = (date: Date): DayKey =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

export const keyToDate = (key: DayKey): Date =>
  new Date(Number(key.slice(0, 4)), Number(key.slice(5, 7)) - 1, Number(key.slice(8, 10)));

export const getTodayString = (): DayKey => dayKey(new Date());

/** ISO week id, e.g. "2026-W26" — today's when no date given. */
export function getIsoWeekId(date: Date = new Date()): string {
  return `${getISOWeekYear(date)}-W${String(getISOWeek(date)).padStart(2, '0')}`;
}

interface ParsedWeek { year: number; week: number }
export function parseWeekId(weekId: string): ParsedWeek | null {
  const m = /^(\d{4})-W(\d{1,2})$/.exec(weekId);
  return m ? { year: Number(m[1]), week: Number(m[2]) } : null;
}

/** Monday (start) of an ISO week id, local midnight. */
export function weekIdToMonday(weekId: string): Date {
  const p = parseWeekId(weekId);
  if (!p) throw new TypeError(`Invalid week id ${JSON.stringify(weekId)}; expected format "2026-W26"`);
  // ISO week 1 is the week containing Jan 4.
  const week1Monday = startOfISOWeek(new Date(p.year, 0, 4));
  return addWeeks(week1Monday, p.week - 1);
}

/** Sunday (end) of an ISO week id. */
export function weekIdToSunday(weekId: string): Date {
  return endOfISOWeek(weekIdToMonday(weekId));
}

/** Shift an ISO week id by N weeks. */
export function shiftIsoWeek(weekId: string, weeksDelta: number): string {
  return getIsoWeekId(addWeeks(weekIdToMonday(weekId), weeksDelta));
}

/** Chronological comparison of two week ids (negative = a before b). */
export function compareWeekId(a: string, b: string): number {
  return weekIdToMonday(a).getTime() - weekIdToMonday(b).getTime();
}

/** Whole weeks between two week ids (b - a), can be negative. */
export function weeksBetween(a: string, b: string): number {
  return Math.round((weekIdToMonday(b).getTime() - weekIdToMonday(a).getTime()) / (7 * 86400000));
}

/** Short calendar label for an endpoint, e.g. "Jun 22". */
export function formatWeekDate(weekId: string, which: 'mon' | 'sun' = 'mon'): string {
  return format(which === 'mon' ? weekIdToMonday(weekId) : weekIdToSunday(weekId), 'MMM d');
}

/**
 * Derived title for a week span:
 *   single week        → "W26"
 *   same ISO-week-year → "W23–25"           (en-dash, year not repeated)
 *   cross year         → "2025-W52 – 2026-W01"
 */
export function spanTitle(start: string, end: string): string {
  const s = parseWeekId(start);
  const e = parseWeekId(end);
  if (!s || !e) return start || end;
  if (start === end) return `W${s.week}`;
  if (s.year === e.year) return `W${s.week}–${e.week}`;
  return `${start} – ${end}`;
}

/** 'W28' | 'W26–29' for a Monday→Sunday-aligned DAY span; '' otherwise. */
function weekBadge(lo: DayKey, hi: DayKey): string {
  const s = getIsoWeekId(keyToDate(lo));
  const e = getIsoWeekId(keyToDate(hi));
  if (dayKey(weekIdToMonday(s)) !== lo || dayKey(weekIdToSunday(e)) !== hi) return '';
  return spanTitle(s, e);
}

/**
 * Label for an inclusive DAY span — the one template the range picker's trigger
 * and its footer share, so the preview and the committed chip can never word
 * the same window differently.
 *
 *   single day            → { text: 'Jul 8',           week: ''       }
 *   inside one month      → { text: 'Jul 8 – 13',      week: ''       }
 *   across months         → { text: 'Jun 30 – Jul 3',  week: ''       }
 *   Monday→Sunday aligned → { text: 'Jul 6 – 12',      week: 'W28'    }
 *   whole weeks           → { text: 'Jun 22 – Jul 19', week: 'W26–29' }
 *
 * `week` is non-empty ONLY for a week-aligned span. That IS the granularity
 * readout: a week number on screen means "you picked whole weeks", and it
 * disappears the moment a day click makes the span partial.
 */
export function formatDaySpan(lo: DayKey, hi: DayKey): { text: string; week: string } {
  if (!lo || !hi) return { text: '—', week: '' };
  const a = keyToDate(lo);
  const b = keyToDate(hi);
  const week = weekBadge(lo, hi);
  // Years only when they DIFFER. A "hide the current year" rule would make this
  // function's output depend on the clock, i.e. untestable after Dec 31.
  if (a.getFullYear() !== b.getFullYear()) {
    return { text: `${format(a, 'MMM d, yyyy')} – ${format(b, 'MMM d, yyyy')}`, week };
  }
  if (lo === hi) return { text: format(a, 'MMM d'), week };
  if (a.getMonth() === b.getMonth()) return { text: `${format(a, 'MMM d')} – ${format(b, 'd')}`, week };
  return { text: `${format(a, 'MMM d')} – ${format(b, 'MMM d')}`, week };
}
