/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import { Avatar, type AvatarProps } from '../solid/avatar';
import type { AvatarValue } from './avatar';
import type { Observable } from './construction';
declare const identity: Observable<AvatarValue>;
declare const text: Observable<string>;
const valid: AvatarProps = { observable: identity, surface: { kind: 'inherit' }, hotkeys: [], size: 'sm' };
new Avatar(valid);
// @ts-expect-error identity must be a registered read handle, not copied profile values
const raw: AvatarProps = { ...valid, observable: { label: 'Ada', initials: 'AD' } };
// @ts-expect-error arbitrary accessors cannot bypass construction
const accessor: AvatarProps = { ...valid, observable: () => ({ label: 'Ada', initials: 'AD' }) };
// @ts-expect-error a registered string is not the required avatar identity model
const wrong: AvatarProps = { ...valid, observable: text };
// @ts-expect-error surface ownership is required
const noSurface: AvatarProps = { observable: identity, hotkeys: [], size: 'sm' };
// @ts-expect-error custom keys must be declared even when empty
const noKeys: AvatarProps = { observable: identity, surface: { kind: 'inherit' }, size: 'sm' };
// @ts-expect-error dimensions must be explicit
const noSize: AvatarProps = { observable: identity, surface: { kind: 'inherit' }, hotkeys: [], };
// @ts-expect-error undefined is not an identity binding
const undefinedIdentity: AvatarProps = { ...valid, observable: undefined };
// @ts-expect-error undefined does not declare a surface
const undefinedSurface: AvatarProps = { ...valid, surface: undefined };
// @ts-expect-error undefined does not declare keyboard ownership
const undefinedKeys: AvatarProps = { ...valid, hotkeys: undefined };
// @ts-expect-error generic controls do not accept feature rollout switches
const undefinedScope: AvatarProps = { ...valid, uiScope: undefined };
// @ts-expect-error unlabeled identities cannot satisfy the avatar contract
const unnamed: AvatarValue = { initials: 'AD' };
`;

it('requires exact avatar identity, surface, hotkeys, feature scope and geometry at construction', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/contracts/__avatar_typecheck__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  host.readFile = file => path.resolve(file) === filename ? source : read(file);
  host.fileExists = file => path.resolve(file) === filename || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30000);
