/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import { Tabs, TabPanel, type TabsProps, type TabPanelProps } from '../solid/tabs';
import type { Observable } from './construction';
import type { TabsState } from './tabs';
import { Tag, type TagProps } from '../solid/tag';
import { SplitPanel, type SplitPanelProps } from '../solid/split-panel';
import type { TagState } from './tag';
import type { SplitPanelState } from './split-panel';
declare const tabs: Observable<TabsState<'one' | 'two'>>;
declare const visible: Observable<boolean>;
declare const text: Observable<string>;
declare const tag: Observable<TagState>;
declare const split: Observable<SplitPanelState>;
const validTag: TagProps = { observable: tag, surface: { kind: 'inherit' }, hotkeys: [], onRemove: () => {} };
const validSplit: SplitPanelProps = { observable: split, surface: { kind: 'inherit' }, hotkeys: [], min: 320, max: 800, step: 16, label: 'Resize panel', start: 'Chart', end: 'Editor', onEndSizeChange: () => {} };
new Tag(validTag); new SplitPanel(validSplit);
// @ts-expect-error tag content must use the exact registered model
const wrongTag: TagProps = { ...validTag, observable: text };
// @ts-expect-error no undefined observable
const absentTag: TagProps = { ...validTag, observable: undefined };
// @ts-expect-error explicit surface ownership required
const absentTagSurface: TagProps = { ...validTag, surface: undefined };
// @ts-expect-error explicit hotkeys required
const absentTagKeys: TagProps = { ...validTag, hotkeys: undefined };
// @ts-expect-error reading a label grants no remove command
const absentTagCommand: TagProps = { ...validTag, onRemove: undefined };
// @ts-expect-error split size and collapsed state must use the exact registered model
const wrongSplit: SplitPanelProps = { ...validSplit, observable: text };
// @ts-expect-error no undefined observable
const absentSplit: SplitPanelProps = { ...validSplit, observable: undefined };
// @ts-expect-error explicit surface ownership required
const absentSplitSurface: SplitPanelProps = { ...validSplit, surface: undefined };
// @ts-expect-error explicit hotkeys required
const absentSplitKeys: SplitPanelProps = { ...validSplit, hotkeys: undefined };
// @ts-expect-error resizing needs an explicit typed write command
const absentSplitCommand: SplitPanelProps = { ...validSplit, onEndSizeChange: undefined };
const valid: TabsProps<'one' | 'two'> = { observable: tabs, surface: { kind: 'inherit' }, hotkeys: [], size: 'compact', label: 'Sections', onValueChange: (value: 'one' | 'two') => {} };
const panel: TabPanelProps = { observable: visible, surface: { kind: 'inherit' }, hotkeys: [], id: 'panel-one', tabId: 'tab-one', value: 'one', children: 'Body' };
new Tabs(valid); new TabPanel(panel);
// @ts-expect-error registered exact model required
const raw: TabsProps = { ...valid, observable: { value: 'one', tabs: [] } };
// @ts-expect-error arbitrary accessors cannot bypass construction
const accessor: TabsProps = { ...valid, observable: () => ({ value: 'one', tabs: [] }) };
// @ts-expect-error text is not a tab state
const wrong: TabsProps = { ...valid, observable: text };
// @ts-expect-error explicit surface required
const noSurface: TabsProps = { observable: tabs, hotkeys: [], size: 'compact', label: 'Sections', onValueChange: () => {} };
// @ts-expect-error explicit hotkeys required
const noKeys: TabsProps = { observable: tabs, surface: { kind: 'inherit' }, size: 'compact', label: 'Sections', onValueChange: () => {} };
// @ts-expect-error read permission does not imply write command
const noCommand: TabsProps = { observable: tabs, surface: { kind: 'inherit' }, hotkeys: [], size: 'compact', label: 'Sections' };
// @ts-expect-error domain value command must match exact state
const wrongCommand: TabsProps<'one' | 'two'> = { ...valid, onValueChange: (value: 'three') => {} };
// @ts-expect-error no undefined observable
const undefinedState: TabsProps = { ...valid, observable: undefined };
// @ts-expect-error no undefined surface
const undefinedSurface: TabsProps = { ...valid, surface: undefined };
// @ts-expect-error no undefined hotkeys
const undefinedKeys: TabsProps = { ...valid, hotkeys: undefined };
// @ts-expect-error generic controls do not accept feature rollout switches
const undefinedScope: TabsProps = { ...valid, uiScope: undefined };
// @ts-expect-error panel visibility is precisely boolean
const wrongPanel: TabPanelProps = { ...panel, observable: text };
// @ts-expect-error panel surface is explicit
const undefinedPanelSurface: TabPanelProps = { ...panel, surface: undefined };
// @ts-expect-error panel custom hotkeys are explicit
const undefinedPanelKeys: TabPanelProps = { ...panel, hotkeys: undefined };
// @ts-expect-error generic controls do not accept feature rollout switches
const undefinedPanelScope: TabPanelProps = { ...panel, uiScope: undefined };
`;

it('requires exact registered selection and visibility, explicit commands, surfaces and keyboard contracts', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/contracts/__tabs_typecheck__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  host.readFile = file => path.resolve(file) === filename ? source : read(file);
  host.fileExists = file => path.resolve(file) === filename || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30000);
