// @vitest-environment happy-dom
import { createRoot } from 'solid-js';
import { expect, it } from 'vitest';
import { constructItem } from '../infrastructure/construction';
import { TextField, SearchField } from '../solid/text-field';
import { Textarea } from '../solid/textarea';
import { Select } from '../solid/select';

it('rejects JavaScript styling and reserved search inputs before creating a control host', () => {
  createRoot(dispose => {
    try {
      const observable = constructItem('field.presentation', item => item.constant('text', 'Value'));
      const base = { observable, surface: { kind: 'inherit' } as const, hotkeys: [], label: 'Name', onValueChange: () => {} };
      expect(() => new TextField({ ...base, style: { color: 'red' } } as never)).toThrow('style is owned');
      expect(() => new Textarea({ ...base, 'style:color': 'red' } as never)).toThrow('style:color cannot bypass');
      expect(() => new Select({ ...base, options: [], class: 'paint' } as never)).toThrow('class is owned');
      expect(() => new SearchField({ ...base, size: 'large' } as never)).toThrow('size is owned');
      expect(document.querySelector('wa-input,wa-select,wa-textarea')).toBeNull();
    } finally { dispose(); }
  });
});

it('rejects unsupported field recipes rather than silently choosing another appearance', () => {
  createRoot(dispose => {
    try {
      const observable = constructItem('field.presentation.recipes', item => item.constant('text', 'Value'));
      const base = { observable, surface: { kind: 'inherit' } as const, hotkeys: [], label: 'Name', onValueChange: () => {} };
      expect(() => new TextField({ ...base, recipe: 'composer' } as never)).toThrow('unsupported field recipe');
      expect(() => new Textarea({ ...base, recipe: 'custom' } as never)).toThrow('unsupported field recipe');
      expect(() => new Select({ ...base, options: [], recipe: 'code' } as never)).toThrow('unsupported field recipe');
    } finally { dispose(); }
  });
});
