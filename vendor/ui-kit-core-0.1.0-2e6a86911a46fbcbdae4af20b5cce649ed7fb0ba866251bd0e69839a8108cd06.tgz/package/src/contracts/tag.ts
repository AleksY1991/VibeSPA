import type { JSX } from '@solidjs/web';

export interface TagState {
  readonly label: string;
  readonly removeLabel: string;
  readonly disabled?: boolean;
}

export interface TagControlProps {
  readonly textSize?: 'body' | 'caption';
  readonly class?: string;
  readonly children: JSX.Element;
  readonly onElement?: (element: HTMLElement) => void;
}
