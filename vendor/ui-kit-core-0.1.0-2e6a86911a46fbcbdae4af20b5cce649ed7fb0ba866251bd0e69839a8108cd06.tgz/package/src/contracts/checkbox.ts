import type { FocusHandle } from './controls';
import type { ControlSize } from '../control-size';

export interface CheckboxControlProps {
  readonly onElement?: (element: HTMLElement) => void;
  readonly label: string;
  readonly labelHidden?: boolean;
  readonly truncateLabel?: boolean;
  readonly checked: boolean;
  readonly indeterminate?: boolean;
  readonly onCheckedChange: (checked: boolean) => void;
  readonly disabled?: boolean;
  readonly id?: string;
  readonly name?: string;
  readonly form?: string;
  readonly value?: string;
  readonly required?: boolean;
  readonly 'aria-labelledby'?: string;
  readonly 'aria-describedby'?: string;
  readonly 'data-tip'?: string;
  readonly 'data-testid'?: string;
  readonly size?: ControlSize;
  readonly class?: string;
  readonly onHandle?: (handle: FocusHandle | undefined) => void;
}
