import type { JSX } from '@solidjs/web';
import type { ElementConstruction } from './construction';
import type { Activation } from './controls';

export interface ContentEditableState {
  readonly text: string;
  readonly editing: boolean;
  readonly readonly?: boolean;
}

export interface ContentEditableActivation extends Activation {
  readonly clientX: number;
  readonly clientY: number;
  readonly detail: number;
}

export interface ContentEditableHandle {
  getText(): string;
  focus(options?: FocusOptions): void;
  blur(): void;
  selectAll(): void;
  caretEnd(): void;
  /** An unavailable or out-of-element browser hit test falls back to selecting all. */
  caretAtPoint(point: { readonly x: number; readonly y: number }): boolean;
}

export interface ContentEditableControlProps extends ElementConstruction<ContentEditableState> {
  
  readonly label: string;
  readonly onValueChange: (text: string) => void;
  readonly as?: 'div' | 'span';
  readonly id?: string;
  readonly class?: string;
  readonly style?: JSX.CSSProperties;
  readonly multiline?: boolean;
  /** Wrapping does not grant Enter permission to insert a newline. */
  readonly wrap?: boolean;
  readonly placeholder?: string;
  readonly tabindex?: number;
  readonly spellcheck?: boolean;
  readonly 'aria-describedby'?: string;
  readonly 'data-testid'?: string;
  readonly focusOnEdit?: 'none' | 'selectAll' | 'caretEnd';
  readonly commitOnDispose?: boolean;
  readonly onHandle?: (handle: ContentEditableHandle | undefined) => void;
  /**
   * Submit on Enter, blur, or requested disposal. Returning false (or rejecting)
   * retains a retryable session; callers own failure reporting and end editing
   * after acceptance. Void keeps the synchronous, once-per-session behavior.
   */
  readonly onCommit?: (text: string) => void | boolean | Promise<void | boolean>;
  readonly onCancel?: () => void;
  readonly onBlur?: (text: string) => void;
  readonly onFocus?: () => void;
  readonly onActivate?: (activation: ContentEditableActivation) => void;
  readonly onDoubleActivate?: (activation: ContentEditableActivation) => void;
  readonly onPressStart?: (activation: ContentEditableActivation) => void;
}
