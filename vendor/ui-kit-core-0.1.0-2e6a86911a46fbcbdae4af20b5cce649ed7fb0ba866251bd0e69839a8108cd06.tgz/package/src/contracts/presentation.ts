import type { JSX } from '@solidjs/web';

/** Complete controls own their paint, typography and inner geometry. */
export interface ClosedControlPresentation {
  readonly class?: never;
  readonly className?: never;
  readonly classList?: never;
  readonly style?: never;
  readonly 'attr:class'?: never;
  readonly 'attr:className'?: never;
  readonly 'attr:classList'?: never;
  readonly 'attr:style'?: never;
  readonly 'prop:class'?: never;
  readonly 'prop:className'?: never;
  readonly 'prop:classList'?: never;
  readonly 'prop:style'?: never;
  readonly dataset?: never;
  readonly 'prop:dataset'?: never;
  readonly [key: `style:${string}`]: never;
  readonly [key: `class:${string}`]: never;
  readonly [key: `data-ui-${string}`]: never;
  readonly [key: `data-wa-${string}`]: never;
  readonly [key: `attr:data-ui-${string}`]: never;
  readonly [key: `prop:data-ui-${string}`]: never;
  readonly [key: `attr:data-wa-${string}`]: never;
  readonly [key: `prop:data-wa-${string}`]: never;
}

type PlacementKey = 'width' | 'min-width' | 'max-width' | 'inline-size' | 'min-inline-size' | 'max-inline-size' | 'margin' | 'margin-left' | 'margin-right'
  | 'margin-top' | 'margin-bottom' | 'margin-inline' | 'margin-inline-start' | 'margin-inline-end'
  | 'margin-block' | 'margin-block-start' | 'margin-block-end' | 'position' | 'left' | 'right' | 'top' | 'bottom'
  | 'inset' | 'inset-inline' | 'inset-inline-start' | 'inset-inline-end' | 'inset-block' | 'inset-block-start' | 'inset-block-end'
  | 'z-index' | 'flex' | 'flex-grow' | 'flex-shrink' | 'flex-basis' | 'align-self' | 'justify-self' | 'order'
  | 'grid-column' | 'grid-row' | 'grid-area';

/** Parent-facing placement only, including when a wider imported object is supplied. */
export type ControlPlacement = Pick<JSX.CSSProperties, PlacementKey>
  & { readonly [Key in Exclude<keyof JSX.CSSProperties, PlacementKey>]?: never };
