import type { JSX } from '@solidjs/web';
import type { DialogPresentation } from '../dialog-presentation';
import type { FocusHandle } from './controls';
import type { SurfaceAuthority } from './platform';

/** Complete modal behavior belongs to the component implementation. */
export type DialogControlProps = DialogPresentation & {
  readonly open: boolean;
  readonly lifetime: boolean;
  readonly authority: () => SurfaceAuthority | undefined;
  readonly label: string;
  readonly withoutHeader?: boolean;
  readonly closeOnEscape?: boolean;
  readonly closeOnOutsidePointerDown?: boolean;
  readonly contentLifetime?: 'visible' | 'owner';
  readonly id?: string;
  readonly role?: 'dialog' | 'alertdialog';
  readonly 'aria-label'?: string;
  readonly 'aria-labelledby'?: string;
  readonly 'aria-describedby'?: string;
  readonly 'data-surface'?: string;
  readonly initialFocus?: () => HTMLElement | FocusHandle | null | undefined;
  readonly restoreFocus?: () => HTMLElement | null | undefined;
  readonly onOutsidePointerDown?: (event: PointerEvent) => void;
  readonly onContentElement?: (element: HTMLElement) => void;
  readonly onOpenChange: (open: boolean) => void;
  readonly onElement: (element: HTMLElement) => void;
  readonly children: JSX.Element;
}

/** Private UI layouts own geometry and semantics; vendor bindings own panel paint. */
export interface SurfaceControlProps {
  readonly contentClass?: string;
  readonly backdrop?: 'default' | 'transparent';
  readonly children?: JSX.Element;
  readonly variant?: 'default' | 'fullscreen' | 'detached';
  readonly overflow?: 'visible' | 'hidden';
  readonly class?: string;
  readonly style?: JSX.CSSProperties;
  readonly id?: string;
  readonly role?: 'dialog' | 'alertdialog' | 'menu' | 'listbox';
  readonly 'aria-modal'?: 'true' | 'false';
  readonly 'aria-label'?: string;
  readonly 'aria-labelledby'?: string;
  readonly 'aria-describedby'?: string;
  readonly 'data-surface'?: string;
  readonly 'data-ui-popover'?: string;
  readonly onElement?: (element: HTMLElement) => void;
  readonly onPointerDown?: (event: PointerEvent) => void;
  readonly onPointerLeave?: (event: PointerEvent) => void;
}
