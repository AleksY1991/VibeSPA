export interface BadgeControlProps {
  readonly value: string;
  readonly tone: 'accent' | 'neutral';
  readonly label?: string;
  readonly class?: string;
  readonly onElement?: (element: HTMLElement) => void;
}
