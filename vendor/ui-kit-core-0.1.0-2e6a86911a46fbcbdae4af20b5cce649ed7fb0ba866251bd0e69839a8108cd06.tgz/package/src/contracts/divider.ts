import type { JSX } from '@solidjs/web';

/** Horizontal menu divisions retain their place while their visibility source is false. */
export interface DividerControlProps {
  readonly attributes?: Omit<JSX.HTMLAttributes<HTMLElement>, 'children' | 'class' | 'ref' | 'hidden' | 'aria-hidden' | 'role' | 'aria-orientation'>;
  readonly hidden: boolean;
  readonly class?: string;
  readonly onElement?: (element: HTMLElement) => void;
}
