/** Public metadata shared by registration and editors. Values and defaults are
 * owned by the feature and deliberately never enter the search index. */
export interface SettingDescriptor {
  readonly id: string;
  readonly label: string;
  readonly type: 'boolean' | 'text' | 'password' | 'number' | 'select' | 'time' | 'days' | 'action' | 'readonly';
  readonly description?: string;
  readonly keywords?: readonly string[];
  readonly tags?: readonly string[];
  readonly choices?: readonly string[];
}

export function defineSetting<const T extends SettingDescriptor>(setting: T): Readonly<T> {
  if (!setting.id.trim() || !setting.label.trim()) throw new TypeError('Settings require a stable ID and label');
  return Object.freeze({ ...setting,
    ...(setting.keywords && { keywords: Object.freeze([...setting.keywords]) }),
    ...(setting.tags && { tags: Object.freeze([...setting.tags]) }),
    ...(setting.choices && { choices: Object.freeze([...setting.choices]) }),
  });
}
