/// <reference types="node" />
import path from 'node:path';
import ts from 'typescript';
import { expect, it } from 'vitest';

const source = `
import { MenuSeparator, type MenuSeparatorProps } from '../solid/menu-separator';
import type { Observable } from './construction';
declare const visible: Observable<boolean>;
declare const text: Observable<string>;
const valid: MenuSeparatorProps = { observable: visible, surface: { kind: 'inherit' }, hotkeys: [], };
new MenuSeparator(valid);
// @ts-expect-error visibility is a registered boolean, never a copied value
const raw: MenuSeparatorProps = { ...valid, observable: true };
// @ts-expect-error a different registered payload is not visibility
const wrong: MenuSeparatorProps = { ...valid, observable: text };
// @ts-expect-error surface ownership must be declared
const noSurface: MenuSeparatorProps = { observable: visible, hotkeys: [], };
// @ts-expect-error keys must be declared even when empty
const noKeys: MenuSeparatorProps = { observable: visible, surface: { kind: 'inherit' }, };
// @ts-expect-error visibility cannot bypass the registered source
const hidden: MenuSeparatorProps = { ...valid, hidden: true };
// @ts-expect-error accessibility visibility cannot bypass the registered source
const ariaHidden: MenuSeparatorProps = { ...valid, 'aria-hidden': true };
// @ts-expect-error separators own their semantics
const role: MenuSeparatorProps = { ...valid, role: 'button' };
// @ts-expect-error keyboard dispatch must use the declared hotkeys
const keydown: MenuSeparatorProps = { ...valid, onKeyDown: () => {} };
// @ts-expect-error undefined is not a registered source
const undefinedObservable: MenuSeparatorProps = { ...valid, observable: undefined };
// @ts-expect-error undefined is not a surface declaration
const undefinedSurface: MenuSeparatorProps = { ...valid, surface: undefined };
// @ts-expect-error undefined is not an empty keys declaration
const undefinedKeys: MenuSeparatorProps = { ...valid, hotkeys: undefined };
// @ts-expect-error generic controls do not accept feature rollout switches
const undefinedScope: MenuSeparatorProps = { ...valid, uiScope: undefined };
`;

it('requires registered visibility, explicit surface and keyboard contracts', () => {
  const root = process.cwd();
  const filename = path.join(root, 'src/contracts/__divider_typecheck__.ts');
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const options: ts.CompilerOptions = { ...parsed.options, noEmit: true, incremental: false, composite: false,
    noUnusedLocals: false, noUnusedParameters: false };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host); const exists = host.fileExists.bind(host);
  host.readFile = file => path.resolve(file) === filename ? source : read(file);
  host.fileExists = file => path.resolve(file) === filename || exists(file);
  const program = ts.createProgram([filename], options, host);
  const fixture = program.getSourceFile(filename)!;
  expect(fixture).toBeDefined();
  const diagnostics = [...program.getSyntacticDiagnostics(fixture), ...program.getSemanticDiagnostics(fixture)];
  expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
}, 30000);
