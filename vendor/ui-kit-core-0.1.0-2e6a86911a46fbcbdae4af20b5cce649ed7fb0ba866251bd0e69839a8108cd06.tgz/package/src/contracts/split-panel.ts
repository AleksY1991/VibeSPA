import type { JSX } from '@solidjs/web';

export interface SplitPanelState {
  readonly endSize: number;
  readonly collapsed: boolean;
}

export interface SplitPanelControlProps {
  readonly state: SplitPanelState;
  readonly min: number;
  readonly max: number;
  readonly step: number;
  readonly label: string;
  readonly onEndSizeChange: (pixels: number) => void;
  readonly start: JSX.Element;
  readonly end: JSX.Element;
  readonly class?: string;
  /** The containing host remains visible when only its end pane is collapsed. */
  readonly onElement?: (element: HTMLElement) => void;
  /** Only the internal divider owns native resize keys. */
  readonly onNativeElement?: (element: HTMLElement) => void;
}
