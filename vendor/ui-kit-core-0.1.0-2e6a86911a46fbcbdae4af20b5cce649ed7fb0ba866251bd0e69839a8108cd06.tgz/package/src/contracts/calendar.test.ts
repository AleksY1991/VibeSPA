import { describe, expect, it } from 'vitest';
import { dayKey, weekIdToMonday, weekIdToSunday, shiftIsoWeek } from './calendar';

describe('neutral calendar values', () => {
  it('preserves ISO boundaries across years', () => {
    expect(dayKey(weekIdToMonday('2026-W01'))).toBe('2025-12-29');
    expect(dayKey(weekIdToSunday('2026-W01'))).toBe('2026-01-04');
    expect(shiftIsoWeek('2025-W52', 1)).toBe('2026-W01');
  });
  it('rejects malformed inputs instead of choosing the current week', () => {
    expect(() => weekIdToMonday('2026-07-08')).toThrow(TypeError);
    expect(() => weekIdToSunday('')).toThrow(TypeError);
  });
});
