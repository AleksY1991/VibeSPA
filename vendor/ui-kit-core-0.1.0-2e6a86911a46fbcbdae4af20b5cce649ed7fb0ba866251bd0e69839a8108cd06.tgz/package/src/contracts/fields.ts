import type { JSX } from '@solidjs/web';
import type { FocusHandle, TextFieldControlProps } from './controls';
import type { FieldPresentation, SelectRecipe, TextareaRecipe } from './field-presentation';

export interface SelectOption {
  readonly value: string;
  readonly label: string;
  readonly disabled?: boolean;
}

export interface SelectControlProps extends Omit<FieldPresentation, 'recipe'> {
  readonly recipe?: SelectRecipe;
  readonly onElement?: (element: HTMLElement) => void;
  /** The renderer reports its actual Escape policy, retaining native ownership if unknown. */
  readonly onEscapeOwnership?: (ownsEscape: () => boolean) => void;
  readonly label: string;
  readonly start?: JSX.Element;
  readonly end?: JSX.Element;
  readonly value: string;
  readonly options: readonly SelectOption[];
  readonly onValueChange: (value: string) => void;
  readonly id?: string;
  readonly name?: string;
  readonly form?: string;
  readonly required?: boolean;
  readonly disabled?: boolean;
  readonly placeholder?: string;
  readonly 'aria-describedby'?: string;
  readonly 'data-tip'?: string;
  readonly onFocus?: () => void;
  readonly onBlur?: () => void;
  readonly onHandle?: (handle: FocusHandle | undefined) => void;
}

export interface TextareaControlProps extends Omit<TextFieldControlProps, 'recipe' | 'type' | 'min' | 'max' | 'step' | 'pattern' | 'compact' | 'start' | 'end'> {
  readonly recipe?: TextareaRecipe;
  /** Fill a bounded writing pane while preserving internal scrolling. */
  readonly fillHeight?: boolean;
  readonly rows?: number;
  readonly resize?: 'none' | 'vertical' | 'horizontal' | 'both' | 'auto';
  readonly minHeight?: number;
  readonly maxHeight?: number;
  readonly trailingAction?: never;
}
