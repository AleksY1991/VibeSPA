/**
 * Equality for derived containers, never a replacement for a narrow subscription.
 * Keep the old output only when every observable part of its value is unchanged.
 * Document elements compare by reference so a new source revision still publishes.
 */
export function sameItems<T>(previous: readonly T[], next: readonly T[]): boolean {
  if (previous === next) return true;
  if (previous.length !== next.length) return false;
  for (let index = 0; index < previous.length; index++) {
    if ((index in previous) !== (index in next) || !Object.is(previous[index], next[index])) return false;
  }
  return true;
}

/** Own enumerable string keys and their order are part of a record's output. */
export function sameRecord<T>(
  previous: Readonly<Record<string, T>>,
  next: Readonly<Record<string, T>>,
  equals: (previous: T, next: T) => boolean = Object.is,
): boolean {
  if (previous === next) return true;
  const keys = Object.keys(previous);
  const nextKeys = Object.keys(next);
  return sameItems(keys, nextKeys) && keys.every((key) => equals(previous[key] as T, next[key] as T));
}

/** Preserve iteration order as well as keys/values; consumers may render that order. */
export function sameMap<K, V>(
  previous: ReadonlyMap<K, V>,
  next: ReadonlyMap<K, V>,
  equals: (previous: V, next: V) => boolean = Object.is,
): boolean {
  if (previous === next) return true;
  if (previous.size !== next.size) return false;
  const nextEntries = next.entries();
  for (const [key, value] of previous) {
    const entry = nextEntries.next();
    if (entry.done || !Object.is(key, entry.value[0]) || !equals(value, entry.value[1])) return false;
  }
  return true;
}

/** Set iteration order is observable too. */
export function sameSet<T>(previous: ReadonlySet<T>, next: ReadonlySet<T>): boolean {
  if (previous === next) return true;
  if (previous.size !== next.size) return false;
  const nextValues = next.values();
  for (const value of previous) {
    const entry = nextValues.next();
    if (entry.done || !Object.is(value, entry.value)) return false;
  }
  return true;
}

/**
 * Equality gate for a small control-state object (`{ pressed }`, `{ ariaDisabled }`).
 * Such a memo re-runs whenever any input changes; without this gate every run publishes
 * a new-but-equivalent object and every subscriber re-runs with it.
 */
export function sameFields<T extends object>(previous: T, next: T): boolean {
  return sameRecord(previous as Readonly<Record<string, unknown>>, next as Readonly<Record<string, unknown>>);
}
