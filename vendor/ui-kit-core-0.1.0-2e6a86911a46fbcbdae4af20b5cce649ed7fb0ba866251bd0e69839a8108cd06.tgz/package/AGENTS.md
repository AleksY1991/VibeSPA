# Package agent context

Read [the repository guide](../../CLAUDE.md) and [design intent](../../DESIGN.md)
before changing this package. The [root instructions](../../AGENTS.md), including
SQL approval and the Supabase integration ban, apply to all delegated work.

Use the runtime/compiler versions pinned in [package.json](package.json). With
workspace dependencies installed, read the relevant installed references:

- Solid implementation: [Solid 2 cheatsheet](node_modules/solid-js/CHEATSHEET.md).
  Do not substitute React or Solid 1 lifecycle/reactivity assumptions.
- Reactive diagnostics: [Solid's repair skill](node_modules/solid-js/skills/reactivity-diagnostics/SKILL.md).
- Vendor adapters: [Web Awesome's component API skill](node_modules/@awesome.me/webawesome/dist-cdn/skills/webawesome/SKILL.md)
  and its focused component references.
- Vendor metadata: [Web Awesome's custom-element manifest](node_modules/@awesome.me/webawesome/dist/custom-elements.json).
  This describes vendor elements, not the public `@ui-kit/core` API.
- Vendor composition guidance, when relevant: [Web Awesome's design skill](node_modules/@awesome.me/webawesome/dist-cdn/skills/webawesome-design/SKILL.md).
  Its styling/layout advice is subordinate to `DESIGN.md`; it does not authorize
  vendor defaults, direct vendor controls or application styling overrides.

The public package API is defined by [exports](package.json),
[control exports](src/solid/index.ts) and [typed contracts](src/contracts/).
Use the associated executable tests for construction and behavior requirements.
Keep each control's renderer, observables, surfaces, hotkeys and cleanup owned by
the package. Keep consumer code on the public controls rather than vendor adapters.
Consumer code follows [the component guide](components.md) and its checked
examples. Regenerate the guide and [manifest](components.json) with
`pnpm run docs:components` at the repository root after public API changes.
`pnpm run check:components` verifies generated context and compiles the examples.

For legacy Button, field and Dialog callers, run
`node tools/migrate-presentation.mjs <source-path>` from the repository root for a
JSON dry-run report. `--write` applies only proven mappings; any manual issue leaves
that entire file unchanged. Review unsupported combinations against the public
recipe types. The tool parses source without executing it and skips tests and fixtures.

Browser regression checks use the pinned Playwright Chromium, Firefox and WebKit builds. After dependency
installation, run `pnpm --filter @ui-kit/core exec playwright install chromium firefox webkit`
once, then `pnpm run test:browser` (also part of the root build). Screenshot baselines
live in `tests/browser/screenshots/<platform>/`; compare and update them on the same
OS and browser build. Use `pnpm --filter @ui-kit/core test:browser --update-snapshots`
only after reviewing the changed appearance. Screenshots supplement contract tests.
