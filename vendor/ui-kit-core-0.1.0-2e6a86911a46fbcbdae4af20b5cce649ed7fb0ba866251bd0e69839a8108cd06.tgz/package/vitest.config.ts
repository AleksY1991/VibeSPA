import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import solid from '@solidjs/vite-plugin';
import { defineConfig } from 'vitest/config';

const root = fileURLToPath(new URL('.', import.meta.url));
const require = createRequire(import.meta.url);
const solidRoot = path.dirname(require.resolve('solid-js/package.json'));
const signalsRoot = path.dirname(createRequire(path.join(solidRoot, 'package.json')).resolve('@solidjs/signals/package.json'));
const webRoot = path.resolve(path.dirname(require.resolve('@solidjs/web')), '..');

export default defineConfig({
  root,
  css: { postcss: { plugins: [] } },
  plugins: [solid({
    include: /\.tsx$/,
    ssr: true,
    refresh: { disabled: true },
    babel: { presets: [['@babel/preset-typescript', { onlyRemoveTypeImports: true }]] },
  })],
  resolve: {
    dedupe: ['solid-js', '@solidjs/signals', '@solidjs/web'],
    alias: [
      { find: /^solid-js$/, replacement: path.join(solidRoot, 'dist/solid.dev.js') },
      { find: /^solid-js\/attribution$/, replacement: path.join(solidRoot, 'dist/attribution.js') },
      { find: /^@solidjs\/signals$/, replacement: path.join(signalsRoot, 'dist/dev.js') },
      { find: /^@solidjs\/signals\/attribution$/, replacement: path.join(signalsRoot, 'dist/dev.attribution.js') },
      { find: /^@solidjs\/web(?:\/jsx(?:-dev)?-runtime)?$/, replacement: path.join(webRoot, 'dist/web.dev.js') },
    ],
  },
  test: {
    environment: 'node',
    maxWorkers: 2,
    setupFiles: ['./tests/setup.ts'],
    server: { deps: { inline: [/lit/, /@awesome\.me/, /solid-js/, /@solidjs/] } },
    projects: [
      { extends: true, resolve: { conditions: ['browser'] }, test: { name: 'unit', include: ['src/**/*.test.{ts,tsx}', 'tests/**/*.test.{ts,tsx}'], exclude: ['src/vendor/web-awesome/{text-field.selection,spinner.adapter,progress-bar.adapter,tooltip.adapter}.test.tsx'] } },
      { extends: true, resolve: { conditions: ['browser'] }, test: {
        name: 'web-awesome',
        include: ['src/vendor/web-awesome/{text-field.selection,spinner.adapter,progress-bar.adapter,tooltip.adapter}.test.tsx'],
        server: { deps: { inline: [/lit/, /@awesome\.me/, /solid-js/, /@solidjs/] } },
      } },
    ],
  },
});
