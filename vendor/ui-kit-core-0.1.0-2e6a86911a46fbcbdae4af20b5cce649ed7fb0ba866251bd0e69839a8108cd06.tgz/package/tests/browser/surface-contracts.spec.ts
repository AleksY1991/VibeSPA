import { expect, test, type Page } from '@playwright/test';

const browserErrors = new WeakMap<Page, string[]>();

test.beforeEach(async ({ page }) => {
  const errors: string[] = [];
  browserErrors.set(page, errors);
  page.on('pageerror', error => errors.push(error.message));
});
test.afterEach(async ({ page }) => {
  expect(browserErrors.get(page), 'browser runtime errors').toEqual([]);
});

async function openFixture(page: Page) {
  await page.goto('/surface-contracts.html');
  await expect(page.locator('#surface-contracts')).toBeVisible();
  await expect(page.locator('[data-ui-control-unavailable]')).toHaveCount(0);
  await expect(page.locator('[data-ui-ready="false"]')).toHaveCount(0);
  await page.evaluate(async () => { await document.fonts.ready; });
}

test('closed Card recipes own paint and bounds while retaining native content', async ({ page }) => {
  await openFixture(page);
  const panel = page.locator('#surface-card-panel');
  expect((await panel.boundingBox())!.height).toBe(112);
  await expect(panel).toHaveCSS('overflow', 'hidden');
  await expect(page.locator('#surface-card-content')).toHaveCSS('padding', '16px');
  await expect(page.locator('#surface-card-notice')).toHaveCSS('padding', '16px');
  await expect(page.locator('#card-recipes')).toHaveScreenshot('card-recipes.png');
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.locator('#card-recipes').evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
  await expect(page.locator('#card-recipes')).toHaveScreenshot('card-recipes-narrow.png');
  const draft = page.locator('#card-draft');
  const card = page.locator('#live-card');
  const originalDraft = await draft.elementHandle();
  const originalCard = await card.elementHandle();
  await draft.fill('A native Card draft');
  await draft.press('Home'); await draft.press('Shift+ArrowRight');
  for (const recipe of ['content', 'panel', 'popover', 'notice', 'plain']) {
    await draft.press('F7');
    await expect(page.locator('#card-recipe')).toHaveText(recipe);
    await expect(draft).toBeFocused();
    await expect(draft).toHaveValue('A native Card draft');
    expect(await draft.evaluate((node, original) => node === original, originalDraft)).toBe(true);
    expect(await card.evaluate((node, original) => node === original, originalCard)).toBe(true);
    expect(await draft.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
  }
  await originalDraft!.dispose(); await originalCard!.dispose();
});

test('closed Popover recipes retain editing, ownership and independent dismissal', async ({ page }) => {
  await openFixture(page);
  await page.locator('#surface-open-popover').focus();
  await page.locator('#surface-open-popover').press('Enter');
  const panel = page.locator('wa-popover[data-ui-popover]');
  const dialog = page.getByRole('dialog', { name: 'Recipe popup', exact: true });
  const draft = page.locator('#popover-draft');
  await expect(dialog).toBeVisible();
  const originalPanel = await panel.elementHandle();
  const originalDraft = await draft.elementHandle();
  await draft.fill('A popup draft');
  await draft.press('Home'); await draft.press('Shift+ArrowRight');
  for (const [recipe, width, padding, display] of [
    ['popover', 288, '16px', 'block'], ['picker', 288, '4px', 'grid'],
    ['content', 288, '0px', 'block'], ['form', 320, '8px', 'flex'],
  ] as const) {
    if (recipe !== 'popover') await draft.press('F7');
    await expect(page.locator('#popover-recipe')).toHaveText(recipe);
    expect((await panel.boundingBox())!.width).toBe(width);
    await expect(panel).toHaveCSS('padding', '0px');
    const content = panel.locator('[data-ui-surface-content]');
    await expect(content).toHaveCSS('padding', padding);
    await expect(content).toHaveCSS('display', display);
    await expect(draft).toBeFocused();
    await expect(draft).toHaveValue('A popup draft');
    expect(await panel.evaluate((node, original) => node === original, originalPanel)).toBe(true);
    expect(await draft.evaluate((node, original) => node === original, originalDraft)).toBe(true);
    expect(await draft.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
    await expect(panel).toHaveScreenshot(`popover-${recipe}.png`);
  }
  await page.setViewportSize({ width: 280, height: 720 });
  expect((await panel.boundingBox())!.width).toBeLessThanOrEqual(280);
  await draft.press('Escape');
  await expect(dialog).toBeHidden();
  await expect(page.locator('#surface-open-popover')).toBeFocused();
  await originalPanel!.dispose(); await originalDraft!.dispose();
});

for (const update of ['pending', 'rejected'] as const) {
  test(`TabPanel ${update} updates do not gate child editing or surface lifetime`, async ({ page }) => {
    await page.addInitScript(failure => {
      const define = customElements.define.bind(customElements);
      customElements.define = (name, constructor, options) => {
        if (name === 'wa-tab-panel') Object.defineProperty(constructor.prototype, 'updateComplete', {
          configurable: true,
          get() { return failure === 'pending' ? new Promise(() => {}) : Promise.reject(new Error('Injected panel update failure')); },
        });
        define(name, constructor, options);
      };
    }, update);
    await openFixture(page);
    const panel = page.locator('#fault-panel');
    const draft = page.locator('#panel-draft');
    await expect(panel).not.toHaveAttribute('inert');
    await expect(panel).not.toHaveAttribute('data-ui-ready');
    if (update === 'rejected') await expect(panel).toHaveAttribute('data-ui-error', 'update-failed');
    const originalDraft = await draft.elementHandle();
    await draft.fill('Draft through update failure');
    await draft.press('Home'); await draft.press('Shift+ArrowRight');
    await draft.press('F8');
    await expect(page.locator('#panel-keys')).toHaveText('1');
    await page.locator('#toggle-panel').click();
    await expect(panel).toBeHidden();
    await page.locator('#toggle-panel').press('F8');
    await expect(page.locator('#panel-keys')).toHaveText('1');
    await page.locator('#toggle-panel').click();
    await expect(panel).toBeVisible();
    await draft.focus();
    await expect(draft).toHaveValue('Draft through update failure');
    expect(await draft.evaluate((node, original) => node === original, originalDraft)).toBe(true);
    expect(await draft.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
    await draft.press('F8');
    await expect(page.locator('#panel-keys')).toHaveText('2');
    await page.locator('#unmount-panel').click();
    await expect(panel).toHaveCount(0);
    await expect(page.locator('#panel-cleanups')).toHaveText('1');
    await page.locator('#unmount-panel').press('F8');
    await expect(page.locator('#panel-keys')).toHaveText('2');
    await originalDraft!.dispose();
  });
}
