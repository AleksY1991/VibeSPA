import { expect, test, type Page } from '@playwright/test';

const browserErrors = new WeakMap<Page, string[]>();

test.beforeEach(async ({ page }) => {
  const errors: string[] = [];
  browserErrors.set(page, errors);
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/');
  await expect(page.locator('#catalog')).toBeVisible();
  await expect(page.locator('#catalog [data-ui-ready="false"]')).toHaveCount(0);
  await page.evaluate(async () => { await document.fonts.ready; });
});

test.afterEach(async ({ page }) => {
  expect(browserErrors.get(page), 'browser runtime errors').toEqual([]);
});

test('desktop controls retain shared dimensions, selection paint and actual vendor parts', async ({ page }) => {
  for (const [size, height] of [['dense', 32], ['compact', 36], ['standard', 40], ['large', 44]] as const) {
    const button = page.locator(`#button-${size}`);
    const field = page.locator(`#field-${size}`);
    expect((await button.boundingBox())?.height).toBe(height);
    await expect(button).toHaveCSS('background-color', 'rgb(0, 0, 0)');
    await expect(button).toHaveCSS('color', 'rgb(255, 255, 255)');
    expect((await field.boundingBox())?.height).toBe(height);
    expect(await field.locator('input').count()).toBe(1);
    await expect(page.locator(`#selected-${size}`)).toHaveAttribute('aria-pressed', 'true');
    await expect(page.locator(`#disabled-${size}`)).toBeDisabled();
  }
  await expect(page.locator('#catalog')).toHaveScreenshot('controls-desktop.png');
});

test('narrow controls retain touch targets, field text and reviewed appearance', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const button = page.locator('#button-dense');
  const field = page.locator('#field-dense');
  expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  expect((await field.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  expect(await field.locator('input').evaluate(input => getComputedStyle(input).fontSize)).toBe('16px');
  expect(await page.locator('#catalog').evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
  await expect(page.locator('#catalog')).toHaveScreenshot('controls-narrow.png');
});

test('dark controls retain readable primary actions and reviewed selection paint', async ({ page }) => {
  await page.evaluate(() => document.documentElement.classList.add('dark'));
  await expect(page.locator('#button-dense')).toHaveCSS('background-color', 'rgb(255, 255, 255)');
  await expect(page.locator('#button-dense')).toHaveCSS('color', 'rgb(0, 0, 0)');
  await expect(page.locator('#catalog')).toHaveScreenshot('controls-dark.png');
});

test('ordinary commands stay quiet while explicit primary actions retain emphasis', async ({ page }) => {
  const ordinary = page.locator('#recipe-button');
  const primary = page.locator('#button-dense');
  await expect(ordinary).toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  await expect(ordinary).toHaveCSS('color', 'rgb(0, 0, 0)');
  await expect(primary).toHaveCSS('background-color', 'rgb(0, 0, 0)');
  expect((await ordinary.boundingBox())!.height).toBe(32);
  await page.evaluate(() => document.documentElement.classList.add('dark'));
  await expect(ordinary).toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  await expect(ordinary).toHaveCSS('color', 'rgb(255, 255, 255)');
  await expect(primary).toHaveCSS('background-color', 'rgb(255, 255, 255)');
  await page.setViewportSize({ width: 390, height: 844 });
  expect((await ordinary.boundingBox())!.height).toBeGreaterThanOrEqual(44);
});

test('native Button keeps external form participation and external ARIA references', async ({ page }) => {
  const submit = page.locator('#submit-action');
  expect(await submit.evaluate(element => (element as HTMLButtonElement).form?.id)).toBe('external-form');
  await expect(submit).toHaveAttribute('aria-controls', 'external-form');
  await expect(submit).toHaveAttribute('aria-describedby', 'form-description');
  await expect(submit).toHaveAccessibleName('Submit external form');
  await expect(submit).toHaveAccessibleDescription('Browser-owned form submission and reset.');
  await submit.click();
  await expect(page.locator('#submission')).toHaveText('submit-action:publish');
  await expect(page.locator('#submission')).toHaveAttribute('data-count', '1');
  await page.locator('#form-draft').fill('Unsubmitted form draft');
  await page.locator('#reset-action').click();
  await expect(page.locator('#form-draft')).toHaveValue('saved');
});

test('installed Web Awesome field keeps browser selection and controlled edits', async ({ page }) => {
  const field = page.locator('#field-compact');
  const input = field.locator('input');
  await input.fill('alpha beta');
  await expect(page.locator('#field-value-compact')).toHaveText('alpha beta');
  await input.press('Home');
  await input.press('Shift+ArrowRight');
  expect(await input.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd })))
    .toEqual({ start: 0, end: 1 });
  await input.press('X');
  await expect(page.locator('#field-value-compact')).toHaveText('Xlpha beta');
  await expect(input).toHaveValue('Xlpha beta');
});

test('a failed adapter import stays local and retry preserves healthy browser editing state', async ({ page }) => {
  let unavailable = true;
  await page.route('**/spinner.adapter.tsx*', route => unavailable ? route.abort('failed') : route.continue());
  await page.reload();
  await expect(page.locator('[data-ui-control-unavailable="Spinner"]')).toBeVisible();
  await expect(page.locator('#spinner-state')).toHaveText('failed');
  await expect(page.locator('#button-dense')).toBeEnabled();
  const field = page.locator('#field-compact input');
  await field.fill('Draft survives another family retry');
  const editingNode = await field.elementHandle();
  await field.press('Home');
  await field.press('Shift+ArrowRight');
  unavailable = false;
  // Retained browser selection survives moving focus to the host retry action.
  await page.locator('#retry-preparation').click();
  await expect(page.locator('#spinner-state')).toHaveText('ready');
  await expect(page.locator('[data-ui-control-unavailable="Spinner"]')).toHaveCount(0);
  await expect(page.getByRole('progressbar', { name: 'Isolated spinner' })).toBeVisible();
  await expect(field).toHaveValue('Draft survives another family retry');
  expect(await editingNode!.evaluate(element => element.isConnected)).toBe(true);
  expect(await field.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd })))
    .toEqual({ start: 0, end: 1 });
  await editingNode!.dispose();
});

test('an unresolved adapter import does not hold healthy controls behind its startup deadline', async ({ page }) => {
  let release!: () => void;
  let intercepted = false;
  const held = new Promise<void>(resolve => { release = resolve; });
  await page.route('**/spinner.adapter.tsx*', async route => {
    intercepted = true;
    await held;
    await route.continue();
  });
  const deadline = Date.now() + 5000;
  const remaining = () => Math.max(1, deadline - Date.now());
  // Commit returns before module loading completes, so an all-or-nothing
  // bootstrap cannot hide its eight-second delay in page.reload().
  await page.reload({ waitUntil: 'commit' });
  const field = page.locator('#field-compact input');
  try {
    await expect(page.locator('#catalog')).toBeVisible({ timeout: remaining() });
    expect(intercepted).toBe(true);
    await expect(page.locator('#spinner-state')).toHaveText('pending', { timeout: remaining() });
    await field.fill('Draft while Spinner is still loading', { timeout: remaining() });
    await expect(page.locator('#field-value-compact')).toHaveText('Draft while Spinner is still loading', { timeout: remaining() });
    await page.locator('#submit-action').click({ timeout: remaining() });
    await expect(page.locator('#submission')).toHaveText('submit-action:publish', { timeout: remaining() });
    expect(Date.now()).toBeLessThan(deadline);
    const editingNode = await field.elementHandle();
    release();
    await expect(page.locator('#spinner-state')).toHaveText('ready');
    await expect(page.getByRole('progressbar', { name: 'Isolated spinner' })).toBeVisible();
    await expect(field).toHaveValue('Draft while Spinner is still loading');
    expect(await editingNode!.evaluate(element => element.isConnected)).toBe(true);
    await editingNode!.dispose();
  } finally {
    release();
  }
});

test('native Dialog preserves draft owners across modality and retained close/reopen', async ({ page }) => {
  await page.locator('#open-dialog').click();
  const panel = page.locator('#browser-dialog');
  const overlay = page.locator('dialog[data-ui-dialog-overlay]');
  await expect(panel).toBeVisible();
  await expect(page.locator('#preferred-field')).toBeFocused();
  expect(await overlay.evaluate(element => element.matches(':modal'))).toBe(true);
  await expect(panel).toHaveAccessibleName('Browser dialog');
  await expect(panel).toHaveAttribute('aria-modal', 'true');
  await page.locator('#retained-draft').fill('Unsubmitted editor draft');
  await page.locator('#toggle-modal').click();
  await expect(page.locator('#dialog-mode')).toHaveText('pinned');
  expect(await overlay.evaluate(element => element.matches(':modal'))).toBe(false);
  await expect(panel).toHaveAttribute('aria-modal', 'false');
  await page.locator('#background-action').click();
  await expect(page.locator('#background-count')).toHaveText('1');
  await page.locator('#retained-draft').fill('Still the same draft');
  await page.locator('#toggle-modal').click();
  expect(await overlay.evaluate(element => element.matches(':modal'))).toBe(true);
  await expect(page.locator('#retained-draft')).toHaveValue('Still the same draft');
  await page.locator('#close-dialog').click();
  await expect(panel).toBeHidden();
  await page.locator('#open-dialog').click();
  await expect(page.locator('#retained-draft')).toHaveValue('Still the same draft');
  await expect(page.locator('#mount-count')).toHaveText('1');
  await expect(page.locator('#cleanup-count')).toHaveText('0');
});

test('Dialog waits for preferred readiness and preserves child-first Escape and backdrop return focus', async ({ page }) => {
  await page.locator('#open-delayed').focus();
  await page.locator('#open-delayed').press('Enter');
  const preferred = page.locator('#preferred-field');
  await expect(preferred).toHaveAttribute('data-ui-ready', 'false');
  await expect(page.locator('#first-field')).not.toBeFocused();
  await expect(preferred).not.toBeFocused();
  await expect(preferred).toHaveAttribute('data-ui-ready', 'true');
  await expect(preferred).toBeFocused();
  await page.locator('#open-nested').click();
  await expect(page.locator('#nested-action')).toBeVisible();
  await page.locator('#nested-action').press('Escape');
  await expect(page.locator('#nested-action')).toBeHidden();
  await expect(page.locator('#browser-dialog')).toBeVisible();
  await page.locator('#preferred-field').press('Escape');
  await expect(page.locator('#browser-dialog')).toBeHidden();
  await expect(page.locator('#open-delayed')).toBeFocused();
  await page.locator('#open-dialog').focus();
  await page.locator('#open-dialog').press('Enter');
  await expect(page.locator('#preferred-field')).toBeFocused();
  // This is a real pointer default, which a DOM dispatch cannot exercise.
  await page.mouse.click(12, 12);
  await expect(page.locator('#browser-dialog')).toBeHidden();
  await expect(page.locator('#open-dialog')).toBeFocused();
  await expect(page.locator('#background-count')).toHaveText('0');
});

test('Dialog geometry and pixels remain bounded on desktop and narrow viewports', async ({ page }) => {
  await page.locator('#open-dialog').click();
  const panel = page.locator('#browser-dialog');
  await expect(page.locator('#preferred-field')).toBeFocused();
  expect((await panel.boundingBox())?.width).toBe(512);
  await expect(panel).toHaveScreenshot('dialog-desktop.png');
  await page.setViewportSize({ width: 390, height: 844 });
  const bounds = (await panel.boundingBox())!;
  expect(bounds.x).toBe(16);
  expect(bounds.width).toBe(358);
  expect(bounds.y).toBeGreaterThanOrEqual(16);
  expect(bounds.y + bounds.height).toBeLessThanOrEqual(828);
  await expect(panel).toHaveScreenshot('dialog-narrow.png');
});

test('closed Button and field recipes own their real geometry and appearance', async ({ page }) => {
  await expect(page.locator('#recipe-catalog [data-ui-ready="false"]')).toHaveCount(0);
  await expect(page.locator('#recipe-button')).toHaveAttribute('data-ui-recipe', 'button');
  await expect(page.locator('#recipe-button')).toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  const content = page.locator('#recipe-content');
  await expect(content).toHaveCSS('white-space', 'normal');
  expect((await content.boundingBox())!.width).toBe(220);
  expect((await content.boundingBox())!.height).toBeGreaterThan(36);
  for (const selector of ['#recipe-menu', '#recipe-navigation', '#recipe-dense-navigation']) {
    const row = page.locator(selector);
    const width = await row.evaluate(element => element.parentElement!.getBoundingClientRect().width);
    expect((await row.boundingBox())!.width).toBe(width);
  }
  const label = await page.locator('#recipe-menu [data-ui-button-label]').boundingBox();
  const start = await page.locator('#menu-start').boundingBox();
  const end = await page.locator('#menu-end').boundingBox();
  expect(start!.x + start!.width).toBeLessThanOrEqual(label!.x + 0.5);
  expect(end!.x).toBeGreaterThanOrEqual(label!.x + label!.width - 0.5);
  await expect(page.locator('#recipe-navigation')).toHaveAttribute('data-ui-selected', '');
  await expect(page.locator('#recipe-navigation')).toHaveCSS('font-weight', '600');
  await expect(page.locator('#recipe-navigation .ui-navigation-marker')).toBeVisible();
  for (const selector of ['#recipe-navigation', '#recipe-dense-navigation']) {
    const navigation = page.locator(selector);
    const navigationLabel = navigation.locator('[data-ui-button-label]');
    const labelGeometry = () => navigationLabel.evaluate(element => {
      const label = element.getBoundingClientRect();
      const control = element.parentElement!.getBoundingClientRect();
      return { x: label.x - control.x, y: label.y - control.y, width: label.width, height: label.height };
    });
    const selectedLabelBounds = await labelGeometry();
    const expectRetainedLabelGeometry = async () => {
      const current = await labelGeometry();
      // A key press can scroll the page; Firefox's transformed page coordinates
      // differ by sub-thousandth-pixel rounding after that native scroll.
      for (const axis of ['x', 'y', 'width', 'height'] as const) {
        expect(current[axis]).toBeCloseTo(selectedLabelBounds[axis], 3);
      }
    };
    expect(selectedLabelBounds.x).toBe(8);
    const marker = navigation.locator('.ui-navigation-marker path');
    // Firefox includes SVG stroke joins in its protocol bounds differently from
    // Chromium. Map the SVG geometry into CSS coordinates for fixed placement,
    // then separately check the painted bounds remain inside the control.
    const glyph = await marker.evaluate(element => {
      const path = element as SVGGraphicsElement;
      const bounds = path.getBBox();
      const transform = path.getScreenCTM()!;
      return {
        left: new DOMPoint(bounds.x, bounds.y).matrixTransform(transform).x,
        right: new DOMPoint(bounds.x + bounds.width, bounds.y + bounds.height).matrixTransform(transform).x,
      };
    });
    const ink = (await marker.boundingBox())!;
    const row = (await navigation.boundingBox())!;
    expect(glyph.left - row.x).toBeGreaterThanOrEqual(1);
    expect(glyph.right).toBeLessThan(row.x + selectedLabelBounds.x - 1);
    expect(ink.x).toBeGreaterThanOrEqual(row.x);
    expect(ink.x + ink.width).toBeLessThan(row.x + selectedLabelBounds.x);
    await navigation.press('F10');
    await expect(navigation).not.toHaveAttribute('data-ui-selected');
    await expectRetainedLabelGeometry();
    await navigation.press('F10');
    await expect(navigation).toHaveAttribute('data-ui-selected', '');
    await expectRetainedLabelGeometry();
  }
  expect((await page.locator('#recipe-dense-navigation').boundingBox())!.height).toBe(32);
  await page.locator('#recipe-catalog h2').click();
  expect(label!.x - (start!.x + start!.width)).toBeGreaterThanOrEqual(4);
  expect(end!.x - (label!.x + label!.width)).toBeGreaterThanOrEqual(4);
  for (const recipe of ['form', 'inline', 'filled', 'code']) {
    const host = page.locator(`#recipe-field-${recipe}`);
    await expect(host).toHaveAttribute('data-ui-field-recipe', recipe);
    expect((await host.boundingBox())!.height).toBe(32);
  }
  const code = page.locator('#recipe-field-code input');
  expect(await code.evaluate(input => getComputedStyle(input).fontFamily)).toMatch(/monospace/);
  await expect(page.locator('#recipe-readonly input')).not.toBeEditable();
  await expect(page.locator('#recipe-readonly input')).toBeEnabled();
  await expect(page.locator('#recipe-disabled input')).toBeDisabled();
  await expect(page.locator('#recipe-select')).toHaveAttribute('data-ui-field-recipe', 'form');
  await expect(page.locator('#recipe-composer')).toHaveAttribute('data-ui-field-recipe', 'composer');
  const composer = page.locator('#recipe-composer textarea');
  expect(await composer.evaluate(input => getComputedStyle(input).paddingInlineEnd)).toBe('48px');
  expect(await composer.evaluate(input => getComputedStyle(input).lineHeight)).toBe('20px');
  expect(await page.locator('#recipe-composer').evaluate(host => getComputedStyle(host).getPropertyValue('--ui-field-padding-block').trim())).toBe('12px');
  await expect(page.locator('#recipe-catalog')).toHaveScreenshot('recipes-desktop.png');
  const composerHeight = (await page.locator('#recipe-composer').boundingBox())!.height;
  await composer.fill(Array.from({ length: 30 }, (_, index) => `Long document line ${index + 1}`).join('\n'));
  await expect.poll(async () => (await page.locator('#recipe-composer').boundingBox())!.height).toBe(160);
  expect((await page.locator('#recipe-composer').boundingBox())!.height).toBeGreaterThan(composerHeight);
  expect(await composer.evaluate(input => input.scrollHeight > input.clientHeight)).toBe(true);
  await composer.fill('Short draft');
  await expect.poll(async () => (await page.locator('#recipe-composer').boundingBox())!.height).toBeLessThan(160);
  expect((await page.locator('#recipe-composer').boundingBox())!.height).toBeGreaterThanOrEqual(64);
});

test('closed recipes remain legible and bounded on narrow and dark surfaces', async ({ page }) => {
  await expect(page.locator('#recipe-catalog [data-ui-ready="false"]')).toHaveCount(0);
  await page.setViewportSize({ width: 390, height: 844 });
  for (const selector of ['#recipe-button', '#recipe-content', '#recipe-menu', '#recipe-navigation', '#recipe-dense-navigation', '#recipe-field-form', '#recipe-field-inline', '#recipe-field-filled', '#recipe-field-code', '#recipe-readonly', '#recipe-disabled', '#recipe-select', '#recipe-composer']) {
    expect((await page.locator(selector).boundingBox())!.height).toBeGreaterThanOrEqual(44);
  }
  await expect(page.locator('#recipe-composer textarea')).toHaveCSS('font-size', '16px');
  expect(await page.locator('#recipe-catalog').evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
  await expect(page.locator('#recipe-catalog')).toHaveScreenshot('recipes-narrow.png');
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.evaluate(() => document.documentElement.classList.add('dark'));
  await expect(page.locator('#recipe-button')).toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  await expect(page.locator('#recipe-catalog')).toHaveScreenshot('recipes-dark.png');
});

test('inline recipe preserves label-only pointer targeting and native keyboard activation', async ({ page }) => {
  const button = page.locator('#recipe-inline');
  const label = button.locator('[data-ui-button-label]');
  await expect(button).toHaveCSS('pointer-events', 'none');
  await expect(label).toHaveCSS('pointer-events', 'auto');
  await label.click();
  await expect(page.locator('#inline-activations')).toHaveText('1');
  const decoration = (await page.locator('#inline-decoration').boundingBox())!;
  await page.mouse.click(decoration.x + decoration.width / 2, decoration.y + decoration.height / 2);
  await expect(page.locator('#inline-activations')).toHaveText('1');
  await button.press('Enter');
  await expect(page.locator('#inline-activations')).toHaveText('2');
  await button.press('Space');
  await expect(page.locator('#inline-activations')).toHaveText('3');
});

test('recipe changes retain Button labels and native field editing owners', async ({ page }) => {
  const button = page.locator('#recipe-live-button');
  const buttonNode = await button.elementHandle();
  const labelNode = await page.locator('#recipe-live-label').elementHandle();
  for (const recipe of ['menu-item', 'navigation', 'inline-action', 'button']) {
    await button.press('F7');
    await expect(page.locator('#live-button-recipe')).toHaveText(recipe);
    await expect(button).toBeFocused();
    expect(await button.evaluate((node, original) => node === original, buttonNode)).toBe(true);
    expect(await page.locator('#recipe-live-label').evaluate((node, original) => node === original, labelNode)).toBe(true);
    await expect(page.locator('#label-mounts')).toHaveText('1');
    await expect(page.locator('#label-cleanups')).toHaveText('0');
  }
  const host = page.locator('#recipe-live-field');
  const input = host.locator('input');
  const fieldNode = await host.elementHandle();
  const inputNode = await input.elementHandle();
  await input.fill('Draft retained across every field recipe');
  await input.press('Home'); await input.press('Shift+ArrowRight');
  for (const recipe of ['inline', 'filled', 'code', 'form']) {
    await input.press('F8');
    await expect(page.locator('#live-field-recipe')).toHaveText(recipe);
    await expect(input).toBeFocused();
    await expect(input).toHaveValue('Draft retained across every field recipe');
    expect(await host.evaluate((node, original) => node === original, fieldNode)).toBe(true);
    expect(await input.evaluate((node, original) => node === original, inputNode)).toBe(true);
    expect(await input.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
  }
  await buttonNode!.dispose(); await labelNode!.dispose(); await fieldNode!.dispose(); await inputNode!.dispose();
  const textareaHost = page.locator('#recipe-live-textarea');
  const textarea = textareaHost.locator('textarea');
  const textareaHostNode = await textareaHost.elementHandle();
  const textareaNode = await textarea.elementHandle();
  const initialTextareaStyle = await textarea.evaluate(element => {
    const style = getComputedStyle(element);
    return { end: style.paddingInlineEnd, lineHeight: style.lineHeight };
  });
  await textarea.fill('Textarea draft stays owned\nSecond line');
  await textarea.press('Control+Home'); await textarea.press('Shift+ArrowRight');
  for (const recipe of ['inline', 'filled', 'code', 'composer', 'form']) {
    await textarea.press('F9');
    await expect(page.locator('#live-textarea-recipe')).toHaveText(recipe);
    await expect(textarea).toBeFocused();
    await expect(textarea).toHaveValue('Textarea draft stays owned\nSecond line');
    expect(await textareaHost.evaluate((node, original) => node === original, textareaHostNode)).toBe(true);
    expect(await textarea.evaluate((node, original) => node === original, textareaNode)).toBe(true);
    expect(await textarea.evaluate(element => ({ start: (element as HTMLTextAreaElement).selectionStart, end: (element as HTMLTextAreaElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
    if (recipe === 'composer') {
      await expect(textarea).toHaveCSS('padding-inline-end', '48px');
      await expect(textarea).toHaveCSS('line-height', '20px');
    } else if (recipe === 'form') {
      expect(await textarea.evaluate(element => {
        const style = getComputedStyle(element);
        return { end: style.paddingInlineEnd, lineHeight: style.lineHeight };
      })).toEqual(initialTextareaStyle);
    }
  }
  await textareaHostNode!.dispose(); await textareaNode!.dispose();
  await page.locator('#reject-retired').click();
  await expect(page.locator('#retired-result')).toContainText('Button: style:color');
  await expect(page.locator('#retired-result')).not.toContainText('construct the element');
});

test('Dialog frame recipes retain draft focus while owning bounded geometry and scroll', async ({ page }) => {
  await page.locator('#open-recipe-dialog').focus();
  await page.locator('#open-recipe-dialog').press('Enter');
  const panel = page.locator('#browser-dialog');
  const overlay = page.locator('dialog[data-ui-dialog-overlay]');
  const draft = page.locator('#retained-draft');
  const panelNode = await panel.elementHandle();
  const overlayNode = await overlay.elementHandle();
  const draftNode = await draft.elementHandle();
  await expect(page.locator('#preferred-field')).toBeFocused();
  await draft.fill('Draft through all frame recipes');
  await draft.press('Home'); await draft.press('Shift+ArrowRight');
  for (const recipe of ['editor', 'fullscreen', 'detached', 'dialog']) {
    await draft.press('F6');
    await expect(page.locator('#live-dialog-recipe')).toHaveText(recipe);
    await expect(draft).toBeFocused();
    await expect(draft).toHaveValue('Draft through all frame recipes');
    expect(await panel.evaluate((node, original) => node === original, panelNode)).toBe(true);
    expect(await overlay.evaluate((node, original) => node === original, overlayNode)).toBe(true);
    expect(await draft.evaluate((node, original) => node === original, draftNode)).toBe(true);
    expect(await draft.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
    await expect(page.locator('#mount-count')).toHaveText('1');
    await expect(page.locator('#cleanup-count')).toHaveText('0');
    const bounds = (await panel.boundingBox())!;
    if (recipe === 'editor') {
      expect(bounds.width).toBe(512); expect(bounds.height).toBe(688);
      await expect(panel).toHaveCSS('overflow', 'hidden');
      const textarea = page.locator('#recipe-dialog-document textarea');
      expect(await textarea.evaluate(element => element.scrollHeight > element.clientHeight)).toBe(true);
      expect((await page.locator('#recipe-dialog-document').boundingBox())!.y + (await page.locator('#recipe-dialog-document').boundingBox())!.height)
        .toBeLessThanOrEqual(bounds.y + bounds.height);
      await expect(panel).toHaveScreenshot('dialog-editor.png');
    } else if (recipe === 'fullscreen' || recipe === 'detached') {
      expect(bounds).toEqual({ x: 0, y: 0, width: 1280, height: 720 });
      if (recipe === 'detached') await expect(panel).toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
      await expect(panel).toHaveScreenshot(`dialog-${recipe}.png`);
    }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await draft.press('F6');
  await expect(page.locator('#live-dialog-recipe')).toHaveText('editor');
  const narrow = (await panel.boundingBox())!;
  expect(narrow.x).toBe(16); expect(narrow.y).toBe(16); expect(narrow.width).toBe(358); expect(narrow.height).toBe(812);
  await expect(panel).toHaveScreenshot('dialog-editor-narrow.png');
  await draft.press('F6'); await draft.press('F6');
  await expect(page.locator('#live-dialog-recipe')).toHaveText('detached');
  await page.locator('#preferred-field').click();
  await expect(panel).toBeVisible();
  await page.mouse.click(378, 832);
  await expect(panel).toBeHidden();
  await expect(page.locator('#open-recipe-dialog')).toBeFocused();
  await page.locator('#open-recipe-dialog').click();
  await expect(draft).toHaveValue('Draft through all frame recipes');
  expect(await draft.evaluate((node, original) => node === original, draftNode)).toBe(true);
  await panelNode!.dispose(); await overlayNode!.dispose(); await draftNode!.dispose();
});
