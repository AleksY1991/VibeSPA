/** @jsxImportSource @solidjs/web */
import { createEffect, createSignal, OBSERVE, onCleanup } from 'solid-js';
import { render } from '@solidjs/web';
import { prepareAppImplementation } from '../../../src/bootstrap';
import { constructItem } from '../../../src/infrastructure/construction';
import { UiRootImplementation } from '../../../src/infrastructure/renderUiRoot';
import { configureSurfacePlatform } from '../../../src/runtime/platform';
import { Button } from '../../../src/solid/button';
import { ChoiceGroup, Toggle } from '../../../src/solid/controls';
import type { InputFocusHandle } from '../../../src/contracts/controls';
import { ContentEditable, type ContentEditableState } from '../../../src/solid/content-editable';
import { Field, Input } from '../../../src/solid/field';
import { FilePicker } from '../../../src/solid/file-picker';
import { Form } from '../../../src/solid/form';
import { Link } from '../../../src/solid/link';
import { List } from '../../../src/solid/list';
import { Popover } from '../../../src/solid/popover';
import { ScrollArea } from '../../../src/solid/scroll-area';
import { SplitPanel } from '../../../src/solid/split-panel';
import { TooltipLayer } from '../../../src/solid/tooltip-layer';
import { TextField } from '../../../src/solid/text-field';
import { attachDispatcher, surfaceRegistry } from '../../surface-host';
import { DisplaySamples } from './catalogue-display';
import { SelectionSamples } from './catalogue-selection';
import '../../../src/theme.css';
import './catalogue.css';

configureSurfacePlatform(surfaceRegistry.platform);
attachDispatcher({ window, document, registry: surfaceRegistry });
const implementation = await prepareAppImplementation();
const host = document.getElementById('app')!;

function CompositionSamples() {
  const [endSize, setEndSize] = createSignal(140);
  const [collapsed, setCollapsed] = createSignal(false);
  const model = constructItem('browser.catalogue.composition', item => ({
    visible: item.constant('visible', true),
    action: item.constant('action', {}),
    split: item.observe('split', () => ({ endSize: endSize(), collapsed: collapsed() })),
    rows: item.constant('rows', Array.from({ length: 8 }, (_, index) => ({ id: index, label: `Retained record ${index + 1}` }))),
  }));
  return <section class="catalogue-section">
    <h2>Layout and retained content</h2>
    <div class="catalogue-scroll-slot">
      <ScrollArea.View id="catalogue-scroll" as="section" observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]}
        fill aria-label="Scrollable records">
        <div class="catalogue-scroll-content"><List.View observable={model.rows} surface={{ kind: 'inherit' }} hotkeys={[]}
          keyBy={row => row.id}>{row => <p>{row.read().label}</p>}</List.View></div>
      </ScrollArea.View>
    </div>
    <div class="catalogue-split-slot">
      <SplitPanel.View observable={model.split} surface={{ kind: 'inherit' }} hotkeys={[]}
        min={80} max={180} step={10} label="Details width" onEndSizeChange={setEndSize}
        start={<div class="catalogue-split-pane"><h3>Start pane</h3><p>Main content</p></div>}
        end={<div class="catalogue-split-pane"><h3>End pane</h3><input id="catalogue-retained-pane" aria-label="Retained pane draft" value="Unsaved draft" /></div>} />
    </div>
    <div class="catalogue-row">
      <Button.View id="catalogue-collapse-pane" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setCollapsed(value => !value)}>{collapsed() ? 'Restore end pane' : 'Collapse end pane'}</Button.View>
      <output id="catalogue-pane-width" class="catalogue-status">{endSize()}</output>
    </div>
  </section>;
}

function NativeSamples() {
  const [text, setText] = createSignal('Inline task title');
  const [editing, setEditing] = createSignal(false);
  const [native, setNative] = createSignal('invalid@example');
  const [file, setFile] = createSignal<File | null>(null);
  const [submitted, setSubmitted] = createSignal('No submission');
  const model = constructItem('browser.catalogue.native', item => ({
    action: item.constant('action', {}),
    editor: item.observe<ContentEditableState>('editor', () => ({ text: text(), editing: editing() })),
    readonlyEditor: item.constant<ContentEditableState>('readonlyEditor', { text: 'Read-only inline content', editing: false, readonly: true }),
    native: item.observe('native', native),
    caption: item.constant('caption', 'Native field with validation'),
    form: item.constant('form', {}),
    file: item.observe('file', file),
    noFile: item.constant<File | null>('noFile', null),
    link: item.constant('link', { href: '#component-catalogue' }),
    disabledLink: item.constant('disabledLink', { href: '#component-catalogue', disabled: true }),
  }));
  return <section class="catalogue-section">
    <h2>Native editing and browser engines</h2>
    <div class="catalogue-editor-slot">
      <ContentEditable.View id="catalogue-inline-editor" observable={model.editor} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Inline task title" focusOnEdit="selectAll" onValueChange={setText}
        onCommit={() => { setEditing(false); }} onCancel={() => setEditing(false)} />
    </div>
    <ContentEditable.View id="catalogue-readonly-editor" observable={model.readonlyEditor} surface={{ kind: 'inherit' }} hotkeys={[]}
      label="Read-only inline content" onValueChange={() => {}} />
    <Button.View id="catalogue-edit-inline" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" onActivate={() => setEditing(true)}>Edit inline title</Button.View>
    <Form.View class="catalogue-native-form" observable={model.form} surface={{ kind: 'inherit' }} hotkeys={[]}
      onSubmit={intent => { intent.preventDefault(); setSubmitted(String(intent.formData().get('contact'))); }}>
      <Field.View observable={model.caption} surface={{ kind: 'inherit' }} hotkeys={[]} for="catalogue-native-input"
        required error="Enter a complete address.">
        <Input.View id="catalogue-native-input" observable={model.native} surface={{ kind: 'inherit' }} hotkeys={[]}
          type="text" name="contact" aria-invalid="true" onValueChange={setNative} />
      </Field.View>
      <Button.View id="catalogue-submit-native" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        type="submit" variant="outline">Submit native form</Button.View>
      <output id="catalogue-submission" class="catalogue-status">{submitted()}</output>
    </Form.View>
    <FilePicker.View label="Catalogue attachment" observable={model.file} surface={{ kind: 'inherit' }} hotkeys={[]}
      accept="text/plain" onFileChange={setFile} />
    <FilePicker.View label="Disabled attachment" observable={model.noFile} surface={{ kind: 'inherit' }} hotkeys={[]}
      disabled onFileChange={() => {}} />
    <div class="catalogue-row">
      <Link.View id="catalogue-inline-link" observable={model.link} surface={{ kind: 'inherit' }} hotkeys={[]}>Inline navigation</Link.View>
      <Link.View id="catalogue-action-link" observable={model.link} surface={{ kind: 'inherit' }} hotkeys={[]}
        appearance="action" controlSize="dense">Action-shaped anchor</Link.View>
      <Link.View id="catalogue-disabled-link" observable={model.disabledLink} surface={{ kind: 'inherit' }} hotkeys={[]}>Disabled link</Link.View>
    </div>
  </section>;
}

function OverlaySamples() {
  const [open, setOpen] = createSignal(false);
  const model = constructItem('browser.catalogue.overlays', item => ({
    action: item.constant('action', {}), open: item.observe('open', open), tips: item.constant('tips', true),
  }));
  return <section class="catalogue-section">
    <h2>Transient surfaces</h2>
    <div class="catalogue-row">
      <Popover.View observable={model.open} surface={{ kind: 'own', name: 'catalogue.popover', transparent: false, layer: true }} hotkeys={[]}
        onOpenChange={setOpen} aria-label="Catalogue choices" recipe="popover"
        trigger={api => <Button.View id="catalogue-open-popover" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="outline" onActivate={api.toggle}>Open choices</Button.View>}>
        {api => <div class="catalogue-popover-content catalogue-stack">
          <h3>Explicit popup surface</h3><p>Escape closes this surface and returns focus.</p>
          <Button.View id="catalogue-popover-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            variant="outline" onActivate={api.close}>Choose action</Button.View>
        </div>}
      </Popover.View>
      <Button.View id="catalogue-tooltip-trigger" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="ghost" data-tip="A visible action retains its accessible name">Named action with tooltip</Button.View>
    </div>
    <TooltipLayer.View observable={model.tips} surface={{ kind: 'inherit' }} hotkeys={[]} delayMs={0} />
  </section>;
}

function Catalogue() {
  return <div id="component-catalogue">
    <h1>Representative component states</h1>
    <div class="catalogue-grid"><SelectionSamples /><DisplaySamples /><CompositionSamples /><NativeSamples /></div>
    <OverlaySamples />
  </div>;
}

/** Native platform proofs stay outside the visual catalogue's screenshot crop. */
function PlatformProofs() {
  const [checked, setChecked] = createSignal(false);
  const [writes, setWrites] = createSignal(0);
  const [disabledChecked, setDisabledChecked] = createSignal(false);
  const [disabledWrites, setDisabledWrites] = createSignal(0);
  const [text, setText] = createSignal('Saved description');
  const [focuses, setFocuses] = createSignal(0);
  const [blurs, setBlurs] = createSignal(0);
  const [commits, setCommits] = createSignal(0);
  const [valueCommits, setValueCommits] = createSignal(0);
  const [focusRequest, setFocusRequest] = createSignal<'idle' | 'focus' | 'blur'>('idle');
  const [choice, setChoice] = createSignal<'one' | 'two'>('one');
  let fieldHandle: InputFocusHandle | undefined;
  let cancelBlur = false;
  let captureFieldDiagnostics = false;
  let diagnosticOutput: HTMLElement | undefined;
  const errorCodes: string[] = [];
  const stopDiagnostics = OBSERVE?.diagnostics.subscribe(event => {
    if (!captureFieldDiagnostics || event.severity !== 'error') return;
    errorCodes.push(event.code);
    if (diagnosticOutput) diagnosticOutput.textContent = errorCodes.join(',');
  });
  onCleanup(() => { captureFieldDiagnostics = false; stopDiagnostics?.(); });
  const model = constructItem('browser.platform-proofs', item => ({
    checked: item.observe('checked', checked), disabledChecked: item.observe('disabledChecked', disabledChecked),
    text: item.observe('text', text), action: item.constant('action', {}), choice: item.observe('choice', choice),
  }));
  const commit = () => { fieldHandle?.blur(); };
  const cancel = () => { cancelBlur = true; fieldHandle?.blur(); };
  const effectBlur = () => { setFocusRequest('blur'); };
  createEffect(focusRequest, request => {
    if (request === 'focus') fieldHandle?.focus();
    else if (request === 'blur') fieldHandle?.blur();
  });
  return <section id="platform-proofs" class="catalogue-section catalogue-platform">
    <h2>Native platform contracts</h2>
    <div class="catalogue-row">
      <label id="platform-toggle-label" for="platform-external-toggle">Publish automatically</label>
      <Toggle.View id="platform-external-toggle" observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Internal publication control" labelHidden aria-labelledby="platform-toggle-label" aria-describedby="platform-toggle-description"
        onCheckedChange={value => { setChecked(value); setWrites(count => count + 1); }} />
      <label id="platform-disabled-label" for="platform-disabled-toggle">Unavailable publication</label>
      <Toggle.View id="platform-disabled-toggle" observable={model.disabledChecked} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Internal unavailable control" labelHidden disabled aria-labelledby="platform-disabled-label" aria-describedby="platform-toggle-description"
        onCheckedChange={value => { setDisabledChecked(value); setDisabledWrites(count => count + 1); }} />
    </div>
    <p id="platform-toggle-description">Publish only when the workspace is ready.</p>
    <output id="platform-toggle-writes" class="catalogue-status">{writes()}:{disabledWrites()}</output>
    <TextField.View id="platform-focus-field" observable={model.text} surface={{ kind: 'inherit' }}
      hotkeys={[{ key: 'Enter', handler: commit }, { key: 'Escape', handler: cancel }, { key: 'F6', handler: effectBlur }]}
      recipe="inline" label="Description focus contract" onValueChange={setText}
      onValueCommit={() => setValueCommits(count => count + 1)}
      onHandle={handle => { fieldHandle = handle; }}
      onFocus={() => { setFocuses(count => count + 1); cancelBlur = false; }}
      onBlur={() => { setBlurs(count => count + 1); if (!cancelBlur) setCommits(count => count + 1); cancelBlur = false; }}
      end={<Button.View id="platform-field-end-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="ghost">Field end action</Button.View>} />
    <output id="platform-focus-counts" class="catalogue-status">{focuses()}:{blurs()}:{commits()}</output>
    <output id="platform-value-commits" class="catalogue-status">{valueCommits()}</output>
    <output id="platform-field-diagnostics" ref={element => { diagnosticOutput = element; }} class="catalogue-status" />
    <Button.View id="platform-effect-focus" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" onActivate={() => { captureFieldDiagnostics = true; setFocusRequest('focus'); }}>Focus from effect apply</Button.View>
    <Button.View id="platform-outside-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline">Outside action</Button.View>
    <p id="platform-choice-description">Choose the scope of this action.</p>
    <ChoiceGroup.View observable={model.choice} surface={{ kind: 'inherit' }} hotkeys={[]}
      label="Externally described mode" aria-describedby="platform-choice-description"
      options={[{ value: 'one', label: 'One record' }, { value: 'two', label: 'Two records' }]} onValueChange={setChoice} />
  </section>;
}

render(() => <UiRootImplementation host={host} implementation={implementation}><Catalogue /><PlatformProofs /></UiRootImplementation>, host);
