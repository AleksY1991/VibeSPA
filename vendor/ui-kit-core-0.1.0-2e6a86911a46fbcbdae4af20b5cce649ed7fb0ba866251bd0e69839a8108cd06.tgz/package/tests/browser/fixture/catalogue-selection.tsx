/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { constructItem } from '../../../src/infrastructure/construction';
import type { TabsState } from '../../../src/contracts/tabs';
import { Checkbox } from '../../../src/solid/checkbox';
import { ChoiceGroup, Toggle } from '../../../src/solid/controls';
import { TabPanel, Tabs } from '../../../src/solid/tabs';

type Section = 'overview' | 'details' | 'locked';

const tabOptions = [
  { value: 'overview', label: 'Overview', id: 'catalogue-tab-overview', panelId: 'catalogue-panel-overview' },
  { value: 'details', label: 'Details', id: 'catalogue-tab-details', panelId: 'catalogue-panel-details' },
  { value: 'locked', label: 'Unavailable', id: 'catalogue-tab-locked', panelId: 'catalogue-panel-locked', disabled: true },
] as const;

export function SelectionSamples() {
  const [unchecked, setUnchecked] = createSignal(false);
  const [checked, setChecked] = createSignal(true);
  const [mixed, setMixed] = createSignal(false);
  const [indeterminate, setIndeterminate] = createSignal(true);
  const [toggleOff, setToggleOff] = createSignal(false);
  const [toggleOn, setToggleOn] = createSignal(true);
  const [choice, setChoice] = createSignal<Section>('overview');
  const [tab, setTab] = createSignal<Section>('overview');
  const [verticalTab, setVerticalTab] = createSignal<Section>('overview');
  const verticalOptions = [
    { value: 'overview', label: 'Summary', id: 'catalogue-vertical-summary', panelId: 'catalogue-vertical-panel-summary' },
    { value: 'details', label: 'Activity', id: 'catalogue-vertical-activity', panelId: 'catalogue-vertical-panel-activity' },
  ] as const;
  const model = constructItem('browser.catalogue.selection', item => ({
    unchecked: item.observe('unchecked', unchecked),
    checked: item.observe('checked', checked),
    mixed: item.observe('mixed', mixed),
    disabled: item.constant('disabled', true),
    toggleOff: item.observe('toggleOff', toggleOff),
    toggleOn: item.observe('toggleOn', toggleOn),
    choice: item.observe('choice', choice),
    disabledChoice: item.constant<Section>('disabledChoice', 'overview'),
    tabs: item.observe<TabsState<Section>>('tabs', () => ({ value: tab(), tabs: tabOptions })),
    overviewPanel: item.observe('overviewPanel', () => tab() === 'overview'),
    detailsPanel: item.observe('detailsPanel', () => tab() === 'details'),
    verticalTabs: item.observe<TabsState<Section>>('verticalTabs', () => ({ value: verticalTab(), tabs: verticalOptions })),
    summaryPanel: item.observe('summaryPanel', () => verticalTab() === 'overview'),
    activityPanel: item.observe('activityPanel', () => verticalTab() === 'details'),
  }));
  return <section id="catalogue-selection" class="catalogue-section">
    <h2>Selection controls</h2>
    <div class="catalogue-row">
      <Checkbox.View id="catalogue-checkbox-unchecked" observable={model.unchecked} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Unchecked checkbox" onCheckedChange={setUnchecked} />
      <Checkbox.View id="catalogue-checkbox-checked" observable={model.checked} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Checked checkbox" onCheckedChange={setChecked} />
      <Checkbox.View id="catalogue-checkbox-mixed" observable={model.mixed} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Mixed checkbox" indeterminate={indeterminate()} onCheckedChange={value => { setMixed(value); setIndeterminate(false); }} />
      <Checkbox.View id="catalogue-checkbox-disabled" observable={model.disabled} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Disabled checkbox" disabled onCheckedChange={() => {}} />
    </div>
    <div class="catalogue-row">
      <Toggle.View id="catalogue-toggle-off" observable={model.toggleOff} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Off switch" onCheckedChange={setToggleOff} />
      <Toggle.View id="catalogue-toggle-on" observable={model.toggleOn} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="On switch" onCheckedChange={setToggleOn} />
      <Toggle.View id="catalogue-toggle-readonly" observable={model.disabled} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Read-only switch" aria-disabled="true" onCheckedChange={() => {}} />
      <Toggle.View id="catalogue-toggle-disabled" observable={model.disabled} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Disabled switch" disabled onCheckedChange={() => {}} />
    </div>
    <div id="catalogue-choice" class="catalogue-row">
      <ChoiceGroup.View observable={model.choice} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="View mode" size="dense" options={[
          { value: 'overview', label: 'Overview' }, { value: 'details', label: 'Details' },
          { value: 'locked', label: 'Unavailable', disabled: true },
        ]} onValueChange={setChoice} />
      <ChoiceGroup.View observable={model.disabledChoice} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Disabled mode" size="dense" disabled options={[
          { value: 'overview', label: 'Overview' }, { value: 'details', label: 'Details' },
        ]} onValueChange={() => {}} />
    </div>
    <div id="catalogue-tabs">
      <Tabs.View observable={model.tabs} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Document sections" size="dense" onValueChange={setTab} />
      <TabPanel.View observable={model.overviewPanel} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="catalogue-panel-overview" tabId="catalogue-tab-overview" value="overview">Overview panel content</TabPanel.View>
      <TabPanel.View observable={model.detailsPanel} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="catalogue-panel-details" tabId="catalogue-tab-details" value="details">Details panel content</TabPanel.View>
    </div>
    <div id="catalogue-vertical-tabs">
      <Tabs.View observable={model.verticalTabs} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Vertical sections" size="dense" orientation="vertical" onValueChange={setVerticalTab} />
      <TabPanel.View observable={model.summaryPanel} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="catalogue-vertical-panel-summary" tabId="catalogue-vertical-summary" value="overview">Summary panel content</TabPanel.View>
      <TabPanel.View observable={model.activityPanel} surface={{ kind: 'inherit' }} hotkeys={[]}
        id="catalogue-vertical-panel-activity" tabId="catalogue-vertical-activity" value="details">Activity panel content</TabPanel.View>
    </div>
    <output id="catalogue-selection-values">{`${unchecked()}:${checked()}:${mixed()}:${indeterminate()}:${toggleOff()}:${toggleOn()}:${choice()}:${tab()}:${verticalTab()}`}</output>
  </section>;
}
