/** @jsxImportSource @solidjs/web */
import { render } from '@solidjs/web';
import { prepareAppImplementation } from '../../../src/bootstrap';
import { UiRootImplementation } from '../../../src/infrastructure/renderUiRoot';
import { configureSurfacePlatform } from '../../../src/runtime/platform';
import { TaskFocusExample } from '../../../examples/consumer/task-focus';
import { attachDispatcher, surfaceRegistry } from '../../surface-host';
import '../../../src/theme.css';
import './task-focus.css';

configureSurfacePlatform(surfaceRegistry.platform);
attachDispatcher({ window, document, registry: surfaceRegistry });
const implementation = await prepareAppImplementation();
const host = document.getElementById('app')!;
const dispose = render(() => <UiRootImplementation host={host} implementation={implementation}><TaskFocusExample /></UiRootImplementation>, host);

window.addEventListener('pagehide', dispose, { once: true });
