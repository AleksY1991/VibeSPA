/** @jsxImportSource @solidjs/web */
import { createRoot, createSignal, onCleanup, Show } from 'solid-js';
import { render } from '@solidjs/web';
import { controlPreparation, prepareAppImplementation } from '../../../src/bootstrap';
import type { ControlSize } from '../../../src/control-size';
import { constructItem } from '../../../src/infrastructure/construction';
import { UiRootImplementation } from '../../../src/infrastructure/renderUiRoot';
import { configureSurfacePlatform } from '../../../src/runtime/platform';
import { Button, type ButtonProps } from '../../../src/solid/button';
import { Dialog, type DialogRecipe } from '../../../src/solid/dialog';
import { Popover } from '../../../src/solid/popover';
import { TextField } from '../../../src/solid/text-field';
import { Textarea } from '../../../src/solid/textarea';
import { Select } from '../../../src/solid/select';
import { Spinner } from '../../../src/solid/spinner';
import type { TextareaRecipe, TextFieldRecipe } from '../../../src/contracts/field-presentation';
import { HOTKEY_PASS } from '../../../src/contracts/platform';
import { attachDispatcher, surfaceRegistry } from '../../surface-host';
import '../../../src/theme.css';
import './fixture.css';

configureSurfacePlatform(surfaceRegistry.platform);
attachDispatcher({ window, document, registry: surfaceRegistry });
const implementation = await prepareAppImplementation();
const host = document.getElementById('app')!;

function ControlSamples(props: { readonly size: ControlSize }) {
  const [value, setValue] = createSignal(`${props.size} value`);
  const model = constructItem(`browser.samples.${props.size}`, item => ({
    action: item.constant('action', {}),
    selected: item.constant('selected', { pressed: true }),
    disabled: item.constant('disabled', { disabled: true }),
    text: item.observe('text', value),
  }));
  return <section class="sample-row" data-sample-size={props.size}>
    <h2>{props.size}</h2>
    <div class="sample-buttons">
      <Button.View id={`button-${props.size}`} observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        size={props.size} variant="default">Action</Button.View>
      <Button.View id={`selected-${props.size}`} observable={model.selected} surface={{ kind: 'inherit' }} hotkeys={[]}
        size={props.size} variant="ghost" aria-label={`Selected ${props.size}`}>Selected</Button.View>
      <Button.View id={`disabled-${props.size}`} observable={model.disabled} surface={{ kind: 'inherit' }} hotkeys={[]}
        size={props.size} variant="outline">Disabled</Button.View>
    </div>
    <div class="sample-field">
      <TextField.View id={`field-${props.size}`} observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]}
        label={`${props.size} field`} size={props.size} onValueChange={setValue} />
      <output id={`field-value-${props.size}`} class="field-value">{value()}</output>
    </div>
  </section>;
}

function RecipeField(props: { readonly recipe: TextFieldRecipe }) {
  const [value, setValue] = createSignal(`${props.recipe} value`);
  const model = constructItem(`browser.field-recipe.${props.recipe}`, item => item.observe('text', value));
  return <div class="recipe-field">
    <span>{props.recipe}</span>
    <TextField.View id={`recipe-field-${props.recipe}`} observable={model} surface={{ kind: 'inherit' }} hotkeys={[]}
      recipe={props.recipe} label={`${props.recipe} recipe`} onValueChange={setValue} />
  </div>;
}

function RecipeSamples() {
  const [activations, setActivations] = createSignal(0);
  const [navigationSelected, setNavigationSelected] = createSignal(true);
  const [composer, setComposer] = createSignal('Composer draft\nSecond line');
  const [choice, setChoice] = createSignal('one');
  const model = constructItem('browser.recipe-catalog', item => ({
    action: item.constant('action', {}), selected: item.constant('selected', { pressed: true }),
    text: item.constant('text', 'Read-only value'), disabled: item.constant('disabled', 'Disabled value'),
    composer: item.observe('composer', composer), choice: item.observe('choice', choice),
  }));
  return <section class="fixture-section">
    <div id="recipe-catalog">
      <h2>Closed presentation recipes</h2>
      <div class="recipe-columns">
        <div class="recipe-button-list">
          <div class="recipe-labelled"><span>button</span><Button.View id="recipe-button" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}>Ordinary action</Button.View></div>
          <div class="recipe-labelled"><span>content</span><div class="recipe-content-slot"><Button.View id="recipe-content" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="content" variant="outline" size="compact" placement={{ width: '100%' }}>Choose a document with a deliberately long filename</Button.View></div></div>
          <div class="recipe-labelled"><span>menu-item</span><div class="recipe-row"><Button.View id="recipe-menu" observable={model.selected} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="menu-item" size="compact" start={<span id="menu-start" aria-hidden="true">A</span>}
            end={<span id="menu-end" aria-hidden="true">Ctrl+M</span>}>Menu action</Button.View></div></div>
          <div class="recipe-labelled"><span>navigation</span><div class="recipe-row"><Button.View id="recipe-navigation" observable={model.action} surface={{ kind: 'inherit' }}
            hotkeys={[{ key: 'F10', handler: () => setNavigationSelected(selected => !selected) }]}
            recipe="navigation" size="compact" aria-current={navigationSelected() ? 'page' : undefined}>Current destination</Button.View></div></div>
          <div class="recipe-labelled"><span>navigation · dense</span><div class="recipe-row"><Button.View id="recipe-dense-navigation" observable={model.action} surface={{ kind: 'inherit' }}
            hotkeys={[{ key: 'F10', handler: () => setNavigationSelected(selected => !selected) }]}
            recipe="navigation" size="dense" aria-current={navigationSelected() ? 'page' : undefined}>Dense destination</Button.View></div></div>
          <div class="recipe-labelled"><span>inline-action</span><p class="recipe-inline-context">Text before <Button.View id="recipe-inline" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="inline-action" aria-label="Inline action" start={<span id="inline-decoration" aria-hidden="true">Before </span>}
            onActivate={() => setActivations(count => count + 1)}>inline action</Button.View> text after.</p></div>
        </div>
        <div class="recipe-field-list">
          <RecipeField recipe="form" /><RecipeField recipe="inline" /><RecipeField recipe="filled" /><RecipeField recipe="code" />
          <TextField.View id="recipe-readonly" observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]}
            label="Read-only field" readonly onValueChange={() => {}} />
          <TextField.View id="recipe-disabled" observable={model.disabled} surface={{ kind: 'inherit' }} hotkeys={[]}
            label="Disabled field" disabled onValueChange={() => {}} />
          <Select.View id="recipe-select" observable={model.choice} surface={{ kind: 'inherit' }} hotkeys={[]}
            label="Form select" options={[{ value: 'one', label: 'First choice' }, { value: 'two', label: 'Second choice' }]} onValueChange={setChoice} />
        </div>
      </div>
      <Textarea.View id="recipe-composer" observable={model.composer} surface={{ kind: 'inherit' }} hotkeys={[]}
        recipe="composer" label="Composer" rows={2} resize="auto" minHeight={64} maxHeight={160} onValueChange={setComposer} />
    </div>
    <output id="inline-activations">{activations()}</output>
  </section>;
}

function RecipeLifetimeSamples() {
  const [recipe, setRecipe] = createSignal<'button' | 'menu-item' | 'navigation' | 'inline-action'>('button');
  const [fieldRecipe, setFieldRecipe] = createSignal<TextFieldRecipe>('form');
  const [textareaRecipe, setTextareaRecipe] = createSignal<TextareaRecipe>('form');
  const [value, setValue] = createSignal('Draft across field recipes');
  const [textareaValue, setTextareaValue] = createSignal('Draft across textarea recipes\nSecond line');
  const [mounts, setMounts] = createSignal(0, { ownedWrite: true });
  const [cleanups, setCleanups] = createSignal(0, { ownedWrite: true });
  const [rejected, setRejected] = createSignal('');
  const model = constructItem('browser.recipe-lifetime', item => ({
    action: item.constant('action', {}), value: item.observe('value', value), textareaValue: item.observe('textareaValue', textareaValue),
  }));
  function Label() {
    setMounts(count => count + 1);
    onCleanup(() => setCleanups(count => count + 1));
    return <span id="recipe-live-label">Same label owner</span>;
  }
  const nextButton = () => {
    const recipes = ['button', 'menu-item', 'navigation', 'inline-action'] as const;
    setRecipe(recipes[(recipes.indexOf(recipe()) + 1) % recipes.length]);
  };
  const nextField = () => {
    const recipes = ['form', 'inline', 'filled', 'code'] as const;
    setFieldRecipe(recipes[(recipes.indexOf(fieldRecipe()) + 1) % recipes.length]);
  };
  const nextTextarea = () => {
    const recipes = ['form', 'inline', 'filled', 'code', 'composer'] as const;
    setTextareaRecipe(recipes[(recipes.indexOf(textareaRecipe()) + 1) % recipes.length]);
  };
  const rejectRetired = () => {
    const result = createRoot(dispose => {
      try {
        new Button({ observable: model.action, surface: { kind: 'inherit' }, hotkeys: [], 'style:color': 'red' } as unknown as ButtonProps);
        return 'unexpectedly accepted';
      } catch (error) { return error instanceof Error ? error.message : String(error); }
      finally { dispose(); }
    });
    setRejected(result);
  };
  return <section id="recipe-lifetime" class="fixture-section">
    <h2>Recipe owner identity</h2>
    <div class="recipe-row"><Button.View id="recipe-live-button" observable={model.action} surface={{ kind: 'inherit' }}
      hotkeys={[{ key: 'F7', handler: nextButton }]} recipe={recipe()}><Label /></Button.View></div>
    <TextField.View id="recipe-live-field" observable={model.value} surface={{ kind: 'inherit' }} hotkeys={[{ key: 'F8', handler: nextField }]}
      recipe={fieldRecipe()} label="Live recipe field" onValueChange={setValue} />
    <Textarea.View id="recipe-live-textarea" observable={model.textareaValue} surface={{ kind: 'inherit' }} hotkeys={[{ key: 'F9', handler: nextTextarea }]}
      recipe={textareaRecipe()} label="Live recipe textarea" rows={2} resize="none" onValueChange={setTextareaValue} />
    <output id="live-button-recipe">{recipe()}</output><output id="live-field-recipe">{fieldRecipe()}</output>
    <output id="live-textarea-recipe">{textareaRecipe()}</output>
    <output id="label-mounts">{mounts()}</output><output id="label-cleanups">{cleanups()}</output>
    <Button.View id="reject-retired" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
      variant="outline" onActivate={rejectRetired}>Reject retired JavaScript props</Button.View>
    <output id="retired-result">{rejected()}</output>
  </section>;
}

function Fixture() {
  const [open, setOpen] = createSignal(false);
  const [modal, setModal] = createSignal(true);
  const [ready, setReady] = createSignal(true);
  const [nested, setNested] = createSignal(false);
  const [dialogRecipe, setDialogRecipe] = createSignal<DialogRecipe>('dialog');
  const [recipeMode, setRecipeMode] = createSignal(false);
  const [background, setBackground] = createSignal(0);
  const [submission, setSubmission] = createSignal('No submission');
  const [submissionCount, setSubmissionCount] = createSignal(0);
  const [text, setText] = createSignal('Dialog value');
  const [documentText, setDocumentText] = createSignal(Array.from({ length: 24 }, (_, index) => `Document line ${index + 1}`).join('\n'));
  const [mountCount, setMountCount] = createSignal(0, { ownedWrite: true });
  const [cleanupCount, setCleanupCount] = createSignal(0, { ownedWrite: true });
  const model = constructItem('browser.fixture', item => ({
    action: item.constant('action', {}),
    open: item.observe('open', open),
    nested: item.observe('nested', nested),
    text: item.observe('text', text),
    document: item.observe('document', documentText),
    busy: item.constant('busy', true),
  }));
  let preferred: HTMLInputElement | undefined;
  let readyTimer: ReturnType<typeof setTimeout> | undefined;
  const showDialog = (delayed: boolean) => {
    clearTimeout(readyTimer);
    setModal(true);
    setDialogRecipe('dialog');
    setRecipeMode(false);
    setReady(!delayed);
    setOpen(true);
    if (delayed) readyTimer = setTimeout(() => setReady(true), 700);
  };
  const showRecipeDialog = () => {
    setModal(true); setReady(true); setDialogRecipe('dialog'); setRecipeMode(true); setOpen(true);
  };
  const nextDialogRecipe = () => {
    if (!recipeMode()) return HOTKEY_PASS;
    const recipes = ['dialog', 'editor', 'fullscreen', 'detached'] as const;
    setDialogRecipe(recipes[(recipes.indexOf(dialogRecipe()) + 1) % recipes.length]);
  };
  onCleanup(() => clearTimeout(readyTimer));

  function RetainedDraft() {
    setMountCount(count => count + 1);
    onCleanup(() => setCleanupCount(count => count + 1));
    return <label class="fixture-field">Retained draft<input id="retained-draft" aria-label="Retained draft" value="Unsaved draft" /></label>;
  }

  return <>
    <section id="catalog" aria-label="Canonical control appearance">
      <h1>Canonical controls</h1>
      <ControlSamples size="dense" />
      <ControlSamples size="compact" />
      <ControlSamples size="standard" />
      <ControlSamples size="large" />
    </section>
    <section class="fixture-section" aria-label="Browser form association">
      <h2>External form association</h2>
      <form id="external-form" onSubmit={event => {
        event.preventDefault();
        const submitter = event.submitter as HTMLButtonElement;
        setSubmission(`${submitter.id}:${new FormData(event.currentTarget, submitter).get('intent')}`);
        setSubmissionCount(count => count + 1);
      }}>
        <label class="fixture-field">Form draft<input id="form-draft" name="draft" value="saved" ref={element => { element.defaultValue = 'saved'; }} /></label>
      </form>
      <div class="fixture-actions">
        <Button.View id="submit-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          type="submit" form="external-form" name="intent" value="publish" aria-controls="external-form" aria-describedby="form-description">Submit external form</Button.View>
        <Button.View id="reset-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="outline" type="reset" form="external-form">Reset external form</Button.View>
      </div>
      <p id="form-description">Browser-owned form submission and reset.</p>
      <output id="submission" data-count={submissionCount()}>{submission()}</output>
    </section>
    <section class="fixture-section" aria-label="Dialog browser behavior">
      <h2>Dialog ownership</h2>
      <div class="fixture-actions">
        <Button.View id="open-dialog" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          onActivate={() => showDialog(false)}>Open dialog</Button.View>
        <Button.View id="open-delayed" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="outline" onActivate={() => showDialog(true)}>Open delayed dialog</Button.View>
        <Button.View id="background-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="ghost" onActivate={() => setBackground(count => count + 1)}>Background action</Button.View>
        <Button.View id="open-recipe-dialog" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="outline" onActivate={showRecipeDialog}>Open recipe dialog</Button.View>
      </div>
      <div class="fixture-diagnostics">
        <output id="background-count">{background()}</output>
        <output id="mount-count">{mountCount()}</output>
        <output id="cleanup-count">{cleanupCount()}</output>
        <output id="dialog-mode">{modal() ? 'modal' : 'pinned'}</output>
      </div>
    </section>
    <section id="family-isolation" class="fixture-section" aria-label="Control preparation isolation">
      <h2>Independent control preparation</h2>
      <Spinner.View observable={model.busy} surface={{ kind: 'inherit' }} hotkeys={[]} label="Isolated spinner" size="sm" />
      <output id="spinner-state">{controlPreparation(implementation, 'Spinner').status}</output>
      <Button.View id="retry-preparation" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => { void prepareAppImplementation(); }}>Retry control preparation</Button.View>
    </section>
    <RecipeSamples />
    <RecipeLifetimeSamples />
    <Dialog.View id="browser-dialog" observable={model.open}
      surface={{ kind: 'own', name: 'browser.dialog', transparent: false, layer: true }} hotkeys={[{ key: 'F6', handler: nextDialogRecipe }]}
      recipe={dialogRecipe()}
      label="Browser dialog" contentLifetime="owner" modal={modal()} onOpenChange={setOpen}
      initialFocus={() => ready() ? preferred : undefined}>
      <label class="fixture-field">First field<input id="first-field" aria-label="First field" value="First" /></label>
      <label class="fixture-field">Preferred field<input id="preferred-field" aria-label="Preferred field" value="Preferred"
        ref={element => { preferred = element; }} data-ui-ready={ready() ? 'true' : 'false'} /></label>
      <RetainedDraft />
      <TextField.View id="dialog-vendor-field" observable={model.text} surface={{ kind: 'inherit' }} hotkeys={[]}
        label="Dialog vendor field" onValueChange={setText} />
      <Button.View id="toggle-modal" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setModal(value => !value)}>Toggle modal or pinned</Button.View>
      <Button.View id="close-dialog" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setOpen(false)}>Close dialog</Button.View>
      <Popover.View observable={model.nested}
        surface={{ kind: 'own', name: 'browser.dialog.nested', transparent: false, layer: true }} hotkeys={[]}
        aria-label="Nested choices" onOpenChange={setNested}
        trigger={api => <Button.View id="open-nested" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="ghost" onActivate={api.toggle}>Open nested choices</Button.View>}>
        {api => <Button.View id="nested-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          onActivate={api.close}>Choose nested action</Button.View>}
      </Popover.View>
      <Show when={recipeMode()}>
        <Textarea.View id="recipe-dialog-document" observable={model.document} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="code" fillHeight rows={6} resize="none" label="Recipe document" onValueChange={setDocumentText} />
        <output id="live-dialog-recipe">{dialogRecipe()}</output>
      </Show>
    </Dialog.View>
  </>;
}

render(() => <UiRootImplementation host={host} implementation={implementation}><Fixture /></UiRootImplementation>, host);
