/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { render } from '@solidjs/web';
import { prepareAppImplementation } from '../../../src/bootstrap';
import type { TextareaRecipe, TextFieldRecipe } from '../../../src/contracts/field-presentation';
import { CheckIcon, XIcon } from '../../../src/icons';
import { constructItem } from '../../../src/infrastructure/construction';
import { UiRootImplementation } from '../../../src/infrastructure/renderUiRoot';
import { configureSurfacePlatform } from '../../../src/runtime/platform';
import { Button } from '../../../src/solid/button';
import { Select } from '../../../src/solid/select';
import { TextField } from '../../../src/solid/text-field';
import { Textarea } from '../../../src/solid/textarea';
import { attachDispatcher, surfaceRegistry } from '../../surface-host';
import { ConsumerDialogSamples } from './catalogue-dialog-recipes';
import '../../../src/theme.css';
import './catalogue.css';

configureSurfacePlatform(surfaceRegistry.platform);
attachDispatcher({ window, document, registry: surfaceRegistry });
const implementation = await prepareAppImplementation();
const host = document.getElementById('app')!;

function ConsumerActionSamples() {
  const [overlayCount, setOverlayCount] = createSignal(0);
  const model = constructItem('browser.consumer-recipes.actions', item => ({
    action: item.constant('action', {}), selected: item.constant('selected', { pressed: true }),
  }));
  return <section class="catalogue-section">
    <h1>Consumer-derived action roles</h1>
    <div class="catalogue-grid">
      <div class="catalogue-stack">
        <h2>Cells and property rows</h2>
        <Button.View id="consumer-cell-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="cell-action" size="compact">Open a disclosure cell</Button.View>
        <Button.View id="consumer-property-row" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="property-row" size="compact"><span class="consumer-property-label"><strong>Owner</strong><span>Current workspace member</span></span></Button.View>
        <div class="catalogue-row">
          <Button.View id="consumer-selection-cell" observable={model.selected} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="selection-cell" size="compact"><span class="consumer-selection-value">12</span></Button.View>
          <Button.View id="consumer-selection-icon" observable={model.selected} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="selection-cell" shape="icon" size="compact" aria-label="Selected option"><CheckIcon /></Button.View>
        </div>
      </div>
      <div class="catalogue-stack">
        <h2>Content and overlay actions</h2>
        <Button.View id="consumer-action-row" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="action-row" variant="outline" size="compact"><span class="consumer-property-label"><strong>Rich action row</strong><span>Secondary content remains inside the same action.</span></span></Button.View>
        <div class="consumer-fill-slot"><Button.View id="consumer-fill-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="fill-action">Bounded chart cell</Button.View></div>
        <div class="consumer-overlay-context">
          <span>Attachment preview</span>
          <Button.View id="consumer-overlay-action" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="overlay-action" size="compact" aria-label="Remove attachment preview"
            placement={{ position: 'absolute', right: '0px', top: '0px' }} onActivate={() => setOverlayCount(count => count + 1)}><XIcon /></Button.View>
        </div>
        <output id="consumer-overlay-count" class="catalogue-status">{overlayCount()}</output>
      </div>
    </div>
  </section>;
}

function ConsumerFieldSamples() {
  const [search, setSearch] = createSignal('Search with a separate clear action');
  const [entry, setEntry] = createSignal('A large text entry');
  const [title, setTitle] = createSignal('Editable document heading');
  const [reading, setReading] = createSignal('Long-form reading and editing\nRetains a normal text weight');
  const [composer, setComposer] = createSignal('Compact conversation message');
  const [choice, setChoice] = createSignal('one');
  const [fieldRecipe, setFieldRecipe] = createSignal<TextFieldRecipe>('form');
  const [areaRecipe, setAreaRecipe] = createSignal<TextareaRecipe>('form');
  const [draft, setDraft] = createSignal('Draft across consumer field recipes');
  const model = constructItem('browser.consumer-recipes.fields', item => ({
    action: item.constant('action', {}),
    search: item.observe('search', search), entry: item.observe('entry', entry), title: item.observe('title', title),
    reading: item.observe('reading', reading), composer: item.observe('composer', composer), choice: item.observe('choice', choice),
    draft: item.observe('draft', draft),
  }));
  const nextField = () => {
    const recipes = ['form', 'entry', 'title', 'search-action'] as const;
    setFieldRecipe(recipes[(recipes.indexOf(fieldRecipe() as typeof recipes[number]) + 1) % recipes.length]);
  };
  const nextArea = () => {
    const recipes = ['form', 'entry', 'reading', 'compact-composer', 'composer'] as const;
    setAreaRecipe(recipes[(recipes.indexOf(areaRecipe() as typeof recipes[number]) + 1) % recipes.length]);
  };
  return <>
    <section id="consumer-field-catalogue" class="catalogue-section">
      <h1>Consumer-derived field roles</h1>
      <div class="catalogue-grid">
        <div class="catalogue-stack">
          <h2>Entry and heading</h2>
          <TextField.View id="consumer-field-entry" observable={model.entry} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="entry" size="compact" label="Large text entry" onValueChange={setEntry} />
          <TextField.View id="consumer-field-title" observable={model.title} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="title" size="compact" label="Editable heading" onValueChange={setTitle} />
          <Select.View id="consumer-select-entry" observable={model.choice} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="entry" size="compact" label="Large text choice" options={[{ value: 'one', label: 'First choice' }, { value: 'two', label: 'Second choice' }]} onValueChange={setChoice} />
          <h2>Search with clear action</h2>
          <div class="consumer-search-row">
            <TextField.View id="consumer-field-search" observable={model.search} surface={{ kind: 'inherit' }} hotkeys={[]}
              recipe="search-action" size="compact" label="Search records" onValueChange={setSearch} />
            <Button.View id="consumer-clear-search" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
              shape="icon" variant="ghost" size="compact" aria-label="Clear search text"
              placement={{ position: 'absolute', right: '4px', top: '0px' }} onActivate={() => setSearch('')}><XIcon /></Button.View>
          </div>
        </div>
        <div class="catalogue-stack">
          <h2>Reading and conversation</h2>
          <Textarea.View id="consumer-area-reading" observable={model.reading} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="reading" size="compact" label="Long-form document" rows={2} resize="none" onValueChange={setReading} />
          <Textarea.View id="consumer-area-entry" observable={model.entry} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="entry" size="compact" label="Large multiline entry" rows={1} resize="none" onValueChange={setEntry} />
          <Textarea.View id="consumer-area-compact" observable={model.composer} surface={{ kind: 'inherit' }} hotkeys={[]}
            recipe="compact-composer" size="compact" label="Compact conversation composer" rows={1} resize="auto" onValueChange={setComposer} />
        </div>
      </div>
    </section>
    <section class="catalogue-section" aria-label="Consumer recipe identity checks">
      <h2>Retained editing owners</h2>
      <TextField.View id="consumer-live-field" observable={model.draft} surface={{ kind: 'inherit' }}
        hotkeys={[{ key: 'F9', handler: nextField }]} recipe={fieldRecipe()} label="Retained single-line draft" onValueChange={setDraft} />
      <output id="consumer-live-field-recipe" class="catalogue-status">{fieldRecipe()}</output>
      <Textarea.View id="consumer-live-area" observable={model.draft} surface={{ kind: 'inherit' }}
        hotkeys={[{ key: 'F10', handler: nextArea }]} recipe={areaRecipe()} label="Retained multiline draft" rows={2} resize="none" onValueChange={setDraft} />
      <output id="consumer-live-area-recipe" class="catalogue-status">{areaRecipe()}</output>
    </section>
  </>;
}

function ConsumerRecipes() {
  return <div id="consumer-recipe-catalogue"><div id="consumer-control-catalogue"><ConsumerActionSamples /><ConsumerFieldSamples /></div><ConsumerDialogSamples /></div>;
}

render(() => <UiRootImplementation host={host} implementation={implementation}><ConsumerRecipes /></UiRootImplementation>, host);
