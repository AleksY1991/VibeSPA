/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { constructItem } from '../../../src/infrastructure/construction';
import { Button } from '../../../src/solid/button';
import { Dialog, type DialogDrawerState } from '../../../src/solid/dialog';
import { TextField } from '../../../src/solid/text-field';

const preview = 'data:image/svg+xml,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="768" height="384" viewBox="0 0 768 384">'
  + '<rect width="768" height="384" fill="#e5e5e5"/>'
  + '<path d="M0 288 192 96 384 288 576 96 768 288v96H0Z" fill="#737373"/>'
  + '<rect x="24" y="24" width="168" height="40" fill="#fff"/>'
  + '<text x="40" y="50" font-family="sans-serif" font-size="18" fill="#000">Media preview</text></svg>',
);

export function ConsumerDialogSamples() {
  const [formOpen, setFormOpen] = createSignal(false);
  const [mediaOpen, setMediaOpen] = createSignal(false);
  const [drawerOpen, setDrawerOpen] = createSignal(false);
  const [formName, setFormName] = createSignal('New project');
  const [drawer, setDrawer] = createSignal<DialogDrawerState>({ width: 400, expanded: false });
  const model = constructItem('browser.catalogue.consumerDialogs', item => ({
    action: item.constant('action', {}),
    formOpen: item.observe('formOpen', formOpen),
    mediaOpen: item.observe('mediaOpen', mediaOpen),
    drawerOpen: item.observe('drawerOpen', drawerOpen),
    formName: item.observe('formName', formName),
    drawer: item.observe<DialogDrawerState>('drawer', drawer),
  }));
  let drawerDraft: HTMLInputElement | undefined;
  const resizeDrawer = () => { setDrawer(current => ({ ...current, width: current.width === 400 ? 520 : 400 })); };
  const expandDrawer = () => { setDrawer(current => ({ ...current, expanded: !current.expanded })); };

  return <section id="catalogue-consumer-dialogs" class="catalogue-section">
    <h2>Consumer dialog compositions</h2>
    <div class="catalogue-row">
      <Button.View id="catalogue-open-form" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setFormOpen(true)}>Open form</Button.View>
      <Button.View id="catalogue-open-media" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setMediaOpen(true)}>Open media</Button.View>
      <Button.View id="catalogue-open-drawer" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setDrawerOpen(true)}>Open drawer</Button.View>
    </div>

    <Dialog.View id="catalogue-dialog-form" observable={model.formOpen}
      surface={{ kind: 'own', name: 'catalogue.dialog.form', transparent: false, layer: true }} hotkeys={[]}
      recipe="form" label="Project form" contentLifetime="owner" onOpenChange={setFormOpen}>
      <form class="catalogue-native-form catalogue-card-content" onSubmit={event => { event.preventDefault(); setFormOpen(false); }}>
        <h2>Project form</h2>
        <TextField.View id="catalogue-dialog-form-name" observable={model.formName} surface={{ kind: 'inherit' }} hotkeys={[]}
          recipe="form" label="Project name" labelVisible onValueChange={setFormName} />
        <div class="catalogue-row">
          <Button.View id="catalogue-dialog-form-submit" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            type="submit" variant="default">Create project</Button.View>
          <Button.View id="catalogue-close-form" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            variant="outline" onActivate={() => setFormOpen(false)}>Cancel</Button.View>
        </div>
      </form>
    </Dialog.View>

    <Dialog.View id="catalogue-dialog-media" observable={model.mediaOpen}
      surface={{ kind: 'own', name: 'catalogue.dialog.media', transparent: false, layer: true }} hotkeys={[]}
      recipe="media" label="Media preview" contentLifetime="owner" onOpenChange={setMediaOpen}>
      <img id="catalogue-media-preview" src={preview} alt="Grayscale mountain illustration" width="768" height="384"
        style={{ width: '100%', height: 'auto', display: 'block' }} />
      <Button.View id="catalogue-close-media" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setMediaOpen(false)}>Close preview</Button.View>
    </Dialog.View>

    <Dialog.View id="catalogue-dialog-drawer" observable={model.drawerOpen}
      surface={{ kind: 'own', name: 'catalogue.dialog.drawer', transparent: false, layer: true }}
      hotkeys={[{ key: 'F7', handler: resizeDrawer }, { key: 'F8', handler: expandDrawer }]}
      recipe="drawer" drawer={model.drawer} label="Retained detail panel" contentLifetime="owner" onOpenChange={setDrawerOpen}
      initialFocus={() => drawerDraft}>
      <div class="catalogue-stack catalogue-card-content">
        <h2>Retained detail panel</h2>
        <label>Draft<input id="drawer-draft" aria-label="Drawer draft" value="Unsaved drawer draft"
          ref={element => { drawerDraft = element; }} /></label>
        <p>F7 changes the width; F8 expands the same panel.</p>
        <div class="catalogue-row">
          <Button.View id="catalogue-drawer-resize" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            variant="outline" onActivate={resizeDrawer}>Change width</Button.View>
          <Button.View id="catalogue-drawer-expand" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            variant="outline" onActivate={expandDrawer}>Toggle expanded</Button.View>
          <Button.View id="catalogue-close-drawer" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
            variant="outline" onActivate={() => setDrawerOpen(false)}>Close panel</Button.View>
        </div>
        <output id="catalogue-drawer-state">{`${drawer().width}:${drawer().expanded === true}`}</output>
      </div>
    </Dialog.View>
  </section>;
}
