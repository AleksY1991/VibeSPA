/** @jsxImportSource @solidjs/web */
import { Show, createSignal, onCleanup } from 'solid-js';
import { render } from '@solidjs/web';
import { prepareAppImplementation } from '../../../src/bootstrap';
import type { CardRecipe } from '../../../src/contracts/controls';
import { constructItem } from '../../../src/infrastructure/construction';
import { UiRootImplementation } from '../../../src/infrastructure/renderUiRoot';
import { configureSurfacePlatform } from '../../../src/runtime/platform';
import { Button } from '../../../src/solid/button';
import { Card } from '../../../src/solid/controls';
import { Popover, type PopoverRecipe } from '../../../src/solid/popover';
import { TabPanel } from '../../../src/solid/tabs';
import { attachDispatcher, surfaceRegistry } from '../../surface-host';
import '../../../src/theme.css';
import './catalogue.css';
import './surface-contracts.css';

configureSurfacePlatform(surfaceRegistry.platform);
attachDispatcher({ window, document, registry: surfaceRegistry });
const implementation = await prepareAppImplementation();
const host = document.getElementById('app')!;

function SurfaceContracts() {
  const [cardRecipe, setCardRecipe] = createSignal<CardRecipe>('plain');
  const [popoverRecipe, setPopoverRecipe] = createSignal<PopoverRecipe>('popover');
  const [open, setOpen] = createSignal(false);
  const [active, setActive] = createSignal(true);
  const [mounted, setMounted] = createSignal(true);
  const [keys, setKeys] = createSignal(0);
  const [cleanups, setCleanups] = createSignal(0);
  const model = constructItem('browser.surface-contracts', item => ({
    visible: item.constant('visible', true), action: item.constant('action', {}),
    open: item.observe('open', open), active: item.observe('active', active),
  }));
  const nextCard = () => {
    const recipes = ['plain', 'content', 'panel', 'popover', 'notice'] as const;
    setCardRecipe(recipes[(recipes.indexOf(cardRecipe()) + 1) % recipes.length]);
  };
  const nextPopover = () => {
    const recipes = ['popover', 'picker', 'content', 'form'] as const;
    setPopoverRecipe(recipes[(recipes.indexOf(popoverRecipe()) + 1) % recipes.length]);
  };
  function PanelDraft() {
    onCleanup(() => setCleanups(count => count + 1));
    return <input id="panel-draft" aria-label="Retained panel draft" value="Panel draft" />;
  }
  return <div id="surface-contracts" class="catalogue-section">
    <h1>Closed surface recipes</h1>
    <div id="card-recipes" class="surface-card-grid">
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} attributes={{ id: 'surface-card-plain' }}><p>Plain parent content</p></Card.View>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="content" attributes={{ id: 'surface-card-content' }}><p>Readable content surface</p></Card.View>
      <div class="surface-panel-slot"><Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="panel" attributes={{ id: 'surface-card-panel' }}><p>Bounded column panel</p><p>Content stays inside its parent.</p></Card.View></div>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="popover" attributes={{ id: 'surface-card-popover' }}><p>Self-contained popup content</p></Card.View>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="notice" tone="warning" attributes={{ id: 'surface-card-notice' }}><p>Warning notice</p></Card.View>
    </div>
    <section class="catalogue-section">
      <h2>Retained Card content</h2>
      <div class="surface-panel-slot"><Card.View observable={model.visible} surface={{ kind: 'inherit' }}
        hotkeys={[{ key: 'F7', handler: nextCard }]} recipe={cardRecipe()} attributes={{ id: 'live-card' }}>
        <input id="card-draft" aria-label="Retained card draft" value="Card draft" />
      </Card.View></div>
      <output id="card-recipe">{cardRecipe()}</output>
    </section>
    <section class="catalogue-section">
      <h2>Retained Popover content</h2>
      <Popover.View observable={model.open} surface={{ kind: 'own', name: 'browser.surface-contracts.popover', transparent: false, layer: true }}
        hotkeys={[{ key: 'F7', handler: nextPopover }]} recipe={popoverRecipe()} aria-label="Recipe popup" onOpenChange={setOpen}
        trigger={api => <Button.View id="surface-open-popover" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
          variant="outline" onActivate={api.toggle}>Edit popup draft</Button.View>}>
        {() => <><label for="popover-draft">Popup draft</label><input id="popover-draft" value="Popup draft" /><output id="popover-recipe">{popoverRecipe()}</output></>}
      </Popover.View>
    </section>
    <section class="catalogue-section">
      <h2>TabPanel update observation</h2>
      <Button.View id="toggle-panel" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setActive(value => !value)}>Toggle panel activity</Button.View>
      <Button.View id="unmount-panel" observable={model.action} surface={{ kind: 'inherit' }} hotkeys={[]}
        variant="outline" onActivate={() => setMounted(false)}>Dispose panel</Button.View>
      <Show when={mounted()}><TabPanel.View id="fault-panel" tabId="fault-tab" value="draft" observable={model.active}
        surface={{ kind: 'own', name: 'browser.surface-contracts.panel', transparent: true }}
        hotkeys={[{ key: 'F8', handler: () => setKeys(count => count + 1) }]}><PanelDraft /></TabPanel.View></Show>
      <output id="panel-keys">{keys()}</output><output id="panel-cleanups">{cleanups()}</output>
    </section>
  </div>;
}

render(() => <UiRootImplementation host={host} implementation={implementation}><SurfaceContracts /></UiRootImplementation>, host);
