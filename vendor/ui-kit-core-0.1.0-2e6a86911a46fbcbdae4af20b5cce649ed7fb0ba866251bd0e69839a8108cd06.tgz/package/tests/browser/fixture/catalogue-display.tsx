/** @jsxImportSource @solidjs/web */
import { createSignal } from 'solid-js';
import { constructItem } from '../../../src/infrastructure/construction';
import type { AvatarValue } from '../../../src/contracts/avatar';
import type { TagState } from '../../../src/contracts/tag';
import { Avatar } from '../../../src/solid/avatar';
import { Badge } from '../../../src/solid/badge';
import { Card } from '../../../src/solid/controls';
import { Image } from '../../../src/solid/image';
import { Media } from '../../../src/solid/media';
import { Divider } from '../../../src/solid/menu-separator';
import { ProgressBar } from '../../../src/solid/progress-bar';
import { Spinner } from '../../../src/solid/spinner';
import { Tag } from '../../../src/solid/tag';

const portrait = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" fill="#e5e5e5"/><circle cx="32" cy="24" r="10" fill="#555"/><path d="M12 60c0-14 8-22 20-22s20 8 20 22" fill="#555"/></svg>')}`;
const preview = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="240" height="120" viewBox="0 0 240 120"><rect width="240" height="120" fill="#e5e5e5"/><path d="m0 120 60-76 42 48 38-36 100 64" fill="#777"/><circle cx="185" cy="30" r="13" fill="#444"/></svg>')}`;

/** Distinct display appearances share one stable, network-free browser scene. */
export function DisplaySamples() {
  const [removals, setRemovals] = createSignal(0);
  const model = constructItem('browser.catalogue.display', item => ({
    neutral: item.constant('neutral', '12 items'),
    accent: item.constant('accent', 'New'),
    initials: item.constant<AvatarValue>('initials', { label: 'Alex Lane', initials: 'AL' }),
    photo: item.constant<AvatarValue>('photo', { label: 'Sam Reed', initials: 'SR', image: portrait }),
    symbol: item.constant<AvatarValue>('symbol', { label: 'Shared workspace', initials: 'SW', symbol: '◇' }),
    tag: item.constant<TagState>('tag', { label: 'Planning', removeLabel: 'Remove Planning filter' }),
    disabledTag: item.constant<TagState>('disabled-tag', { label: 'Required', removeLabel: 'Remove Required filter', disabled: true }),
    visible: item.constant('visible', true),
    progress: item.constant('progress', 62),
    complete: item.constant('complete', 100),
    warning: item.constant('warning', 37),
    danger: item.constant('danger', 83),
    busy: item.constant('busy', true),
    image: item.constant('image', { src: preview }),
    media: item.constant('media', { src: undefined }),
  }));
  return <>
    <section class="catalogue-section" id="display-identities">
      <h2>Badges, identities and tags</h2>
      <div class="catalogue-row" id="display-badges">
        <Badge.View observable={model.neutral} surface={{ kind: 'inherit' }} hotkeys={[]} tone="neutral" label="Item count" />
        <Badge.View observable={model.accent} surface={{ kind: 'inherit' }} hotkeys={[]} tone="accent" label="New status" />
      </div>
      <div class="catalogue-row" id="display-avatars">
        <Avatar.View observable={model.initials} surface={{ kind: 'inherit' }} hotkeys={[]} size="dense" />
        <Avatar.View observable={model.photo} surface={{ kind: 'inherit' }} hotkeys={[]} size="standard" />
        <Avatar.View observable={model.symbol} surface={{ kind: 'inherit' }} hotkeys={[]} size="large" appearance="icon" />
      </div>
      <div class="catalogue-row" id="display-tags">
        <Tag.View observable={model.tag} surface={{ kind: 'inherit' }} hotkeys={[]} onRemove={() => setRemovals(count => count + 1)} />
        <Tag.View observable={model.disabledTag} surface={{ kind: 'inherit' }} hotkeys={[]} onRemove={() => setRemovals(count => count + 1)} />
      </div>
      <output id="display-tag-removals">{removals()}</output>
      <div class="catalogue-menu-divider-slot"><Divider.View id="display-divider" observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} /></div>
      <p>Caption and divider retain their own semantic roles.</p>
    </section>

    <section class="catalogue-section" id="display-progress">
      <h2>Progress and busy state</h2>
      <div class="catalogue-progress-row">
        <span>Brand · 62 / 100</span>
        <ProgressBar.View observable={model.progress} surface={{ kind: 'inherit' }} hotkeys={[]} label="Upload progress" valueText="62 of 100 files" />
      </div>
      <div class="catalogue-progress-row">
        <span>Success · complete</span>
        <ProgressBar.View observable={model.complete} surface={{ kind: 'inherit' }} hotkeys={[]} label="Completed progress" variant="success" />
      </div>
      <div class="catalogue-progress-row">
        <span>Warning · 37 / 100</span>
        <ProgressBar.View observable={model.warning} surface={{ kind: 'inherit' }} hotkeys={[]} label="Warning progress" variant="warning" />
      </div>
      <div class="catalogue-progress-row">
        <span>Danger · 83 / 100</span>
        <ProgressBar.View observable={model.danger} surface={{ kind: 'inherit' }} hotkeys={[]} label="Danger progress" variant="danger" />
      </div>
      <div class="catalogue-row" id="display-spinners">
        <Spinner.View observable={model.busy} surface={{ kind: 'inherit' }} hotkeys={[]} size="sm" label="Small busy indicator" />
        <Spinner.View observable={model.busy} surface={{ kind: 'inherit' }} hotkeys={[]} size="md" label="Medium busy indicator" />
      </div>
    </section>

    <section class="catalogue-section" id="display-cards">
      <h2>Card surfaces</h2>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} attributes={{ id: 'card-plain' }}>
        <p>Plain content keeps its parent surface.</p>
      </Card.View>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="content" attributes={{ id: 'card-surface' }}>
        <p>Outlined surface</p>
      </Card.View>
      <Card.View observable={model.visible} surface={{ kind: 'inherit' }} hotkeys={[]} recipe="notice" tone="warning" attributes={{ id: 'card-warning' }}>
        <p>Warning surface</p>
      </Card.View>
    </section>

    <section class="catalogue-section" id="display-media">
      <h2>Native image and media</h2>
      <div class="catalogue-row">
        <Image.View id="display-image" observable={model.image} surface={{ kind: 'inherit' }} hotkeys={[]} alt="A grayscale landscape" width={120} height={60} />
        <Media.View id="display-video" observable={model.media} surface={{ kind: 'inherit' }} hotkeys={[]} kind="video" poster={preview} preload="none" width={120} height={60} aria-label="Landscape video preview" />
      </div>
      <p>Image alternative and media identity remain available without loading external resources.</p>
    </section>
  </>;
}
