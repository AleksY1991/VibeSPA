import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import solid from '@solidjs/vite-plugin';

const require = createRequire(import.meta.url);
const solidRoot = path.dirname(require.resolve('solid-js/package.json'));
const signalsRoot = path.dirname(createRequire(path.join(solidRoot, 'package.json')).resolve('@solidjs/signals/package.json'));
const webRoot = path.resolve(path.dirname(require.resolve('@solidjs/web')), '..');
const packageRoot = fileURLToPath(new URL('../..', import.meta.url));

export default {
  root: fileURLToPath(new URL('./fixture', import.meta.url)),
  css: { postcss: { plugins: [] } },
  plugins: [solid({
    include: /\.tsx$/,
    ssr: false,
    refresh: { disabled: true },
    babel: { presets: [['@babel/preset-typescript', { onlyRemoveTypeImports: true }]] },
  })],
  resolve: {
    dedupe: ['solid-js', '@solidjs/signals', '@solidjs/web'],
    alias: [
      { find: /^solid-js$/, replacement: path.join(solidRoot, 'dist/solid.dev.js') },
      { find: /^@solidjs\/signals$/, replacement: path.join(signalsRoot, 'dist/dev.js') },
      { find: /^@solidjs\/web(?:\/jsx(?:-dev)?-runtime)?$/, replacement: path.join(webRoot, 'dist/web.dev.js') },
    ],
  },
  server: {
    host: '127.0.0.1', port: 5191, strictPort: true, hmr: false,
    fs: { allow: [packageRoot] },
  },
};
