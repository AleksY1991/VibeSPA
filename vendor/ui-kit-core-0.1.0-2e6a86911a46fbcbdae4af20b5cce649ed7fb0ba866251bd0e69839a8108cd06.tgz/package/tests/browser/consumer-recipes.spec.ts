import { expect, test, type Page } from '@playwright/test';

const browserErrors = new WeakMap<Page, string[]>();

test.beforeEach(async ({ page }) => {
  const errors: string[] = [];
  browserErrors.set(page, errors);
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/consumer-recipes.html');
  await expect(page.locator('#consumer-control-catalogue')).toBeVisible();
  await expect(page.locator('[data-ui-control-unavailable]')).toHaveCount(0);
  await expect(page.locator('[data-ui-ready="false"]')).toHaveCount(0);
  await expect(page.locator('[data-ui-error]')).toHaveCount(0);
  await page.evaluate(async () => { await document.fonts.ready; });
});

test.afterEach(async ({ page }) => {
  expect(browserErrors.get(page), 'browser runtime errors').toEqual([]);
});

test('consumer action and field recipes own distinct desktop geometry', async ({ page }) => {
  await expect(page.locator('#consumer-field-entry input')).toHaveCSS('font-size', '16px');
  await expect(page.locator('#consumer-field-title input')).toHaveCSS('font-size', '17px');
  await expect(page.locator('#consumer-field-title input')).toHaveCSS('font-weight', '600');
  await expect(page.locator('#consumer-area-reading textarea')).toHaveCSS('font-size', '17px');
  await expect(page.locator('#consumer-area-reading textarea')).toHaveCSS('font-weight', '400');
  await expect(page.locator('#consumer-area-entry textarea')).toHaveCSS('font-size', '16px');
  await expect(page.locator('#consumer-select-entry [part~="display-input"]')).toHaveCSS('font-size', '16px');
  await expect(page.locator('#consumer-field-search [part~="input-wrapper"]')).toHaveCSS('padding-inline-end', '44px');
  await expect(page.locator('#consumer-area-compact textarea')).toHaveCSS('line-height', '20px');
  await expect(page.locator('#consumer-area-compact')).toHaveCSS('height', '36px');
  // Firefox's protocol subtracts fractional page coordinates with floating-point
  // noise; retain the fixed token and tolerate less than 0.001 CSS pixel.
  expect((await page.locator('#consumer-area-compact').boundingBox())!.height).toBeCloseTo(36, 3);
  expect(await page.locator('#consumer-area-compact textarea').evaluate(element => getComputedStyle(element).paddingInlineEnd)).not.toBe('48px');
  expect((await page.locator('#consumer-cell-action').boundingBox())!.height).toBe(36);
  expect((await page.locator('#consumer-property-row').boundingBox())!.height).toBeGreaterThanOrEqual(36);
  await expect(page.locator('#consumer-selection-cell')).toHaveAttribute('aria-pressed', 'true');
  await expect(page.locator('#consumer-selection-cell')).not.toHaveAttribute('data-ui-selected');
  await expect(page.locator('#consumer-selection-cell')).toHaveCSS('outline-style', 'none');
  const fill = page.locator('#consumer-fill-action');
  const innerSize = await fill.evaluate(element => ({ width: element.parentElement!.clientWidth, height: element.parentElement!.clientHeight }));
  expect((await fill.boundingBox())!.width).toBe(innerSize.width);
  expect((await fill.boundingBox())!.height).toBe(innerSize.height);
  await expect(page.locator('#consumer-control-catalogue')).toHaveScreenshot('consumer-controls-desktop.png');
});

test('consumer field roles retain narrow typography, bounds and reserved action space', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  for (const selector of ['#consumer-field-entry input', '#consumer-area-reading textarea', '#consumer-area-compact textarea']) {
    await expect(page.locator(selector)).toHaveCSS('font-size', '16px');
  }
  // Editable headings retain their existing heading role on mobile as well.
  await expect(page.locator('#consumer-field-title input')).toHaveCSS('font-size', '17px');
  await expect(page.locator('#consumer-field-title input')).toHaveCSS('font-weight', '600');
  await expect(page.locator('#consumer-area-compact textarea')).toHaveCSS('line-height', '22.4px');
  await expect(page.locator('#consumer-area-compact')).toHaveCSS('height', '44px');
  expect((await page.locator('#consumer-area-compact').boundingBox())!.height).toBeCloseTo(44, 3);
  await expect(page.locator('#consumer-field-search [part~="input-wrapper"]')).toHaveCSS('padding-inline-end', '44px');
  expect(await page.locator('#consumer-control-catalogue').evaluate(element => element.scrollWidth <= element.clientWidth)).toBe(true);
  await expect(page.locator('#consumer-control-catalogue')).toHaveScreenshot('consumer-controls-narrow.png');
  await page.locator('#consumer-clear-search').click();
  await expect(page.locator('#consumer-field-search input')).toHaveValue('');
});

test('new field roles preserve input, draft, selection and focus through recipe changes', async ({ page }) => {
  for (const [selector, hotkey, output, recipes] of [
    ['#consumer-live-field input', 'F9', '#consumer-live-field-recipe', ['entry', 'title', 'search-action', 'form']],
    ['#consumer-live-area textarea', 'F10', '#consumer-live-area-recipe', ['entry', 'reading', 'compact-composer', 'composer', 'form']],
  ] as const) {
    const input = page.locator(selector);
    const original = await input.elementHandle();
    await input.fill('Draft and browser selection stay owned');
    await input.press('Home');
    await input.press('Shift+ArrowRight');
    for (const recipe of recipes) {
      await input.press(hotkey);
      await expect(page.locator(output)).toHaveText(recipe);
      await expect(input).toBeFocused();
      await expect(input).toHaveValue('Draft and browser selection stay owned');
      expect(await input.evaluate((node, saved) => node === saved, original)).toBe(true);
      expect(await input.evaluate(element => ({ start: (element as HTMLInputElement | HTMLTextAreaElement).selectionStart,
        end: (element as HTMLInputElement | HTMLTextAreaElement).selectionEnd }))).toEqual({ start: 0, end: 1 });
    }
    await original!.dispose();
  }
});

test('overlay actions receive glyph hits and native keyboard activation without intercepting empty space', async ({ page }) => {
  const action = page.locator('#consumer-overlay-action');
  const label = action.locator('[data-ui-button-label]');
  await expect(action).toHaveCSS('pointer-events', 'none');
  await expect(label).toHaveCSS('pointer-events', 'auto');
  const box = (await action.boundingBox())!;
  await page.mouse.click(box.x + 1, box.y + 1);
  await expect(page.locator('#consumer-overlay-count')).toHaveText('0');
  await label.click();
  await expect(page.locator('#consumer-overlay-count')).toHaveText('1');
  await action.press('Enter');
  await expect(page.locator('#consumer-overlay-count')).toHaveText('2');
  await action.press('Space');
  await expect(page.locator('#consumer-overlay-count')).toHaveText('3');
  await expect(action).toBeFocused();
});

test('consumer Dialog frames retain form and media bounds', async ({ page }) => {
  for (const [recipe, width] of [['form', 512], ['media', 768]] as const) {
    await page.locator(`#catalogue-open-${recipe}`).focus();
    await page.locator(`#catalogue-open-${recipe}`).press('Enter');
    const panel = page.locator(`#catalogue-dialog-${recipe}`);
    await expect(panel).toBeVisible();
    expect((await panel.boundingBox())!.width).toBe(width);
    if (recipe === 'form') {
      await expect(panel).toHaveCSS('overflow', 'hidden');
      await expect(panel.locator('[data-ui-surface-content]')).toHaveCSS('display', 'flex');
      await expect(panel.locator('[data-ui-surface-content]')).toHaveCSS('padding', '0px');
    } else {
      await expect(page.locator('#catalogue-media-preview')).toHaveJSProperty('complete', true);
      await expect(panel).toHaveCSS('overflow', 'hidden');
    }
    await expect(panel).toHaveScreenshot(`consumer-dialog-${recipe}.png`);
    await page.locator(`#catalogue-close-${recipe}`).click();
    await expect(panel).toBeHidden();
    await expect(page.locator(`#catalogue-open-${recipe}`)).toBeFocused();
  }
});

test('drawer width and expansion retain the same focused draft and native overlay', async ({ page }) => {
  await page.locator('#catalogue-open-drawer').click();
  const panel = page.locator('#catalogue-dialog-drawer');
  const draft = page.locator('#drawer-draft');
  await expect(draft).toBeFocused();
  const panelNode = await panel.elementHandle();
  const draftNode = await draft.elementHandle();
  const overlay = page.locator('dialog[data-ui-dialog-overlay][open]');
  const overlayNode = await overlay.elementHandle();
  expect((await panel.boundingBox())!).toEqual({ x: 16, y: 16, width: 400, height: 688 });
  await expect(panel).toHaveScreenshot('consumer-dialog-drawer.png');
  await draft.fill('Draft retained during live panel resizing');
  await draft.press('Home');
  await draft.press('Shift+ArrowRight');
  await draft.press('F7');
  await expect(page.locator('#catalogue-drawer-state')).toHaveText('520:false');
  expect((await panel.boundingBox())!.width).toBe(520);
  await draft.press('F8');
  await expect(page.locator('#catalogue-drawer-state')).toHaveText('520:true');
  expect((await panel.boundingBox())!).toEqual({ x: 0, y: 0, width: 1280, height: 720 });
  await draft.press('F8');
  await expect(page.locator('#catalogue-drawer-state')).toHaveText('520:false');
  await expect(draft).toBeFocused();
  await expect(draft).toHaveValue('Draft retained during live panel resizing');
  expect(await draft.evaluate(element => ({ start: (element as HTMLInputElement).selectionStart, end: (element as HTMLInputElement).selectionEnd })))
    .toEqual({ start: 0, end: 1 });
  expect(await panel.evaluate((node, original) => node === original, panelNode)).toBe(true);
  expect(await draft.evaluate((node, original) => node === original, draftNode)).toBe(true);
  expect(await overlay.evaluate((node, original) => node === original, overlayNode)).toBe(true);
  await page.setViewportSize({ width: 390, height: 844 });
  expect((await panel.boundingBox())!).toEqual({ x: 16, y: 16, width: 358, height: 812 });
  await draft.press('Escape');
  await expect(panel).toBeHidden();
  await page.locator('#catalogue-open-drawer').click();
  await expect(draft).toHaveValue('Draft retained during live panel resizing');
  expect(await draft.evaluate((node, original) => node === original, draftNode)).toBe(true);
  await panelNode!.dispose();
  await draftNode!.dispose();
  await overlayNode!.dispose();
});
