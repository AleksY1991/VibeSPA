import { expect, test } from '@playwright/test';

test.beforeEach(async ({ page }) => {
  await page.goto('/task-focus.html');
  await expect(page.getByRole('heading', { name: 'Release notes', exact: true })).toBeVisible();
  await expect(page.locator('[data-ui-ready="false"]')).toHaveCount(0);
});

test('main editing stays visible while occasional actions require a named disclosure', async ({ page }) => {
  const editor = page.getByRole('textbox', { name: 'Release notes', exact: true });
  await expect(editor).toBeVisible();
  await expect(page.getByRole('button', { name: 'Save', exact: true })).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Show document details', exact: true })).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Revert unsaved changes', exact: true })).toHaveCount(0);
  await expect(page.locator('#task-options')).toHaveCSS('background-color', 'rgba(0, 0, 0, 0)');
  await editor.fill('Updated release notes');
  await page.getByRole('button', { name: 'Save', exact: true }).click();
  await expect(editor).toHaveValue('Updated release notes');
  await expect(page.locator('.task-focus-status')).toHaveText('Saved for this session.');
});

test('keyboard disclosure keeps the draft owner and restores focus after a command', async ({ page }) => {
  const editor = page.getByRole('textbox', { name: 'Release notes', exact: true });
  const initial = await editor.inputValue();
  const editingNode = await editor.elementHandle();
  await editor.fill('An unsaved draft');
  const trigger = page.getByRole('button', { name: 'Document options', exact: true });
  await trigger.press('Enter');
  const details = page.getByRole('button', { name: 'Show document details', exact: true });
  await expect(details).toBeFocused();
  await details.press('Tab');
  const revert = page.getByRole('button', { name: 'Revert unsaved changes', exact: true });
  await expect(revert).toBeFocused();
  await revert.press('Enter');
  await expect(trigger).toBeFocused();
  await expect(editor).toHaveValue(initial);
  expect(await editingNode!.evaluate(element => element.isConnected)).toBe(true);
  await trigger.press('Enter');
  await expect(details).toBeFocused();
  await details.press('Escape');
  await expect(trigger).toBeFocused();
  await expect(details).toHaveCount(0);
  await editingNode!.dispose();
});

test('secondary details preserve editing and fit a narrow workspace', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const editor = page.getByRole('textbox', { name: 'Release notes', exact: true });
  await editor.fill('Draft survives opening document details');
  const trigger = page.getByRole('button', { name: 'Document options', exact: true });
  expect((await trigger.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  await trigger.click();
  await expect(page.getByRole('dialog', { name: 'Document options', exact: true })).toBeVisible();
  // The vendor's accessible dialog is boxless; its surface host owns geometry.
  const panel = page.locator('[data-ui-popover]');
  await expect(panel).toBeVisible();
  const bounds = (await panel.boundingBox())!;
  expect(bounds.x).toBeGreaterThanOrEqual(0);
  expect(bounds.x + bounds.width).toBeLessThanOrEqual(390);
  await page.getByRole('button', { name: 'Show document details', exact: true }).click();
  await expect(page.getByRole('complementary', { name: 'Document details', exact: true })).toBeVisible();
  await expect(editor).toHaveValue('Draft survives opening document details');
  expect(await page.locator('body').evaluate(element => element.scrollWidth <= window.innerWidth)).toBe(true);
  await trigger.click();
  await page.getByRole('button', { name: 'Hide document details', exact: true }).click();
  await expect(page.getByRole('complementary', { name: 'Document details', exact: true })).toHaveCount(0);
});
