import { expect, test, type Page } from '@playwright/test';

const browserErrors = new WeakMap<Page, string[]>();

/** Playwright's DOM name algorithm does not read ARIA element-reference IDL.
 * Check the browser-owned references in every engine, plus Chromium's native AX
 * tree where Playwright exposes that platform protocol. */
async function nativeRoleNames(page: Page, role: string) {
  const client = await page.context().newCDPSession(page);
  try {
    await client.send('Accessibility.enable');
    const { nodes } = await client.send('Accessibility.getFullAXTree');
    return nodes.filter(node => !node.ignored && node.role?.value === role)
      .map(node => ({ name: String(node.name?.value ?? ''), description: String(node.description?.value ?? '') }));
  } finally {
    await client.detach();
  }
}

test.beforeEach(async ({ page }) => {
  const errors: string[] = [];
  browserErrors.set(page, errors);
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/catalogue.html');
  await expect(page.locator('#component-catalogue')).toBeVisible();
  await expect(page.locator('[data-ui-control-unavailable]')).toHaveCount(0);
  await expect(page.locator('[data-ui-ready="false"]')).toHaveCount(0);
  await expect(page.locator('[data-ui-error]')).toHaveCount(0);
  await page.evaluate(async () => { await document.fonts.ready; });
  await expect(page.locator('#display-image')).toHaveJSProperty('complete', true);
});

test.afterEach(async ({ page }) => {
  expect(browserErrors.get(page), 'browser runtime errors').toEqual([]);
});

test('representative component states retain readable desktop appearance and semantics', async ({ page }) => {
  await expect(page.getByRole('checkbox', { name: 'Unchecked checkbox', exact: true })).not.toBeChecked();
  await expect(page.getByRole('checkbox', { name: 'Checked checkbox', exact: true })).toBeChecked();
  await expect(page.getByRole('checkbox', { name: 'Mixed checkbox', exact: true })).toBeChecked({ indeterminate: true });
  await expect(page.getByRole('checkbox', { name: 'Disabled checkbox', exact: true })).toBeDisabled();
  for (const [id, opacity] of [['catalogue-checkbox-checked', '1'], ['catalogue-checkbox-disabled', '0.5']] as const) {
    expect(await page.locator(`#${id}`).evaluate(element => getComputedStyle(element.shadowRoot!.querySelector('[part~="base"]')!).opacity)).toBe(opacity);
  }
  await expect(page.getByRole('switch', { name: 'Off switch', exact: true })).not.toBeChecked();
  await expect(page.getByRole('switch', { name: 'On switch', exact: true })).toBeChecked();
  await expect(page.getByRole('switch', { name: 'Read-only switch', exact: true })).toHaveAttribute('aria-disabled', 'true');
  await expect(page.getByRole('switch', { name: 'Disabled switch', exact: true })).toBeDisabled();
  await expect(page.getByRole('tab', { name: 'Overview', exact: true })).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByRole('tab', { name: 'Unavailable', exact: true })).toBeDisabled();
  await expect(page.getByRole('progressbar', { name: 'Upload progress', exact: true })).toHaveAttribute('aria-valuenow', '62');
  await expect(page.getByRole('progressbar', { name: 'Upload progress', exact: true })).toHaveAttribute('aria-valuetext', '62 of 100 files');
  await expect(page.getByRole('progressbar', { name: 'Small busy indicator', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Remove Required filter', exact: true })).toBeDisabled();
  await expect(page.getByRole('link', { name: 'Disabled link', exact: true })).toHaveAttribute('aria-disabled', 'true');
  await expect(page.locator('#catalogue-native-input')).toHaveAttribute('aria-invalid', 'true');
  await expect(page.locator('#display-divider')).toHaveCSS('border-top-width', '1px');
  await expect(page.locator('#component-catalogue')).toHaveScreenshot('components-desktop.png');
});

test('representative states retain their distinct appearance in dark mode', async ({ page }) => {
  await page.evaluate(() => document.documentElement.classList.add('dark'));
  await expect(page.locator('#app')).toHaveCSS('background-color', 'rgb(0, 0, 0)');
  await expect(page.locator('#component-catalogue')).toHaveScreenshot('components-dark.png');
});

test('representative states fit a narrow viewport without losing touch targets', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const overflow = await page.locator('#component-catalogue').evaluate(element => {
    if (element.scrollWidth <= element.clientWidth) return [];
    const bounds = element.getBoundingClientRect();
    return [...element.querySelectorAll('*')].filter(child => child.getBoundingClientRect().right > bounds.right + 1)
      .map(child => ({ tag: child.tagName, id: child.id, class: child.className, width: child.getBoundingClientRect().width })).slice(0, 12);
  });
  expect(overflow, 'fixture content exceeds the narrow viewport').toEqual([]);
  for (const selector of ['#catalogue-checkbox-unchecked', '#catalogue-toggle-off', '#catalogue-edit-inline', '#catalogue-submit-native']) {
    expect((await page.locator(selector).boundingBox())!.height).toBeGreaterThanOrEqual(44);
  }
  await expect(page.locator('#component-catalogue')).toHaveScreenshot('components-narrow.png');
});

test('selection controls retain native keyboard ownership and disabled state', async ({ page }) => {
  const mixed = page.getByRole('checkbox', { name: 'Mixed checkbox', exact: true });
  await mixed.press('Space');
  await expect(mixed).toBeChecked();
  await expect(mixed).not.toBeChecked({ indeterminate: true });
  const toggle = page.getByRole('switch', { name: 'Off switch', exact: true });
  await toggle.press('Space');
  await expect(toggle).toBeChecked();
  const locked = page.getByRole('switch', { name: 'Read-only switch', exact: true });
  await locked.press('Space');
  await expect(locked).toBeChecked();
  await expect(locked).toBeFocused();
  await page.getByRole('radio', { name: 'Overview', exact: true }).first().press('ArrowRight');
  await expect(page.getByRole('radio', { name: 'Details', exact: true }).first()).toBeChecked();
  const overview = page.getByRole('tab', { name: 'Overview', exact: true });
  await overview.press('ArrowRight');
  await expect(page.getByRole('tab', { name: 'Details', exact: true })).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('#catalogue-panel-overview')).toBeHidden();
  await expect(page.locator('#catalogue-panel-details')).toBeVisible();
  await page.getByRole('tab', { name: 'Details', exact: true }).press('ArrowRight');
  await expect(overview).toBeFocused();
  await page.getByRole('tab', { name: 'Summary', exact: true }).press('ArrowDown');
  await expect(page.getByRole('tab', { name: 'Activity', exact: true })).toHaveAttribute('aria-selected', 'true');
  await page.getByRole('button', { name: 'Remove Planning filter', exact: true }).click();
  await expect(page.locator('#display-tag-removals')).toHaveText('1');
});

test('native editing, file engines and split panes retain browser state', async ({ page }) => {
  const scroll = page.getByRole('region', { name: 'Scrollable records', exact: true });
  // Overflow creates a native keyboard stop without a caller ref or a second scroller.
  await expect(scroll).toHaveAttribute('tabindex', '0');
  await scroll.press('End');
  await expect.poll(() => scroll.evaluate(element => element.scrollTop)).toBeGreaterThan(0);
  const separator = page.getByRole('separator', { name: 'Details width', exact: true });
  await separator.press('ArrowLeft');
  await expect(page.locator('#catalogue-pane-width')).toHaveText('150');
  const draft = page.locator('#catalogue-retained-pane');
  const draftNode = await draft.elementHandle();
  await draft.fill('Draft survives collapsed pane');
  await page.locator('#catalogue-collapse-pane').click();
  await expect(draft).toBeHidden();
  await page.locator('#catalogue-collapse-pane').click();
  await expect(draft).toHaveValue('Draft survives collapsed pane');
  expect(await draft.evaluate((node, original) => node === original, draftNode)).toBe(true);
  await draftNode!.dispose();
  await page.locator('#catalogue-edit-inline').click();
  const editor = page.locator('#catalogue-inline-editor');
  await expect(editor).toHaveAttribute('contenteditable', 'plaintext-only');
  await editor.fill('Edited inline draft');
  await editor.press('Enter');
  await expect(editor).toHaveText('Edited inline draft');
  await expect(editor).toHaveAttribute('contenteditable', 'false');
  await page.locator('#catalogue-native-input').fill('reader@example.com');
  await page.locator('#catalogue-submit-native').click();
  await expect(page.locator('#catalogue-submission')).toHaveText('reader@example.com');
  await page.getByLabel('Catalogue attachment', { exact: true }).setInputFiles({ name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('local fixture only') });
  await expect(page.getByRole('status').filter({ hasText: 'notes.txt' })).toBeVisible();
});

test('popover and tooltip surfaces retain readable paint and independent dismissal', async ({ page }) => {
  await page.locator('#catalogue-open-popover').click();
  const panel = page.getByRole('dialog', { name: 'Catalogue choices', exact: true });
  await expect(panel).toBeVisible();
  // The semantic shadow dialog is display:contents; the host owns its paint box.
  await expect(page.locator('wa-popover[data-ui-popover]')).toHaveScreenshot('popover-open.png');
  await page.locator('#catalogue-popover-action').press('Escape');
  await expect(panel).toBeHidden();
  await expect(page.locator('#catalogue-open-popover')).toBeFocused();
  await page.locator('#catalogue-tooltip-trigger').hover();
  // Optional visual hints are aria-hidden and never rename the action.
  const tooltip = page.locator('[data-ui-tooltip-content]');
  await expect(tooltip).toHaveText('A visible action retains its accessible name');
  await expect(tooltip).toHaveScreenshot('tooltip-open.png');
  await expect(page.locator('#catalogue-tooltip-trigger')).toHaveAccessibleName('Named action with tooltip');
  await page.mouse.move(0, 0);
  await expect(tooltip).toBeHidden();
});

test('native external Toggle labels activate once and retain external accessible references', async ({ page, browserName }) => {
  const label = page.locator('#platform-toggle-label');
  const toggle = page.locator('#platform-external-toggle input');
  expect(await label.evaluate(element => (element as HTMLLabelElement).control?.id)).toBe('platform-external-toggle');
  await expect(toggle).not.toBeChecked();
  expect(await toggle.evaluate(element => ({
    labelledBy: element.ariaLabelledByElements?.map(reference => reference.id),
    describedBy: element.ariaDescribedByElements?.map(reference => reference.id),
  }))).toEqual({ labelledBy: ['platform-toggle-label'], describedBy: ['platform-toggle-description'] });
  if (browserName === 'chromium') {
    await expect.poll(() => nativeRoleNames(page, 'switch')).toContainEqual({
      name: 'Publish automatically', description: 'Publish only when the workspace is ready.',
    });
  }
  await label.click();
  await expect(toggle).toBeChecked();
  await expect(page.locator('#platform-toggle-writes')).toHaveText('1:0');
  await label.click();
  await expect(toggle).not.toBeChecked();
  await expect(page.locator('#platform-toggle-writes')).toHaveText('2:0');
  const disabled = page.locator('#platform-disabled-toggle input');
  await expect(disabled).toBeDisabled();
  expect(await disabled.evaluate(element => ({
    labelledBy: element.ariaLabelledByElements?.map(reference => reference.id),
    describedBy: element.ariaDescribedByElements?.map(reference => reference.id),
  }))).toEqual({ labelledBy: ['platform-disabled-label'], describedBy: ['platform-toggle-description'] });
  if (browserName === 'chromium') {
    await expect.poll(() => nativeRoleNames(page, 'switch')).toContainEqual({
      name: 'Unavailable publication', description: 'Publish only when the workspace is ready.',
    });
  }
  await page.locator('#platform-disabled-label').click();
  await expect(disabled).not.toBeChecked();
  await expect(page.locator('#platform-toggle-writes')).toHaveText('2:0');
});

test('TextField public focus and blur callbacks fire once across native shadow focus', async ({ page }) => {
  const input = page.locator('#platform-focus-field input');
  const counts = page.locator('#platform-focus-counts');
  await expect(counts).toHaveText('0:0:0');
  await input.click();
  await expect(input).toBeFocused();
  await expect(counts).toHaveText('1:0:0');
  await input.fill('A pending edit commits on Enter blur');
  await expect(counts).toHaveText('1:0:0');
  await input.press('Enter');
  await expect(input).not.toBeFocused();
  await expect(counts).toHaveText('1:1:1');
  await input.click();
  await expect(counts).toHaveText('2:1:1');
  await input.press('Escape');
  await expect(counts).toHaveText('2:2:1');
  await input.click();
  await expect(counts).toHaveText('3:2:1');
  // Safari does not focus buttons on a pointer click. Keyboard navigation owns
  // this focus transition in every engine and must not invoke field callbacks
  // again when the slotted action is activated.
  await input.press('Tab');
  await expect(page.locator('#platform-field-end-action')).toBeFocused();
  await expect(counts).toHaveText('3:3:2');
  await page.locator('#platform-field-end-action').press('Enter');
  await expect(counts).toHaveText('3:3:2');
  await page.locator('#platform-outside-action').click();
  await expect(counts).toHaveText('3:3:2');
});

test('effect-driven field focus and blur keep native callbacks outside reactive apply scopes', async ({ page }) => {
  const input = page.locator('#platform-focus-field input');
  const counts = page.locator('#platform-focus-counts');
  await expect(counts).toHaveText('0:0:0');
  await page.locator('#platform-effect-focus').click();
  await expect(input).toBeFocused();
  await expect(counts).toHaveText('1:0:0');
  await input.fill('Native change commits during effect-driven blur');
  await expect(page.locator('#platform-value-commits')).toHaveText('0');
  await input.press('F6');
  await expect(input).not.toBeFocused();
  await expect(counts).toHaveText('1:1:1');
  await expect(page.locator('#platform-value-commits')).toHaveText('1');
  await expect(page.locator('#platform-field-diagnostics')).toHaveText('');
});

test('ChoiceGroup external description reaches the actual vendor radiogroup', async ({ page, browserName }) => {
  const group = page.getByRole('radiogroup', { name: 'Externally described mode', exact: true });
  if (browserName === 'chromium') {
    await expect.poll(() => nativeRoleNames(page, 'radiogroup')).toContainEqual({
      name: 'Externally described mode', description: 'Choose the scope of this action.',
    });
  }
  expect(await group.evaluate(element => element.ariaDescribedByElements?.map(reference => reference.id)))
    .toContain('platform-choice-description');
  // The radios are light-DOM children slotted into the shadow fieldset.
  await page.getByRole('radio', { name: 'Two records', exact: true }).click();
  await expect(page.getByRole('radio', { name: 'Two records', exact: true })).toBeChecked();
  expect(await group.evaluate(element => element.ariaDescribedByElements?.map(reference => reference.id)))
    .toContain('platform-choice-description');
  if (browserName === 'chromium') {
    await expect.poll(() => nativeRoleNames(page, 'radiogroup')).toContainEqual({
      name: 'Externally described mode', description: 'Choose the scope of this action.',
    });
  }
});
