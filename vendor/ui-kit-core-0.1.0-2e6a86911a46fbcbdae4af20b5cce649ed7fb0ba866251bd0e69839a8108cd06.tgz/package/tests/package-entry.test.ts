// @vitest-environment happy-dom
import { createRoot, flush } from 'solid-js';
import { render } from '@solidjs/web';
import { expect, it, vi } from 'vitest';
import { Button, constructItem } from '@ui-kit/core';
import * as controls from '@ui-kit/core/solid/controls';
import * as contentEditable from '@ui-kit/core/solid/content-editable';
import * as scrollArea from '@ui-kit/core/solid/scroll-area';
import * as splitPanel from '@ui-kit/core/solid/split-panel';

it('exposes constructed controls without internal renderer and layout entry points', () => {
  expect(Object.keys(controls).sort()).toEqual(['Card', 'ChoiceGroup', 'Toggle']);
  expect(Object.keys(contentEditable)).toEqual(['ContentEditable']);
  expect(Object.keys(scrollArea).sort()).toEqual(['SCROLL_KEYS', 'ScrollArea']);
  expect(Object.keys(splitPanel)).toEqual(['SplitPanel']);
});

it('mounts and disposes a control through the package export without application aliases', () => {
  const host = document.createElement('div');
  document.body.append(host);
  const command = vi.fn();
  let disposeRoot!: () => void;
  const disposeView = createRoot(dispose => {
    disposeRoot = dispose;
    const observable = constructItem('consumer', item => item.constant('button', {}));
    return render(() => Button.View({
      observable,
      surface: { kind: 'own', name: 'consumer.action', transparent: false },
      hotkeys: [],
      children: 'Run',
      onActivate: command,
    }), host);
  });
  try {
    flush();
    const button = host.querySelector('button')!;
    button.click();
    expect(command).toHaveBeenCalledOnce();
    disposeView(); disposeRoot();
    button.click();
    expect(command).toHaveBeenCalledOnce();
  } finally {
    disposeView(); disposeRoot(); host.remove();
  }
});
