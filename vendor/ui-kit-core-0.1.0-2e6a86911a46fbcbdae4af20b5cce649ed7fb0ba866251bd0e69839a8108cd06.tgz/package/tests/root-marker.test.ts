// @vitest-environment happy-dom
import { describe, expect, it } from 'vitest';
import { renderUiRoot } from '../src/infrastructure/renderUiRoot';

describe('owned stylesheet scope', () => {
  it('retains a shared host marker until its final root releases it', () => {
    const host = document.createElement('div');
    const first = renderUiRoot(() => null, host);
    const second = renderUiRoot(() => null, host);
    expect(host.hasAttribute('data-ui-root')).toBe(true);
    first();
    expect(host.hasAttribute('data-ui-root')).toBe(true);
    second();
    expect(host.hasAttribute('data-ui-root')).toBe(false);
  });

  it('restores a host marker supplied by the consumer', () => {
    const host = document.createElement('div');
    host.setAttribute('data-ui-root', 'consumer');
    const dispose = renderUiRoot(() => null, host);
    dispose();
    expect(host.getAttribute('data-ui-root')).toBe('consumer');
  });
});
