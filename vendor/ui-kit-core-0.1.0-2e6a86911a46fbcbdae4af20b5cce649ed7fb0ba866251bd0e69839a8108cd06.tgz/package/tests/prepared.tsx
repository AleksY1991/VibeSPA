/** @jsxImportSource @solidjs/web */
import { afterAll, beforeAll, vi } from 'vitest';
import { createComponent, untrack } from 'solid-js';
import { render, type JSX } from '@solidjs/web';
import { controlPreparation, prepareAppImplementation } from '../src/bootstrap';
import { ImplementationContext, type ControlFamily, type PreparedImplementation } from '../src/infrastructure/implementation-context';

let prepared: PreparedImplementation;
let restoreInternals: (() => void) | undefined;
beforeAll(async () => {
  // Happy DOM omits ElementInternals. Supply only that browser platform API;
  // installed WA/Lit behavior, updates, selection and event handling stay real.
  if (!HTMLElement.prototype.attachInternals) {
    Object.defineProperty(HTMLElement.prototype, 'attachInternals', { configurable: true, value() {
      let validity: Record<string, boolean> = { valid: true };
      let validationMessage = '';
      return { states: new Set<string>(), labels: [], form: null, willValidate: true,
        get validity() { return validity; }, get validationMessage() { return validationMessage; },
        setFormValue() {},
        setValidity(flags: Record<string, boolean>, message = '') {
          validity = { ...flags, valid: !Object.values(flags).some(Boolean) }; validationMessage = message;
        },
        checkValidity: () => validity.valid, reportValidity: () => validity.valid,
      };
    } });
    restoreInternals = () => { Reflect.deleteProperty(HTMLElement.prototype, 'attachInternals'); };
  }
  prepared = await prepareAppImplementation();
  // Production mounts immediately and handles each pending family locally.
  // These integration fixtures deliberately start from terminal family states.
  await vi.waitFor(() => {
    const pending = (Object.keys(prepared) as ControlFamily[]).filter(family =>
      untrack(() => controlPreparation(prepared, family)).status === 'pending');
    if (pending.length) throw new Error(`Still preparing test controls: ${pending.join(', ')}`);
  }, { timeout: 9000, interval: 10 });
});
afterAll(() => restoreInternals?.());

/** Exercise public controls with the same prepared implementation as a host app. */
export function renderPrepared(code: () => JSX.Element, host: HTMLElement): () => void {
  return render(() => <ImplementationContext value={prepared}>{createComponent(code, {})}</ImplementationContext>, host);
}
