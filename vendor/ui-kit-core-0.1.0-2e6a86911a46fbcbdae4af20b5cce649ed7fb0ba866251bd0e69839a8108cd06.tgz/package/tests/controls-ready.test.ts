// @vitest-environment happy-dom
import { afterEach, expect, it, vi } from 'vitest';
import { whenControlsReady } from '@ui-kit/core/solid/overlay';

afterEach(() => { vi.unstubAllGlobals(); document.body.replaceChildren(); });

function preparingControl(): HTMLElement {
  const control = document.createElement('div');
  control.setAttribute('data-ui-ready', 'false');
  return control;
}

it('completes synchronously without pending descendants and ignores unrelated controls', async () => {
  const container = preparingControl();
  const outside = preparingControl();
  document.body.append(container, outside);
  const ready = vi.fn();
  const cancel = whenControlsReady(container, ready);
  expect(ready).toHaveBeenCalledOnce();
  cancel(); cancel();
  const later = preparingControl(); container.append(later);
  later.setAttribute('data-ui-ready', 'true');
  await Promise.resolve();
  expect(ready).toHaveBeenCalledOnce();
});

it('waits for every descendant and completes once when pending children are replaced or removed', async () => {
  const container = document.createElement('div');
  const first = preparingControl();
  const wrapper = document.createElement('div');
  const second = preparingControl(); wrapper.append(second); container.append(first, wrapper);
  document.body.append(container);
  const ready = vi.fn(); const cancel = whenControlsReady(container, ready);
  first.setAttribute('data-ui-ready', 'true');
  const replacement = preparingControl(); wrapper.replaceChildren(replacement);
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(ready).not.toHaveBeenCalled();
  replacement.remove();
  await vi.waitFor(() => expect(ready).toHaveBeenCalledOnce());
  const later = preparingControl(); container.append(later); later.remove();
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(ready).toHaveBeenCalledOnce();
  cancel();
});

it('cancels the observer before a pending control becomes ready', async () => {
  const container = document.createElement('div'); const control = preparingControl(); container.append(control);
  const ready = vi.fn(); const cancel = whenControlsReady(container, ready);
  cancel(); cancel(); control.remove();
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(ready).not.toHaveBeenCalled();
});

function deliveredObserver(): { notify(): void; disconnect: ReturnType<typeof vi.fn> } {
  let callback!: MutationCallback;
  const disconnect = vi.fn();
  class ObserverDouble {
    constructor(next: MutationCallback) { callback = next; }
    observe(): void { /* The test delivers the native observer boundary explicitly. */ }
    disconnect = disconnect;
  }
  vi.stubGlobal('MutationObserver', ObserverDouble);
  return { notify: () => callback([], {} as MutationObserver), disconnect };
}

it('defers a readiness notification until handles can publish and disconnects before delivery', async () => {
  const observer = deliveredObserver();
  const container = document.createElement('div'); const control = preparingControl(); container.append(control);
  let handlePublished = false;
  const ready = vi.fn(() => {
    expect(handlePublished).toBe(true);
    expect(observer.disconnect).toHaveBeenCalledOnce();
  });
  const cancel = whenControlsReady(container, ready);
  control.setAttribute('data-ui-ready', 'true'); observer.notify(); observer.notify();
  expect(ready).not.toHaveBeenCalled();
  handlePublished = true;
  await Promise.resolve();
  expect(ready).toHaveBeenCalledOnce();
  cancel(); expect(observer.disconnect).toHaveBeenCalledOnce();
});

it('cancels a queued completion and rechecks replacement controls before completing', async () => {
  const observer = deliveredObserver();
  const container = document.createElement('div'); const control = preparingControl(); container.append(control);
  const ready = vi.fn(); const cancel = whenControlsReady(container, ready);
  control.remove(); observer.notify();
  const replacement = preparingControl(); container.append(replacement);
  await Promise.resolve();
  expect(ready).not.toHaveBeenCalled();
  replacement.remove(); observer.notify(); cancel(); cancel();
  await Promise.resolve();
  expect(ready).not.toHaveBeenCalled();
  expect(observer.disconnect).toHaveBeenCalledOnce();
});
