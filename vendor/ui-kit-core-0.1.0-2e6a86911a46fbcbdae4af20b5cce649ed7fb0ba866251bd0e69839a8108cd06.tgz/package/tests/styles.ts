import { afterAll, afterEach, beforeAll, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/** Exercise authored component styles inside the same scope a standalone host supplies. */
export function useStyles(...sourcePaths: readonly string[]): void {
  let sheet: HTMLStyleElement;
  let previousScope: string | null;
  beforeAll(() => {
    sheet = document.createElement('style');
    const sourceRoot = join(dirname(fileURLToPath(import.meta.url)), '../src');
    // Each dependency is explicit here; Happy DOM cannot load CSS imports and
    // otherwise drops the first following rule while parsing an import.
    sheet.textContent = sourcePaths.map(sourcePath => readFileSync(join(sourceRoot, sourcePath), 'utf8')
      .replace(/^\s*@import[^;]+;/gm, '')).join('\n');
    document.head.append(sheet);
  });
  beforeEach(() => {
    previousScope = document.body.getAttribute('data-ui-root');
    document.body.setAttribute('data-ui-root', '');
  });
  afterEach(() => {
    if (previousScope === null) document.body.removeAttribute('data-ui-root');
    else document.body.setAttribute('data-ui-root', previousScope);
  });
  afterAll(() => sheet.remove());
}

/** Happy DOM does not resolve tokenized HSL colors; inspect matching authored declarations. */
export function authoredStyle(element: Element, property: string): string {
  let value = '';
  const visit = (rules: CSSRuleList): void => {
    for (const rule of rules) {
      if (rule instanceof CSSStyleRule) {
        if (element.matches(rule.selectorText) && rule.style.getPropertyValue(property)) {
          value = rule.style.getPropertyValue(property);
        }
      } else if (rule instanceof CSSMediaRule) {
        if (window.matchMedia(rule.conditionText).matches) visit(rule.cssRules);
      } else if ('cssRules' in rule) visit(rule.cssRules as CSSRuleList);
    }
  };
  for (const sheet of document.styleSheets) visit(sheet.cssRules);
  return value;
}
