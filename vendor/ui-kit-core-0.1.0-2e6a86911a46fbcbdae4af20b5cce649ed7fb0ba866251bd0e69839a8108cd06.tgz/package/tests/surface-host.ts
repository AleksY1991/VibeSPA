import { HOTKEY_DELEGATE, HOTKEY_PASS, isSurfaceElement, surfaceShadowHost, nativeOwnsCombo } from '../src/contracts/platform';
import type { ActiveSurface, Dispose, ElementSurfaceDefinition, ElementSurfaceLease, ElementSurfaceResolution, ElementSurfaceUpdate, NonvisualSurfaceDefinition, SurfaceHotkeyHandler, SurfaceLease, UiRendererDefinition, UiSurfacePlatform } from '../src/contracts/platform';

interface MountedSurface {
  readonly token: number;
  readonly name: string;
  readonly element?: Element;
  readonly target?: EventTarget;
  readonly transparent: boolean;
  readonly layer: boolean;
  readonly keys: Readonly<Record<string, SurfaceHotkeyHandler>>;
  readonly dismissable?: boolean;
  readonly modal?: boolean;
  readonly delegate?: readonly string[] | 'all';
  readonly nativeOverrides?: readonly string[];
  readonly nativeOwners?: readonly Element[];
  readonly activationRoots?: readonly Element[];
  readonly focusKeys?: Readonly<Record<string, SurfaceHotkeyHandler>>;
  readonly parentId?: string | null;
}
type MountedElement = MountedSurface & { readonly element: Element };
const isMountedElement = (surface: MountedSurface): surface is MountedElement => surface.element !== undefined;

/** In-memory browser host: DOM ownership, keyboard arbitration and leases without application actions or state. */
export class TestSurfaceRegistry {
  readonly #listeners = new Set<() => void>();
  readonly #mounted = new Map<number, MountedSurface>();
  readonly #elements = new Map<Element, Map<number, MountedElement>>();
  readonly #instances = new Map<string, MountedSurface>();
  readonly #nativeOwners = new Map<Element, Map<number, MountedElement>>();
  readonly #layers = new Map<number, MountedElement>();
  readonly #children = new Map<string, Set<number>>();
  readonly #dispatching = new WeakMap<KeyboardEvent, Set<number>>();
  readonly #delegatedOwners = new Set<number>();
  readonly #dismissedEvents = new WeakSet<Event>();
  readonly #definitions = new Map<string, UiRendererDefinition>();
  readonly #actions = new Map<string, Set<() => void>>();
  #nextMount = 0;
  #instancesDirty = true;
  #publicationScheduled = false;
  #snapshot: { readonly activeSurfaces: readonly ActiveSurface[] } = { activeSurfaces: [] };

  #listen(listener: () => void): Dispose {
    this.#listeners.add(listener);
    return () => { this.#listeners.delete(listener); };
  }
  read = () => { if (this.#instancesDirty) this.#derive(); return this.#snapshot; };
  subscribe = (listener: () => void): Dispose => this.#listen(listener);
  registerRenderer = (definition: UiRendererDefinition): void => { this.#definitions.set(definition.id, definition); };
  mountRenderer = (id: string): SurfaceLease => {
    const definition = this.#definitions.get(id);
    if (!definition) throw new Error('Unknown renderer: ' + id);
    const token = ++this.#nextMount;
    this.#remember({ token, name: id, transparent: definition.transparent, layer: false, keys: {} });
    this.#schedulePublication();
    return { instanceId: id + ':' + token, dispose: () => { if (this.#forgetTree(token)) this.#schedulePublication(); } };
  };
  onAction = (id: string, listener: () => void): Dispose => {
    let listeners = this.#actions.get(id);
    if (!listeners) this.#actions.set(id, listeners = new Set());
    listeners.add(listener);
    return () => { listeners.delete(listener); };
  };
  invokeAction(id: string): void { for (const listener of this.#actions.get(id) ?? []) listener(); }
  reset(): void {
    for (const token of [...this.#mounted.keys()]) this.#forgetTree(token);
    this.#derive();
  }
  readonly platform: UiSurfacePlatform = {
    registerRenderer: definition => this.registerRenderer(definition),
    mountRenderer: id => this.mountRenderer(id),
    mountElement: definition => this.mountElementLease(definition),
    mountNonvisual: definition => this.mountNonvisualLease(definition),
    onAction: (id, listener) => this.onAction(id, listener),
  };
  /** Register one live DOM keyboard owner; the returned lease is its lifecycle. */
  mountElement(definition: ElementSurfaceDefinition): Dispose {
    return this.mountElementLease(definition).dispose;
  }

  /** Element identities also own descendants that render through a portal. */
  mountElementLease(definition: ElementSurfaceDefinition): ElementSurfaceLease {
    return this.#mountOwner(definition);
  }

  mountNonvisualLease(definition: NonvisualSurfaceDefinition): ElementSurfaceLease {
    return this.#mountOwner({ ...definition, transparent: false, layer: false, keys: {}, delegate: 'all' });
  }

  #mountOwner(definition: Omit<ElementSurfaceDefinition, 'element'> & { readonly element?: Element; readonly target?: EventTarget }): ElementSurfaceLease {
    if (!definition.name.trim()) throw new Error('[surface] element surface requires a name');
    const token = ++this.#nextMount;
    let surface: MountedSurface = Object.freeze({
      token,
      name: definition.name,
      element: definition.element,
      target: definition.target,
      transparent: definition.transparent,
      layer: definition.layer,
      keys: Object.freeze({ ...definition.keys }),
      dismissable: definition.dismissable,
      modal: definition.modal,
      delegate: definition.delegate === 'all' ? 'all' : definition.delegate && Object.freeze([...definition.delegate]),
      nativeOverrides: definition.nativeOverrides && Object.freeze([...definition.nativeOverrides]),
      nativeOwners: definition.nativeOwners && Object.freeze([...definition.nativeOwners]),
      activationRoots: definition.activationRoots && Object.freeze([...definition.activationRoots]),
      focusKeys: definition.focusKeys && Object.freeze({ ...definition.focusKeys }),
      parentId: definition.parentId,
    });
    this.#remember(surface);
    this.#schedulePublication();
    let active = true;
    const dispose = () => {
      if (!active) return;
      active = false;
      if (this.#forgetTree(token)) this.#schedulePublication();
    };
    const update = (next: ElementSurfaceUpdate): void => {
      if (!active || !this.#mounted.has(token)) return;
      this.#forget(token);
      surface = Object.freeze({
        ...surface,
        layer: surface.element ? next.layer ?? surface.layer : false,
        modal: next.modal ?? surface.modal,
        dismissable: next.dismissable ?? surface.dismissable,
        nativeOwners: next.nativeOwners ? Object.freeze([...next.nativeOwners]) : surface.nativeOwners,
        activationRoots: next.activationRoots ? Object.freeze([...next.activationRoots]) : surface.activationRoots,
      });
      this.#remember(surface);
      this.#schedulePublication();
    };
    return Object.freeze({ instanceId: `${definition.name}:${token}`, dispose, update, authority: Object.freeze({
      subscribe: (listener: () => void) => this.#listen(listener),
      canDismiss: (target?: EventTarget | null) => isMountedElement(surface) && this.#canDismiss(surface, target),
      claimDismissal: (event: Event) => {
        if (!isMountedElement(surface) || this.#dismissedEvents.has(event) || !this.#canDismiss(surface, event.target)) return false;
        this.#dismissedEvents.add(event);
        return true;
      },
      canMoveFocus: () => isMountedElement(surface) && this.#canMoveFocus(surface),
      canRestoreFocus: (target?: Element | null) => isMountedElement(surface) && this.#canRestoreFocus(surface, target),
      hasDismissableChild: () => isMountedElement(surface) && this.#dismissableChildren(surface).length > 0,
      dispatchChildEscape: (event: KeyboardEvent): ElementSurfaceResolution => isMountedElement(surface)
        ? this.#dispatchChildEscape(surface, event) : Object.freeze({ kind: 'unclaimed' }),
      canActivate: () => this.canActivate(`${surface.name}:${surface.token}`),
    }) });
  }

  /** Command callbacks share the same live owner and global scope as keyboard dispatch. */
  canActivate(instanceId: string | null): boolean {
    const surface = instanceId ? this.#instances.get(instanceId) : undefined;
    if (!surface || !this.#live(surface)) return false;
    for (const layer of [...this.#layers.values()].sort((a, b) => b.token - a.token)) {
      if (layer.transparent || !this.#live(layer)) continue;
      return layer.token === surface.token || this.#ownedBy(surface, layer)
        || !!surface.element && (layer.activationRoots?.some(root => root === surface.element || root.contains(surface.element!)) ?? false);
    }
    return true;
  }

  /** Native release is permitted only within the current global ownership scope. */
  allowsNative(nativeOwner: Element): boolean {
    const layer = [...this.#layers.values()].sort((a, b) => b.token - a.token)
      .find(candidate => !candidate.transparent && this.#live(candidate));
    if (!layer) return true;
    if (this.#containsTarget(layer, nativeOwner)
      || layer.activationRoots?.some(root => root === nativeOwner || root.contains(nativeOwner))) return true;
    for (const owner of this.#nativeOwners.get(nativeOwner)?.values() ?? []) {
      if (this.#live(owner) && (owner.token === layer.token || this.#ownedBy(owner, layer))) return true;
    }
    return false;
  }

  #live(surface: MountedSurface): boolean {
    const visited = new Set<number>();
    let owner: MountedSurface | undefined = surface;
    while (owner && !visited.has(owner.token)) {
      visited.add(owner.token);
      if (!this.#mounted.has(owner.token)) return false;
      if (owner.element) {
        // Synthetic registry tests supply an ancestry-only stand-in. Real
        // hosts always have a document whose DOM owns visibility/liveness.
        if (!owner.element.ownerDocument) return true;
        if (owner.element.isConnected === false) return false;
        let element: Element | null = owner.element;
        while (element) {
          if (element.hasAttribute?.('hidden') || element.hasAttribute?.('inert')) return false;
          const style = element.ownerDocument?.defaultView?.getComputedStyle(element);
          if (style?.display === 'none' || style?.visibility === 'hidden' || style?.visibility === 'collapse') return false;
          const root = element.getRootNode?.();
          element = element.parentElement ?? (root ? surfaceShadowHost(root) : null);
        }
      }
      if (owner.parentId && !this.#instances.has(owner.parentId)) return false;
      owner = this.#parent(owner);
    }
    return true;
  }

  #containsTarget(surface: MountedElement, target: EventTarget | null | undefined): boolean {
    if (!target || !('nodeType' in target)) return false;
    const node = target as Node;
    if (surface.element === node || surface.element.contains(node)) return true;
    let element = isSurfaceElement(node) ? node : node.parentElement;
    while (element) {
      for (const candidate of this.#elements.get(element)?.values() ?? []) {
        if (this.#ownedBy(candidate, surface)) return true;
      }
      const root = element.getRootNode();
      element = element.parentElement ?? surfaceShadowHost(root);
    }
    return false;
  }

  #canDismiss(surface: MountedElement, target?: EventTarget | null): boolean {
    if (!surface.dismissable || !this.#live(surface)) return false;
    if (!surface.layer && target && !this.#containsTarget(surface, target)) return false;
    const global = [...this.#layers.values()].sort((a, b) => b.token - a.token)
      .find(candidate => candidate.dismissable && this.#live(candidate));
    if (!surface.layer && global && !this.#ownedBy(surface, global)) return false;
    for (const candidate of [...this.#mounted.values()].sort((a, b) => b.token - a.token)) {
      if (!isMountedElement(candidate) || !candidate.dismissable || !this.#live(candidate)) continue;
      if (candidate.token !== surface.token && this.#delegatedOwners.has(surface.token) && this.#ownedBy(candidate, surface)) continue;
      if (candidate.layer || candidate.token === surface.token || this.#containsTarget(candidate, target)) {
        return candidate.token === surface.token;
      }
    }
    return false;
  }

  #topModal(): MountedElement | undefined {
    return [...this.#layers.values()].sort((a, b) => b.token - a.token).find(surface => surface.modal && this.#live(surface));
  }

  #canMoveFocus(surface: MountedElement): boolean {
    if (!this.#live(surface)) return false;
    const modal = this.#topModal();
    return !modal || modal.token === surface.token || this.#ownedBy(surface, modal);
  }

  #canRestoreFocus(surface: MountedElement, target?: Element | null): boolean {
    if (!surface.layer && !surface.modal) {
      let focused = surface.element.ownerDocument.activeElement;
      while (focused?.shadowRoot?.activeElement) focused = focused.shadowRoot.activeElement;
      if (focused && focused !== surface.element.ownerDocument.body && focused.isConnected && !this.#containsTarget(surface, focused)) return false;
    }
    for (const candidate of this.#mounted.values()) {
      if (!isMountedElement(candidate) || !candidate.dismissable || candidate.token <= surface.token || !this.#live(candidate)) continue;
      if (candidate.layer || this.#ownedBy(candidate, surface)) return false;
    }
    const modal = this.#topModal();
    return !modal || (target ? this.#containsTarget(modal, target)
      : modal.token === surface.token || this.#ownedBy(surface, modal));
  }

  #dismissableChildren(surface: MountedElement): MountedElement[] {
    if (!this.#mounted.has(surface.token)) return [];
    return [...this.#mounted.values()].filter((candidate): candidate is MountedElement =>
      isMountedElement(candidate) && candidate.token !== surface.token && candidate.dismissable === true
      && this.#live(candidate) && this.#ownedBy(candidate, surface));
  }

  #dispatchChildEscape(surface: MountedElement, event: KeyboardEvent): ElementSurfaceResolution {
    const active = this.#dispatching.get(event);
    const child = this.#dismissableChildren(surface).sort((a, b) => b.token - a.token).find(candidate =>
      !active?.has(candidate.token) && (candidate.layer || this.#containsTarget(candidate, event.target)));
    if (!child) return Object.freeze({ kind: 'unclaimed' });
    const result = this.#resolve(child, event, 'Escape', new Set(), surface.token);
    if (result.kind === 'unclaimed' && active?.has(surface.token)) this.#delegatedOwners.add(surface.token);
    return result;
  }

  /** Native exceptions belong to the control or its explicitly declared composite. */
  dispatchNativeOverride(
    event: KeyboardEvent,
    combo: string,
    nativeOwner: EventTarget,
  ): ElementSurfaceResolution {
    const visited = new Set<number>();
    const invokeOverride = (surface: MountedElement): ElementSurfaceResolution | undefined => {
      if (visited.has(surface.token) || !surface.nativeOverrides?.includes(combo)) return;
      visited.add(surface.token);
      if (!surface.keys[combo] || !this.#live(surface)) return;
      if (!this.canActivate(`${surface.name}:${surface.token}`)) {
        const child = combo === 'Escape' && surface.dismissable ? this.#dispatchChildEscape(surface, event) : undefined;
        return child?.kind !== 'unclaimed' && child ? child : Object.freeze({ kind: 'blocked', name: surface.name });
      }
      return this.#resolve(surface, event, combo, new Set());
    };
    for (const target of event.composedPath()) {
      const owners = this.#elements.get(target as Element);
      for (const surface of [...owners?.values() ?? []].sort((a, b) => b.token - a.token)) {
        const result = invokeOverride(surface);
        if (result) return result;
      }
      if (target === nativeOwner) break;
    }
    for (const surface of [...this.#nativeOwners.get(nativeOwner as Element)?.values() ?? []].sort((a, b) => b.token - a.token)) {
      const result = invokeOverride(surface);
      if (result) return result;
    }
    return Object.freeze({ kind: 'unclaimed' });
  }

  /** A modal retains focus containment while an owned popup retains dismissal. */
  dispatchFocus(event: KeyboardEvent, combo: string): ElementSurfaceResolution {
    const path = event.composedPath();
    const visited = new Set<number>();
    // A modal owns containment globally, even if focus was programmatically
    // moved into an older modal. Popovers without a containment policy do not
    // displace it merely because they opened more recently.
    for (const surface of [...this.#layers.values()].sort((a, b) => b.token - a.token)) {
      if (!this.#live(surface)) continue;
      const handler = surface.focusKeys?.[combo];
      if (!handler) {
        if (surface.modal && (combo === 'Tab' || combo === 'Shift+Tab')) {
          return Object.freeze({ kind: 'blocked', name: surface.name });
        }
        continue;
      }
      visited.add(surface.token);
      const result = handler(event, surface.element);
      if (result !== HOTKEY_DELEGATE) {
        return Object.freeze({ kind: result === HOTKEY_PASS ? 'blocked' : 'handled', name: surface.name });
      }
    }
    for (const target of path) {
      for (const candidate of [...this.#elements.get(target as Element)?.values() ?? []].sort((a, b) => b.token - a.token)) {
        let surface: MountedSurface | undefined = candidate;
        while (surface && !visited.has(surface.token)) {
          if (!this.#live(surface)) break;
          visited.add(surface.token);
          const handler = surface.focusKeys?.[combo];
          if (handler && surface.element) {
            const result = handler(event, surface.element);
            if (result !== HOTKEY_DELEGATE) {
              return Object.freeze({ kind: result === HOTKEY_PASS ? 'blocked' : 'handled', name: surface.name });
            }
          }
          surface = this.#parent(surface);
        }
      }
    }
    return Object.freeze({ kind: 'unclaimed' });
  }

  /**
   * Resolve open layers by mount order, then ordinary surfaces on the DOM path.
   * `within` confines resolution to one container's subtree (never its ancestors).
   */
  dispatchElement(event: KeyboardEvent, combo: string, within?: Element): ElementSurfaceResolution {
    const path = typeof event.composedPath === 'function'
      ? event.composedPath()
      : [];
    const inside = (surface: MountedElement) => !within || within === surface.element
      || within.contains(surface.element)
      || [...this.#elements.get(within)?.values() ?? []].some(owner => this.#ownedBy(surface, owner));
    const pathOrder = new Map<EventTarget, number>();
    path.forEach((target, index) => pathOrder.set(target, index));
    const pathCandidates = [...pathOrder.keys()]
      .flatMap((target) => [...this.#elements.get(target as Element)?.values() ?? []])
      .filter(inside)
      .sort((a, b) =>
        (pathOrder.get(a.element) ?? Number.MAX_SAFE_INTEGER)
        - (pathOrder.get(b.element) ?? Number.MAX_SAFE_INTEGER)
        || b.token - a.token);
    const layers = [...this.#layers.values()]
      .filter(inside)
      .sort((a, b) => b.token - a.token);
    const ordered: typeof pathCandidates = [];
    const included = new Set<number>();
    for (const layer of layers) {
      for (const candidate of pathCandidates) {
        if (
          included.has(candidate.token)
          || (candidate.token !== layer.token && !this.#ownedBy(candidate, layer))
        ) continue;
        ordered.push(candidate);
        included.add(candidate.token);
      }
      if (!included.has(layer.token)) {
        ordered.push(layer);
        included.add(layer.token);
      }
    }
    for (const candidate of pathCandidates) {
      if (!included.has(candidate.token)) ordered.push(candidate);
    }
    for (const surface of ordered) {
      const result = this.#resolve(surface, event, combo, new Set());
      if (result.kind !== 'unclaimed') return result;
    }
    return Object.freeze({ kind: 'unclaimed' });
  }

  #resolve(surface: MountedSurface, event: KeyboardEvent, combo: string, visited: Set<number>, boundary?: number): ElementSurfaceResolution {
    let active = this.#dispatching.get(event);
    if (!active) this.#dispatching.set(event, active = new Set());
    active.add(surface.token);
    try {
      return this.#resolveKey(surface, event, combo, visited, boundary);
    } finally {
      active.delete(surface.token);
      this.#delegatedOwners.delete(surface.token);
      if (!active.size) this.#dispatching.delete(event);
    }
  }

  #resolveKey(surface: MountedSurface, event: KeyboardEvent, combo: string, visited: Set<number>, boundary?: number): ElementSurfaceResolution {
    if (!this.#live(surface)) return Object.freeze({ kind: 'unclaimed' });
    if (isMountedElement(surface) && surface.dismissable && !this.canActivate(`${surface.name}:${surface.token}`)) {
      const blocker = [...this.#layers.values()].sort((a, b) => b.token - a.token)
        .find(candidate => !candidate.transparent && this.#live(candidate));
      const delegated = this.#delegatedOwners.has(surface.token) && blocker && this.#ownedBy(blocker, surface);
      if (!delegated) {
        const child = combo === 'Escape' ? this.#dispatchChildEscape(surface, event) : undefined;
        return child?.kind !== 'unclaimed' && child ? child : Object.freeze({ kind: 'blocked', name: surface.name });
      }
    }
    if (visited.has(surface.token)) return Object.freeze({ kind: 'blocked', name: surface.name });
    visited.add(surface.token);
    const handler = surface.keys[combo];
    if (handler && surface.element) {
      const result = handler(event, surface.element);
      if (result === HOTKEY_DELEGATE) return this.#delegate(surface, event, combo, visited, boundary);
      return Object.freeze({ kind: result === HOTKEY_PASS ? 'blocked' : 'handled', name: surface.name });
    }
    if (surface.delegate === 'all' || surface.delegate?.includes(combo)) {
      return this.#delegate(surface, event, combo, visited, boundary);
    }
    return surface.transparent
      ? Object.freeze({ kind: 'unclaimed' })
      : Object.freeze({ kind: 'blocked', name: surface.name });
  }

  #delegate(surface: MountedSurface, event: KeyboardEvent, combo: string, visited: Set<number>, boundary?: number): ElementSurfaceResolution {
    let parent = this.#parent(surface);
    while (parent) {
      if (parent.token === boundary) return Object.freeze({ kind: 'unclaimed' });
      this.#delegatedOwners.add(parent.token);
      const result = this.#resolve(parent, event, combo, visited, boundary);
      if (result.kind !== 'unclaimed') return result;
      parent = this.#parent(parent);
    }
    // Exhausting an explicit owner chain never exposes an unrelated global scope.
    return Object.freeze({ kind: 'blocked', name: surface.name });
  }

  #parent(surface: MountedSurface): MountedSurface | undefined {
    const logical = surface.parentId ? this.#instances.get(surface.parentId) : undefined;
    // Forwarding wrappers may deliberately share one host. Their explicit
    // lineage wins; climbing parentElement would discard that ownership.
    if (logical?.element === surface.element && logical) return logical;
    if (surface.element) {
      // A deferred observer can attach after the control that owns this exact
      // host. Preserve that control's keyboard contract before climbing out of
      // the host, but only within the observer's declared ownership lineage.
      const peers = [...this.#elements.get(surface.element)?.values() ?? []]
        .filter(candidate => candidate.token < surface.token)
        .sort((a, b) => b.token - a.token);
      for (const peer of peers) {
        if (!logical) return peer;
        const visited = new Set<number>([surface.token, peer.token]);
        let ancestor = this.#parent(peer);
        while (ancestor && !visited.has(ancestor.token)) {
          if (ancestor.token === logical.token) return peer;
          visited.add(ancestor.token);
          ancestor = this.#parent(ancestor);
        }
      }
    }
    let parent = surface.element?.parentElement ?? null;
    while (parent) {
      const owner = [...this.#elements.get(parent)?.values() ?? []].sort((a, b) => b.token - a.token)[0];
      if (owner) {
        if (!logical?.element || logical.element.contains(owner.element)) return owner;
        // A nearer composite can also belong to the declared owner through a
        // portal. DOM ancestors outside that ownership chain have no authority.
        const visited = new Set<number>();
        let ancestor: MountedSurface | undefined = owner;
        while (ancestor && !visited.has(ancestor.token)) {
          if (ancestor.token === logical.token) return owner;
          visited.add(ancestor.token);
          ancestor = ancestor.parentId ? this.#instances.get(ancestor.parentId) : undefined;
        }
        return logical;
      }
      parent = parent.parentElement;
    }
    return logical;
  }

  #ownedBy(surface: MountedSurface, owner: MountedElement): boolean {
    if (surface.element && owner.element.contains(surface.element)) return true;
    const visited = new Set<number>([surface.token]);
    let parent = this.#parent(surface);
    while (parent && !visited.has(parent.token)) {
      if (parent.token === owner.token) return true;
      visited.add(parent.token);
      parent = this.#parent(parent);
    }
    return false;
  }

  #remember(surface: MountedSurface): void {
    this.#mounted.set(surface.token, surface);
    this.#instances.set(`${surface.name}:${surface.token}`, surface);
    if (isMountedElement(surface)) {
      let owners = this.#elements.get(surface.element);
      if (!owners) this.#elements.set(surface.element, owners = new Map());
      owners.set(surface.token, surface);
      if (surface.layer) this.#layers.set(surface.token, surface);
      for (const nativeOwner of surface.nativeOwners ?? []) {
        let composites = this.#nativeOwners.get(nativeOwner);
        if (!composites) this.#nativeOwners.set(nativeOwner, composites = new Map());
        composites.set(surface.token, surface);
      }
    }
    if (surface.parentId) {
      let children = this.#children.get(surface.parentId);
      if (!children) this.#children.set(surface.parentId, children = new Set());
      children.add(surface.token);
    }
    this.#instancesDirty = true;
  }

  #forget(token: number): boolean {
    const surface = this.#mounted.get(token);
    if (!surface) return false;
    this.#mounted.delete(token);
    this.#instances.delete(`${surface.name}:${surface.token}`);
    this.#layers.delete(token);
    if (surface.element) {
      const owners = this.#elements.get(surface.element);
      owners?.delete(token);
      if (!owners?.size) this.#elements.delete(surface.element);
      for (const nativeOwner of surface.nativeOwners ?? []) {
        const composites = this.#nativeOwners.get(nativeOwner);
        composites?.delete(token);
        if (!composites?.size) this.#nativeOwners.delete(nativeOwner);
      }
    }
    if (surface.parentId) {
      const children = this.#children.get(surface.parentId);
      children?.delete(token);
      if (!children?.size) this.#children.delete(surface.parentId);
    }
    this.#instancesDirty = true;
    return true;
  }

  #forgetTree(token: number): boolean {
    const surface = this.#mounted.get(token);
    if (!surface) return false;
    const descendants = [token];
    for (const descendantToken of descendants) {
      const descendant = this.#mounted.get(descendantToken);
      if (!descendant) continue;
      descendants.push(...this.#children.get(`${descendant.name}:${descendant.token}`) ?? []);
      this.#forget(descendantToken);
    }
    return true;
  }

  #schedulePublication(): void {
    if (this.#publicationScheduled || this.#listeners.size === 0) return;
    this.#publicationScheduled = true;
    queueMicrotask(() => {
      this.#publicationScheduled = false;
      if (this.#instancesDirty && this.#listeners.size > 0) this.#derive();
    });
  }

  #derive(): void {
    this.#instancesDirty = false;
    this.#snapshot = { activeSurfaces: [...this.#mounted.values()].sort((a, b) => b.token - a.token).map(surface => ({
      name: surface.name, instanceId: surface.name + ':' + surface.token,
      parentId: (() => { const parent = this.#parent(surface); return parent ? parent.name + ':' + parent.token : null; })(),
      keys: [...new Set([...Object.keys(surface.keys), ...Object.keys(surface.focusKeys ?? {})])],
      openedAt: surface.token, transparent: surface.transparent, layer: surface.layer,
    })) };
    for (const listener of this.#listeners) listener();
  }
}

export const surfaceRegistry = new TestSurfaceRegistry();
export const mountElementSurfaceLease = (definition: ElementSurfaceDefinition): ElementSurfaceLease => surfaceRegistry.mountElementLease(definition);

export function isTextEntry(value: unknown): boolean {
  if (!isSurfaceElement(value)) return false;
  const tag = value.tagName.toLowerCase();
  return value.getAttribute('data-ui-text-entry') === 'true' || tag === 'input' || tag === 'textarea' || value.getAttribute('contenteditable') === 'true';
}

function comboFor(event: KeyboardEvent): string | null {
  if (['Control', 'Meta', 'Alt', 'Shift'].includes(event.key)) return null;
  const key = /^Digit\d$/.test(event.code) ? event.code : event.key === ' ' ? 'Space' : event.key.length === 1 ? event.key.toUpperCase() : event.key;
  const control = event.ctrlKey ? 'Ctrl+' : event.metaKey ? (/^Arrow/.test(key) ? 'Meta+' : 'Ctrl+') : '';
  return control + (event.altKey ? 'Alt+' : '') + (event.shiftKey ? 'Shift+' : '') + key;
}

interface TestDispatcherEnvironment {
  readonly window: Window;
  readonly document: Document;
  readonly registry: TestSurfaceRegistry;
  readonly commands?: { dispatch: (...args: never[]) => unknown };
  readonly runtime?: () => unknown;
}

/** A host-owned capture dispatcher exercises native admission, overrides and modal focus policy. */
export function attachDispatcher({ window: ownerWindow, registry }: TestDispatcherEnvironment): Dispose {
  const handled = (event: KeyboardEvent, resolution: ElementSurfaceResolution): boolean => {
    if (resolution.kind !== 'handled') return false;
    event.preventDefault(); event.stopPropagation(); return true;
  };
  const dispatch = (event: KeyboardEvent) => {
    if (event.isComposing || event.key === 'Process' || event.keyCode === 229) return;
    const combo = comboFor(event);
    if (!combo) return;
    const path = event.composedPath();
    const nativeOwner = path.findIndex(target => isSurfaceElement(target) && nativeOwnsCombo(combo, target.getAttribute('data-ui-keyboard-owner')?.split(/\s+/) ?? []));
    if (nativeOwner >= 0 && combo === 'Escape' && (path[nativeOwner] as Element).hasAttribute('data-ui-modal')) {
      const owner = path[nativeOwner] as Element;
      const result = registry.dispatchElement(event, combo, owner);
      if (!handled(event, result) && !registry.allowsNative(owner)) { event.preventDefault(); event.stopPropagation(); }
      return;
    }
    const tabOwner = (combo === 'Tab' || combo === 'Shift+Tab') ? path.findIndex(target => isSurfaceElement(target) && target.hasAttribute('data-ui-keyboard-owner')) : -1;
    const overrideOwner = tabOwner >= 0 ? tabOwner : nativeOwner;
    if (overrideOwner >= 0) {
      const owner = path[overrideOwner] as Element;
      if (!registry.allowsNative(owner)) {
        if (combo === 'Tab' || combo === 'Shift+Tab') registry.dispatchFocus(event, combo);
        event.preventDefault(); event.stopPropagation(); return;
      }
      const result = registry.dispatchNativeOverride(event, combo, owner);
      if (handled(event, result) || result.kind !== 'unclaimed') return;
    }
    if (handled(event, registry.dispatchFocus(event, combo)) || nativeOwner >= 0) return;
    handled(event, registry.dispatchElement(event, combo));
  };
  ownerWindow.addEventListener('keydown', dispatch, { capture: true });
  return () => { ownerWindow.removeEventListener('keydown', dispatch, { capture: true }); };
}
