// @vitest-environment happy-dom
import { afterEach, describe, expect, it, vi } from 'vitest';
import { HOTKEY_DELEGATE } from '../src/contracts/platform';
import { attachDispatcher, TestSurfaceRegistry } from './surface-host';

afterEach(() => { document.body.replaceChildren(); });

describe('neutral browser host', () => {
  it('revokes portal descendants with their owning lease', () => {
    const registry = new TestSurfaceRegistry();
    const owner = document.createElement('div');
    const portal = document.createElement('div');
    document.body.append(owner, portal);
    const parent = registry.mountElementLease({ name: 'owner', element: owner, transparent: true, layer: false, keys: {} });
    const child = registry.mountElementLease({ name: 'portal', element: portal, parentId: parent.instanceId, transparent: false, layer: true, keys: {} });
    expect(child.authority.canActivate()).toBe(true);
    parent.dispose();
    expect(child.authority.canActivate()).toBe(false);
    expect(registry.read().activeSurfaces).toEqual([]);
    child.dispose();
  });

  it('blocks covered controls and admits explicitly related activation roots', () => {
    const registry = new TestSurfaceRegistry();
    const background = document.createElement('button');
    const trigger = document.createElement('button');
    const popup = document.createElement('div');
    document.body.append(background, trigger, popup);
    const ordinary = registry.mountElementLease({ name: 'background', element: background, transparent: true, layer: false, keys: {} });
    const related = registry.mountElementLease({ name: 'trigger', element: trigger, transparent: true, layer: false, keys: {} });
    const layer = registry.mountElementLease({ name: 'popup', element: popup, transparent: false, layer: true, modal: true, activationRoots: [trigger], keys: {} });
    expect(ordinary.authority.canActivate()).toBe(false);
    expect(related.authority.canActivate()).toBe(true);
    expect(ordinary.authority.canMoveFocus()).toBe(false);
    layer.dispose();
    expect(ordinary.authority.canActivate()).toBe(true);
    ordinary.dispose(); related.dispose();
  });

  it('delegates to the logical owner and releases its capture listener', () => {
    const registry = new TestSurfaceRegistry();
    const parent = document.createElement('div');
    const child = document.createElement('button');
    parent.append(child); document.body.append(parent);
    const handler = vi.fn();
    const owner = registry.mountElementLease({ name: 'parent', element: parent, transparent: false, layer: false, keys: { Enter: handler } });
    const nested = registry.mountElementLease({ name: 'child', element: child, parentId: owner.instanceId, transparent: false, layer: false, keys: { Enter: () => HOTKEY_DELEGATE } });
    const stop = attachDispatcher({ window, document, registry });
    const press = () => child.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
    expect(press()).toBe(false);
    expect(handler).toHaveBeenCalledOnce();
    stop();
    expect(press()).toBe(true);
    expect(handler).toHaveBeenCalledOnce();
    nested.dispose(); owner.dispose();
  });
});
