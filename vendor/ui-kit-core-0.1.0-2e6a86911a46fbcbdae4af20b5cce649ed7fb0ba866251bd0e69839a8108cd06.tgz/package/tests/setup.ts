import { afterAll, afterEach } from 'vitest';
import { OBSERVE } from 'solid-js';
import { configureSurfacePlatform } from '../src/runtime/platform';
import { surfaceRegistry } from './surface-host';

const releasePlatform = configureSurfacePlatform(surfaceRegistry.platform);
afterAll(releasePlatform);

const reads = new Set<string>();
const unsubscribe = OBSERVE!.diagnostics.subscribe(event => {
  if (event.code === 'STRICT_READ_UNTRACKED') reads.add(`${event.message}\n${new Error().stack}`);
});
const assertTracked = () => {
  const failures = [...reads];
  reads.clear();
  if (failures.length) throw new Error(`Reactive reads must be tracked or explicitly captured.\n\n${failures.join('\n\n')}`);
};
afterEach(assertTracked);
afterEach(() => { surfaceRegistry.reset(); });
afterAll(() => { unsubscribe(); assertTracked(); });
