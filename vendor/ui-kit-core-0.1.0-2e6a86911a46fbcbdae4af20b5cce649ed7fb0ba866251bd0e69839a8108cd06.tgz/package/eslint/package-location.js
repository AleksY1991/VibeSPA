import { existsSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';

export const DESIGN_SYSTEM_PACKAGE_ROOT = fileURLToPath(new URL('..', import.meta.url));
const normalize = value => path.posix.normalize(value.replaceAll('\\', '/'));
const packageRoot = normalize(DESIGN_SYSTEM_PACKAGE_ROOT).replace(/\/$/, '');

/** A stable policy identity for source checkouts and installed packages alike. */
export function designSystemFilename(filename) {
  const value = normalize(filename);
  return value.toLowerCase().startsWith(`${packageRoot.toLowerCase()}/`)
    ? `packages/design-system/${value.slice(packageRoot.length + 1)}` : value;
}

/** Local fixture workspaces take precedence; installed consumers use this package. */
export function designSystemPackageRoot(root = process.cwd()) {
  const local = path.resolve(root, 'packages/design-system');
  if (existsSync(path.join(local, 'package.json')) || existsSync(path.join(local, 'src'))) return local;
  return DESIGN_SYSTEM_PACKAGE_ROOT;
}

export function designSystemManifest(root = process.cwd()) {
  return JSON.parse(readFileSync(path.join(designSystemPackageRoot(root), 'package.json'), 'utf8'));
}

export function resolveDesignSystemImport(specifier, root = process.cwd()) {
  const manifest = designSystemManifest(root);
  const key = specifier === manifest.name ? '.' : specifier.startsWith(`${manifest.name}/`) ? `.${specifier.slice(manifest.name.length)}` : undefined;
  const target = key && manifest.exports?.[key];
  if (typeof target === 'string') return path.resolve(designSystemPackageRoot(root), target);
  if (key?.startsWith('./eslint/')) {
    const wildcard = manifest.exports?.['./eslint/*'];
    if (typeof wildcard === 'string') return path.resolve(designSystemPackageRoot(root), wildcard.replace('*', key.slice('./eslint/'.length)));
  }
  return undefined;
}

/** Resolve consumer aliases from its own tsconfig, never a design-system allowlist. */
export function resolveConsumerImport(filename, specifier, root = process.cwd()) {
  const owned = resolveDesignSystemImport(specifier, root);
  if (owned) return owned;
  if (specifier.startsWith('.')) return path.resolve(path.dirname(filename), specifier);
  const configPath = ts.findConfigFile(root, ts.sys.fileExists);
  if (configPath) {
    const config = ts.readConfigFile(configPath, ts.sys.readFile);
    // Import resolution needs compiler options, not the consumer's source list.
    const parsed = ts.parseJsonConfigFileContent(config.config, { ...ts.sys, readDirectory: () => [] }, path.dirname(configPath));
    const resolved = ts.resolveModuleName(specifier, filename, parsed.options, ts.sys).resolvedModule;
    if (resolved) return resolved.resolvedFileName;
  }
  try { return createRequire(path.resolve(root, 'package.json')).resolve(specifier); }
  catch { return specifier; }
}
