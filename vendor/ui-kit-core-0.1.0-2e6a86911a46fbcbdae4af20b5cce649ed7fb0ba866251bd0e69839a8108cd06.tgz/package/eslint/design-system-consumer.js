import path from 'node:path';
import selectorParser from 'postcss-selector-parser';
import {
  DESIGN_SYSTEM_COMPONENTS,
  DESIGN_SYSTEM_AS_HOSTS,
  decodeCss,
  fontFamilyNames,
  designSystemOwnership,
  designSystemConsumerStylesheetProblems,
  isDesignSystemOwner,
  isDesignSystemPlacementProperty,
  isDesignSystemPresentationProperty,
  ownsDesignSystemAppearance,
  isProtectedDesignSystemSelector,
  isProtectedDesignSystemVariable,
} from './design-system-ownership.js';

const FORBIDDEN_PROPS = new Set(['css', 'sx', 'asChild', 'ref', 'innerHTML', 'outerHTML', 'dangerouslySetInnerHTML', 'onElement', 'onNativeElement', 'onContentElement']);
const CLASSES = new Set(['class', 'className', 'classList']);
const CLOSED_PRESENTATION_CONTROLS = new Set(['Button', 'TextField', 'SearchField', 'Textarea', 'Select', 'Dialog', 'Card', 'Popover']);
const PRIVATE_MARKER = /^(?:(?:attr|prop):)?data-(?:ui|wa)-/;
const RAW_EVENT = /^on(?::(?:.+)|(?:Click|DblClick|DoubleClick|KeyDown|KeyUp|KeyPress|PointerDown|PointerUp|MouseDown|MouseUp))$/;
const normalize = value => path.posix.normalize(value.replaceAll('\\', '/'));
const unwrap = node => node?.type === 'JSXExpressionContainer' ? unwrap(node.expression)
  : ['TSAsExpression', 'TSTypeAssertion', 'TSSatisfiesExpression', 'TSNonNullExpression', 'ChainExpression', 'TSInstantiationExpression'].includes(node?.type) ? unwrap(node.expression) : node;
const nameOf = node => node?.type === 'JSXNamespacedName' ? `${node.namespace.name}:${node.name.name}`
  : ['Identifier', 'JSXIdentifier', 'PrivateIdentifier'].includes(node?.type) ? node.name
    : node?.type === 'Literal' ? String(node.value) : undefined;
const unsafeClass = value => /(?:^|\s)(?:!?[\w-]+:|[^\s]*\[[^\]]*\]|(?:h|min-h|max-h|size|p[trblxyse]?|gap(?:-[xy])?|space-[xy]|bg|text|font|leading|tracking|rounded|border|outline|ring|shadow|opacity|scale|rotate|translate|skew|overflow|cursor|pointer-events|select|transition|animate)-)/.test(value);

/** Consumers can place complete controls, but cannot replace their paint or behavior. */
export const DESIGN_SYSTEM_CONSUMER = {
  meta: { type: 'problem', schema: [], messages: {
    privateImport: 'Import the design system through its curated public exports. Private vendor, source and implementation paths cannot be consumer dependencies.',
    override: '{{component}} owns its appearance and behavior. Remove {{property}} and choose an explicit public control option.',
    recipe: '{{component}} owns {{property}}. Choose an approved recipe; class/style and individual presentation overrides are not public control inputs.',
    placement: '{{component}} owns {{property}}. Consumer style may set only outer placement such as width, margins, position and flex item alignment.',
    unknown: '{{component}} consumer props/classes must be statically checkable. Pass explicit properties or a finite typed shape so overrides cannot hide in a dynamic spread.',
    variable: 'Design-system custom property {{property}} is immutable in consumers, including ancestors.',
    selector: 'Design-system selectors, parts, data markers and vendor elements are private. Compose a public control instead of reaching into its implementation.',
    mutation: 'Consumer code cannot mutate a design-system host or inject styling for its implementation. Use the public state, variant and interaction contracts.',
    font: 'Design-system font registrations are private. Consumer FontFace constructors require finite explicit families outside the ui- namespace.',
  } },
  create(context) {
    const filename = normalize(context.filename);
    if (isDesignSystemOwner(filename) || !/(?:^|\/)(?:src|catalog)\//.test(filename)) return {};
    if (/\.(?:test(?:-helpers?)?|spec|fixture)\.[cm]?[jt]sx?$|\/(?:__tests__|tests)\//.test(filename)) return {};
    const root = normalize(context.cwd ?? process.cwd());
    const ownership = designSystemOwnership(root);
    const source = context.sourceCode;
    const controlClasses = new Set();
    const controlIds = new Set();
    const controlEventHandlers = new Set();
    const mutationCandidates = [];
    const reported = new WeakMap();
    const report = (node, messageId, data = {}) => {
      if (!node) return;
      const key = `${messageId}:${data.property ?? ''}`;
      const keys = reported.get(node) ?? new Set();
      if (keys.has(key)) return;
      keys.add(key); reported.set(node, keys);
      context.report({ node, messageId, data });
    };
    const definitions = node => {
      for (let scope = source.getScope(node); scope; scope = scope.upper) {
        const variable = scope.set.get(node.name);
        if (variable) return variable.defs;
      }
      return [];
    };
    const typeOf = value => {
      if (value?.type === 'OwnershipTypedValue') return { type: value.valueType, checker: value.checker, node: value.node };
      const services = source.parserServices;
      const node = services?.esTreeNodeToTSNodeMap?.get(unwrap(value));
      return node && services.program ? { type: services.program.getTypeChecker().getTypeAtLocation(node), checker: services.program.getTypeChecker(), node } : undefined;
    };
    const staticStrings = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return undefined;
      seen.add(node);
      if (node.type === 'Literal') return typeof node.value === 'string' ? [node.value] : node.value == null || typeof node.value === 'boolean' ? [] : undefined;
      if (node.type === 'TemplateLiteral' && !node.expressions.length) return [node.quasis[0].value.cooked];
      if (node.type === 'Identifier') {
        if (node.name === 'undefined') return [];
        for (const definition of definitions(node)) if (definition.type === 'Variable') {
          const found = staticStrings(definition.node.init, new Set(seen));
          if (found) return found;
        }
      }
      if (node.type === 'ConditionalExpression' || node.type === 'LogicalExpression') {
        const first = staticStrings(node.consequent ?? node.left, new Set(seen));
        const second = staticStrings(node.alternate ?? node.right, new Set(seen));
        if (first && second) return [...first, ...second];
      }
      if (node.type === 'BinaryExpression' && node.operator === '+') {
        const first = staticStrings(node.left, new Set(seen));
        const second = staticStrings(node.right, new Set(seen));
        if (first && second) return first.flatMap(a => second.map(b => a + b));
      }
      if (node.type === 'CallExpression' && ['cn', 'clsx', 'classNames'].includes(nameOf(node.callee))) {
        const parts = node.arguments.map(argument => staticStrings(argument, new Set(seen)));
        if (parts.every(Boolean)) return parts.flat();
      }
      const typed = typeOf(node);
      if (typed) {
        const values = [];
        for (const member of typed.type.types ?? [typed.type]) {
          if (typeof member.value === 'string') values.push(member.value);
          else if (!['undefined', 'null', 'false', 'true', 'never'].includes(typed.checker.typeToString(member))) return undefined;
        }
        return values;
      }
      return undefined;
    };
    const staticKey = node => node?.computed ? staticStrings(node.key)?.[0] : nameOf(node?.key);
    const browserGlobals = new Set(['window', 'self', 'globalThis']);
    const globalProperty = (owner, name) => browserGlobals.has(owner) ? name
      : owner === 'document' && name === 'defaultView' ? 'window' : undefined;
    const patternGlobal = (pattern, target, owner) => {
      if (pattern === target) return owner;
      if (pattern?.type === 'AssignmentPattern') return patternGlobal(pattern.left, target, owner);
      if (pattern?.type !== 'ObjectPattern') return;
      for (const property of pattern.properties) {
        if (property.type !== 'Property') continue;
        const found = patternGlobal(property.value, target, globalProperty(owner, staticKey(property)));
        if (found) return found;
      }
    };
    const globalName = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return;
      seen.add(node);
      if (node.type === 'Identifier') {
        const bindings = definitions(node);
        if (bindings.length === 0) return node.name;
        if (bindings.length === 1 && bindings[0].type === 'Variable') {
          const definition = bindings[0];
          return patternGlobal(definition.node.id, definition.name, globalName(definition.node.init, seen));
        }
      }
      if (node.type === 'MemberExpression') return globalProperty(globalName(node.object, seen),
        node.computed ? staticStrings(node.property)?.[0] : nameOf(node.property));
    };
    const component = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return undefined;
      seen.add(node);
      if (node.type === 'AwaitExpression') return component(node.argument, seen);
      if (node.type === 'ImportExpression' && (staticStrings(node.source) ?? []).some(value => /^@ui-kit\/core(?:\/|$)/.test(value))) return { namespace: true };
      if (node.type === 'CallExpression' && nameOf(node.callee) === 'require'
        && (staticStrings(node.arguments[0]) ?? []).some(value => /^@ui-kit\/core(?:\/|$)/.test(value))) return { namespace: true };
      if (['Identifier', 'JSXIdentifier'].includes(node.type)) {
        for (const definition of definitions(node)) {
          if (definition.type === 'ImportBinding') {
            const imported = definition.parent?.source?.value;
            if (typeof imported !== 'string' || !/^@ui-kit\/core(?:\/|$)|^#ui\/internal(?:\/|$)/.test(imported)) continue;
            if (definition.node.type === 'ImportNamespaceSpecifier') return { namespace: true };
            const name = nameOf(definition.node.imported) ?? (imported.split('/').at(-1) === 'button' ? 'Button' : undefined);
            if (DESIGN_SYSTEM_COMPONENTS.has(name)) return { name };
          }
          if (definition.type === 'Variable') {
            if (definition.node.id?.type === 'ObjectPattern') {
              const property = definition.node.id.properties.find(property => nameOf(property.value) === node.name);
              if (property) {
                const owner = component(definition.node.init, new Set(seen));
                if (owner?.namespace && DESIGN_SYSTEM_COMPONENTS.has(staticKey(property))) return { name: staticKey(property) };
              }
            } else {
              const found = component(definition.node.init, new Set(seen));
              if (found) return found;
            }
          }
        }
      }
      if (node.type === 'MemberExpression' || node.type === 'JSXMemberExpression') {
        const property = node.computed ? staticStrings(node.property)?.[0] : nameOf(node.property);
        const owner = component(node.object, seen);
        if (property === 'View') return owner;
        if (owner?.namespace && DESIGN_SYSTEM_COMPONENTS.has(property)) return { name: property };
        const object = unwrap(node.object);
        if (object?.type === 'ObjectExpression') {
          const entry = object.properties.find(entry => entry.type === 'Property' && staticKey(entry) === property);
          if (entry) return component(entry.value, seen);
        }
        if (['Identifier', 'JSXIdentifier'].includes(object?.type)) for (const definition of definitions(object)) {
          const initializer = unwrap(definition.node.init);
          if (initializer?.type === 'ObjectExpression') {
            const entry = initializer.properties.find(entry => entry.type === 'Property' && staticKey(entry) === property);
            if (entry) return component(entry.value, seen);
          }
        }
      }
      // Follow re-exported and imported aliases through TypeScript's actual source symbol.
      const typed = typeOf(node);
      let symbol = typed?.type.aliasSymbol ?? typed?.type.symbol;
      if (typed && symbol) {
        if (symbol.flags & 2097152) symbol = typed.checker.getAliasedSymbol(symbol);
        const declaration = symbol.declarations?.find(declaration => isDesignSystemOwner(declaration.getSourceFile().fileName));
        const name = symbol.name;
        if (declaration && DESIGN_SYSTEM_COMPONENTS.has(name)) return { name };
      }
      return undefined;
    };
    const properties = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return undefined;
      seen.add(node);
      if (node.type === 'ObjectExpression') {
        const entries = [];
        for (const property of node.properties) {
          if (property.type === 'SpreadElement') {
            const spread = properties(property.argument, new Set(seen));
            if (!spread) return undefined;
            entries.push(...spread);
          } else {
            const key = staticKey(property);
            if (key === undefined) return undefined;
            entries.push({ key, value: property.value, node: property });
          }
        }
        return entries;
      }
      if (node.type === 'Identifier') for (const definition of definitions(node)) if (definition.type === 'Variable') {
        const found = properties(definition.node.init, new Set(seen));
        if (found) return found;
      }
      if (node.type === 'ConditionalExpression') {
        const first = properties(node.consequent, new Set(seen));
        const second = properties(node.alternate, new Set(seen));
        if (first && second) return [...first, ...second];
      }
      const typed = typeOf(node);
      if (typed) {
        const entries = [];
        for (const member of typed.type.types ?? [typed.type]) {
          if (['undefined', 'null', 'never'].includes(typed.checker.typeToString(member))) continue;
          if (member.flags & (1 | 2 | 4) || typed.checker.getIndexInfosOfType(member).length) return undefined;
          for (const property of member.getProperties()) entries.push({ key: property.name, node,
            value: { type: 'OwnershipTypedValue', valueType: typed.checker.getTypeOfSymbolAtLocation(property, typed.node), checker: typed.checker, node: typed.node } });
        }
        return entries;
      }
      return undefined;
    };
    const eventHandler = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return undefined;
      seen.add(node);
      if (['ArrowFunctionExpression', 'FunctionExpression', 'FunctionDeclaration'].includes(node.type)) return node;
      if (node.type === 'Identifier') for (const definition of definitions(node)) {
        if (definition.type === 'FunctionName') return definition.node;
        if (definition.type === 'Variable') {
          const found = eventHandler(definition.node.init, seen);
          if (found) return found;
        }
      }
      return undefined;
    };
    const checkStyle = (value, owner, label, appearance) => {
      const entries = properties(value);
      if (!entries) { if (appearance) report(owner, 'unknown', { component: label }); return; }
      for (const entry of entries) {
        if (isProtectedDesignSystemVariable(entry.key, ownership)) report(owner, 'variable', { property: entry.key });
        else if (appearance && !isDesignSystemPresentationProperty(entry.key, label)) report(owner, 'placement', { component: label, property: entry.key });
      }
    };
    const checkClass = (value, owner, label, appearance, classList = false) => {
      const values = classList ? properties(value)?.map(entry => entry.key) : staticStrings(value);
      if (!values) { if (appearance) report(owner, 'unknown', { component: label }); return; }
      for (const text of values) if (appearance && unsafeClass(text) || text.split(/\s+/).some(token =>
        (ownership.classes.has(token) || /^(?:ui|wa)-/.test(token))
        && !((!appearance || label === 'ContentEditable') && ownership.publicContentClasses?.has(token)))) {
        report(owner, 'override', { component: label, property: 'class' });
      }
    };
    const absentTypedValue = value => value?.type === 'OwnershipTypedValue'
      && (value.valueType.types ?? [value.valueType]).every(member => ['undefined', 'never'].includes(value.checker.typeToString(member)));
    const closedPresentationProperty = (key, label) => CLOSED_PRESENTATION_CONTROLS.has(label) && (
      CLASSES.has(key) || key === 'style' || /^(?:(?:attr|prop):)?(?:class|className|classList|style)(?::|$)|^(?:(?:attr|prop):)?dataset$/.test(key)
      || label === 'SearchField' && ['recipe', 'size', 'type'].includes(key)
      || label === 'Popover' && key === 'anchorClass');
    const checkPlacement = (value, owner, label) => {
      if (label === 'Dialog') {
        const values = staticStrings(value);
        if (!values) report(owner, 'unknown', { component: label });
        else if (values.some(value => !['center', 'start', 'corner'].includes(value))) report(owner, 'recipe', { component: label, property: 'placement' });
        return;
      }
      const entries = properties(value);
      if (!entries) { report(owner, 'unknown', { component: label }); return; }
      for (const entry of entries) {
        if (absentTypedValue(entry.value)) continue;
        if (!isDesignSystemPlacementProperty(entry.key)) report(owner, 'placement', { component: label, property: entry.key });
      }
    };
    const checkProperty = (key, value, owner, label, appearance) => {
      if (/^on[A-Z]/.test(key)) {
        const callback = eventHandler(value);
        if (callback) controlEventHandlers.add(callback);
      }
      if (closedPresentationProperty(key, label)) {
        if (!absentTypedValue(value)) report(owner, 'recipe', { component: label, property: key });
      } else if (key === 'placement' && CLOSED_PRESENTATION_CONTROLS.has(label)) checkPlacement(value, owner, label);
      else if (CLASSES.has(key)) checkClass(value, owner, label, appearance, key === 'classList');
      else if (key === 'style') checkStyle(value, owner, label, appearance);
      else if (key === 'attributes') checkProps(value, owner, label, appearance);
      else if (FORBIDDEN_PROPS.has(key) || key === 'as' && !DESIGN_SYSTEM_AS_HOSTS.has(label)
        || RAW_EVENT.test(key) && !(label === 'InteractionRegion' && key === 'onPointerUp')
        || PRIVATE_MARKER.test(key)) report(owner, 'override', { component: label, property: key });
      if (appearance && CLASSES.has(key)) for (const text of (key === 'classList' ? properties(value)?.map(entry => entry.key) : staticStrings(value)) ?? []) for (const token of text.split(/\s+/)) controlClasses.add(token);
      if (appearance && key === 'id') for (const id of staticStrings(value) ?? []) controlIds.add(id);
    };
    const checkProps = (value, owner, label, appearance) => {
      const entries = properties(value);
      if (!entries) { report(owner, 'unknown', { component: label }); return; }
      const protectedAppearance = appearance ?? ownsDesignSystemAppearance(label);
      for (const entry of entries) checkProperty(entry.key, entry.value, owner, label, protectedAppearance);
    };
    const checkImport = (node, value) => {
      for (const imported of staticStrings(value) ?? []) {
        const clean = imported.replace(/\?.*$/, '').replace(/(?!^)#.*$/, '');
        const resolved = clean.startsWith('.') ? normalize(path.posix.join(path.posix.dirname(filename), clean)) : normalize(clean);
        if (/^@ui-kit\/core(?:\/|$)/.test(clean) && (!ownership.publicImports.has(clean) || /^@ui-kit\/core\/vendor\//.test(clean))
          || /^@ui-kit\/core\/testing(?:\/|$)/.test(clean) && !/\.(?:test(?:-helpers?)?|spec|fixture)\.[cm]?[jt]sx?$|\/(?:__tests__|tests)\//.test(filename)
          || /^#ui\/internal(?:\/|$)|^@awesome\.me\/webawesome(?:\/|$)/.test(clean)
          || /(?:^|\/)packages\/design-system(?:\/|$)/.test(resolved)) report(node, 'privateImport');
      }
    };
    const variable = (node, property) => { if (property && isProtectedDesignSystemVariable(property, ownership)) report(node, 'variable', { property }); };
    const knownHost = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return false;
      seen.add(node);
      if (node.type === 'Identifier') return definitions(node).some(definition => definition.type === 'Variable' && knownHost(definition.node.init, new Set(seen)));
      if (node.type === 'MemberExpression') {
        const property = node.computed ? staticStrings(node.property)?.[0] : nameOf(node.property);
        const target = unwrap(node.object);
        if (property === 'currentTarget' && target?.type === 'Identifier'
          && definitions(target).some(definition => definition.type === 'Parameter' && controlEventHandlers.has(definition.node))) return true;
        return knownHost(node.object, seen);
      }
      if (node.type !== 'CallExpression' || node.callee.type !== 'MemberExpression') return false;
      const method = nameOf(node.callee.property);
      if (!['querySelector', 'querySelectorAll', 'getElementById', 'getElementsByClassName'].includes(method)) return false;
      return (staticStrings(node.arguments[0]) ?? []).some(selector => {
        if (method === 'getElementById') return controlIds.has(selector);
        if (method === 'getElementsByClassName') return selector.split(/\s+/).some(name => controlClasses.has(name));
        if (isProtectedDesignSystemSelector(selector, ownership)) return true;
        let host = false;
        try { selectorParser(selectors => selectors.walk(node => {
          if (node.type === 'class' && controlClasses.has(node.value) || node.type === 'id' && controlIds.has(node.value)) host = true;
          if (node.type === 'attribute' && node.value && ['class', 'id'].includes(node.attribute.toLowerCase())) {
            const names = node.attribute.toLowerCase() === 'class' ? controlClasses : controlIds;
            if ([...names].some(name => node.operator === '=' ? node.value.split(/\s+/).includes(name)
              : node.operator === '~=' ? node.value === name : name.includes(node.value))) host = true;
          }
        })).processSync(selector); } catch { /* Invalid query selectors cannot select a mounted host. */ }
        return host;
      });
    };
    const memberHost = node => {
      let receiver = unwrap(node);
      if (knownHost(receiver)) return true;
      while (receiver?.type === 'MemberExpression') {
        if (knownHost(receiver.object)) return true;
        receiver = unwrap(receiver.object);
      }
      return knownHost(receiver);
    };
    const checkEmbedded = (node, text) => {
      if (typeof text !== 'string') return;
      for (const match of text.matchAll(/(?:^|[;{])\s*(--(?:[\w-]|\\.)+)\s*:/g)) variable(node, match[1]);
      if (/\[[^\]]*(?:ui-|wa-|haku-|::part)/.test(text) && isProtectedDesignSystemSelector(decodeCss(text).replaceAll('_', ' '), ownership)) report(node, 'selector');
      if (text.includes('{')) {
        try { if (designSystemConsumerStylesheetProblems(text, filename, new Set(), root, ownership).length) report(node, 'mutation'); } catch { if (isProtectedDesignSystemSelector(text, ownership)) report(node, 'mutation'); }
      }
    };
    return {
      ImportDeclaration(node) { checkImport(node, node.source); },
      ExportNamedDeclaration(node) { if (node.source) checkImport(node, node.source); },
      ExportAllDeclaration(node) { checkImport(node, node.source); },
      ImportExpression(node) { checkImport(node, node.source); },
      TSImportType(node) { checkImport(node, node.source ?? node.argument?.literal ?? node.argument); },
      TSImportEqualsDeclaration(node) { if (node.moduleReference.type === 'TSExternalModuleReference') checkImport(node, node.moduleReference.expression); },
      Literal(node) { checkEmbedded(node, node.value); },
      TemplateElement(node) { checkEmbedded(node, node.value.cooked ?? node.value.raw); },
      Property(node) {
        const key=staticKey(node);
        variable(node,key);
        if (PRIVATE_MARKER.test(key ?? '')) report(node,'selector');
        if (CLASSES.has(key)) for (const value of (key === 'classList' ? properties(node.value)?.map(entry => entry.key) : staticStrings(node.value)) ?? []) {
          if (value.split(/\s+/).some(name => (ownership.classes.has(name) || /^(?:ui|wa)-/.test(name)) && !ownership.publicContentClasses?.has(name))) report(node,'selector');
        }
      },
      JSXAttribute(node) {
        const key=nameOf(node.name);
        variable(node,key?.replace(/^style:/,''));
        if (PRIVATE_MARKER.test(key ?? '')) report(node,'selector');
        if (CLASSES.has(key)) for (const value of (key === 'classList' ? properties(node.value)?.map(entry => entry.key) : staticStrings(node.value)) ?? []) {
          if (value.split(/\s+/).some(name => (ownership.classes.has(name) || /^(?:ui|wa)-/.test(name)) && !ownership.publicContentClasses?.has(name))) report(node,'selector');
        }
      },
      JSXOpeningElement(node) {
        if (node.name.type === 'JSXIdentifier' && /^wa-/.test(node.name.name)) report(node, 'selector');
        let target = component(node.name);
        if (!target?.name) {
          const dynamic = node.attributes.find(attribute => attribute.type === 'JSXAttribute' && nameOf(attribute.name) === 'component');
          target = component(dynamic?.value);
        }
        if (!target?.name) return;
        const appearance = ownsDesignSystemAppearance(target.name);
        for (const attribute of node.attributes) {
          if (attribute.type === 'JSXSpreadAttribute') checkProps(attribute.argument, attribute, target.name, appearance);
          else {
            const name = nameOf(attribute.name);
            checkProperty(name, attribute.value, attribute, target.name, appearance);
          }
        }
      },
      NewExpression(node) {
        const target = component(node.callee);
        if (target?.name) checkProps(node.arguments[0], node, target.name);
        if (globalName(node.callee) === 'FontFace') {
          const names = staticStrings(node.arguments[0]);
          if (!names?.length || names.some(value => fontFamilyNames(value).some(family => /^ui-/i.test(family ?? '')))) report(node, 'font');
        }
      },
      AssignmentExpression(node) {
        const left = unwrap(node.left);
        if (left?.type === 'MemberExpression') variable(node, left.computed ? staticStrings(left.property)?.[0] : nameOf(left.property));
        if (left?.type === 'MemberExpression' && nameOf(left.object?.property) === 'dataset'
          && /^(?:ui|wa)[A-Z]/.test(left.computed ? staticStrings(left.property)?.[0] ?? '' : nameOf(left.property) ?? '')) report(node,'selector');
        mutationCandidates.push(node);
      },
      UpdateExpression(node) { mutationCandidates.push(node); },
      UnaryExpression(node) { if (node.operator === 'delete') mutationCandidates.push(node); },
      CallExpression(node) {
        mutationCandidates.push(node);
        if (nameOf(node.callee) === 'require') checkImport(node, node.arguments[0]);
        const target = component(node.callee);
        if (target?.name) checkProps(node.arguments[0], node, target.name);
        else if (['createComponent', 'createElement', 'jsx', 'jsxs', 'jsxDEV'].includes(nameOf(node.callee))) {
          const nested = component(node.arguments[0]);
          if (nested?.name) checkProps(node.arguments[1], node, nested.name);
        }
        if (node.callee.type !== 'MemberExpression') return;
        const method = node.callee.computed ? staticStrings(node.callee.property)?.[0] : nameOf(node.callee.property);
        if (['createElement', 'createElementNS', 'getElementsByTagName'].includes(method)
          && (staticStrings(node.arguments[method === 'createElementNS' ? 1 : 0]) ?? []).some(name => /^wa-/i.test(name))) report(node, 'selector');
        if (['setAttribute','removeAttribute','setAttributeNS','removeAttributeNS'].includes(method)
          && (staticStrings(node.arguments[method.endsWith('NS') ? 1 : 0]) ?? []).some(name => /^data-(?:ui|wa)-/i.test(name))) report(node,'selector');
        if (method === 'setProperty' || method === 'removeProperty') variable(node, staticStrings(node.arguments[0])?.[0]);
        if (!/\/catalog\/measurements\.tsx$/.test(filename) && ['querySelector', 'querySelectorAll', 'closest', 'matches', 'getElementsByClassName', 'getElementsByTagName'].includes(method)) {
          for (const value of staticStrings(node.arguments[0]) ?? []) {
            const selector = method === 'getElementsByClassName' ? `.${value}` : value;
            if (isProtectedDesignSystemSelector(selector, ownership)) report(node, 'selector');
          }
          if (/\.ui-|\.wa-|\bwa-|data-ui-|::part/.test(source.getText(node.arguments[0] ?? node))) report(node, 'selector');
        }
        if (['setAttribute', 'insertRule', 'replaceSync', 'replace'].includes(method)) for (const argument of node.arguments) {
          for (const text of staticStrings(argument) ?? []) checkEmbedded(node, text);
        }
        if (['insertRule', 'replaceSync'].includes(method) && !staticStrings(node.arguments[0])) report(node, 'mutation');
      },
      'Program:exit'() {
        for (const node of mutationCandidates) {
          if (node.type === 'AssignmentExpression' && memberHost(node.left)) report(node, 'mutation');
          if (['UpdateExpression', 'UnaryExpression'].includes(node.type) && memberHost(node.argument)) report(node, 'mutation');
          if (node.type !== 'CallExpression') continue;
          const callee = unwrap(node.callee);
          if (callee?.type !== 'MemberExpression') continue;
          const method = callee.computed ? staticStrings(callee.property)?.[0] : nameOf(callee.property);
          if (memberHost(callee.object) && ['setProperty', 'removeProperty', 'setAttribute', 'removeAttribute', 'add', 'remove', 'toggle', 'replace', 'addEventListener', 'removeEventListener', 'appendChild', 'replaceChildren'].includes(method)) report(node, 'mutation');
          if (nameOf(callee.object) === 'Object' && ['assign', 'defineProperty', 'defineProperties'].includes(method) && memberHost(node.arguments[0])) report(node, 'mutation');
          if (nameOf(callee.object) === 'Reflect' && ['set', 'deleteProperty', 'defineProperty'].includes(method) && memberHost(node.arguments[0])) report(node, 'mutation');
        }
      },
    };
  },
};
