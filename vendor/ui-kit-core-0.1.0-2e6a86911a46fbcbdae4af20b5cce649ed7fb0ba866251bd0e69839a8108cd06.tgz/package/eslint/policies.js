import { FOCUS_HIGHLIGHT } from './focus-highlight.js';

// ─── One tooltip ──────────────────────────────────────────────────────────────
// `title` draws the OS bubble and cannot be themed; a second tooltip primitive is a second
// card. Default-deny on every JSX element (wrappers spread props), allow-list below.
const TITLE_IS_CONTENT = "Section|SectionHeader|PanelEmpty";

const TOOLTIP_SELECTORS = [
  {
    selector:
      `JSXOpeningElement:not([name.name='iframe']):not([name.name=/^(${TITLE_IS_CONTENT})$/])` +
      " > JSXAttribute[name.name='title']",
    message:
      '❌ TOOLTIP: `title` reaches the DOM and is drawn by the OS, not the page — a black bubble the app cannot theme (directly on a host element, or spread through a wrapper like Button). Use `data-tip="…"`, which @ui-kit/core/solid/tooltip-layer renders in the app\'s own surface. A tooltip is never the accessible name: keep `aria-label` on icon-only controls. If `title` is genuinely visible TEXT on a new component, add it to TITLE_IS_CONTENT in @ui-kit/core/eslint/policies. See DESIGN.md → Selected, hovered, focused.',
  },
  {
    selector:
      "JSXOpeningElement[name.name=/^(Tooltip|TooltipTrigger|TooltipContent|TooltipProvider|HoverCard|HoverCardTrigger|HoverCardContent)$/]",
    message:
      '❌ TOOLTIP: one tooltip in this app and it is TooltipLayer — use `data-tip="…"`. A Radix tooltip is a second card with its own delay, position and theme, which is what made the properties panel show two different tooltips for the same gesture. See DESIGN.md → Selected, hovered, focused.',
  },
  {
    selector:
      "ImportDeclaration[source.value=/(@radix-ui\\/react-(tooltip|hover-card)|\\/ui\\/(tooltip|hover-card))$/]",
    message:
      '❌ TOOLTIP: the Radix tooltip/hover-card primitives are DELETED. Use `data-tip="…"`. See DESIGN.md → Selected, hovered, focused.',
  },
];

const CALENDAR_MESSAGE =
  '❌ CALENDAR: native date, datetime-local, week, and month inputs open a second calendar. ' +
  'Use CalendarField or RangeCalendar so every date selector shares the same selection, spacing, and keyboard behavior. ' +
  'TextField type="time" remains available for native time editing.';
const CALENDAR_SELECTORS = [
  {
    selector: "JSXAttribute[name.name='type'] Literal[value=/^(date|datetime-local|week|month)$/i]",
    message: CALENDAR_MESSAGE,
  },
  {
    selector: "JSXAttribute[name.name='type'] TemplateElement[value.raw=/^(date|datetime-local|week|month)$/i]",
    message: CALENDAR_MESSAGE,
  },
  {
    selector: "JSXSpreadAttribute Property:matches([key.name='type'], [key.value='type']) Literal[value=/^(date|datetime-local|week|month)$/i]",
    message: CALENDAR_MESSAGE,
  },
  {
    selector: "JSXSpreadAttribute Property:matches([key.name='type'], [key.value='type']) TemplateElement[value.raw=/^(date|datetime-local|week|month)$/i]",
    message: CALENDAR_MESSAGE,
  },
];

// ─── Design System ────────────────────────────────────────────────────────────
export const DESIGN_SELECTORS = [
  // haku/design-geometry enforces text weights across features and primitives.
  // Shadows are removed from the system. Structural depth comes from borders and spacing.
  {
    "selector": "JSXAttribute[name.name=/^(class|className)$/] Literal[value=/\\bshadow(?:-(none|sm|md|lg|xl|2xl))?\\b/]",
    "message": "❌ DESIGN: shadows are removed. Use borders, spacing, and contrast."
  },
  {
    "selector": "TemplateElement[value.raw=/\\bshadow(?:-(none|sm|md|lg|xl|2xl))?\\b/]",
    "message": "❌ DESIGN: shadows are removed. Use borders, spacing, and contrast."
  },
  // Saturated Colors
  {
    "selector": "JSXAttribute[name.name=/^(class|className)$/] Literal[value=/\\bbg-(red|blue|green|yellow|purple|pink|orange|indigo|cyan|teal|emerald|lime|amber|fuchsia|violet|rose|sky)-[5-9]00\\b/]",
    "message": "❌ DESIGN: Saturated bg colors forbidden. Use shared background, card, muted, or semantic status color tokens."
  },
  {
    "selector": "TemplateElement[value.raw=/\\bbg-(red|blue|green|yellow|purple|pink|orange|indigo|cyan|teal|emerald|lime|amber|fuchsia|violet|rose|sky)-[5-9]00\\b/]",
    "message": "❌ DESIGN: Saturated bg colors forbidden. Use shared background, card, muted, or semantic status color tokens."
  },
  {
    "selector": "JSXAttribute[name.name=/^(class|className)$/] Literal[value=/\\btext-(red|blue|green|yellow|purple|pink|orange|indigo|cyan|teal|emerald|lime|amber|fuchsia|violet|rose|sky)-[5-9]00\\b/]",
    "message": "❌ DESIGN: Saturated text colors forbidden. Use text-foreground, text-muted-foreground, or semantic text-status-*."
  },
  {
    "selector": "TemplateElement[value.raw=/\\btext-(red|blue|green|yellow|purple|pink|orange|indigo|cyan|teal|emerald|lime|amber|fuchsia|violet|rose|sky)-[5-9]00\\b/]",
    "message": "❌ DESIGN: Saturated text colors forbidden. Use text-foreground, text-muted-foreground, or semantic text-status-*."
  },
  // Motion is removed from the system.
  {
    "selector": "JSXAttribute[name.name=/^(class|className)$/] Literal[value=/\\b(?:transition(?:-[a-z]+)?|duration-[0-9]+|animate(?:-[a-z-]+)?)\\b/]",
    "message": "❌ DESIGN: animations and transitions are removed. State changes must be immediate."
  },
  {
    "selector": "TemplateElement[value.raw=/\\b(?:transition(?:-[a-z]+)?|duration-[0-9]+|animate(?:-[a-z-]+)?)\\b/]",
    "message": "❌ DESIGN: animations and transitions are removed. State changes must be immediate."
  },
  // Circular and pill geometry is not part of the Haku structural vocabulary.
  {
    "selector": "JSXAttribute[name.name=/^(class|className)$/] Literal[value=/\\brounded-(?:full|2xl)\\b/]",
    "message": "❌ DESIGN: circular and pill geometry is removed. Use the shared square-corner radius scale."
  },
  {
    "selector": "TemplateElement[value.raw=/\\brounded-(?:full|2xl)\\b/]",
    "message": "❌ DESIGN: circular and pill geometry is removed. Use the shared square-corner radius scale."
  },
];

// ─── Palette gate ─────────────────────────────────────────────────────────────
// Every colour comes from a token in @ui-kit/core/tokens.css. Matches any string literal, so a class
// in a styles.ts or a cn() argument is covered. LIMIT: .css files are not parsed by ESLint.
const PALETTE_MESSAGE =
  "❌ PALETTE: colour literals are forbidden. Use a token from @ui-kit/core/tokens.css — " +
  "background/foreground/card/popover/primary/secondary/muted/accent/destructive/border/input/ring, " +
  "status-{success,warning,error,info,ready,neutral,review,backlog}{,-foreground,-muted,-border,-solid}, " +
  "or priority-{low,medium,high,critical}{,-foreground,-muted,-border,-solid}. " +
  "In CSS-in-JS or canvas code write hsl(var(--token)).";
const TW_PREFIX =
  "bg|text|border|ring|fill|stroke|from|via|to|divide|placeholder|decoration|outline|caret|accent|shadow";
const TW_HUE =
  "slate|gray|grey|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose";
const TW_PALETTE_RE = `\\b(?:${TW_PREFIX})-(?:${TW_HUE})-(?:50|100|200|300|400|500|600|700|800|900|950)\\b`;
// `text-white`, `bg-black/5`. There is a token for every one of these.
const TW_MONO_RE = `\\b(?:${TW_PREFIX})-(?:white|black)(?:\\/\\d{1,3})?\\b`;
// Any hex colour, including Tailwind arbitrary values like `bg-[#eee]`.
const HEX_RE = "#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\\b";
// rgb()/hsl()/oklch()/… with LITERAL channels. Two guards, both load-bearing:
//   (?!var\() keeps the sanctioned `hsl(var(--ui-border))` / `hsl(var(--haku-heat) / 0.4)` legal;
//   the trailing digit class requires a channel value to actually follow the paren, so a
//   TemplateElement that ends at `hsl(` before an interpolation — `hsl(${token})`, which
//   is a token read, not a literal — is not flagged.
const COLOR_FN_RE =
  "\\b(?:rgba?|hsla?|hwb|oklch|oklab|lab|lch|color)\\(\\s*(?!var\\()[+-]?[.\\d]";

const paletteSelectors = (re, note) => [
  { selector: `Literal[value=/${re}/]`, message: `${PALETTE_MESSAGE} (${note})` },
  { selector: `TemplateElement[value.raw=/${re}/]`, message: `${PALETTE_MESSAGE} (${note})` },
];

// ─── Canonical ink + size sets ───────────────────────────────────────────────
// Twelve inks, four sizes. Anything else is a tier nobody declared.
const INK_SELECTORS = [
  {
    re: "\\btext-(?:card|popover|accent|secondary)-foreground\\b",
    msg: "identical (or imperceptibly close) to text-foreground — use text-foreground",
  },
  {
    // SURFACE tokens used as ink. Found by audit: `text-card` on a check glyph sitting on
    // a solid status fill — a token, so the palette gate passed it, and not on the
    // deny-list, so the ink gate passed it too. This entry is what turns the deny-list
    // into an effective allow-list: every colour token in index.css is now either one of
    // the canonical twelve or explicitly not-ink. `(?![-a-z])` is load-bearing — without
    // it `text-muted` also matches `text-muted-foreground`.
    re: "\\btext-(?:background|card|popover|muted|accent|secondary|border|input|ring|scrim|heat)(?![-a-z])",
    msg: "that is a SURFACE token, not ink. Use text-foreground / text-muted-foreground, or text-status-on-solid on a fill",
  },
  {
    re: "\\btext-destructive\\b",
    msg: "use text-status-error-foreground on a surface, or text-status-on-solid on a fill",
  },
  {
    re: "\\btext-status-(?:success|warning|error|info|ready|neutral|review|backlog)(?:-solid)?(?![-a-z])",
    msg: "bare and -solid status colours are FILLS. For text use the -foreground variant",
  },
  {
    // Same fill/ink split for the priority namespace. `fill-priority-*-solid` is the
    // correct way to colour the priority flag — it is a glyph, not a text run.
    re: "\\btext-priority-(?:low|medium|high|critical)(?:-solid)?(?![-a-z])",
    msg: "bare and -solid priority colours are FILLS. For text use the -foreground variant; for the flag glyph use fill-priority-<level>-solid",
  },
  {
    re: "\\btext-(?:foreground|muted-foreground|primary|primary-foreground|status-[a-z-]+|priority-[a-z-]+)\\/\\d",
    msg: "no opacity modifiers on text — the two ink tiers are text-foreground and text-muted-foreground",
  },
];

// One size, one name. The xs/sm/base/lg/xl/2xl aliases were duplicates of the semantic
// scale that also disagreed with it on font-weight — see the note in packages/design-system/src/typography.ts.
// They no longer exist in the config, so a leftover `text-sm` silently renders at the
// inherited size; this rule is what makes that a build-stopping error instead.
const SIZE_SELECTORS = [
  {
    // Two generations of deletions. First the Tailwind aliases (xs/sm/base/…), then the
    // scale's own dead weight: `small` merged into `body`, `subheading` was 14/600 (that
    // is `text-body font-semibold`), `display` had 3 uses. Four sizes now — eight names
    // was not a hierarchy, it was eight ways for two panels to disagree, which is how the
    // View popover shipped at 11px next to the Filter menu's 13px.
    re: "\\btext-(?:xs|sm|small|base|lg|xl|2xl|3xl|4xl|5xl|subheading|display)\\b",
    msg: "deleted size. The scale is FOUR: caption 11 · body 13 · heading 17 · title 22 (+ field 16 for form controls). `subheading` uses the body role and emphasis weight.",
  },
  {
    // Arbitrary font sizes. This ban could not be written until today: 30 sites carried
    // `text-[10px]`/`text-[9px]`, below the scale's 11px floor. Eighteen were plain drift
    // in unconstrained flex rows; the other twelve were text wedged into a fixed box, and
    // the only one that genuinely could not hold 11px was a 16px avatar circle — grown to
    // 20px rather than blessing a 7th step. NO `micro: 10px` TOKEN, deliberately: naming
    // it would make "the box is too small" a permanent, reusable answer.
    re: "\\btext-\\[[0-9.]+(?:px|rem|em)\\]",
    msg: "arbitrary font size. Use the caption (11px), body (13px), heading (17px), title (22px), or field (16px) CSS role tokens",
  },
];

// ─── Hover ────────────────────────────────────────────────────────────────────
// A hover never recolours: every fill/ink/border hover measured ≤1.20 rest→hover contrast,
// under the 1.163 wash already deleted as invisible. Survivors: opacity reveal, underline.
const HILITE = "(?:focus|aria-selected|data-\\[(?:highlighted|selected)[^\\]]*\\])";
const HOVER_SELECTORS = [
  {
    re: `\\b${HILITE}:bg-accent\\b`,
    msg: "gray is not a selection state. Use the shared Button selected treatment or ui-selection-outline for the explicit current option",
  },
  {
    re: `\\b${HILITE}:bg-muted(?![-a-z])`,
    msg: "neutral surfaces carry no selection state. Use the shared Button selected treatment or ui-selection-outline for the explicit current option",
  },
  {
    // TOTAL ban, every tier — this is the deleted wash itself. `\b` matches after the `-`
    // in `group-hover:`, so the group variant is caught by the same selector.
    // ─── A HOVER MUST NOT RECOLOUR ─────────────────────────────────────────────
    // TOTAL ban on a hover FILL, every tier, with ONE carve-out: a solid button or
    // badge stepping to /90 of its OWN fill. `\b` matches after the `-` in
    // `group-hover:` and `peer-hover:`, so both group variants land here too.
    //
    // This replaces six narrower selectors (accent / muted / solid-not-/90 /
    // status+priority / status-muted-with-a-tier / surface tokens). They were a
    // vocabulary — a list of which hues you may arrive in — and a vocabulary is the
    // wrong shape for this rule, because the objection is not to any particular hue.
    // Hover does not exist on touch. A hue that appears under the pointer is
    // information a finger can never get, which makes it not information.
    //
    // NO carve-out any more. The `/90` press on a solid fill was the last exemption and
    // it died to its own measurement: rest→hover is 1.156 primary, 1.132 destructive,
    // 1.009 secondary — at or below the 1.163 accent wash this same rule already bans as
    // imperceptible. Secondary is the proof: a near-white fill at 90% over a near-white
    // page returns the same pixel. An exemption for an effect nobody can see is a hole.
    re: "\\bhover:bg-[-a-z0-9]",
    msg: "a hover must not RECOLOUR, and nothing paints a fill on mouseover — not the neutral wash (`bg-accent`/`bg-muted`), not `bg-status-error-muted` on a delete control, not a surface token, and no longer `/90` on a solid button either (measured 1.009–1.156 rest→hover, under the wash already deleted as invisible). Hover does not exist on touch, so a meaning that only arrives under a pointer is not a meaning: put it in the RESTING state (the glyph, the ink, `data-tip`), use the shared selected treatment for selection and explicit highlighted state for the active option. Two things are still legal because neither is a colour: REVEAL (`opacity-50` → `hover:opacity-100`, which measures 1.4–4.2) and UNDERLINE",
  },
  {
    // 21 uses across seven tiers — a parallel hover language with no entry in DESIGN.md.
    // 100 survives as half of the swatch pair (`opacity-50` → `hover:opacity-100`). It is
    // NOT touched by the recolour ban above and never will be: opacity reveals what is
    // already there, it does not introduce a hue. What is banned is the seven-tier taste.
    re: "\\bhover:opacity-(?!100\\b)\\d+",
    msg: "the only hover opacity is the swatch pair `opacity-50` → `hover:opacity-100` — one pair, not a per-site dimming taste (it read 40/50/60/70/75/80/90 across five pickers). The pair itself is LEGAL: a reveal is not a recolour",
  },
  {
    // TOTAL, no whitelist. `hover:border-border` used to be the AIM case, exempt from the
    // recolour ban above on the grounds that a neutral hairline marks WHICH card the
    // pointer is over without tinting it. Measured, a transparent edge going to
    // `border-border` is 1.197 against the card — which puts the sole survivor under the
    // same bar that condemned everything else here. It was an edge nobody could see.
    re: "\\bhover:border-[-\\w\\/]+",
    msg: "no hover border, at all. `hover:border-border` was the last exemption and measures 1.197 against the card it sits on — under the 1.163 accent wash already deleted as imperceptible. Selection is `border-primary`; the resting edge stays whatever it already is",
  },
  {
    // NO INK SURVIVES. There is no carve-out here at all, because unlike a fill an ink
    // has no "same colour, one step darker" tier — every hover ink is a hue arriving
    // under the pointer. `hover:text-foreground` went with the neutral wash (72 of its
    // 100 sites sat on the same line as the fill). `hover:text-status-error-foreground`
    // outlived it by one pass as the ink half of the destructive ghost pair: 22 sites,
    // every one of them a Trash2 or X glyph that already says what it does at rest.
    // Also still caught: `hover:text-primary` on a rename button (`text-primary` means
    // LINK — see "Which ink goes where") and `hover:text-muted-foreground`, a toggle
    // that DIMMED its own label on hover.
    re: "\\bhover:text-[-a-z0-9]",
    msg: "a hover must not RECOLOUR, and ink is colour. There is no hover ink left — `hover:text-status-error-foreground` went with the fill it was paired with, and `hover:text-foreground` before it. A destructive control is destructive at REST: the Trash2/X glyph, its `aria-label` and its `data-tip` say so on every device, including the ones with no pointer",
  },
];


// ─── Trial gates (2026-09-01) — the DESIGN.md rules a regex can hold ───────────
const TRIAL_SELECTORS = [
  {
    re: "(?<![\\w-])(?:border(?:-[trblxy])?|outline)-[248]\\b",
    msg: "thick border or outline. Edges are 1px hairlines; selected outlines use ui-selection-outline and the shared --ui-line-width token",
  },
  {
    re: "\\b-?(?:[pm][trblxy]?|gap(?:-[xy])?|space-[xy]|inset(?:-[xy])?|top|right|bottom|left)-\\[[0-9.]+(?:px|rem|em)\\]",
    msg: "off-grid spacing. The scale is 4px multiples; an arbitrary value is a box sized to its content instead of the grid",
  },
  {
    re: "^(?!.*\\btext-caption\\b)(?=.*\\b(?:text-|font-|tracking-|px-|py-|p-\\d|gap-|flex|items-|rounded)).*\\buppercase\\b",
    msg: "all-caps outside a caption. Caps are legal only on a tiny tracked label (text-caption tracking-wide)",
  },
];
const TRIAL_JSX_SELECTORS = [
  {
    selector: "JSXOpeningElement[name.name='button'] > JSXAttribute[name.name=/^(class|className)$/] Literal[value=/(?:^|\\s)(?:min-)?h-(?:[1-7]|7\\.5)(?:\\s|$)/]",
    message: "❌ TAP: a button painted under 32px. The floor is 32px on a fine pointer (h-8), 44px hit box on a coarse one (coarse:h-11 or .tap-44)",
  },
  {
    selector: "JSXOpeningElement[name.name=/Icon$/] > JSXAttribute[name.name=/^(class|className)$/] Literal[value=/\\b[hw]-(?:7|8|9|1[0-9]|2[0-9])\\b/]",
    message: "❌ ICON: larger than 24px. Sizes are 16 inline (h-4), 20 in a button (h-5), 24 max (h-6)",
  },
];

const moduleLiteral = ':matches(ImportDeclaration, ExportNamedDeclaration, ExportAllDeclaration, ImportExpression) > Literal.source';
const moduleTemplate = 'ImportExpression > TemplateLiteral.source > TemplateElement';
const setSelectors = (entries, prefix, excludeModuleSources = false) =>
  entries.flatMap(({ re, msg }) => [
    { selector: `Literal[value=/${re}/]${excludeModuleSources ? `:not(${moduleLiteral})` : ''}`, message: `${prefix} ${msg}` },
    { selector: `TemplateElement[value.raw=/${re}/]${excludeModuleSources ? `:not(${moduleTemplate})` : ''}`, message: `${prefix} ${msg}` },
  ]);

export const CANONICAL_SELECTORS = [
  ...setSelectors(INK_SELECTORS, "❌ INK:", true),
  ...setSelectors(SIZE_SELECTORS, "❌ SIZE:"),
  ...setSelectors(HOVER_SELECTORS, "❌ HOVER:"),
  // Keep the rule groups distinct so config coverage can detect partial gates.
  ...setSelectors(TRIAL_SELECTORS, "❌ TRIAL:"),
  ...TRIAL_JSX_SELECTORS,
  // Tooltip and calendar policy binds private controls as well as compositions.
  ...TOOLTIP_SELECTORS,
  // Primitives keep this gate too: a native input in a wrapper is still a second calendar.
  ...CALENDAR_SELECTORS,
];

export const COLOR_SELECTORS = [
  ...paletteSelectors(TW_PALETTE_RE, "tailwind palette class"),
  ...paletteSelectors(TW_MONO_RE, "tailwind white/black"),
  ...paletteSelectors(HEX_RE, "hex literal"),
  ...paletteSelectors(COLOR_FN_RE, "literal-channel colour function"),
  // A bare named CSS colour on a style prop — `style={{ color: 'red' }}`. Restricted to
  // the colour-bearing properties so a `display: 'flex'` is untouched, and the keyword
  // lookahead keeps currentColor/transparent/inherit/none legal.
  {
    selector:
      "JSXAttribute[name.name='style'] Property[key.name=/^(color|fill|stroke|background|backgroundColor|borderColor|borderTopColor|borderRightColor|borderBottomColor|borderLeftColor|outlineColor|caretColor|textDecorationColor|accentColor)$/][value.value=/^(?!currentColor$|transparent$|inherit$|initial$|unset$|revert$|none$|auto$)[A-Za-z]+$/]",
    message: `${PALETTE_MESSAGE} (named CSS colour on a style prop)`,
  },
];


// ─── haku/hover-hygiene ───────────────────────────────────────────────────────
// The two hover rules a `no-restricted-syntax` regex CANNOT express, because both are
// properties of a whole className rather than of one string literal:
//
//   1. Every `hover:` needs a transition. 63 of 140 `transition-colors` shipped with no
//      duration (so 150ms, not the mandated 100ms) and 37 hover utilities had no transition
//      at all — but the base class and the variant that needs it are routinely different
//      literals. `cva({ base: "… transition-colors", variants: { ghost: "hover:bg-accent/50" }})`
//      is correct code that a per-literal regex flags, and flagging correct code is how a
//      rule earns a file full of eslint-disable and stops enforcing anything.
//
//   2. No hover-REVEAL (DESIGN.md, ADD-Friendly / Zero-Discovery). `opacity-0` and
//      `group-hover:opacity-100` are individually innocent; the pair is the violation. On
//      touch there is no hover, so an action at opacity-0 does not exist at all.
//
// UNIT OF ANALYSIS: a `className` JSX attribute, or a variable declarator (which is how
// `cva(…)` and the `retro/components/styles.ts` class constants are written). Every string
// literal and template chunk in that unit's subtree is unioned before the checks run. The
// union is deliberately lenient — it can miss (two unrelated class strings in one const
// sharing a transition), never invent.
//
const HOVER_HYGIENE = {
  meta: {
    type: "problem",
    schema: [],
    // The transition half is auto-fixable, and deliberately so: the first attempt at this
    // sweep was a PowerShell regex over the raw source, which desynced on an apostrophe
    // inside a comment ("WeekRangePicker's") and inserted class text into three expressions
    // and two comments. A fixer works on AST ranges and cannot make that mistake. The
    // vocabulary half is NOT fixable — swapping `hover:opacity-80` for a fill is a design
    // decision about what the control IS, and no fixer can read that.
    fixable: "code",
    messages: {
      noTransition:
        "❌ HOVER: `{{cls}}` has no transition in this className. Every pointer-driven state carries `transition-colors duration-100` (`transition-opacity duration-100` for the swatch role) — including a Radix `focus:`/`data-[selected]` item highlight, which is a mouseover. See DESIGN.md → Hover: one language.",
      noDuration:
        "❌ HOVER: `{{cls}}` has a transition with no `duration-100`. Use the owned stylesheet and the declared hover duration.",
      reveal:
        "❌ ADD: hover-REVEAL — `{{cls}}` uncovers something hidden at `opacity-0`/`hidden`. Affordances are always visible (DESIGN.md → Zero-Discovery); there is no hover on touch. Dimming a PRESENT control is the swatch role: `opacity-50` → `hover:opacity-100`.",
      deadHover:
        "❌ HOVER: `{{cls}}` is a DEAD hover — the same fill is already the resting state in this className, so the pointer changes nothing. Either step to a different fill or drop the hover; a hover state that paints what is already there reads as a broken control.",
      cursorDefault:
        "❌ HOVER: `{{cls}}` paints on pointer-over but the element is `cursor-default`, so the arrow never becomes a hand. shadcn ships `cursor-default select-none` on every menu item to imitate a native OS menu; Haku's own rows are `cursor-pointer`, so the app answered the same question two ways depending on whether a row came from a primitive. Use `cursor-pointer`.",
      swatchRest:
        "❌ HOVER: `hover:opacity-100` pairs with `opacity-50` at rest, and this className rests at `{{cls}}`. The swatch role is ONE pair, not a per-site dimming taste — it read 40, 50, 60 and 70 across five pickers.",
    },
  },
  create(context) {
    // `group-hover:` is stripped first: it is the reveal mechanism (check 2), never a
    // hover state needing its own transition (check 1).
    //
    // The second alternative covers Radix/cmdk, which never write `hover:` — they focus the
    // item on pointermove, so `focus:bg-accent` and `data-[selected=true]:bg-accent` are
    // mouseovers too (see the HILITE note above). Restricted to `bg-`/`text-` on purpose:
    // Focus paint is independently forbidden by haku/focus-highlight. Note
    // `focus-visible:` cannot match — the alternation demands `:` straight after `focus`.
    const HOVER =
      /(?<!group-)\bhover:[-a-z0-9/[\]().%]+|(?:focus|aria-selected|data-\[(?:highlighted|selected)[^\]]*\]):(?:bg|text)-[-a-z0-9/[\]().%]+/gi;
    const HIDDEN = /(?:\bopacity-0(?![.\d])|(?<![-\w])hidden\b)/;
    const REVEAL = /\bgroup-hover:[-a-z0-9/]+|\bhover:opacity-\d+/i;

    const collect = (node, out) => {
      if (!node || typeof node.type !== "string") return;
      if (node.type === "Literal" && typeof node.value === "string") out.push([node, node.value]);
      else if (node.type === "TemplateElement") out.push([node, node.value.raw]);
      for (const key of Object.keys(node)) {
        if (key === "parent") continue;
        const child = node[key];
        if (Array.isArray(child)) child.forEach((c) => collect(c, out));
        else if (child && typeof child.type === "string") collect(child, out);
      }
    };

    const check = (root) => {
      const parts = [];
      collect(root, parts);
      if (!parts.length) return;
      const all = parts.map(([, s]) => s).join(" ");

      const hovers = parts.filter(([, s]) => HOVER.test((HOVER.lastIndex = 0, s)));
      if (hovers.length) {
        // A node's range INCLUDES its delimiters for both kinds: `"…"` and the
        // `` ` ``/`}` … `${`/`` ` `` of a template chunk. So the text starts at range[0]+1,
        // and the safe insertion point is one before the end for a Literal (before the
        // closing quote) and two before for a TemplateElement (before `${`, or before the
        // closing backtick — one char either way is still inside the class string, but two
        // is correct for the common non-final chunk). Getting this off by one is not
        // theoretical: the first version used range[1] and range[0] here and produced
        // `transition-color duration-100s` in two template literals.
        const textStart = (node) => node.range[0] + 1;
        const insertInto = ([node]) =>
          node.type === "Literal" ? node.range[1] - 1 : node.range[1] - 2;

        if (!/\btransition(?:-|\b)/.test(all)) {
          const target = hovers[0];
          context.report({
            node: target[0],
            messageId: "noTransition",
            data: { cls: target[1].match(HOVER)[0] },
            fix: (f) => f.insertTextBeforeRange([insertInto(target), insertInto(target)], " transition-colors duration-100"),
          });
        } else if (!/\bduration-100\b/.test(all)) {
          const carrier = parts.find(([, s]) => /\btransition-(?:colors|opacity|all)\b/.test(s));
          context.report({
            node: (carrier ?? hovers[0])[0],
            messageId: "noDuration",
            data: { cls: hovers[0][1].match(HOVER)[0] },
            fix: carrier
              ? (f) => {
                  const m = /\btransition-(?:colors|opacity|all)\b/.exec(carrier[1]);
                  const at = textStart(carrier[0]) + m.index + m[0].length;
                  return f.insertTextBeforeRange([at, at], " duration-100");
                }
              : null,
          });
        }
      }
      if (HIDDEN.test(all)) {
        for (const [node, s] of parts) {
          const m = s.match(REVEAL);
          if (m) context.report({ node, messageId: "reveal", data: { cls: m[0] } });
        }
      }

      // CURSOR: a pointer-over fill on a `cursor-default` element. 13 of these shipped —
      // every Radix menu item — against 34 `cursor-pointer` hand-rolled rows, so pointing
      // at a <Select> option gave an arrow and pointing at a list row gave a hand. Colour
      // was only half the mouseover; this is the half you feel rather than see.
      if (/\bcursor-default\b/.test(all)) {
        for (const [node, s] of parts) {
          const m = s.match(/(?:hover|focus|aria-selected|data-\[(?:highlighted|selected)[^\]]*\]):bg-[-a-z0-9/]+/i);
          if (m) context.report({ node, messageId: "cursorDefault", data: { cls: m[0] } });
        }
      }

      // SWATCH REST VALUE. The vocabulary regexes can only see `hover:opacity-100`, which
      // is legal; what they cannot see is the resting tier it is paired with, and that read
      // 40 / 50 / 60 / 70 across five pickers.
      if (/\bhover:opacity-100\b/.test(all)) {
        const rest = all.match(/(?<![-a-z:[])\bopacity-(\d+)\b/);
        if (rest && rest[1] !== "50") {
          for (const [node, s] of parts) {
            if (/\bopacity-\d+\b/.test(s) && !/hover:opacity/.test(s.replace(/hover:opacity-\d+/g, "")))
              context.report({ node, messageId: "swatchRest", data: { cls: rest[0] } });
          }
        }
      }

      // DEAD HOVER: `bg-X … hover:bg-X` in the SAME literal. Two shipped — the retro
      // strip's settled "done — undo" button and a retro row control — and both looked
      // deliberate in review because the two tokens sit far apart in a long class string.
      //
      // This is the ONE check here that does NOT use the union, and both reasons are
      // false positives the union produced:
      //   `isDragOver ? 'bg-accent/50 …' : '… hover:bg-accent/50'`  — mutually exclusive
      //      branches, so the fill is never resting while the hover applies;
      //   `hover:bg-accent/50 … data-[active]:bg-accent/50`         — a variant-prefixed
      //      fill is a state, not the resting one (hence the `(?<![-a-z0-9:[\]])` guard).
      // Within one literal both tokens are unconditionally live together, which is
      // exactly when "the pointer paints what is already there" is provable.
      for (const [node, s] of parts) {
        for (const m of s.matchAll(/\bhover:bg-([-a-z0-9/]+)/g)) {
          const fill = m[1].replace(/\//g, "\\/");
          if (new RegExp(`(?<![-a-z0-9:[\\]])bg-${fill}(?![-a-z0-9/])`).test(s)) {
            context.report({ node, messageId: "deadHover", data: { cls: m[0] } });
          }
        }
      }
    };

    const hasJsx = (node) => {
      let found = false;
      const scan = (n) => {
        if (found || !n || typeof n.type !== "string") return;
        if (n.type.startsWith("JSX")) { found = true; return; }
        for (const key of Object.keys(n)) {
          if (key === "parent") continue;
          const c = n[key];
          if (Array.isArray(c)) c.forEach(scan);
          else if (c && typeof c.type === "string") scan(c);
        }
      };
      scan(node);
      return found;
    };

    return {
      "JSXAttribute[name.name=/^(class|className)$/]": check,
      // A declarator is a unit ONLY when it holds no JSX — that is `cva(…)` and the
      // `retro/components/styles.ts` class constants, whose strings never reach a
      // className attribute in the same file. A component's declarator would otherwise
      // both double-report its own className attributes and union a transition from one
      // element into a sibling that lacks one.
      VariableDeclarator(node) {
        if (node.init && !hasJsx(node.init)) check(node.init);
      },
    };
  },
};


// ─── haku/icon-only-label ──────────────────────────────────────────────────────
// A <button> whose only content is an icon element needs aria-label; data-tip is inert
// to assistive tech and is never the accessible name (DESIGN.md → Accessibility floor).
const ICON_ONLY_LABEL = {
  meta: { type: "problem", schema: [], messages: {
    missing: "❌ A11Y: icon-only button without aria-label. The tooltip is never the accessible name",
  } },
  create(context) {
    const attrName = (a) => a.type === "JSXAttribute" && a.name && (a.name.name ?? a.name.name?.name);
    const elName = (el) => {
      const n = el.openingElement.name;
      return n.type === "JSXIdentifier" ? n.name : n.type === "JSXMemberExpression" ? n.property.name : "";
    };
    return {
      JSXElement(node) {
        if (elName(node) !== "button") return;
        const attrs = node.openingElement.attributes;
        if (attrs.some((a) => a.type === "JSXSpreadAttribute")) return; // label may arrive by spread
        if (attrs.some((a) => /^aria-(label|labelledby)$/.test(String(attrName(a))))) return;
        const kids = node.children.filter((c) => !(c.type === "JSXText" && !/\S/.test(c.value)));
        if (kids.length === 0) return;
        const iconOnly = kids.every((c) => c.type === "JSXElement" && /(?:Icon|^svg)$/i.test(elName(c)));
        if (iconOnly) context.report({ node: node.openingElement, messageId: "missing" });
      },
    };
  },
};


export const designSystemPlugin = { rules: { "hover-hygiene": HOVER_HYGIENE, "icon-only-label": ICON_ONLY_LABEL, "focus-highlight": FOCUS_HIGHLIGHT } };
