import { describe, expect, it } from 'vitest';
// @ts-expect-error Stylesheet analysis is intentionally JavaScript.
import { collectDesignSystemControlClasses } from './control-stylesheets.js';

const collect = (code: string) => collectDesignSystemControlClasses(code, 'src/features/example/Controls.tsx');

describe('complete-control stylesheet ownership', () => {
  it('keeps host identity from real controls while ignoring retired class factories', () => {
    const usage = collect(`
      import {Button,buttonVariants as legacyClasses} from '@ui-kit/core';
      const legacy = legacyClasses;
      legacy({class:'legacy-factory',id:'legacy-id'});
      const View=()=> <Button.View id="real-control" class="real-host" shape="icon"/>;
    `);
    expect([...usage.classes]).toEqual(['real-host']);
    expect([...usage.ids]).toEqual(['real-control']);
    expect([...usage.iconClasses]).toEqual(['real-host']);
    expect([...usage.classControlTypes.get('real-host')]).toEqual(['Button']);
  });

  it('does not promote namespace factories or class constants into complete controls', () => {
    const usage = collect(`
      import * as UI from '@ui-kit/core';
      const {buttonVariants: legacyClasses}=UI;
      UI.buttonVariants({class:'namespace-factory'});
      legacyClasses({class:'destructured-factory'});
      const classes=UI.BUTTON_SIZE_CLASSES;
      const View=()=> <a class={classes.dense}/>;
    `);
    expect([...usage.classes]).toEqual([]);
    expect([...usage.ids]).toEqual([]);
  });

  it('continues following aliases, constructors and dynamic complete controls', () => {
    const usage = collect(`
      import * as UI from '@ui-kit/core';
      const Action=UI.Button;
      new Action({id:'constructed',class:'constructed-host'});
      createComponent(Action.View,{id:'created',class:'created-host'});
      const View=()=> <Dynamic component={Action.View} id="dynamic" class="dynamic-host"/>;
    `);
    expect([...usage.classes].sort()).toEqual(['constructed-host','created-host','dynamic-host']);
    expect([...usage.ids].sort()).toEqual(['constructed','created','dynamic']);
  });
});
