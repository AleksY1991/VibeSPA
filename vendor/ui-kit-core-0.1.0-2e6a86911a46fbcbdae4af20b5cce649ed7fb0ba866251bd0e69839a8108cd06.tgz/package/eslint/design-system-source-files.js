import path from 'node:path';
import { designSystemPackageRoot } from './package-location.js';
import { readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

// ESLint discovers configured extensions only. Reject other production module
// formats independently so adding a file cannot silently create an ungated edge.
export function designSystemSourceFileProblems(filename) {
  return /\.(?:[cm]ts|jsx)$/i.test(filename)
    ? ['Design-system source uses .ts/.tsx, or .js/.mjs/.cjs for lint tooling. Unsupported module extensions cannot bypass package isolation.'] : [];
}

export function auditDesignSystemSourceFiles(root = process.cwd()) {
  const source = path.join(designSystemPackageRoot(root), 'src');
  const walk = directory => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const filename = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(filename) : designSystemSourceFileProblems(filename).map(message => `${path.relative(root, filename)}: ${message}`);
  });
  return walk(source);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const problems = auditDesignSystemSourceFiles();
  for (const problem of problems) console.error(problem);
  if (problems.length > 0) process.exitCode = 1;
}
