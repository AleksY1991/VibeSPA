import { posix } from 'node:path';
import { designSystemFilename } from './package-location.js';

const FUNCTIONS = new Set(['ArrowFunctionExpression', 'FunctionExpression', 'FunctionDeclaration']);

/** Construction factories are capabilities, never reactive prop computations. */
export const ELEMENT_CONSTRUCTION = {
  meta: { type: 'problem', schema: [], messages: {
    phase: 'Construct registered item bindings once in the component/item body; JSX getters, events and reactive computations must consume existing handles.',
    private: 'Element subscription machinery is private to the design system. Use constructItem and pass its registered observable to the public element.',
    state: 'Pass {{name}} through the button observable state (pressed, expanded, ariaDisabled), not a second JSX value. TypeScript does not reject unknown hyphenated JSX attributes.',
  } },
  create(context) {
    const source = context.sourceCode;
    const filename = designSystemFilename(context.filename);
    const insideControls = /(?:^|\/)packages\/design-system\/src\//.test(filename);
    const insideUi = insideControls || /(?:^|\/)packages\/ui\//.test(filename);
    if (/\.(test|spec)\.[jt]sx?$/.test(filename)) return {};
    const factories = new Set(['constructItem', 'ItemCollection']);
    const buttons = new Set(['Button', 'PropertyRowButton']);
    const tracked = new Set(['createMemo', 'createEffect', 'createRenderEffect']);
    function walk(node, visit) {
      if (!node) return;
      visit(node);
      for (const key of source.visitorKeys[node.type] ?? []) {
        const children = node[key];
        if (Array.isArray(children)) children.forEach(child => walk(child, visit));
        else walk(children, visit);
      }
    }
    function name(node) {
      return node?.type === 'Identifier' ? node.name
        : node?.type === 'MemberExpression' && node.property.name === 'View' ? name(node.object)
        : node?.type === 'MemberExpression' ? node.property.name ?? node.property.value : undefined;
    }
    return {
      ImportDeclaration(node) {
        const path = String(node.source.value);
        const resolved = path.startsWith('.') ? posix.normalize(`${posix.dirname(filename)}/${path}`) : path;
        const isElementModule = /^@ui-kit\/core(?:\/|$)|^#ui\/(?:compositions|presentation)(?:\/|$)/.test(path)
          || /(?:^|\/)packages\/(?:design-system\/src|ui\/src\/(?:compositions|presentation))(?:\/|$)/.test(resolved);
        for (const specifier of node.specifiers) {
          if (specifier.type !== 'ImportSpecifier') continue;
          if (isElementModule && /^[A-Z][a-z]/.test(specifier.imported.name)
            && specifier.importKind !== 'type' && node.importKind !== 'type') factories.add(specifier.local.name);
          if (factories.has(specifier.imported.name)) factories.add(specifier.local.name);
          if (buttons.has(specifier.imported.name)) buttons.add(specifier.local.name);
          if (tracked.has(specifier.imported.name)) tracked.add(specifier.local.name);
          if (!insideUi && ['ElementBinding', 'readObservable', 'ItemConstruction'].includes(specifier.imported.name)
            && specifier.importKind !== 'type' && node.importKind !== 'type') context.report({node:specifier,messageId:'private'});
        }
        if (!insideUi && /(?:@ui-kit\/core|packages\/design-system\/src)\/infrastructure\/element(?:\.|$)/.test(resolved)) context.report({node,messageId:'private'});
      },
      JSXAttribute(node) {
        const attribute = node.name.name;
        if (!['aria-pressed', 'aria-expanded', 'aria-disabled'].includes(attribute)) return;
        const element = node.parent.name;
        const target = element?.property?.name === 'View' ? element.object : element;
        const elementName = target?.type === 'JSXIdentifier' ? target.name : target?.property?.name;
        if (!insideControls && buttons.has(elementName)) context.report({node,messageId:'state',data:{name:attribute}});
      },
      'Program:exit'(program) {
        // Follow local aliases and helper factories so renaming does not move
        // subscription creation into a getter unnoticed.
        let changed = true;
        while (changed) {
          changed = false;
          walk(program, node => {
            const id = node.type === 'VariableDeclarator' ? node.id : node.type === 'FunctionDeclaration' ? node.id : null;
            const value = node.type === 'VariableDeclarator' ? node.init : node;
            if (id?.type !== 'Identifier' || factories.has(id.name) || !value) return;
            let creates = value.type === 'Identifier' && factories.has(value.name);
            if (FUNCTIONS.has(value.type)) walk(value.body, child => {
              if (['CallExpression','NewExpression'].includes(child.type) && factories.has(name(child.callee))) creates = true;
            });
            if (creates) { factories.add(id.name); changed = true; }
          });
        }
        walk(program, node => {
          if (!['CallExpression','NewExpression'].includes(node.type) || !factories.has(name(node.callee))) return;
          for (let parent = node.parent; parent; parent = parent.parent) {
            if (parent.type === 'JSXExpressionContainer' || parent.type === 'JSXSpreadAttribute') {
              context.report({node,messageId:'phase'}); break;
            }
            if (FUNCTIONS.has(parent.type)) {
              const container = parent.parent;
              if ((container?.type === 'CallExpression' && tracked.has(name(container.callee)))
                || (container?.type === 'JSXExpressionContainer' && container.parent?.type === 'JSXAttribute')) context.report({node,messageId:'phase'});
              break;
            }
          }
        });
      },
    };
  },
};
