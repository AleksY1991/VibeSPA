import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import postcss from 'postcss';
import { describe, expect, it } from 'vitest';
import { DESIGN_SYSTEM_PACKAGE_ROOT } from './package-location.js';
import { PINNED_VENDOR_THEME, upstreamVendorThemeDeclarations } from './vendor-theme.js';
import { stylesheetTypographyProblems } from './stylesheet-typography.js';
import { focusDeclarationProblem } from './focus-highlight.js';
const designSystemSourcePath = (...segments: string[]) => path.join(DESIGN_SYSTEM_PACKAGE_ROOT, 'src', ...segments);

describe('stylesheet typography contract', () => {
  it('rejects stylesheet literals, including custom-property fallbacks and hidden values', () => {
    for (const css of [
      'p { font-size: 15px; }',
      'p { font-size: var(--caption, 12px); }',
      'p { --label-size: 15px; font-size: var(--label-size); }',
      'p { --wa-font-size-s: 15px; }',
      'p { font-weight: 500; }',
      'p { --label-weight: 700; font-weight: var(--label-weight); }',
      'p { font: 15px sans-serif; }',
      'p { @apply font-medium; }',
      'p { @apply font-[500]; }',
      'p { @apply text-[15px]; }',
      'p { @apply text-6xl; }',
    ]) expect(stylesheetTypographyProblems(css), css).not.toEqual([]);
    expect(stylesheetTypographyProblems('p { font-size: var(--label-size); }', new Map([['--label-size', ['15px']]]))).not.toEqual([]);
  });

  it('permits semantic text/weight tokens and inherited vendor typography', () => {
    expect(stylesheetTypographyProblems(`p { --text-field: theme('fontSize.field'); font-size: var(--text-field); font-weight: 400; } wa-input { --wa-form-control-value-font-size: 1em; font-weight: inherit; } strong { font-weight: 600; }`)).toEqual([]);
  });

  it('keeps pinned vendor defaults from becoming an application typography scale', () => {
    const vendorVariables = new Map<string, string[]>();
    for (const [property, value] of upstreamVendorThemeDeclarations()) {
      if (property.startsWith('--')) vendorVariables.set(property, [...vendorVariables.get(property) ?? [], value]);
    }
    expect(stylesheetTypographyProblems('p { font-size: var(--wa-font-size-m); }', vendorVariables)).not.toEqual([]);
    expect(stylesheetTypographyProblems('p { font-weight: var(--wa-font-weight-semibold); }', vendorVariables)).not.toEqual([]);
  });

  it('checks every authored stylesheet, including new feature CSS', () => {
    const walk = (directory: string): string[] => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
      if (entry.name === 'node_modules') return [];
      const file = path.join(directory, entry.name);
      return entry.isDirectory() ? walk(file) : entry.name.endsWith('.css') ? [file] : [];
    });
    const stylesheets = walk(designSystemSourcePath())
      .map(file => ({ file, css: readFileSync(file, 'utf8') }));
    const canonicalTokens = new Set(['tokens.css', 'control-tokens.css'].map(file => designSystemSourcePath(file)));
    const reset = designSystemSourcePath('reset.css');
    const vendor = stylesheets.find(({ file }) => file === PINNED_VENDOR_THEME);
    expect(vendor).toBeDefined();
    const vendorDeclarations: string[][] = [];
    postcss.parse(vendor!.css).walkDecls(declaration => {
      vendorDeclarations.push([declaration.prop, declaration.value, String(declaration.important)]);
    });
    expect(vendorDeclarations).toEqual(upstreamVendorThemeDeclarations());
    const variables = new Map<string, string[]>();
    // Exact core token owners define the numeric scales. Follow every other
    // variable so a component cannot hide a second scale behind an alias.
    for (const { css } of stylesheets.filter(({ file }) => !canonicalTokens.has(file))) postcss.parse(css).walkDecls(declaration => {
      if (declaration.prop.startsWith('--')) variables.set(declaration.prop, [...variables.get(declaration.prop) ?? [], declaration.value]);
    });
    // The scoped reset preserves browser relative-size/weight normalization;
    // every component and vendor adapter still chooses owned role tokens.
    // The exact unchanged vendor snapshot owns upstream defaults. Keep its
    // variables in alias analysis so application references still cannot adopt
    // its extra scale; authored adapters continue to choose canonical UI roles.
    const violations = stylesheets.filter(({ file }) => file !== reset && file !== PINNED_VENDOR_THEME).flatMap(({ file, css }) =>
      stylesheetTypographyProblems(css, variables).map(problem => `${path.relative(process.cwd(), file)}:${problem}`));
    expect(violations).toEqual([]);
  });
});

describe('standalone focus stylesheet policy', () => {
  it('keeps every owned stylesheet free of focus paint and vendor opt-ins', () => {
    const problems: string[] = [];
    const vendorDefaults: string[][] = [];
    const scan = (directory: string) => {
      for (const entry of readdirSync(directory, { withFileTypes: true })) {
        const file = path.join(directory, entry.name);
        if (entry.isDirectory()) {
          if (!['node_modules', 'dist', 'coverage'].includes(entry.name)) scan(file);
          continue;
        }
        if (!file.endsWith('.css')) continue;
        postcss.parse(readFileSync(file, 'utf8')).walkDecls(declaration => {
          const selectors: string[] = [];
          for (let parent = declaration.parent; parent; parent = parent.parent) {
            if (parent.type === 'rule') selectors.push(parent.selector);
          }
          if (focusDeclarationProblem(declaration.prop, declaration.value, selectors.join(' '))) {
            if (path.resolve(file) === PINNED_VENDOR_THEME) {
              vendorDefaults.push([declaration.prop, declaration.value, String(declaration.important)]);
            } else problems.push(`${file}:${declaration.source?.start?.line}: ${declaration.toString()}`);
          }
        });
      }
    };
    scan(designSystemSourcePath());
    // This exact snapshot carries upstream defaults, not a consumer opt-in.
    // Changes, extra copies and important defaults all fail the pinned comparison.
    expect(vendorDefaults).toEqual(upstreamVendorThemeDeclarations()
      .filter(([property, value]) => focusDeclarationProblem(property, value)));
    expect(problems).toEqual([]);
  });

  it('neutralizes every pinned vendor focus default on roots and descendant hosts regardless of load order', () => {
    const reset = postcss.parse(readFileSync(path.join(path.dirname(PINNED_VENDOR_THEME), '../../focus.css'), 'utf8'));
    const neutral = new Map([
      ['--wa-focus-ring', 'none'], ['--wa-focus-ring-style', 'none'],
      ['--wa-focus-ring-width', '0px'], ['--wa-focus-ring-offset', '0px'],
      ['--wa-color-focus', 'transparent'],
    ]);
    const policy: string[][] = [];
    reset.walkDecls(declaration => {
      if (!neutral.has(declaration.prop)) return;
      expect(declaration.value).toBe(neutral.get(declaration.prop));
      expect(declaration.important).toBe(true);
      expect(declaration.parent.type).toBe('rule');
      if (declaration.parent.type !== 'rule') throw new Error('Vendor focus resets must target every owned host.');
      expect(declaration.parent.selectors.map(selector => selector.trim())).toEqual([
        ':where([data-ui-root]) *', '*:where([data-ui-root])',
      ]);
      policy.push([declaration.prop, declaration.value]);
    });
    expect(policy).toEqual([...neutral]);
    for (const [property, , important] of upstreamVendorThemeDeclarations()
      .filter(([property, value]) => focusDeclarationProblem(property, value))) {
      expect(neutral.has(property)).toBe(true);
      expect(important).toBe('undefined');
    }
  });
});
