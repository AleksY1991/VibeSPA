import postcss from 'postcss';
import { typographyClassProblems, typographyValueProblem } from './design-geometry.js';

export function stylesheetTypographyProblems(css, sharedVariables = new Map()) {
  const parsed = postcss.parse(css);
  const problems = [];
  const variables = new Map(sharedVariables);
  parsed.walkDecls(declaration => {
    if (declaration.prop.startsWith('--')) variables.set(declaration.prop, [...variables.get(declaration.prop) ?? [], declaration.value]);
  });
  const inspect = (property, value, seen = new Set()) => {
    if (typographyValueProblem(property, value)) return true;
    // A CSS custom property cannot hide a feature's extra font size or weight.
    for (const match of value.matchAll(/var\(\s*(--[-\w]+)/g)) {
      if (seen.has(match[1])) continue;
      seen.add(match[1]);
      if (variables.get(match[1])?.some(candidate => inspect(property, candidate, seen))) return true;
    }
    return false;
  };
  parsed.walkDecls(declaration => {
    if (inspect(declaration.prop, declaration.value)) problems.push(`${declaration.source?.start?.line}: ${declaration.prop}: ${declaration.value}`);
  });
  parsed.walkAtRules('apply', rule => {
    if (typographyClassProblems(rule.params).length) problems.push(`${rule.source?.start?.line}: @apply ${rule.params}`);
  });
  return problems;
}

