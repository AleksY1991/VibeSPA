import { ESLint, Linter } from 'eslint';
import path from 'node:path';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import tseslint from 'typescript-eslint';
import { beforeAll, describe, expect, it } from 'vitest';
// @ts-expect-error ESLint rules are intentionally plain JavaScript modules.
import { EVENT_SCOPE } from '@ui-kit/core/eslint/event-scope';

const root = path.resolve(import.meta.dirname, '../../..');
const filename = path.join(root, 'packages/design-system/src/infrastructure/activation.ts');
const imports = `import { untrack, untrack as snapshot } from 'solid-js';
import * as solid from 'solid-js';
export function eventScope<Args extends readonly unknown[], Result>(callback: (...args: Args) => Result): (...args: Args) => Result {
  return (...args) => untrack(() => callback(...args));
}
declare const command: (...args: readonly unknown[]) => void;
declare const handler: EventListener;
`;
const cases = [
  ['native callback', 'const listener: EventListener = event => handler(event);', 1],
  ['renamed callback', 'const browserObservation = (event: FocusEvent) => handler(event);', 1],
  ['native callback assigned later', 'let guarded: EventListener; guarded = event => handler(event);', 1],
  ['named native callback', 'function listener(event: Event) { handler(event); }', 1],
  ['native function expression', 'const listener: EventListener = function(event) { handler(event); };', 1],
  ['native listener returning a value', 'const listener: EventListener = event => { handler(event); return false; };', 1],
  ['native method', 'const listener = { handleEvent(event: Event) { handler(event); } };', 1],
  ['command factory', 'function surfaceCommand() { return (...args: unknown[]) => command(...args); }', 1],
  ['event factory', 'function surfaceEvent() { return (event: Event) => handler(event); }', 1],
  ['bound-data dispatcher', 'function deliverEvent(event: Event) { handler(event); }', 1],
  ['construction alone is untracked', 'const listener = untrack(() => (event: Event) => handler(event));', 1],
  ['lookup before isolation', 'const listener: EventListener = event => { console.log(event); untrack(() => handler(event)); };', 1],
  ['imitation untrack', 'const untrack = (callback: () => void) => callback(); const listener: EventListener = event => untrack(() => handler(event));', 1],
  ['imitation eventScope', 'const eventScope = (callback: EventListener) => callback; const listener = eventScope((event: Event) => handler(event));', 1],
  ['named imitation eventScope', 'function eventScope(callback: EventListener) { return callback; } const listener = eventScope((event: Event) => handler(event));', 1],
  ['shared entry boundary', 'const listener: EventListener = eventScope(event => handler(event));', 0],
  ['aliased shared boundary', 'const scope = eventScope; const listener: EventListener = scope(event => handler(event));', 0],
  ['complete direct isolation', 'const listener: EventListener = event => untrack(() => handler(event));', 0],
  ['complete block isolation', 'const listener: EventListener = event => { untrack(() => handler(event)); };', 0],
  ['complete returning block isolation', 'const listener: EventListener = event => { return snapshot(() => handler(event)); };', 0],
  ['namespace import', 'const listener: EventListener = event => solid.untrack(() => handler(event));', 0],
  ['isolated named native callback', 'function listener(event: Event) { untrack(() => handler(event)); }', 0],
  ['isolated command factory', 'function surfaceCommand() { return eventScope((...args: unknown[]) => command(...args)); }', 0],
  ['isolated bound-data delivery', 'function deliverEvent(event: Event) { untrack(() => handler(event)); }', 0],
] as const;
const source = imports + cases.map(([, code], index) => `namespace Case${index} { ${code} }`).join('\n');
let messages: Linter.LintMessage[];

beforeAll(() => {
  const options: ts.CompilerOptions = {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler, strict: true, skipLibCheck: true,
  };
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host);
  host.readFile = file => path.normalize(file) === filename ? source : read(file);
  host.getSourceFile = (file, version) => {
    const text = host.readFile(file);
    return text === undefined ? undefined : ts.createSourceFile(file, text, version, true);
  };
  const program = ts.createProgram([filename], options, host);
  messages = new Linter().verify(source, [{
    files: ['**/*.ts'],
    languageOptions: { parser: tseslint.parser, parserOptions: { programs: [program] } },
    plugins: { ui: { rules: { 'event-scope': EVENT_SCOPE } } },
    rules: { 'ui/event-scope': 'error' },
  }], { filename });
  expect(messages.filter(message => message.fatal)).toEqual([]);
}, 20_000);

describe('event scope safeguard', () => {
  cases.forEach(([name, , count], index) => {
    it(name, () => {
      const line = imports.split('\n').length + index;
      expect(messages.filter(message => message.line === line).map(message => message.messageId))
        .toEqual(Array(count).fill('scope'));
    });
  });

  it('rejects an unscoped InteractionEvents listener through the production config', async () => {
    const eslint = new ESLint();
    const filePath = path.join(root, 'packages/design-system/src/solid/interaction-events.ts');
    const code = `import { eventScope } from '../infrastructure/activation';
      const listener: EventListener = event => console.log(event.type);`;
    const [broken] = await eslint.lintText(code, { filePath });
    expect(broken.messages.filter(message => message.ruleId === 'ui/event-scope').map(message => message.messageId))
      .toEqual(['scope']);
    const [fixed] = await eslint.lintText(code.replace('event => console.log(event.type)', 'eventScope(event => console.log(event.type))'), { filePath });
    expect(fixed.messages.filter(message => message.ruleId === 'ui/event-scope')).toEqual([]);
  }, 30_000);

  it.each([
    ['infrastructure/activation.ts', 'return (...args) => untrack(() => callback(...args));', 'return (...args) => callback(...args);'],
    ['infrastructure/activation.ts', 'guarded = eventScope((event: Event & { currentTarget: Element; target: Element }) => {', 'guarded = ((event: Event & { currentTarget: Element; target: Element }) => {'],
    ['infrastructure/element.ts', 'const guardNativeActivation: EventListener = eventScope((event: Event) => {', 'const guardNativeActivation: EventListener = ((event: Event) => {'],
    ['solid/interaction-events.ts', 'const listener: EventListener = eventScope((event: Event) => {', 'const listener: EventListener = ((event: Event) => {'],
    ['solid/button.tsx', 'const activate = eventScope((activation: Activation) => {', 'const activate = ((activation: Activation) => {'],
    ['solid/interaction-region.tsx', 'onClick={props.onActivate && eventScope((event: MouseEvent) => {', 'onClick={props.onActivate && ((event: MouseEvent) => {'],
    ['solid/button.tsx', 'onClick={eventScope((event: MouseEvent) => {', 'onClick={((event: MouseEvent) => {'],
    ['solid/button.tsx', 'onPointerDown={eventScope((event: PointerEvent) => {', 'onPointerDown={((event: PointerEvent) => {'],
  ])('rejects removal of dispatch isolation in %s', async (relative, before, after) => {
    const filePath = path.join(root, 'packages/design-system/src', relative);
    const original = readFileSync(filePath, 'utf8');
    expect(original).toContain(before);
    const eslint = new ESLint();
    const [current] = await eslint.lintText(original, { filePath });
    expect(current.messages.filter(message => message.ruleId === 'ui/event-scope')).toEqual([]);
    const [broken] = await eslint.lintText(original.replace(before, after), { filePath });
    expect(broken.messages.some(message => message.ruleId === 'ui/event-scope')).toBe(true);
  }, 30_000);
});
