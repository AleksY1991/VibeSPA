import path from 'node:path';
import { readFileSync, readdirSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import postcss from 'postcss';
import { designSystemStylesheetScopeProblems } from './design-system-stylesheet-scope.js';
import { fontFamilyNames } from './design-system-ownership.js';

const filename = 'packages/design-system/src/future.css';
const problems = (css: string) => designSystemStylesheetScopeProblems(css, filename);

describe('design-system stylesheet root scope', () => {
  it.each([
    '[data-ui-root] { color: black; }',
    '[data-ui-root] .ui-button { color: black; }',
    ':where([data-ui-root]) .ui-button, .ui-button:where([data-ui-root]) { color: black; }',
    ':is([data-ui-root], .frame[data-ui-root]) button { color: black; }',
    ':where(:is([data-ui-root], [data-ui-root].dark)) .ui-button { color: black; }',
    '[data-ui-root] :is(button, .ui-button) { color: black; }',
    '.feature [data-ui-root] { color: black; }',
    '[data-ui-root] > .first + .second { color: black; }',
    ':is([data-ui-root] .first, [data-ui-root] .other) ~ .second { color: black; }',
    ':where([data-ui-root]) wa-dialog::part(body) { color: black; }',
    '[data-\\75i-root] button { color: black; }',
    '[data-ui-root] { .inner { color: black; } &:hover { color: black; } > .child { color: black; } }',
    '[data-ui-root] { .inner { & + .next { color: black; } } }',
    '[data-ui-root] { & .row + .row { color: black; } }',
    '[data-ui-root] { .first, .second { color: black; } }',
    '@media (pointer: coarse) { [data-ui-root] button { color: black; } }',
    '[data-ui-root] { @supports (display: grid) { .inner { color: black; } } }',
    '@font-face { font-family: "ui-inter"; src: url("./inter.woff2"); }',
    '@FONT-FACE { font-family: UI-Inter; src: url("./inter.woff2"); }',
    '@font-face { font-family: u\\69 -inter; src: url("./inter.woff2"); }',
    '@layer ui-controls, ui-wa-theme; @layer ui-controls { [data-ui-root] { color: black; } }',
    '@layer ui-controls { @layer buttons { [data-ui-root] { color: black; } } }',
    '@layer { [data-ui-root] { color: black; } }',
    '@import "./theme.css" layer(ui-theme);',
    '@keyframes ui-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } } [data-ui-root] { animation: ui-spin 1s steps(4, end) infinite; }',
    '@-webkit-keyframes ui-spin { 0%, 100% { opacity: 1; } } [data-ui-root] { -webkit-animation-name: ui-spin; }',
    '[data-ui-root] { animation: ui-spin 1s cubic-bezier(0, 0, 1, 1), ui-fade 200ms ease-out; animation-name: ui-spin, ui-fade; }',
    '[data-ui-root] { animation: none !important; animation-name: initial; }',
  ])('accepts positively scoped styles: %s', css => expect(problems(css)).toEqual([]));

  it.each([
    '.ui-button { color: red; }',
    '[data-ui-root] .inside, button { color: red; }',
    ':not([data-ui-root]) button { color: red; }',
    ':has([data-ui-root]) button { color: red; }',
    '.parent:has([data-ui-root]) .child { color: red; }',
    ':where(:not([data-ui-root])) button { color: red; }',
    ':is([data-ui-root], body) { color: red; }',
    ':where([data-ui-root], .outside) { color: red; }',
    ':is([data-ui-root], :has([data-ui-root])) button { color: red; }',
    '[data-label="[data-ui-root]"] { color: red; }',
    'button /* [data-ui-root] */ { color: red; }',
    '[data-ui-root] + .outside { color: red; }',
    '[data-ui-root] ~ .outside { color: red; }',
    '[data-ui-root] || .outside { color: red; }',
    ':is([data-ui-root] + .outside, [data-ui-root] .inside) { color: red; }',
    'html { font-size: 10px; }',
    'body[data-ui-root] { font-size: 10px; }',
    ':root[data-ui-root] { font-size: 10px; }',
    ':where([data-ui-root]) body { font-size: 10px; }',
    '[data-ui-root] { & + .outside { color: red; } }',
    '[data-ui-root] { :not(&) button { color: red; } }',
    '[data-ui-root] { :has(&) button { color: red; } }',
    '[data-ui-root] { :is(&, .outside) { color: red; } }',
    '@page { margin: 0; }',
    '@viewport { width: 1px; }',
    '@property --foreign { syntax: "<color>"; inherits: true; initial-value: red; }',
    '@layer app, base;',
    '@layer wa-theme, wa-overrides;',
    '@layer ui-controls, app;',
    '@layer app.ui-controls { [data-ui-root] { color: red; } }',
    '@import "./theme.css" layer(app);',
    '@counter-style app { system: numeric; symbols: "0" "1"; }',
    '@font-feature-values Inter { @styleset { app: 1; } }',
    '@font-palette-values --app { font-family: Inter; }',
    '@font-face { font-family: Inter; src: url("./inter.woff2"); }',
    '@font-face { font-family: "UI Emoji"; src: url("./emoji.ttf"); }',
    '@font-face { font-family: "ui-inter", Inter; src: url("./inter.woff2"); }',
    '@font-face { font-family: var(--ui-family); src: url("./inter.woff2"); }',
    '@font-face { src: url("./inter.woff2"); }',
    '@p\\61 ge { margin: 0; }',
    '@keyframes spin { from { opacity: 0; } to { opacity: 1; } }',
    '@-webkit-keyframes "spin" { from { opacity: 0; } }',
    '[data-ui-root] { animation-name: app-spin; }',
    '[data-ui-root] { animation: app-spin 1s ease; }',
    '[data-ui-root] { animation: linear linear 1s; }',
    '[data-ui-root] { animation: steps(4) ease 1s; }',
    '[data-ui-root] { animation: auto 1s; }',
    '[data-ui-root] { animation-name: var(--ui-animation); }',
    '[data-ui-root] { animation: var(--ui-animation) 1s ease; }',
    '[data-ui-root] { animation-name: "none"; }',
    ':is([data-ui-root],) { color: red; }',
    '[data-ui-root] {',
  ])('rejects styles escaping the mounted library root: %s', css => expect(problems(css).length).toBeGreaterThan(0));

  it('audits only core CSS and reports the source location', () => {
    expect(designSystemStylesheetScopeProblems('body { color: red; }', 'packages/ui/src/views/app.css')).toEqual([]);
    expect(designSystemStylesheetScopeProblems('body { color: red; }', 'packages/design-system/src/future.ts')).toEqual([]);
    expect(problems('\nbody { color: red; }')[0]).toContain(`${filename}:2:`);
    expect(designSystemStylesheetScopeProblems('[data-ui-root] { color: black; }', path.resolve(filename))).toEqual([]);
  });

  it('keeps every current core stylesheet positively scoped', () => {
    const walk = (directory: string): string[] => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
      const filename = path.join(directory, entry.name);
      return entry.isDirectory() ? walk(filename) : filename.endsWith('.css') ? [filename] : [];
    });
    const errors = walk('packages/design-system/src').flatMap(filename =>
      designSystemStylesheetScopeProblems(readFileSync(filename, 'utf8'), filename));
    expect(errors).toEqual([]);
  });

  it('keeps default bundled font families aligned with their owned registrations', () => {
    const theme = postcss.parse(readFileSync('packages/design-system/src/theme-base.css', 'utf8'));
    const tokens = postcss.parse(readFileSync('packages/design-system/src/tokens.css', 'utf8'));
    const registered = new Set<string>();
    theme.walkAtRules('font-face', rule => {
      rule.walkDecls('font-family', declaration => {
        for (const family of fontFamilyNames(declaration.value)) if (family) registered.add(family);
      });
    });
    const defaults: string[] = [];
    tokens.walkDecls('--ui-font-family', declaration => defaults.push(...fontFamilyNames(declaration.value).filter((family): family is string => Boolean(family))));
    expect([...registered].sort()).toEqual(['ui-emoji', 'ui-inter']);
    expect(defaults.slice(0, registered.size)).toEqual(['ui-inter', 'ui-emoji']);
  });
});
