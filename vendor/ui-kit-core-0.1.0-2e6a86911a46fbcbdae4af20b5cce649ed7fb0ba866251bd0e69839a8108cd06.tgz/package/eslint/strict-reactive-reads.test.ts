import path from 'node:path';
import { Linter } from 'eslint';
import ts from 'typescript';
import tseslint from 'typescript-eslint';
import { beforeAll, describe, expect, it } from 'vitest';
// @ts-expect-error ESLint rules are intentionally plain JavaScript modules.
import { STRICT_REACTIVE_READS } from '@ui-kit/core/eslint/strict-reactive-reads';

const root = path.resolve(import.meta.dirname, '../../..');
const filename = path.join(root, 'packages/design-system/src/solid/reactive-rule.fixture.tsx');
const helperFilename = path.join(root, 'packages/design-system/src/lib/reactive-rule.fixture.ts');
const imports = `
import { createEffect, createMemo, createRoot, createSignal, untrack, type Accessor } from 'solid-js';
import { createEffect as effect, untrack as capture } from 'solid-js';
import * as solid from 'solid-js';
import type { Observable } from '../contracts/construction';
import { constructItem } from '../infrastructure/construction';
import { importedRead, importedSnapshot, importedEffects, ImportedModel } from '../lib/reactive-rule.fixture';
declare const value: Accessor<number>;
declare const observable: Observable<number>;
declare function consume(value: unknown): void;
`;
const helper = `
import { untrack, type Accessor } from 'solid-js';
export function importedRead(read: Accessor<number>) { return read(); }
export function importedSnapshot(read: Accessor<number>) { return untrack(read); }
declare const helperValue: Accessor<number>;
export const importedEffects = { effect: () => { helperValue(); }, error: () => {} };
export class ImportedModel {
  constructor(read: Accessor<number>) { read(); }
}
`;

// Every example models a consumer mistake or an allowed scope. The source is
// type-checked against the pinned Solid and Observable declarations, rather than
// recreating those APIs in fixtures or recognizing names such as props/count.
const cases = [
  ['component snapshot', 'function View() { const initial = value(); return <span>{initial}</span>; }', 1],
  ['signal snapshot', 'function View() { const [count] = createSignal(0); const initial = count(); return <span>{initial}</span>; }', 1],
  ['accessor alias', 'const read = value; function View() { return read(); }', 1],
  ['optional accessor', 'declare const maybe: Accessor<number> | undefined; function View() { return maybe?.(); }', 1],
  ['registered observable snapshot', 'function View() { return observable.read(); }', 1],
  ['destructured observable accessor', 'const { read } = observable; function View() { return read(); }', 1],
  ['JSX attributes and children track', 'function View() { return <span data-value={value()}>{observable.read()}</span>; }', 0],
  ['stable accessor handle', 'function View() { const read = value; consume(read); return <span>{read()}</span>; }', 0],
  ['stable observable handle', 'function View() { const model = observable; consume(model); consume(model.read); return null; }', 0],
  ['ordinary function named like a signal', 'declare const count: () => number; function View() { return count(); }', 0],
  ['ordinary props method', 'declare const props: { read(): number }; function View() { return props.read(); }', 0],
  ['local imitation has no Solid contract', 'function untrack(read: () => number) { return read(); } function View() { return untrack(value); }', 0],
  ['memo compute tracks', 'function View() { const doubled = createMemo(() => value() * 2); return <span>{doubled()}</span>; }', 0],
  ['named memo compute tracks', 'function renderValue() { return <span>{value()}</span>; } function View() { const rendered = createMemo(renderValue); return <>{rendered()}</>; }', 0],
  ['effect compute tracks', 'function View() { createEffect(() => value(), next => consume(next)); return null; }', 0],
  ['aliased effect compute tracks', 'function View() { effect(() => value(), next => consume(next)); return null; }', 0],
  ['effect apply snapshot', 'function View() { createEffect(() => 1, () => { consume(value()); }); return null; }', 1],
  ['effect apply via alias', 'function View() { effect(() => 1, () => { consume(observable.read()); }); return null; }', 1],
  ['effect apply remains strict inside untrack', 'function View() { untrack(() => createEffect(() => 1, () => { consume(value()); })); return null; }', 1],
  ['returned effect cleanup snapshot', 'function View() { createEffect(() => value(), () => () => { consume(value()); }); return null; }', 1],
  ['accessor itself as effect cleanup', 'function View() { createEffect(() => value(), () => value); return null; }', 1],
  ['conditional effect cleanup', 'declare const enabled: boolean; function View() { createEffect(() => 1, () => enabled ? () => consume(value()) : undefined); return null; }', 1],
  ['captured effect result in cleanup', 'function View() { createEffect(() => value(), next => () => { consume(next); }); return null; }', 0],
  ['intentional initial snapshot', 'function View() { const initial = untrack(value); return <span>{initial}</span>; }', 0],
  ['aliased intentional snapshot', 'function View() { return capture(() => value()); }', 0],
  ['namespace intentional snapshot', 'function View() { return solid.untrack(() => observable.read()); }', 0],
  ['intentional apply snapshot', 'function View() { createEffect(() => 1, () => { consume(untrack(value)); }); return null; }', 0],
  ['intentional cleanup snapshot', 'function View() { createEffect(() => 1, () => () => { consume(capture(value)); }); return null; }', 0],
  ['deferred event callback', 'function View() { return <button onClick={() => consume(value())}>Run</button>; }', 0],
  ['constructor snapshot', 'class Model { constructor() { consume(value()); } }', 1],
  ['field initializer snapshot', 'class Model { readonly initial = value(); }', 1],
  ['stable constructor handle', 'class Model { readonly read = value; constructor() { consume(this.read); } }', 0],
  ['getter snapshot', 'const model = { get current() { return value(); } }; function View() { return model.current; }', 1],
  ['getter accessor handle', 'const model = { get current() { return value; } }; function View() { return model.current; }', 0],
  ['getter in tracked JSX', 'const model = { get current() { return value(); } }; function View() { return <span>{model.current}</span>; }', 0],
  ['local synchronous helper', 'function readNow() { return value(); } function View() { return readNow(); }', 1],
  ['imported setup helper', 'function View() { return importedRead(value); }', 1],
  ['imported helper under memo', 'function View() { const current = createMemo(() => importedRead(value)); return <span>{current()}</span>; }', 0],
  ['imported intentional snapshot', 'function View() { return importedSnapshot(value); }', 0],
  ['imported constructor setup', 'function View() { new ImportedModel(value); return null; }', 1],
  ['imported helper in apply', 'function View() { createEffect(() => 1, () => consume(importedRead(value))); return null; }', 1],
  ['imported helper in cleanup', 'function View() { createEffect(() => 1, () => () => consume(importedRead(value))); return null; }', 1],
  ['each unsafe imported call site', 'function View() { importedRead(value); createEffect(() => 1, () => consume(importedRead(value))); return null; }', 2],
  ['array callbacks execute during setup', 'function View() { const rows = [1, 2].map(() => value()); return <span>{rows}</span>; }', 1],
  ['root setup snapshot', 'createRoot(() => { consume(value()); });', 1],
  ['construction builder snapshot', 'function View() { constructItem("item", item => { const initial = value(); return item.constant("value", initial); }); return null; }', 1],
  ['construction observes accessor', 'function View() { const model = constructItem("item", item => item.observe("value", value)); return <span>{model.read()}</span>; }', 0],
  ['bound factory captures handle', 'function View() { constructItem("item", item => item.bind("value", () => value)); return null; }', 0],
  ['bound factory snapshots value', 'function View() { constructItem("item", item => item.bind("value", () => { const initial = value(); return () => initial; })); return null; }', 1],
  ['effect options apply snapshot', 'function View() { createEffect(() => 1, { effect: () => { consume(value()); }, error: () => {} }); return null; }', 1],
  ['effect options cleanup snapshot', 'function View() { createEffect(() => 1, { effect: () => () => { consume(value()); }, error: () => {} }); return null; }', 1],
  ['effect options consume computed value', 'function View() { createEffect(() => value(), { effect: next => { consume(next); }, error: () => {} }); return null; }', 0],
  ['typed effect options alias', 'function View() { const callbacks: { effect(next: number): void; error(): void } = { effect: () => { consume(value()); }, error: () => {} }; createEffect(() => 1, callbacks); return null; }', 1],
  ['effect options reference apply function', 'function apply() { consume(value()); } function View() { createEffect(() => 1, { effect: apply, error: () => {} }); return null; }', 1],
  ['effect options method', 'function View() { createEffect(() => 1, { effect() { consume(value()); }, error() {} }); return null; }', 1],
  ['each unsafe imported effect bundle site', 'function View() { createEffect(() => 1, importedEffects); effect(() => 2, importedEffects); return null; }', 2],
  ['effect options intentional snapshot', 'function View() { createEffect(() => 1, { effect() { consume(untrack(value)); }, error() {} }); return null; }', 0],
] as const;
const source = imports + cases.map(([, code], index) => `namespace Case${index} { ${code} }`).join('\n');
let messages: Linter.LintMessage[];

beforeAll(() => {
  const options: ts.CompilerOptions = {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler, strict: true, skipLibCheck: true,
    jsx: ts.JsxEmit.ReactJSX, jsxImportSource: '@solidjs/web',
    customConditions: ['browser', 'development'],
  };
  const files = new Map([[path.normalize(filename), source], [path.normalize(helperFilename), helper]]);
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host);
  const exists = host.fileExists.bind(host);
  host.fileExists = file => files.has(path.normalize(file)) || exists(file);
  host.readFile = file => files.get(path.normalize(file)) ?? read(file);
  host.getSourceFile = (file, version) => {
    const text = host.readFile(file);
    return text === undefined ? undefined : ts.createSourceFile(file, text, version, true);
  };
  const program = ts.createProgram([filename, helperFilename], options, host);
  const fixtureDiagnostics = [...program.getSyntacticDiagnostics(), ...program.getSemanticDiagnostics()]
    .filter(diagnostic => diagnostic.file && files.has(path.normalize(diagnostic.file.fileName)));
  expect(fixtureDiagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
  messages = new Linter().verify(source, [{
    files: ['**/*.tsx'],
    languageOptions: { parser: tseslint.parser, parserOptions: { programs: [program] } },
    plugins: { ui: { rules: { 'strict-reactive-reads': STRICT_REACTIVE_READS } } },
    rules: { 'ui/strict-reactive-reads': 'error' },
  }], { filename });
  expect(messages.filter(message => message.fatal)).toEqual([]);
}, 20_000);

describe('strict reactive reads with the pinned Solid types', () => {
  cases.forEach(([name, , count], index) => {
    it(name, () => {
      const line = imports.split('\n').length + index;
      expect(messages.filter(message => message.line === line).map(message => message.messageId))
        .toEqual(Array(count).fill('setup'));
    });
  });

  it('reports only expected setup reads and no diagnostics outside the consumer examples', () => {
    expect(messages).toHaveLength(cases.reduce((count, [, , expected]) => count + expected, 0));
  });
});
