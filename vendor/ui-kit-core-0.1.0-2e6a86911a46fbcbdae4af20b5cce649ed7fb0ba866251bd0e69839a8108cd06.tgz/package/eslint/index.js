import { DESIGN_SYSTEM_BOUNDARY } from './design-system-boundary.js';
import { DESIGN_SYSTEM_CONSUMER } from './design-system-consumer.js';
import { DESIGN_GEOMETRY } from './design-geometry.js';
import { ICON_BOUNDARY } from './icon-boundary.js';
import { ELEMENT_CONSTRUCTION } from './element-construction.js';
import { EVENT_SCOPE } from './event-scope.js';
import { STRICT_REACTIVE_READS } from './strict-reactive-reads.js';
import { designSystemPlugin } from './policies.js';
import { HOOK_IN_JSX_PROP } from './hook-in-jsx-prop.js';
import { SUBSCRIPTION_DISPOSAL } from './subscription-disposal.js';
import { UI_STATE_PERSISTENCE } from './ui-state-persistence.js';
import { HOTKEY_RENDERER_RULE } from './hotkey-renderer.js';

export { CANONICAL_SELECTORS, COLOR_SELECTORS, DESIGN_SELECTORS } from './policies.js';
export { auditControlStylesheets } from './control-stylesheets.js';
export { auditDesignSystemSourceFiles } from './design-system-source-files.js';
export * from './package-location.js';

export const plugin = {
  rules: {
    ...designSystemPlugin.rules,
    'design-system-boundary': DESIGN_SYSTEM_BOUNDARY,
    'design-system-consumer': DESIGN_SYSTEM_CONSUMER,
    'design-geometry': DESIGN_GEOMETRY,
    'icon-boundary': ICON_BOUNDARY,
    'element-construction': ELEMENT_CONSTRUCTION,
    'event-scope': EVENT_SCOPE,
    'strict-reactive-reads': STRICT_REACTIVE_READS,
    'hook-in-jsx-prop': HOOK_IN_JSX_PROP,
    'subscription-disposal': SUBSCRIPTION_DISPOSAL,
    'ui-state-persistence': UI_STATE_PERSISTENCE,
    'hotkey-renderer': HOTKEY_RENDERER_RULE,
  },
};

export default plugin;
