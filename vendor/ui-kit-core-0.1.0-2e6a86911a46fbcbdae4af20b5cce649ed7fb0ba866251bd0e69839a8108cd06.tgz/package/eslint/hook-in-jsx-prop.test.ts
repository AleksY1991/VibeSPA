import { Linter } from 'eslint';
import { describe, expect, it } from 'vitest';

// @ts-expect-error ESLint rules are intentionally plain JavaScript modules.
import { HOOK_IN_JSX_PROP } from './hook-in-jsx-prop.js';

const linter = new Linter();
const messages = (source: string) =>
  linter.verify(source, [{
    files: ['**/*.{js,jsx,ts,tsx}'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'module',
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    plugins: { haku: { rules: { 'hook-in-jsx-prop': HOOK_IN_JSX_PROP } } },
    rules: { 'haku/hook-in-jsx-prop': 'error' },
  }], { filename: 'src/integrations/example/Control.tsx' });

describe('hook in JSX lint gate', () => {
  it('rejects a hook called inline in a prop or as a child', () => {
    expect(messages('const C = () => <Button model={useModel()} />;')).toHaveLength(1);
    expect(messages('const C = () => <Button model={runtime.useModel().value} />;')).toHaveLength(1);
    expect(messages('const C = () => <Panel>{useModel()}</Panel>;')).toHaveLength(1);
  });

  it('accepts a hook resolved in the component body and callbacks written in JSX', () => {
    expect(messages('const C = () => { const model = useModel(); return <Button model={model} />; }'))
      .toEqual([]);
    expect(messages('const C = () => <Button onClick={() => useless()} ref={hotkeys({})} />;'))
      .toEqual([]);
  });
});
