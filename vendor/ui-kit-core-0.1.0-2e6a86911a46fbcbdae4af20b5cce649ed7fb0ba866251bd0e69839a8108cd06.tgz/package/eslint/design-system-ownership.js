import { existsSync, readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { designSystemFilename, designSystemPackageRoot } from './package-location.js';
import postcss from 'postcss';
import selectorParser from 'postcss-selector-parser';
import valueParser from 'postcss-value-parser';

export const DESIGN_SYSTEM_COMPONENTS = new Set([
  'Button', 'Card', 'Checkbox', 'ChoiceGroup', 'Dialog', 'Field', 'Input', 'Textarea',
  'Popover', 'ProgressBar', 'SearchField', 'Select', 'TextField', 'Toggle',
  'TooltipLayer', 'Spinner', 'ContentEditable', 'Badge', 'Avatar', 'FilePicker',
  'Tabs', 'TabPanel', 'Tag', 'SplitPanel', 'ScrollArea', 'CaretInput',
  'Link', 'Form', 'Image', 'Media', 'EditorHost', 'InteractionRegion', 'InteractionEvents',
  'LayerPortal', 'Divider', 'MenuSeparator',
]);

// These public elements bind state or interaction to application-owned content.
// They do not acquire panel, field, or button chrome by mounting that content.
export const DESIGN_SYSTEM_LAYOUT_HOSTS = new Set([
  'Form', 'Image', 'Media', 'EditorHost', 'InteractionRegion',
  'InteractionEvents', 'LayerPortal',
]);
export const DESIGN_SYSTEM_CONTROLS = new Set([...DESIGN_SYSTEM_COMPONENTS]
  .filter(name => !DESIGN_SYSTEM_LAYOUT_HOSTS.has(name)));
export const DESIGN_SYSTEM_AS_HOSTS = new Set(['InteractionRegion', 'ScrollArea', 'ContentEditable']);

export const ownsDesignSystemAppearance = name => DESIGN_SYSTEM_CONTROLS.has(name);

const PLACEMENT_PROPERTIES = new Set([
  'width', 'min-width', 'max-width', 'inline-size', 'min-inline-size', 'max-inline-size',
  'margin', 'margin-left', 'margin-right', 'margin-top', 'margin-bottom',
  'margin-inline', 'margin-inline-start', 'margin-inline-end', 'margin-block',
  'margin-block-start', 'margin-block-end', 'position', 'left', 'right', 'top', 'bottom',
  'inset', 'inset-inline', 'inset-inline-start', 'inset-inline-end', 'inset-block',
  'inset-block-start', 'inset-block-end', 'z-index', 'flex', 'flex-grow', 'flex-shrink',
  'flex-basis', 'align-self', 'justify-self', 'order', 'grid-column', 'grid-row', 'grid-area',
]);

/** Decode CSS identifiers before comparing ownership, including hexadecimal escapes. */
export const decodeCss = value => String(value).replace(/\\(?:([\da-f]{1,6})(?:\r\n|[\t\n\f\r ])?|([^\n\r\f]))/gi,
  (_, hex, character) => hex ? String.fromCodePoint(Math.min(Number.parseInt(hex, 16) || 0xfffd, 0x10ffff)) : character);

/** Font family registry names are case-insensitive, including escaped identifiers. */
export function fontFamilyNames(value) {
  const groups = [[]];
  for (const node of valueParser(value).nodes) {
    if (node.type === 'div' && node.value === ',') groups.push([]);
    else groups.at(-1).push(node);
  }
  return groups.map(group => {
    const tokens = group.filter(node => !['space', 'comment'].includes(node.type));
    if (tokens.length === 1 && tokens[0].type === 'string') return decodeCss(tokens[0].value);
    if (tokens.length && tokens.every(node => node.type === 'word')) {
      const text = group.map(node => node.type === 'comment' ? ' ' : valueParser.stringify(node)).join('');
      return decodeCss(text).trim().replace(/\s+/g, ' ');
    }
    return undefined;
  });
}
export const cssPropertyName = value => {
  const property = decodeCss(value);
  return property.startsWith('--') ? property : property.includes('-') || /^[A-Z]+$/.test(property)
    ? property.toLowerCase() : property.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`);
};
export const isDesignSystemPlacementProperty = value => PLACEMENT_PROPERTIES.has(cssPropertyName(value));
const VIEWPORT_PROPERTIES = new Set(['height', 'min-height', 'max-height', 'block-size', 'min-block-size', 'max-block-size',
  'scroll-padding', 'scroll-padding-top', 'scroll-padding-right', 'scroll-padding-bottom', 'scroll-padding-left',
  'scroll-padding-inline', 'scroll-padding-inline-start', 'scroll-padding-inline-end', 'scroll-padding-block',
  'scroll-padding-block-start', 'scroll-padding-block-end', 'timeline-scope']);
const TEXT_PROPERTIES = new Set([
  ...VIEWPORT_PROPERTIES, 'display', 'box-sizing', 'padding', 'padding-inline', 'padding-block',
  'padding-top', 'padding-bottom', 'padding-left', 'padding-right', 'padding-inline-start',
  'padding-inline-end', 'padding-block-start', 'padding-block-end', 'font', 'font-family',
  'font-size', 'font-weight', 'font-style', 'font-stretch', 'font-variant', 'font-feature-settings',
  'font-variation-settings', 'line-height', 'letter-spacing', 'word-spacing', 'color', 'text-align',
  'text-indent', 'text-transform', 'text-decoration', 'text-decoration-line', 'text-decoration-color',
  'text-decoration-style', 'text-decoration-thickness', 'text-underline-offset', 'white-space',
  'overflow-wrap', 'word-break', 'text-wrap', 'text-overflow', 'overflow', 'overflow-x', 'overflow-y', 'vertical-align',
]);
export const isDesignSystemPresentationProperty = (value, name) => isDesignSystemPlacementProperty(value)
  || cssPropertyName(value).startsWith('--')
  || name === 'ScrollArea' && VIEWPORT_PROPERTIES.has(cssPropertyName(value))
  || name === 'ContentEditable' && TEXT_PROPERTIES.has(cssPropertyName(value));
const normalize = value => path.posix.normalize(value.replaceAll('\\', '/'));
export const isDesignSystemOwner = (filename, root = process.cwd()) => {
  const name = designSystemFilename(filename);
  const prefix = normalize(root).replace(/\/$/, '') + '/';
  const relative = name.toLowerCase().startsWith(prefix.toLowerCase()) ? name.slice(prefix.length) : name;
  return /^packages\/design-system\/src(?:\/|$)/.test(relative);
};

const sourceFiles = directory => !existsSync(directory) ? [] : readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
  const filename = path.join(directory, entry.name);
  return entry.isDirectory() ? sourceFiles(filename) : /\.(?:css|[cm]?[jt]sx?)$/.test(entry.name) ? [filename] : [];
});
const ownershipCache = new Map();

export function ownedDesignSystemVariables(text, filename) {
  const variables = new Set();
  if (filename.endsWith('.css')) {
    const sheet = postcss.parse(text, { from:filename });
    sheet.walkDecls(declaration => { if (declaration.prop.startsWith('--')) variables.add(decodeCss(declaration.prop)); });
    sheet.walkAtRules('property', rule => variables.add(decodeCss(rule.params.trim())));
  } else {
    // Definitions carry ownership; linter strings mentioning other vendors' variables do not.
    for (const match of text.matchAll(/['"](--[\w-]+)['"]\s*:|\.setProperty\(\s*['"](--[\w-]+)['"]/g)) variables.add(match[1] ?? match[2]);
  }
  return variables;
}

/** Reserve only library-owned markers; ordinary application classes remain available. */
export function designSystemOwnership(root = process.cwd()) {
  const key = normalize(root);
  if (ownershipCache.has(key)) return ownershipCache.get(key);
  const ownership = { classes: new Set(), publicContentClasses:new Set(), attributes: new Set(), variables: new Set(), publicImports: new Set(['@ui-kit/core', '@ui-kit/core/solid', '@ui-kit/core/icons']) };
  const directory = path.join(designSystemPackageRoot(root), 'src');
  for (const filename of sourceFiles(directory)) {
    if (/\.(?:test|spec|fixture)\./.test(filename)) continue;
    const text = readFileSync(filename, 'utf8');
    for (const match of text.matchAll(/\b(ui-[\w-]+)/g)) ownership.classes.add(match[1]);
    for (const match of text.matchAll(/\b(data-ui-[\w-]+)/g)) ownership.attributes.add(match[1]);
    for (const variable of ownedDesignSystemVariables(text, filename)) ownership.variables.add(variable);
    if (normalize(filename).endsWith('/typography.ts')) {
      const recipe = /export const READING_TEXT\s*=\s*Object\.freeze\(\{([\s\S]*?)\}\)/.exec(text)?.[1] ?? '';
      for (const match of recipe.matchAll(/["'](ui-[\w-]+)["']/g)) ownership.publicContentClasses.add(match[1]);
    }
  }
  const manifest = path.join(designSystemPackageRoot(root), 'package.json');
  if (existsSync(manifest)) for (const key of Object.keys(JSON.parse(readFileSync(manifest, 'utf8')).exports ?? {})) {
    if (!key.includes('*')) ownership.publicImports.add(key === '.' ? '@ui-kit/core' : `@ui-kit/core/${key.slice(2)}`);
  }
  if (!ownership.publicImports.has('@ui-kit/core/typography')) ownership.publicContentClasses.clear();
  ownershipCache.set(key, ownership);
  return ownership;
}

export const isProtectedDesignSystemVariable = (value, ownership) => {
  const name = decodeCss(value);
  return /^--(?:ui|wa)-/i.test(name) || ownership.variables.has(name);
};

const protectedNode = (node, ownership) => node.type === 'class'
  ? /^(?:ui|wa)-/.test(node.value) || ownership.classes.has(node.value)
  : node.type === 'attribute'
    ? /^(?:data-(?:ui|wa)-|part$|exportparts$)/i.test(node.attribute) || ownership.attributes.has(node.attribute)
      || node.attribute.toLowerCase() === 'class' && (/(?:^|\s)(?:ui|wa)-/.test(node.value ?? '')
        || [...ownership.classes].some(name => node.value && (name === node.value || node.operator !== '=' && name.includes(node.value))))
    : node.type === 'tag' ? /^wa-/i.test(node.value)
      : node.type === 'pseudo' && /::(?:part|slotted)$/i.test(node.value);

export function isProtectedDesignSystemSelector(selector, ownership = designSystemOwnership()) {
  let protectedSelector = false;
  try {
    selectorParser(selectors => selectors.walk(node => { if (protectedNode(node, ownership)) protectedSelector = true; })).processSync(selector);
  } catch {
    // Invalid/incomplete selectors in generated strings cannot conceal reserved markers.
    protectedSelector = /(?:[.#]|\[data-|--)(?:ui|wa)-|::part\s*\(|\bwa-[\w-]+/i.test(decodeCss(selector));
  }
  return protectedSelector;
}

/** Consumer classes may place a complete control; its appearance and internals stay owned. */
export function designSystemConsumerStylesheetProblems(css, filename, controlClasses = new Set(), root = process.cwd(), ownership = designSystemOwnership(root), presentation = {}) {
  if (isDesignSystemOwner(filename, root)) return [];
  const problems = [];
  const sheet = postcss.parse(css, { from: filename });
  const report = (node, message) => problems.push(`${filename}:${node.source?.start?.line ?? 1}: ${message}`);
  const effectiveSelector = rule => {
    let parent = rule.parent;
    while (parent && parent.type !== 'rule') parent = parent.parent;
    if (!parent) return rule.selector;
    const parents = selectorParser().astSync(effectiveSelector(parent)).nodes.map(selector => selector.toString());
    const selectors = selectorParser().astSync(rule.selector).nodes.map(selector => selector.toString());
    return parents.flatMap(outer => selectors.map(inner => inner.includes('&') ? inner.replaceAll('&', outer) : `${outer} ${inner}`)).join(',');
  };
  const selectorPolicy = rule => {
    let host = false;
    let internals = false;
    let documentRoot = false;
    let strictHost = false;
    const hostNames = new Set();
    const subjectNodes = selector => selector.nodes.slice(selector.nodes.findLastIndex(node => node.type === 'combinator') + 1);
    const hostClass = node => node.type === 'class' ? controlClasses.has(node.value)
      : node.type === 'id' ? presentation.ids?.has(node.value)
      : node.type === 'pseudo' && /^:(?:is|where|nth-child|nth-last-child)$/i.test(node.value)
        && node.nodes?.some(selector => subjectNodes(selector).some(hostClass));
    const matchingSubject = (node, predicate) => predicate(node)
      || node.type === 'pseudo' && /^:(?:is|where|nth-child|nth-last-child)$/i.test(node.value)
        && node.nodes?.some(selector => subjectNodes(selector).some(child => matchingSubject(child, predicate)));
    const ownContentClass = node => node.type === 'class' && !controlClasses.has(node.value) && !protectedNode(node, ownership)
      || node.type === 'pseudo' && /^:(?:is|where)$/i.test(node.value)
        && node.nodes?.every(selector => subjectNodes(selector).some(ownContentClass));
    selectorParser(selectors => selectors.each(selector => {
      let hostPosition = -1;
      let lastCombinator = -1;
      selector.nodes.forEach((node, index) => {
        if (node.type === 'combinator') lastCombinator = index;
        if (hostClass(node)) hostPosition = index;
      });
      const subject = selector.nodes.slice(lastCombinator + 1);
      const namedContent = subject.some(ownContentClass);
      const broad = subject.some(node => matchingSubject(node, candidate => candidate.type === 'universal'
        || candidate.type === 'tag' && /^(?:button|input|select|textarea|dialog|a|summary|form|div|span|svg|path)$/i.test(candidate.value)
        || candidate.type === 'attribute'
        || candidate.type === 'pseudo' && !/^:(?:root|is|where|has)$/i.test(candidate.value)));
      if (broad && !namedContent) internals = true;
      if (subject.some(node => matchingSubject(node, candidate => candidate.type === 'tag' && candidate.value.toLowerCase() === 'html'
        || candidate.type === 'pseudo' && candidate.value.toLowerCase() === ':root'))) documentRoot = true;
      if (hostPosition >= lastCombinator && hostPosition !== -1) host = true;
      if (subject.some(node => matchingSubject(node, candidate => ['class', 'id'].includes(candidate.type) && hostClass(candidate)
        && !['ScrollArea', 'ContentEditable'].some(name => presentation[candidate.type === 'id' ? `${name}Ids` : name]?.has(candidate.value))))) strictHost = true;
      for (const name of ['ScrollArea', 'ContentEditable']) {
        if (subject.some(node => matchingSubject(node, candidate => ['class','id'].includes(candidate.type)
          && presentation[candidate.type === 'id' ? `${name}Ids` : name]?.has(candidate.value)))) hostNames.add(name);
      }
      if (hostPosition !== -1 && hostPosition < lastCombinator) {
        // A named application child is custom content. Bare descendants can be library internals.
        if (!subject.some(node => node.type === 'class' && !protectedNode(node, ownership))) internals = true;
      }
    })).processSync(effectiveSelector(rule));
    return { host, internals, documentRoot, hostNames, strictHost };
  };
  sheet.walkRules(rule => {
    if (isProtectedDesignSystemSelector(effectiveSelector(rule), ownership)) {
      report(rule, 'Design-system selectors, parts and data markers are private; compose the public control instead of styling its implementation.');
      return;
    }
    let policy;
    try { policy = selectorPolicy(rule); } catch { report(rule, 'Consumer selectors must be statically parseable for design-system ownership.'); return; }
    if (policy.host || policy.internals || policy.documentRoot) rule.walkDecls(declaration => {
      let owner = declaration.parent;
      while (owner && owner.type !== 'rule') owner = owner.parent;
      if (owner !== rule) return;
      if (policy.documentRoot && /^(?:font|font-size)$/.test(cssPropertyName(declaration.prop))) report(declaration, 'Document root font size controls design-system rem metrics; define these metrics only in the owned design-system styles.');
      const allowed = isDesignSystemPlacementProperty(declaration.prop) || cssPropertyName(declaration.prop).startsWith('--')
        || !policy.internals && policy.hostNames.size && !policy.strictHost
        && [...policy.hostNames].every(name => isDesignSystemPresentationProperty(declaration.prop, name));
      if ((policy.host || policy.internals) && !allowed) report(declaration, policy.internals
        ? `Broad selectors can match design-system hosts and internals; keep ${decodeCss(declaration.prop)} on named application content or its owned control stylesheet.`
        : `Complete controls own ${decodeCss(declaration.prop)}; this consumer class may set only outer placement properties.`);
    });
    if (policy.host) rule.nodes.filter(node => node.type === 'atrule' && !['media', 'supports', 'container', 'layer'].includes(decodeCss(node.name).toLowerCase()))
      .forEach(rule => report(rule, 'Consumer control classes cannot inject styling directives; use outer placement declarations.'));
  });
  sheet.walkDecls(declaration => {
    if (isProtectedDesignSystemVariable(declaration.prop, ownership)) report(declaration, `Design-system custom property ${decodeCss(declaration.prop)} is immutable in consumers, including ancestors.`);
  });
  sheet.walkAtRules(rule => {
    const name = decodeCss(rule.name).toLowerCase();
    if (name === 'font-face') rule.walkDecls(declaration => {
      if (cssPropertyName(declaration.prop) === 'font-family'
        && fontFamilyNames(declaration.value).some(family => /^ui-/i.test(family ?? ''))) report(declaration,
        'Design-system font family registrations are private. Consumers may use ui- families but cannot redefine their faces.');
    });
    if (name === 'property' && isProtectedDesignSystemVariable(rule.params.trim(), ownership)) report(rule, 'Consumers cannot register or redefine design-system custom properties.');
    if (name === 'scope' && [...rule.params.matchAll(/\(([^()]*)\)/g)].some(match => isProtectedDesignSystemSelector(match[1], ownership))) report(rule, 'Consumers cannot establish a styling scope inside design-system implementation selectors.');
  });
  return problems;
}
