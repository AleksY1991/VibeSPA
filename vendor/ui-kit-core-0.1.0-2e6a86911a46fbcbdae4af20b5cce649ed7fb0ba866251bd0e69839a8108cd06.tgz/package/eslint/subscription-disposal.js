const TRANSPARENT_PARENTS = new Set([
  'AwaitExpression',
  'ChainExpression',
  'TSAsExpression',
  'TSNonNullExpression',
  'TSTypeAssertion',
  'UnaryExpression',
]);

function relativeFilename(context) {
  const normalized = context.filename.replaceAll('\\', '/');
  const at = normalized.lastIndexOf('/src/');
  return at >= 0 ? normalized.slice(at + 1) : normalized.replace(/^\.\//, '');
}

function isTest(filename) {
  return /(?:^|\/)test(?:\/|$)|\.(?:test|spec)\.[cm]?[jt]sx?$/.test(filename);
}

function memberName(callee) {
  if (callee.type !== 'MemberExpression' && callee.type !== 'OptionalMemberExpression') {
    return undefined;
  }
  if (!callee.computed && callee.property.type === 'Identifier') return callee.property.name;
  if (callee.computed && callee.property.type === 'Literal') return String(callee.property.value);
  return undefined;
}

function isDiscarded(node) {
  let current = node;
  while (current.parent && TRANSPARENT_PARENTS.has(current.parent.type)) current = current.parent;
  return current.parent?.type === 'ExpressionStatement';
}

/** A subscription is an owned resource: its returned disposer may not be dropped. */
export function createSubscriptionDisposalRule(REVIEWED_EXTERNAL_LIFECYCLE = new Map()) { return {
  meta: {
    type: 'problem',
    schema: [],
    messages: {
      discarded:
        'SUBSCRIPTION OWNER GATE: keep the disposer returned by .subscribe() and release it from the same lifecycle that created the subscription.',
      stale:
        'SUBSCRIPTION OWNER GATE: this reviewed external-lifecycle call now occurs {{actual}} time(s), below its pinned count of {{expected}}. Lower the exact ledger in eslint/subscription-disposal.js.',
    },
  },
  create(context) {
    const filename = relativeFilename(context);
    if (isTest(filename)) return {};
    const violations = [];
    return {
      CallExpression(node) {
        if (memberName(node.callee) !== 'subscribe' || !isDiscarded(node)) return;
        violations.push(node);
      },
      'Program:exit'(program) {
        const allowance = REVIEWED_EXTERNAL_LIFECYCLE.get(filename) ?? 0;
        for (const node of violations.slice(allowance)) {
          context.report({ node, messageId: 'discarded' });
        }
        if (violations.length < allowance) {
          context.report({
            node: program,
            messageId: 'stale',
            data: { actual: String(violations.length), expected: String(allowance) },
          });
        }
      },
    };
  },
};

}
export const SUBSCRIPTION_DISPOSAL = createSubscriptionDisposalRule();
