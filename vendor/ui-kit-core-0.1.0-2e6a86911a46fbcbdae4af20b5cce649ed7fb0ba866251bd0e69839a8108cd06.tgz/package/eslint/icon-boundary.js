import path from 'node:path';
import { designSystemFilename } from './package-location.js';

const SVG_TAGS = new Set(['svg', 'path', 'circle', 'ellipse', 'rect', 'line', 'polyline', 'polygon', 'g', 'defs', 'marker', 'symbol', 'use', 'tspan', 'linearGradient', 'radialGradient', 'stop', 'clipPath', 'mask']);
const ICON_PACKAGE = /^(?:@lucide\/|lucide(?:[-/]|$)|@heroicons\/|@tabler\/icons|react-icons(?:\/|$)|@phosphor-icons\/)/;
const SVG_TEXT = /<\/?(?:svg|path|circle|rect)\b|data:image\/svg\+xml|%3csvg\b/i;
const nameOf = node => node?.name ?? node?.value;

/** UI views select icons; only private UI graphics construct vector artwork. */
export const ICON_BOUNDARY = {
  meta: {
    type: 'problem', schema: [],
    messages: {
      svg: 'SVG artwork belongs to the core icon library or an explicitly owned application graphic. UI views import icons from @ui-kit/core/icons; business features supply semantic values through @haku/ui-contracts.',
      package: 'Only the core icon library may import icon packages. UI views import icons from @ui-kit/core/icons.',
      private: 'Icon geometry and renderer internals are private. Use @ui-kit/core/icons; only the declared graph icon adapter consumes shared glyph geometry.',
      stroke: 'The private UI icon library owns stroke width. Remove the local stroke override.',
    },
  },
  create(context) {
    const file = designSystemFilename(context.filename);
    if (/\.(?:test|spec)\.[jt]sx?$/.test(file)) return {};
    const iconOwner = /(?:^|\/)packages\/design-system\/src\/icons\//.test(file);
    const graphIconAdapter = /(?:^|\/)packages\/ui\/src\/presentation\/graph\/icon-canvas\.[cm]?[jt]sx?$/.test(file);
    const graphicOwner = iconOwner
      || /(?:^|\/)packages\/design-system\/src\/diagnostic-decoration\.[cm]?[jt]s$/.test(file)
      || /(?:^|\/)packages\/ui\/src\/compositions\/solid\/(?:landing-map|diagram-links)\.[cm]?[jt]sx?$/.test(file);
    const textOf = node => node?.type === 'Literal' ? node.value
      : node?.type === 'TemplateLiteral' && !node.expressions.length ? node.quasis[0]?.value.cooked : undefined;
    const checkImport = (node, source) => {
      if (typeof source !== 'string') return;
      if (ICON_PACKAGE.test(source) && !iconOwner) context.report({ node, messageId: 'package' });
      const target = path.posix.normalize(source.startsWith('#ui/') ? `/packages/ui/src/${source.slice(4)}`
        : source === '@ui-kit/core' ? '/packages/design-system/src/index'
        : source.startsWith('@ui-kit/core/') ? `/packages/design-system/src/${source.slice(13)}`
        : source.startsWith('@/') ? `/src/${source.slice(2)}`
        : source.startsWith('.') ? path.posix.join(path.posix.dirname(file), source) : source);
      const graphGeometry = graphIconAdapter && /\/icons\/(?:catalog|constants)(?:\.[cm]?[jt]sx?)?$/.test(target);
      if (!iconOwner && !graphGeometry && /(?:^|\/)packages\/design-system\/src\/icons\/(?!index(?:\.[cm]?[jt]sx?)?$)/.test(target)) {
        context.report({ node, messageId: 'private' });
      }
    };
    const checkText = (node, value) => {
      if (!graphicOwner && typeof value === 'string' && SVG_TEXT.test(value)) context.report({ node, messageId: 'svg' });
    };
    return {
      ImportDeclaration(node) { checkImport(node, node.source.value); },
      ExportNamedDeclaration(node) { if (node.source) checkImport(node, node.source.value); },
      ExportAllDeclaration(node) { checkImport(node, node.source.value); },
      ImportExpression(node) { checkImport(node, textOf(node.source)); },
      JSXOpeningElement(node) {
        if (graphicOwner) return;
        if (SVG_TAGS.has(nameOf(node.name))) context.report({ node, messageId: 'svg' });
        for (const attribute of node.attributes) {
          if (attribute.type !== 'JSXAttribute') continue;
          const name = nameOf(attribute.name);
          if (name === 'component' && SVG_TAGS.has(textOf(attribute.value?.expression ?? attribute.value))) {
            context.report({ node: attribute, messageId: 'svg' });
          }
          if (name === 'stroke-width' || name === 'strokeWidth') context.report({ node: attribute, messageId: 'stroke' });
        }
      },
      CallExpression(node) {
        if (node.callee.type === 'Identifier' && node.callee.name === 'require') checkImport(node, textOf(node.arguments[0]));
        if (graphicOwner) return;
        const name = nameOf(node.callee.property ?? node.callee);
        if (name === 'createElementNS' && textOf(node.arguments[0]) === 'http://www.w3.org/2000/svg'
          || name === 'createElement' && SVG_TAGS.has(textOf(node.arguments[0]))) context.report({ node, messageId: 'svg' });
      },
      Literal(node) { checkText(node, node.value); },
      TemplateElement(node) { checkText(node, node.value.cooked ?? node.value.raw); },
    };
  },
};
