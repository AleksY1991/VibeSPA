import path from 'node:path';
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { Linter } from 'eslint';
import tseslint from 'typescript-eslint';
import ts from 'typescript';
import { describe, expect, it } from 'vitest';
import { DESIGN_SYSTEM_BOUNDARY, designSystemDependency, isDesignSystemModule, isDesignSystemTest } from './design-system-boundary.js';
import { auditDesignSystemSourceFiles, designSystemSourceFileProblems } from './design-system-source-files.js';

function problems(code: string, filename = 'packages/design-system/src/solid/future.tsx') {
  return new Linter().verify(code, [{
    files: ['**/*.{ts,tsx,js,mjs,cjs}'],
    languageOptions: { parser: tseslint.parser, sourceType: 'module' },
    plugins: { isolation: { rules: { design: DESIGN_SYSTEM_BOUNDARY } } },
    rules: { 'isolation/design': 'error' },
  }], { filename: path.resolve(filename) }).map(message => message.messageId);
}

const root = fileURLToPath(new URL('../../../', import.meta.url));
const core = path.join(root, 'packages/design-system');
const declaration = () => JSON.parse(readFileSync(path.join(core, 'package.json'), 'utf8'));

describe('extractable design-system dependencies', () => {
  it.each([
    'import { View } from "#ui/views/future/View";',
    'import type { NodeStatus } from "@haku/ui-contracts/domain";',
    'export * from "@haku/ui-contracts";',
    'export { appearance } from "../../../ui/src/compositions/node-appearance";',
    'export * from "../../../../../src/features/future/model";',
    'const model = import("@/store/model");',
    'type View = import("@haku/ui-contracts/views/backlog").BacklogView;',
    'const asset = new URL("../../../ui/src/views/future/data.json", import.meta.url);',
    'const base = import.meta.url; const asset = new URL("../../../ui/src/views/future/data.json", base);',
    'const { URL: Asset } = globalThis; const asset = new Asset("../../../ui/src/views/future/data.json", import.meta.url);',
    'const asset = new (URL as typeof URL)("../../../ui/src/views/future/data.json", (import.meta.url as string));',
    'const asset = new globalThis.URL("../../../ui/src/views/future/data.json", import.meta.url);',
    'import "#ui/internal/../compositions/node-appearance";',
    'import "#ui/internal/button-presets";',
    '/// <reference path="../../../../../src/vite-env.d.ts" />\nexport {};',
  ])('rejects application dependencies through every module syntax: %s', code => {
    expect(problems(code)).toContain('dependency');
  });

  it.each(['rxdb', '@supabase/supabase-js', 'livekit-client', 'node:fs', 'unknown-library'])(
    'requires a package-owned generic dependency instead of %s', dependency => {
      expect(problems(`import { value } from "${dependency}";`)).toEqual(['external']);
    },
  );

  it.each([
    'import "@awesome.me/webawesome/dist/styles/themes/default.css";',
    'import theme from "@awesome.me/webawesome/dist/styles/themes/default.css?inline";',
    'export { default as theme } from "@awesome.me/webawesome/dist/styles/themes/default.css?raw";',
    'export * from "@awesome.me/webawesome/dist/styles/themes/default.css#theme";',
    'const theme = import("@awesome.me/webawesome/dist/styles/themes/default.css");',
    'const theme = import("@awesome.me/webawesome/dist/styles/themes/default.CSS?inline");',
    'const theme = new URL("@awesome.me/webawesome/dist/styles/themes/default.css", import.meta.url);',
  ])('requires external stylesheets to be owned and scoped locally: %s', code => {
    expect(problems(code)).toContain('stylesheet');
  });

  it.each([
    'const model = import(modulePath);',
    'const model = import(`./${name}`);',
    'const asset = new URL(assetPath, import.meta.url);',
  ])('rejects uncheckable module paths: %s', code => expect(problems(code)).toEqual(['dynamic']));

  it.each([
    'const model = require("./button");',
    'const load = require; load("@/store/model");',
    'const model = require.resolve("#ui/compositions/node-appearance");',
    'const model = module.require("../../app");',
    'import Model = require("@/features/future/model");',
    'const views = import.meta.glob("./*.ts", { base: "../compositions" });',
    'const views = import.meta.glob("./**/*.{ts,tsx}");',
    'const views = import.meta.glob(["./*.tsx", "../../views/**/*.tsx"]);',
    'const views = import.meta.glob(glob);',
    'const path = import.meta.resolve("./button");',
    'const meta = import.meta;',
    'eval(source);',
    'new Function(source);',
    'importScripts("/app.js");',
    'new Worker("/app.js");',
  ])('requires explicit imports or an injected loader: %s', code => expect(problems(code)).toContain('loader'));

  it('gates every neutral support module as ordinary package-owned source', () => {
    for (const filename of [
      'packages/design-system/src/runtime/hotkeys.ts', 'packages/design-system/src/runtime/platform.ts',
      'packages/design-system/src/lib/utils.ts', 'packages/design-system/src/lib/dayHighlight.ts',
      'packages/design-system/src/contracts/calendar.ts', 'packages/design-system/src/contracts/platform.ts',
      'packages/design-system/src/contracts/settings-metadata.ts',
    ]) expect(problems('export * from "@haku/ui-contracts/domain";', filename), filename).toEqual(['dependency']);
  });

  it('permits controls, assets, declared generic dependencies and owned host contracts', () => {
    for (const code of [
      'import { Button } from "./button";',
      'import "../tokens.css";',
      'const theme = import("../vendor/web-awesome/theme.css");',
      'import theme from "../tokens.css?inline";',
      'import { hotkeys } from "../runtime/hotkeys";',
      'import { cn } from "../lib/utils";',
      'import type { SurfaceAuthority } from "../contracts/platform";',
      'import { sameRecord } from "../contracts/equality";',
      'import { dayKey } from "../contracts/calendar";',
      'import type { SettingDescriptor } from "../contracts/settings-metadata";',
      'import { createSignal } from "solid-js";',
      '/** @jsxImportSource @solidjs/web */\nexport {};',
      'const vendor = import("@awesome.me/webawesome/dist/components/button/button.js");',
      'const asset = new URL("../assets/fonts/inter-400.woff2", import.meta.url);',
    ]) expect(problems(code), code).toEqual([]);
    for (const [key, target] of Object.entries(declaration().exports)) {
      if (key.includes('*')) continue;
      const source = key === '.' ? '@ui-kit/core' : `@ui-kit/core${key.slice(1)}`;
      const expected = isDesignSystemTest(path.join(core, target as string)) ? ['testDependency']
        : (target as string).startsWith('./src/') ? [] : ['dependency'];
      expect(problems(`import "${source}";`), source).toEqual(expected);
    }
    expect(problems('import "@ui-kit/core/eslint/future.js";')).toEqual(['privateImport']);
    expect(problems('import "@ui-kit/core/solid/future";')).toEqual(['privateImport']);
    expect(problems('import "@ui-kit/core/src/solid/button";')).toEqual(['privateImport']);
    expect(problems('import "@ui-kit/core/unknown";')).toEqual(['privateImport']);
  });

  it('uses the package manifest instead of root dependencies or a second allowlist', () => {
    const filename = path.resolve('packages/design-system/src/solid/future.ts');
    const packageDeclaration = { name: '@ui-kit/core', exports: { '.': './src/index.ts' }, dependencies: { 'new-generic-package': '1.0.0' } };
    expect(designSystemDependency(filename, 'new-generic-package', process.cwd(), packageDeclaration)).toBeUndefined();
    expect(designSystemDependency(filename, 'solid-js', process.cwd(), packageDeclaration)).toBe('external');
    expect(designSystemDependency(filename, '@haku/ui', process.cwd(), { ...packageDeclaration, dependencies: { '@haku/ui': '*' } })).toBe('dependency');
    const tooling = { ...packageDeclaration, devDependencies: { vitest: '1.0.0', '@types/mdast': '1.0.0' } };
    expect(designSystemDependency(filename, 'vitest', process.cwd(), tooling)).toBe('external');
    expect(designSystemDependency(filename, 'vitest', process.cwd(), tooling, true)).toBeUndefined();
    expect(designSystemDependency(filename, 'mdast', process.cwd(), tooling)).toBe('external');
    expect(designSystemDependency(filename, 'mdast', process.cwd(), tooling, true)).toBeUndefined();
  });

  it('keeps production independent of test fixtures while allowing application test harnesses', () => {
    expect(problems('import "./button.test";')).toEqual(['testDependency']);
    expect(problems('import "./button.test.tsx?raw";')).toEqual(['testDependency']);
    expect(problems('const test = import("./button.test.tsx");')).toEqual(['testDependency']);
    expect(problems('import "../vendor/web-awesome/dialog.test-helper";')).toEqual(['testDependency']);
    expect(problems('import "../__tests__/helpers";')).toEqual(['testDependency']);
    expect(problems('import "../testing/web-awesome";')).toEqual(['testDependency']);
    expect(problems('import "@ui-kit/core/testing/web-awesome";')).toEqual(['testDependency']);
    expect(problems('import "@/features/future/model";', 'packages/design-system/src/solid/future.test.tsx')).toEqual([]);
    expect(problems('import "@haku/ui-contracts/domain";', 'packages/ui/src/compositions/node-appearance.ts')).toEqual([]);
  });

  it('normalizes relative imports and traversal on Windows and UNC checkouts', () => {
    for (const root of ['C:/repo', '//server/share']) {
      const filename = `${root}/packages/design-system/src/solid/future.tsx`;
      expect(designSystemDependency(filename, '../button-presets', root, declaration())).toBeUndefined();
      expect(designSystemDependency(filename, '../../../ui/src/compositions/node-appearance', root, declaration())).toBe('dependency');
      expect(designSystemDependency(filename, '#ui/internal/button-presets', root, declaration())).toBe('dependency');
    }
  });

  it('covers the complete extraction unit without application aliases, ambient types or tests', () => {
    const walk = (directory: string): string[] => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
      const filename = path.join(directory, entry.name);
      return entry.isDirectory() ? walk(filename) : [filename];
    });
    const relative = (filename: string) => path.relative(root, filename).replaceAll('\\', '/');
    const expected = walk(path.join(core, 'src')).map(relative)
      .filter(filename => /\.tsx?$/.test(filename) && isDesignSystemModule(filename) && !isDesignSystemTest(filename)).sort();
    const filename = path.join(core, 'tsconfig.json');
    const config = ts.readConfigFile(filename, ts.sys.readFile);
    const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, path.dirname(filename));
    expect(parsed.errors).toEqual([]);
    expect(parsed.fileNames.map(relative).sort()).toEqual(expected);
    expect(parsed.options.types).toEqual([]);
    expect(parsed.options.paths ?? {}).not.toHaveProperty('@/*');
    expect(parsed.options.paths ?? {}).not.toHaveProperty('#ui/*');
    expect(auditDesignSystemSourceFiles(root)).toEqual([]);
  });

  it.each(['future.mts', 'future.cts', 'future.jsx', 'future.MTS'])(
    'rejects source formats that ESLint and the standalone checker do not cover: %s', filename => {
      expect(designSystemSourceFileProblems(filename)).toHaveLength(1);
    },
  );

  it('finds unlinted helpers through a filesystem audit independent of ESLint discovery', () => {
    const prefix = path.join(tmpdir(), 'ui-kit-boundary-');
    const root = mkdtempSync(prefix);
    expect(root.startsWith(prefix)).toBe(true);
    try {
      const nested = path.join(root, 'packages/design-system/src/nested');
      mkdirSync(nested, { recursive: true });
      writeFileSync(path.join(nested, 'helper.mts'), 'export * from "@haku/ui-contracts/domain";');
      writeFileSync(path.join(nested, 'entry.ts'), 'export * from "./helper.mjs";');
      const errors = auditDesignSystemSourceFiles(root);
      expect(errors).toHaveLength(1);
      expect(errors[0]).toContain('helper.mts');
    } finally {
      rmSync(root, { recursive: true });
    }
  });
});

describe('design-system host capability isolation', () => {
  it.each([
    'localStorage.getItem("haku.account");',
    'sessionStorage.setItem("account", "1");',
    'indexedDB.open("haku");',
    'caches.open("app");',
    'fetch("/api/account");',
    'window.fetch("/api/account");',
    'window["localStorage"].getItem("account");',
    'self.sessionStorage.clear();',
    'globalThis.indexedDB.open("app");',
    'new XMLHttpRequest();',
    'new WebSocket("wss://app.example");',
    'new EventSource("/events");',
    'new FontFace("Host Face", source);',
    'const Face = globalThis.FontFace; new Face("Inter", source);',
    'navigator.sendBeacon("/analytics");',
    'navigator.storage.persist();',
    'navigator.serviceWorker.register("/app.js");',
    'document.cookie = "account=1";',
    'const browser = window; browser.localStorage.clear();',
    'const { fetch: load } = globalThis; load("/api/account");',
    'const { localStorage } = window;',
    'const key = "fetch"; window[key]("/app");',
    'const endpoint = import.meta.env.VITE_API_URL;',
    'document.defaultView?.fetch("/api/account");',
    'document.defaultView!.fetch("/api/account");',
    'const browser = document.defaultView; browser?.localStorage.clear();',
    'const { fetch: load } = document.defaultView; load("/api/account");',
    'const { defaultView: browser } = document; browser?.fetch("/api/account");',
    'const { defaultView: { localStorage: storage } } = document;',
    'const browser = (document.defaultView as Window); browser.fetch("/api/account");',
    'const api = process.env.API_URL;',
    'const { env } = process;',
    'const node = process; const api = node.env.API_URL;',
    'const { process: node } = globalThis; const api = node.env.API_URL;',
    'const field = "env"; process[field].API_URL;',
  ])('requires the host to supply runtime capabilities: %s', code => expect(problems(code)).toContain('runtime'));

  it.each([
    'function load(fetch: (url: string) => unknown) { return fetch("/api/account"); }',
    'function read(window: {localStorage: {getItem(key: string): string}}) { return window.localStorage.getItem("account"); }',
    'function read(host: {fetch(): void}) { host.fetch(); }',
    'function read(document: {defaultView: {fetch(): void}}) { document.defaultView.fetch(); }',
    'function read(process: {env: {API_URL: string}}) { return process.env.API_URL; }',
    'function read(document: {defaultView: {fetch(): void}}) { const {defaultView: browser} = document; browser.fetch(); }',
    'interface Host { fetch(url: string): Promise<unknown>; }',
    'interface Host { load: typeof fetch; }',
    'type Load = typeof window.fetch;',
    'const source = { fetch: "host command" };',
    'const image = document.createElement("img"); image.src = source;',
    'window.addEventListener("resize", handler);',
    'document.fonts.ready; document.fonts.load("16px ui-inter"); document.fonts.check("16px ui-inter");',
    'const key = Symbol.for("ui-kit.vendor.registration"); const registry = globalThis[key];',
    'function load(require: (name: string) => unknown) { return require("host-resource"); }',
  ])('permits typed injected capabilities and ordinary presentation APIs: %s', code => expect(problems(code)).toEqual([]));
});
