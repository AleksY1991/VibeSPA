import { designSystemFilename } from './package-location.js';
const CORE_MODULE_STATE = new Map([
  ['packages/design-system/src/infrastructure/viewportGeometry.ts', 1],
]);
const CORE_LIFETIME_STATE = new Map([
  ['packages/design-system/src/infrastructure/construction.ts', 1],
  ['packages/design-system/src/solid/interaction-events.ts', 1],
  ['packages/design-system/src/solid/caret-input.ts', 1],
  ['packages/design-system/src/runtime/hotkeys.ts', 2],
  // Canonical family availability belongs to the CustomElementRegistry lifetime.
  ['packages/design-system/src/vendor/web-awesome/registration.ts', 1],
]);
const FACTORIES = new Set([
  'createSignal',
  'createStore',
  'createMutable',
  'createWritableSource',
  'createWritableRecordSource',
  'createNeutralCell',
]);

const FUNCTION_NODES = new Set([
  'FunctionDeclaration',
  'FunctionExpression',
  'ArrowFunctionExpression',
]);

function relativeFilename(context) {
  const normalized = designSystemFilename(context.filename);
  if (normalized.startsWith('packages/design-system/')) return normalized;
  const cwd = String(context.cwd ?? context.getCwd?.() ?? '').replaceAll('\\', '/').replace(/\/$/, '');
  if (cwd && normalized.startsWith(cwd + '/')) return normalized.slice(cwd.length + 1);
  return normalized.match(/(?:^|\/)(packages\/ui\/.*|src\/.*)$/)?.[1] ?? normalized.replace(/^\.\//, '');
}

function isTest(filename) {
  return /(?:^|\/)tests?(?:\/|$)|\.(?:test|spec|test-helper|fixture)\.[cm]?[jt]sx?$/.test(filename);
}

function lexicalOwner(node) {
  for (let current = node.parent; current; current = current.parent) {
    if (FUNCTION_NODES.has(current.type)) {
      if (current.parent?.type === 'MethodDefinition' && current.parent.kind === 'constructor') return current.parent.parent.parent;
      return current;
    }
    if ((current.type === 'PropertyDefinition' || current.type === 'AccessorProperty') && !current.static) {
      return current.parent.parent; // the class instance, never a static module field
    }
    if (current.type === 'Program') return undefined;
  }
  return undefined;
}

function functionName(node) {
  if (node.id?.type === 'Identifier') return node.id.name;
  if (node.parent?.type === 'VariableDeclarator' && node.parent.id.type === 'Identifier') return node.parent.id.name;
  return undefined;
}

/** Follow local startup calls so wrapping a singleton in a helper/IIFE cannot hide it. */
function moduleExecutions(functions, invocations) {
  const names = new Map(functions.map(node => [functionName(node), node]).filter(([name]) => name));
  const executed = new Set();
  let changed = true;
  while (changed) {
    changed = false;
    for (const call of invocations) {
      const owner = lexicalOwner(call);
      if (owner && !executed.has(owner)) continue;
      const target = call.callee.type === 'Identifier' ? names.get(call.callee.name)
        : FUNCTION_NODES.has(call.callee.type) ? call.callee : undefined;
      // A callback registered at module scope also has a module lifetime.
      for (const candidate of [target, ...call.arguments.filter(argument => FUNCTION_NODES.has(argument.type))]) {
        if (candidate && !executed.has(candidate)) { executed.add(candidate); changed = true; }
      }
    }
  }
  return executed;
}

export function createUiStatePersistenceRule(REVIEWED_MODULE_STATE = CORE_MODULE_STATE, REVIEWED_LIFETIME_STATE = CORE_LIFETIME_STATE) { return {
  meta: {
    type: 'problem',
    schema: [],
    messages: {
      unpersisted:
        'UI STATE GATE: unreviewed {{lifetime}} raw state. Persist durable values through a feature-owned PersistedStateDefinition; transient module owners and lifetime-owned TypeScript helpers have separate exact-count entries in eslint/ui-state-persistence.js. A helper or constructor allowance never permits a module singleton.',
      stale:
        'UI STATE GATE: this file has {{actual}} {{lifetime}} raw state factories but its reviewed ledger pins {{expected}}. Update that lifetime only after classifying the removed/replaced owner.',
    },
  },
  create(context) {
    const filename = relativeFilename(context);
    if (isTest(filename)) return {};

    const localFactories = new Set();
    const factoryNamespaces = new Set();
    const calls = [];
    const functions = [];
    const invocations = [];

    return {
      ImportDeclaration(node) {
        for (const specifier of node.specifiers) {
          if (specifier.type === 'ImportSpecifier') {
            const imported = specifier.imported.type === 'Identifier'
              ? specifier.imported.name
              : specifier.imported.value;
            if (FACTORIES.has(imported)) localFactories.add(specifier.local.name);
          } else if (specifier.type === 'ImportNamespaceSpecifier') {
            factoryNamespaces.add(specifier.local.name);
          }
        }
      },
      FunctionDeclaration(node) { functions.push(node); },
      FunctionExpression(node) { functions.push(node); },
      ArrowFunctionExpression(node) { functions.push(node); },
      ClassDeclaration(node) { functions.push(node); },
      ClassExpression(node) { functions.push(node); },
      NewExpression(node) { invocations.push(node); },
      CallExpression(node) {
        invocations.push(node);
        const direct = node.callee.type === 'Identifier' && localFactories.has(node.callee.name);
        const namespaced = node.callee.type === 'MemberExpression'
          && !node.callee.computed
          && node.callee.object.type === 'Identifier'
          && factoryNamespaces.has(node.callee.object.name)
          && node.callee.property.type === 'Identifier'
          && FACTORIES.has(node.callee.property.name);
        if (direct || namespaced) calls.push(node);
      },
      'Program:exit'(program) {
        const executed = moduleExecutions(functions, invocations);
        const owned = { module: [], lifetime: [] };
        for (const call of calls) {
          const owner = lexicalOwner(call);
          owned[!owner || executed.has(owner) ? 'module' : 'lifetime'].push(call);
        }
        for (const [lifetime, registry] of [['module', REVIEWED_MODULE_STATE], ['lifetime', REVIEWED_LIFETIME_STATE]]) {
          // Component bodies remain local; plain helper/constructor modules need a reviewed lifetime.
          if (lifetime === 'lifetime' && filename.endsWith('.tsx')) continue;
          const expected = registry.get(filename) ?? 0;
          const actual = owned[lifetime];
          for (const node of actual.slice(expected)) context.report({ node, messageId: 'unpersisted', data: { lifetime } });
          if (actual.length < expected) context.report({
            node: program, messageId: 'stale',
            data: { lifetime, actual: String(actual.length), expected: String(expected) },
          });
        }
      },
    };
  },
};

}
export const UI_STATE_PERSISTENCE = createUiStatePersistenceRule();
