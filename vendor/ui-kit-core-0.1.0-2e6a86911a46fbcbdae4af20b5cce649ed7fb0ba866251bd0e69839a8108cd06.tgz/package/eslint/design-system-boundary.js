import path from 'node:path';
import { designSystemFilename, designSystemPackageRoot } from './package-location.js';
import { readFileSync } from 'node:fs';

const normalize = value => path.posix.normalize(value.replaceAll('\\', '/'));
const sourceRoot = 'packages/design-system/src/';
const packageRoot = 'packages/design-system';
const testModule = value => /(?:\.(?:test(?:-helpers?)?|spec|fixture|type-test)\.[cm]?[jt]sx?$|\/(?:__tests__|tests|testing)\/)/.test(value);
const literal = node => node?.type === 'Literal' ? node.value
  : node?.type === 'TemplateLiteral' && node.expressions.length === 0 ? node.quasis[0]?.value.cooked : undefined;
const member = node => node?.computed ? literal(node.property) : node?.property?.name;
const packageName = value => value.startsWith('@') ? value.split('/').slice(0, 2).join('/') : value.split('/')[0];
const runtimeApis = new Set(['localStorage', 'sessionStorage', 'indexedDB', 'caches', 'fetch',
  'XMLHttpRequest', 'WebSocket', 'EventSource', 'BroadcastChannel', 'FontFace']);
const loaderApis = new Set(['require', 'module', 'eval', 'Function', 'importScripts', 'Worker', 'SharedWorker', 'System']);
const browserGlobals = new Set(['window', 'self', 'globalThis']);

function manifest(root) {
  try {
    return JSON.parse(readFileSync(path.join(designSystemPackageRoot(root), 'package.json'), 'utf8'));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    // Missing declarations fail closed during moves or partial checkouts.
    return { name: '@ui-kit/core', exports: {} };
  }
}

export function isDesignSystemModule(relativePath) {
  return designSystemFilename(relativePath).startsWith(sourceRoot);
}

export function isDesignSystemTest(relativePath) {
  return testModule(normalize(relativePath));
}

export function designSystemDependency(filename, specifier, root = process.cwd(), declaration, typeOnly = false) {
  if (typeof specifier !== 'string') return 'dynamic';
  declaration ??= manifest(root);
  const resource = specifier.replace(/\?.*$/, '').replace(/(?!^)#.*$/, '');
  const rootPath = `${normalize(root).replace(/\/$/, '')}/`;
  let resolved;
  if (resource.startsWith('.')) {
    resolved = normalize(path.posix.join(path.posix.dirname(normalize(filename)), resource));
  } else if (resource === declaration.name || resource.startsWith(`${declaration.name}/`)) {
    const key = resource === declaration.name ? '.' : `.${resource.slice(declaration.name.length)}`;
    const target = declaration.exports?.[key];
    if (typeof target !== 'string' || key.includes('*')) return 'privateImport';
    resolved = normalize(`${rootPath}${packageRoot}/${target}`);
  } else {
    // Third-party styles are outside the owned CSS scope audit, even when their
    // package is an allowed runtime dependency. Snapshot and scope them locally.
    if (/\.css$/i.test(resource)) return 'stylesheet';
    if (/^(?:[.#/]|[A-Za-z]:[\\/])/.test(resource) || resource.startsWith('@/')
      || resource.startsWith('@haku/')) return 'dependency';
    const declared = { ...declaration.dependencies, ...declaration.peerDependencies,
      ...(typeOnly ? declaration.devDependencies : {}) };
    const name = packageName(resource);
    const typed = name.startsWith('@') ? `@types/${name.slice(1).replace('/', '__')}` : `@types/${name}`;
    return Object.hasOwn(declared, name) || typeOnly && Object.hasOwn(declared, typed) ? undefined : 'external';
  }
  const relative = resolved.toLowerCase().startsWith(rootPath.toLowerCase()) ? resolved.slice(rootPath.length) : resolved;
  if (testModule(`${relative.replace(/\.[cm]?[jt]sx?$/, '')}.ts`)) return 'testDependency';
  return isDesignSystemModule(relative) || isDesignSystemModule(resolved) ? undefined : 'dependency';
}

export const DESIGN_SYSTEM_BOUNDARY = {
  meta: { type: 'problem', schema: [], messages: {
    dependency: 'The reusable design system owns its source and assets. Use relative self imports or its declared package exports; inject host values and commands instead of importing Haku aliases, views, domain models, storage or adapters.',
    privateImport: 'Use an explicit public design-system export. Undeclared package subpaths and source paths are private.',
    external: 'Declare a generic dependency in the design-system package, or inject an explicit host capability. Root application dependencies do not belong to this package.',
    stylesheet: 'Design-system styles must be owned and audited inside the package. Import a locally scoped stylesheet instead of external package CSS.',
    testDependency: 'Production design-system code cannot depend on test helpers, fixtures or specs. Keep its dependency graph extractable without application tests.',
    dynamic: 'Design-system module paths must be static. Use an explicit import or an injected loader capability.',
    loader: 'Production design-system code uses explicit ES module imports. Glob, implicit and executable-string loaders hide dependencies; inject a host loader when necessary.',
    runtime: 'Storage, network, global font registration and application environment access belongs to the host. Use owned font-face CSS or pass an explicit typed capability into the reusable design system.',
  } },
  create(context) {
    const root = normalize(context.cwd ?? process.cwd());
    const filename = normalize(context.filename);
    const relative = designSystemFilename(filename).startsWith(sourceRoot) ? designSystemFilename(filename) : filename.slice(root.length + 1);
    if (testModule(filename) || !isDesignSystemModule(relative)) return {};
    const declaration = manifest(root);
    const report = (node, messageId) => context.report({ node, messageId });
    const check = (node, specifier, typeOnly = false) => {
      const messageId = designSystemDependency(filename, specifier, root, declaration, typeOnly);
      if (messageId) report(node, messageId);
    };
    const variable = node => {
      for (let scope = context.sourceCode.getScope(node); scope; scope = scope.upper) {
        if (scope.set.has(node.name)) return scope.set.get(node.name);
      }
    };
    const propertyGlobal = (owner, name) => browserGlobals.has(owner) ? name
      : owner === 'document' && name === 'defaultView' ? 'window' : undefined;
    const patternGlobal = (pattern, target, owner) => {
      if (pattern === target) return owner;
      if (pattern?.type !== 'ObjectPattern') return;
      for (const property of pattern.properties) {
        if (property.type === 'RestElement') continue;
        const name = property.computed ? literal(property.key) : property.key.name ?? literal(property.key);
        const resolved = patternGlobal(property.value, target, propertyGlobal(owner, name));
        if (resolved) return resolved;
      }
    };
    const globalName = (node, seen = new Set()) => {
      if (['ChainExpression', 'TSAsExpression', 'TSTypeAssertion', 'TSNonNullExpression', 'TSSatisfiesExpression'].includes(node?.type)) return globalName(node.expression, seen);
      if (node?.type === 'Identifier') {
        const binding = variable(node);
        if (!binding || binding.defs.length === 0) return node.name;
        if (seen.has(binding)) return;
        seen.add(binding);
        if (binding.defs.length === 1 && binding.defs[0].type === 'Variable') {
          const definition = binding.defs[0];
          return patternGlobal(definition.node.id, definition.name, globalName(definition.node.init, seen));
        }
      }
      if (node?.type === 'MemberExpression') return propertyGlobal(globalName(node.object, seen), member(node));
    };
    const isValueReference = node => {
      let owner = node.parent;
      while (owner?.type === 'TSQualifiedName') owner = owner.parent;
      if (owner?.type === 'TSTypeQuery') return false;
      for (let scope = context.sourceCode.getScope(node); scope; scope = scope.upper) {
        const reference = scope.references.find(entry => entry.identifier === node);
        if (reference) return reference.isValueReference !== false;
      }
      return false;
    };
    const capability = (owner, name) => runtimeApis.has(name) && browserGlobals.has(owner)
      || owner === 'document' && name === 'cookie'
      || owner === 'process' && name === 'env'
      || owner === 'navigator' && ['sendBeacon', 'storage', 'serviceWorker'].includes(name);
    const symbolKey = (node, seen = new Set()) => {
      if (node?.type === 'Identifier') {
        const binding = variable(node);
        if (!binding || seen.has(binding) || binding.defs.length !== 1 || binding.defs[0].type !== 'Variable') return false;
        seen.add(binding);
        return symbolKey(binding.defs[0].node.init, seen);
      }
      return node?.type === 'CallExpression' && (globalName(node.callee) === 'Symbol'
        || node.callee.type === 'MemberExpression' && globalName(node.callee.object) === 'Symbol' && member(node.callee) === 'for');
    };
    const checkPattern = (pattern, value, inherited) => {
      const owner = inherited ?? globalName(value);
      if (pattern?.type !== 'ObjectPattern' || !['document', 'navigator', 'process', ...browserGlobals].includes(owner)) return;
      for (const property of pattern.properties) {
        if (property.type === 'RestElement') continue;
        const name = property.computed ? literal(property.key) : property.key.name ?? literal(property.key);
        if (capability(owner, name) || name === undefined) report(property, 'runtime');
        if (browserGlobals.has(owner) && loaderApis.has(name)) report(property, 'loader');
        checkPattern(property.value, undefined, propertyGlobal(owner, name));
      }
    };
    const importMetaUrl = (node, seen = new Set()) => {
      if (['ChainExpression', 'TSAsExpression', 'TSTypeAssertion', 'TSNonNullExpression', 'TSSatisfiesExpression'].includes(node?.type)) return importMetaUrl(node.expression, seen);
      if (node?.type === 'Identifier') {
        const binding = variable(node);
        if (!binding || seen.has(binding) || binding.defs.length !== 1 || binding.defs[0].type !== 'Variable') return false;
        seen.add(binding);
        return importMetaUrl(binding.defs[0].node.init, seen);
      }
      return node?.type === 'MemberExpression' && member(node) === 'url'
        && node.object.type === 'MetaProperty' && node.object.meta.name === 'import';
    };
    return {
      Program() {
        for (const comment of context.sourceCode.getAllComments()) {
          for (const match of comment.value.matchAll(/<reference\s+(?:path|types)\s*=\s*["']([^"']+)["']|@jsxImportSource\s+(\S+)/g)) check(comment, match[1] ?? match[2], Boolean(match[1]));
        }
      },
      ImportDeclaration(node) { check(node, node.source.value, node.importKind === 'type'
        || node.specifiers.length > 0 && node.specifiers.every(specifier => specifier.importKind === 'type')); },
      ExportNamedDeclaration(node) { if (node.source) check(node, node.source.value, node.exportKind === 'type'
        || node.specifiers.length > 0 && node.specifiers.every(specifier => specifier.exportKind === 'type')); },
      ExportAllDeclaration(node) { check(node, node.source.value, node.exportKind === 'type'); },
      ImportExpression(node) { check(node, literal(node.source)); },
      TSImportType(node) { check(node, literal(node.source ?? node.argument?.literal ?? node.argument), true); },
      TSImportEqualsDeclaration(node) { if (node.moduleReference.type === 'TSExternalModuleReference') report(node, 'loader'); },
      MetaProperty(node) {
        if (node.meta.name !== 'import') return;
        const access = node.parent;
        const name = access?.type === 'MemberExpression' && access.object === node ? member(access) : undefined;
        if (name !== 'url') report(access ?? node, name === 'env' ? 'runtime' : 'loader');
      },
      Identifier(node) {
        if (!isValueReference(node)) return;
        const name = globalName(node);
        if (runtimeApis.has(name)) report(node, 'runtime');
        if (loaderApis.has(name)) report(node, 'loader');
      },
      MemberExpression(node) {
        const owner = globalName(node.object);
        const name = member(node);
        if (capability(owner, name) || node.computed && name === undefined && (owner === 'process'
          || browserGlobals.has(owner) && !symbolKey(node.property))) report(node, 'runtime');
        if (browserGlobals.has(owner) && loaderApis.has(name)) report(node, 'loader');
      },
      VariableDeclarator(node) { checkPattern(node.id, node.init); },
      AssignmentExpression(node) { checkPattern(node.left, node.right); },
      NewExpression(node) {
        if (globalName(node.callee) === 'URL' && importMetaUrl(node.arguments[1])) check(node, literal(node.arguments[0]));
      },
    };
  },
};
