import path from 'node:path';
import { Linter } from 'eslint';
import tseslint from 'typescript-eslint';
import { describe, expect, it } from 'vitest';
import { HOTKEY_RENDERER_RULE } from './hotkey-renderer.js';
import { DESIGN_SYSTEM_PACKAGE_ROOT } from './package-location.js';

const messages = (code: string, source = 'solid/future.tsx') => new Linter().verify(code, [{
  files: ['**/*.{ts,tsx}'],
  languageOptions: { parser: tseslint.parser, parserOptions: { ecmaFeatures: { jsx: true } } },
  plugins: { ui: { rules: { 'hotkey-renderer': HOTKEY_RENDERER_RULE } } },
  rules: { 'ui/hotkey-renderer': 'error' },
}], { filename: path.join(DESIGN_SYSTEM_PACKAGE_ROOT, 'src', source) }).map(message => message.messageId);

describe('standalone keyboard ownership', () => {
  it('rejects a second native keyboard handler in new controls', () => {
    expect(messages('const view = <div onKeyDown={handle}/>;')).toEqual(['keyboard']);
    expect(messages("element.addEventListener('keydown', handle);")).toEqual(['keyboard']);
    expect(messages("const options = { onKeyUp: handle };")).toEqual(['keyboard']);
    expect(messages("const keys = hotkeys({ Escape: handle });")).toEqual([]);
  });

  it('retains exact keyboard and context ownership after installation', () => {
    expect(messages("element.addEventListener('keydown', handle);", 'solid/field-lifecycle.ts')).toEqual([]);
    expect(messages("element.addEventListener('keydown', handle);", 'solid/field-lifecycle-helper.ts')).toEqual(['keyboard']);
    const context = "import { HotkeyElementContext } from '@ui-kit/core/runtime/context';";
    expect(messages(context, 'infrastructure/element.ts')).toEqual([]);
    expect(messages(context)).toEqual(['lifecycle']);
  });

  it('requires a declared surface for new native layers', () => {
    expect(messages('const view = <div role="dialog"/>;')).toEqual(['unmarked']);
    expect(messages('export function FutureRenderer() {}')).toEqual(['naked']);
  });
});
