import path from 'node:path';
import { designSystemFilename } from './package-location.js';

const DESIGN_SYSTEM_IMPORT = /(?:^|\/)packages\/design-system\/src(?:\/|$)/;
const SIZED_CONTROLS = new Set(['Button', 'ChoiceGroup', 'Tabs']);
const CLASS_PROPERTIES = new Set(['class', 'className', 'classList']);
const INTERNAL_STYLE = /^(?:(?:min-|max-)?(?:height|block-size)|padding(?:-.+)?|(?:row-|column-)?gap|font(?:-.+)?|line-height|letter-spacing|--(?:haku|ui)-(?:button|control|choice)-.+|--wa-(?:font|form-control|space)-.+)$/;
const INTERNAL_CLASS = /(?:^|[\s:!])(?:h-|min-h-|max-h-|size-|p[trblxyse]?-|gap(?:-[xy])?-|space-[xy]-|leading-|tracking-|(?:haku|ui)-button-|text-(?:caption|body|field|heading|title|xs|sm|base|lg|xl|\d+xl)(?:$|[\s/!])|text-\[(?:length:)?[\d.]|\[(?:height|min-height|max-height|block-size|min-block-size|max-block-size|padding(?:-[a-z]+)?|(?:row-|column-)?gap|font(?:-[a-z]+)?|line-height|letter-spacing|--(?:haku|ui)-(?:button|control|choice)-[-\w]+|--wa-(?:font|form-control|space)-[-\w]+):)/;
const UNSUPPORTED_WEIGHT = /(?:^|[\s:!])font-(?:thin|extralight|light|medium|bold|extrabold|black)(?=$|[\s!])/;
const FONT_SIZE_PROPERTY = /(?:^|-)font-size(?:-|$)/;
const FONT_WEIGHT_PROPERTY = /(?:^|-)font-weight(?:-|$)/;
const normalizeProperty = value => String(value).replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`);
export const CONTROL_VARIABLE = /^--(?:haku|ui)-(?:button|control|choice|tab)-/;
export const VENDOR_SIZE_VARIABLE = /^--wa-form-control-(?:height|padding(?:-|$)|toggle-size)/;
const ICON_WIDTH = /(?:^|[\s:!])(?:w-|min-w-|max-w-|basis-|\[(?:width|min-width|max-width|inline-size|min-inline-size|max-inline-size):)/;
const WIDTH_STYLE = /^(?:(?:min-|max-)?(?:width|inline-size)|flex-basis)$/;
const RESIZE_STYLE = /^(?:transform|scale|zoom)$/;
const RESIZE_CLASS = /(?:^|[\s:!])(?:scale(?:-[xy])?-|\[(?:zoom|scale|transform):)/;
const TARGETS_CONTROLS = /\[[^\s]*(?:button|data-(?:haku|ui)-(?:control|tabs?|choice)|&_[*])[^\s]*\]:/;
export const isControlGeometryProperty = property => INTERNAL_STYLE.test(normalizeProperty(property)) || RESIZE_STYLE.test(normalizeProperty(property));
export const isIconWidthProperty = property => WIDTH_STYLE.test(normalizeProperty(property));
export const isControlGeometryClass = value => INTERNAL_CLASS.test(value) || RESIZE_CLASS.test(value);
export const isIconWidthClass = value => ICON_WIDTH.test(value);

export function typographyClassProblems(text) {
  const problems = [];
  if (UNSUPPORTED_WEIGHT.test(text)
    || [...text.matchAll(/(?:^|[\s:!])font-\[(?:number:)?(\d+)\]/g)].some(match => !['400', '600'].includes(match[1]))) problems.push('fontWeight');
  if (/(?:^|[\s:!])text-(?:\[(?:length:)?[\d.]+(?:px|rem|em|%)|(?:xs|sm|small|base|lg|xl|\d+xl|subheading|display)(?=$|[\s/!]))/.test(text)) problems.push('fontSize');
  return problems;
}

/** Shared by the AST rule and the stylesheet contract check. */
export function typographyValueProblem(property, value) {
  const name = normalizeProperty(property);
  const text = String(value).trim();
  if (FONT_SIZE_PROPERTY.test(name) || name === 'font') {
    // 1em/100% pass the host's role through vendor shadow roots; they add no size.
    if (/^(?:1em|100%)$/.test(text)) return undefined;
    if (/^[+-]?(?:\d*\.)?\d+$/.test(text)
      || /(?:^|[^\w-])[+-]?(?:\d*\.)?\d+(?:px|rem|em|pt|pc|in|cm|mm|q|[sld]?vh|[sld]?vw|vmin|vmax|%)(?![\w])/i.test(text)) return 'fontSize';
  }
  if (FONT_WEIGHT_PROPERTY.test(name) || name === 'font') {
    // A shorthand's weight occurs before its size. Ignore line-height and font
    // family numerals after a size token, such as `var(--body)/1.4 "DIN 500"`.
    const weight = name === 'font' ? text.split(/\b(?:var|theme|calc|clamp|min|max)\s*\(|(?:^|\s)(?:[\d.]+(?:px|rem|em|pt|%)|(?:xx?-small|small|medium|large|xx?-large|smaller|larger)\b)/)[0] : text;
    if (/\b(?:bold|bolder|lighter)\b/.test(weight)
      || [...weight.matchAll(/(?:^|[^\w-])(\d+(?:\.\d+)?)(?![\w-])/g)].some(match => !['400', '600'].includes(match[1]))) return 'fontWeight';
  }
  return undefined;
}

/** UI compositions choose controls; their private implementation owns inner geometry. */
export const DESIGN_GEOMETRY = {
  meta: {
    type: 'problem',
    schema: [],
    messages: {
      geometry: '{{component}} owns its height, padding, gaps and typography. Remove {{value}} and choose a shared size/recipe; use the explicit placement contract or surrounding layout for outer placement.',
      iconWidth: 'Icon buttons own both dimensions. Remove {{value}} and use size with shape="icon"; place the control through its surrounding layout.',
      controlVariable: 'Control geometry tokens belong to the shared size/recipe stylesheets. Do not override {{value}} on a control or its ancestors.',
      controlSelector: 'Do not resize shared controls through ancestor selectors. Choose the control size/recipe at construction.',
      fontSize: 'Use semantic typography tokens, or TEXT_METRICS from @ui-kit/core/typography for non-DOM renderers. Numeric font sizes are defined only in packages/design-system/src/typography.ts.',
      fontWeight: 'The only text weights are 400 and 600. Use font-normal or font-semibold; CSS and renderer adapters must use the same two weights.',
    },
  },
  create(context) {
    const filename = designSystemFilename(context.filename);
    if (/\.(?:test|spec)\.[jt]sx?$/.test(filename)) return {};
    const canonicalTypography = /(?:^|\/)packages\/design-system\/src\/typography\.ts$/.test(filename);
    const source = context.sourceCode;
    const imports = new Map();
    const namespaces = new Set();
    const unwrap = node => node?.type === 'JSXExpressionContainer' ? unwrap(node.expression)
      : ['TSAsExpression', 'TSSatisfiesExpression', 'TSNonNullExpression', 'ChainExpression'].includes(node?.type) ? unwrap(node.expression) : node;
    const keyName = node => node?.type === 'Identifier' || node?.type === 'JSXIdentifier' ? node.name
      : node?.type === 'Literal' ? String(node.value) : undefined;
    const definitions = node => {
      for (let scope = source.getScope(node); scope; scope = scope.upper) {
        const variable = scope.set.get(node.name);
        if (variable) return variable.defs;
      }
      return [];
    };
    const componentName = (value, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return undefined;
      seen.add(node);
      if (node.type === 'JSXIdentifier' || node.type === 'Identifier') {
        if (imports.has(node.name)) return imports.get(node.name);
        for (const definition of definitions(node)) {
          if (definition.type === 'Variable') {
            const name = componentName(definition.node.init, seen);
            if (name) return name;
          }
        }
      }
      if (node.type === 'JSXMemberExpression' || node.type === 'MemberExpression') {
        const property = keyName(node.property);
        if (property === 'View') return componentName(node.object, seen);
        if (namespaces.has(node.object.name)) return property;
      }
      return undefined;
    };
    // Resolve local constants, templates, conditionals, cn() and object spreads.
    // Type information also exposes imported literal/union constants in real lint runs.
    const walkValue = (value, visit, seen = new Set()) => {
      const node = unwrap(value);
      if (!node || seen.has(node)) return;
      seen.add(node);
      visit(node);
      if (['Identifier', 'MemberExpression', 'CallExpression'].includes(node.type)) {
        const services = source.parserServices;
        const tsNode = services?.esTreeNodeToTSNodeMap?.get(node);
        if (tsNode && services.program) {
          const type = services.program.getTypeChecker().getTypeAtLocation(tsNode);
          for (const member of type.types ?? [type]) {
            if (typeof member.value === 'string') visit({ type: 'Literal', value: member.value });
          }
        }
      }
      if (node.type === 'Identifier') {
        for (const definition of definitions(node)) {
          if (definition.type === 'Variable') walkValue(definition.node.init, visit, seen);
        }
        return;
      }
      if (node.type === 'MemberExpression') {
        const property = keyName(node.property);
        walkValue(node.object, child => {
          if (child.type !== 'ObjectExpression') return;
          for (const entry of child.properties) {
            if (entry.type === 'Property' && (!property || keyName(entry.key) === property)) walkValue(entry.value, visit, seen);
          }
        }, seen);
        return;
      }
      if (node.type === 'CallExpression' && node.callee.type === 'Identifier') {
        for (const definition of definitions(node.callee)) {
          const fn = definition.type === 'FunctionName' ? definition.node : definition.node.init;
          if (['FunctionDeclaration', 'ArrowFunctionExpression', 'FunctionExpression'].includes(fn?.type)) walkValue(fn.body, visit, seen);
        }
      }
      const keys = node.type === 'CallExpression' ? ['arguments'] : source.visitorKeys[node.type] ?? [];
      for (const key of keys) {
        const children = node[key];
        if (Array.isArray(children)) children.forEach(child => walkValue(child, visit, seen));
        else walkValue(children, visit, seen);
      }
    };
    const literalText = node => node.type === 'Literal' && ['number', 'string'].includes(typeof node.value) ? String(node.value)
      : node.type === 'TemplateElement' ? node.value.cooked ?? node.value.raw : undefined;
    const reportTypography = (node, property, value) => {
      if (canonicalTypography) return;
      const normalized = normalizeProperty(property);
      if (normalized !== 'font' && !FONT_SIZE_PROPERTY.test(normalized) && !FONT_WEIGHT_PROPERTY.test(normalized)) return;
      let problem;
      walkValue(value, child => { problem ??= literalText(child) === undefined ? undefined : typographyValueProblem(property, literalText(child)); });
      if (problem) context.report({ node, messageId: problem });
    };
    const checkText = node => {
      if (canonicalTypography) return;
      const text = literalText(node);
      if (text === undefined) return;
      for (const problem of typographyClassProblems(text)) context.report({ node, messageId: problem });
      if (text.split(/\s+/).some(token => TARGETS_CONTROLS.test(token) && (INTERNAL_CLASS.test(token) || ICON_WIDTH.test(token) || RESIZE_CLASS.test(token)))) {
        context.report({ node, messageId: 'controlSelector' });
      }
      for (const match of text.matchAll(/(?:^|[;{[])\s*(--[-\w]+)\s*:/g)) {
        if (CONTROL_VARIABLE.test(match[1]) || VENDOR_SIZE_VARIABLE.test(match[1])) context.report({ node, messageId: 'controlVariable', data: { value: match[1] } });
      }
      // Also cover CSS-in-JS template strings and serialized style declarations.
      for (const match of text.matchAll(/(?:^|[;{])\s*((?:--[-\w]+-)?font-(?:size|weight)(?:-[-\w]+)?|font)\s*:\s*([^;}]+)/g)) {
        const problem = typographyValueProblem(match[1], match[2]);
        if (problem) context.report({ node, messageId: problem });
      }
    };
    const checkControlProperty = (component, property, value, owner, icon = false) => {
      let problem = property === 'blockPadding' ? property : undefined;
      let width;
      if (CLASS_PROPERTIES.has(property)) {
        walkValue(value, child => {
          const text = literalText(child);
          const token = text?.split(/\s+/).find(part => INTERNAL_CLASS.test(part) || RESIZE_CLASS.test(part));
          if (token) problem ??= token;
          if (icon) width ??= text?.split(/\s+/).find(part => ICON_WIDTH.test(part));
        });
      } else if (property === 'style') {
        const services = source.parserServices;
        const tsNode = services?.esTreeNodeToTSNodeMap?.get(unwrap(value));
        if (icon && tsNode && services.program) {
          const type = services.program.getTypeChecker().getTypeAtLocation(tsNode);
          width = (type.types ?? [type]).flatMap(member => member.getProperties())
            .map(property => property.name).find(isIconWidthProperty);
        }
        walkValue(value, child => {
          if (child.type === 'Property' && isControlGeometryProperty(keyName(child.key))) problem ??= keyName(child.key);
          if (icon && child.type === 'Property' && WIDTH_STYLE.test(normalizeProperty(keyName(child.key)))) width ??= keyName(child.key);
          const text = literalText(child);
          for (const match of text?.matchAll(/(?:^|[;{])\s*([-\w]+)\s*:/g) ?? []) {
            if (isControlGeometryProperty(match[1])) problem ??= match[1];
            if (icon && WIDTH_STYLE.test(normalizeProperty(match[1]))) width ??= match[1];
          }
        });
      }
      if (problem) context.report({ node: owner, messageId: 'geometry', data: { component, value: problem } });
      if (width) context.report({ node: owner, messageId: 'iconWidth', data: { value: width } });
    };
    const isIcon = value => { let icon = false; walkValue(value, node => { if (literalText(node) === 'icon') icon = true; }); return icon; };
    const checkPropsObject = (component, value, owner, knownIcon = false) => {
      let icon = knownIcon;
      walkValue(value, node => { if (node.type === 'Property' && keyName(node.key) === 'shape' && isIcon(node.value)) icon = true; });
      walkValue(value, node => { if (node.type === 'Property') checkControlProperty(component, keyName(node.key), node.value, owner, icon); });
    };
    const checkVariable = (node, property) => {
      if (CONTROL_VARIABLE.test(property) || VENDOR_SIZE_VARIABLE.test(property)) context.report({ node, messageId: 'controlVariable', data: { value: property } });
    };
    return {
      ImportDeclaration(node) {
        const imported = String(node.source.value);
        const target = path.posix.normalize(imported.startsWith('#ui/') ? `/packages/ui/src/${imported.slice(4)}`
          : imported === '@ui-kit/core' ? '/packages/design-system/src/index'
          : imported.startsWith('@ui-kit/core/') ? `/packages/design-system/src/${imported.slice(13)}`
          : imported.startsWith('@/') ? `/src/${imported.slice(2)}`
          : imported.startsWith('.') ? path.posix.join(path.posix.dirname(filename), imported) : imported);
        if (!DESIGN_SYSTEM_IMPORT.test(target)) return;
        for (const specifier of node.specifiers) {
          if (specifier.type === 'ImportNamespaceSpecifier') namespaces.add(specifier.local.name);
          if (specifier.type === 'ImportSpecifier') imports.set(specifier.local.name, keyName(specifier.imported));
        }
      },
      Literal: checkText,
      TemplateElement: checkText,
      Property(node) { reportTypography(node, keyName(node.key), node.value); checkVariable(node, keyName(node.key)); },
      AssignmentExpression(node) {
        if (node.left.type === 'MemberExpression') reportTypography(node, keyName(node.left.property), node.right);
        if (node.left.type === 'MemberExpression') checkVariable(node, keyName(node.left.property));
      },
      CallExpression(node) {
        if (node.callee.type === 'MemberExpression' && keyName(node.callee.property) === 'setProperty') reportTypography(node, keyName(node.arguments[0]), node.arguments[1]);
        if (node.callee.type === 'MemberExpression' && keyName(node.callee.property) === 'setProperty') checkVariable(node, keyName(node.arguments[0]));
      },
      JSXOpeningElement(node) {
        const component = componentName(node.name);
        if (!SIZED_CONTROLS.has(component)) return;
        const shape = unwrap(node.attributes.find(attribute => attribute.type === 'JSXAttribute' && keyName(attribute.name) === 'shape')?.value);
        const icon = isIcon(shape);
        for (const attribute of node.attributes) {
          if (attribute.type === 'JSXSpreadAttribute') checkPropsObject(component, attribute.argument, attribute, icon);
          else {
            const value = unwrap(attribute.value);
            // A text-or-icon control can fill the row only in its text branch.
            // Check geometry in both branches, but width only where shape is icon.
            if (shape?.type === 'ConditionalExpression' && value?.type === 'ConditionalExpression'
              && source.getText(shape.test) === source.getText(value.test)) {
              checkControlProperty(component, keyName(attribute.name), value.consequent, attribute, isIcon(shape.consequent));
              checkControlProperty(component, keyName(attribute.name), value.alternate, attribute, isIcon(shape.alternate));
            } else checkControlProperty(component, keyName(attribute.name), attribute.value, attribute, icon);
          }
        }
      },
      NewExpression(node) {
        const component = componentName(node.callee);
        if (SIZED_CONTROLS.has(component)) checkPropsObject(component, node.arguments[0], node);
      },
    };
  },
};
