export * from '../src/focus-highlight.rule.js';
