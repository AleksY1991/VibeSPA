import { existsSync, readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import postcss from 'postcss';
import valueParser from 'postcss-value-parser';
import ts from 'typescript';
import { CONTROL_VARIABLE, VENDOR_SIZE_VARIABLE, isControlGeometryProperty, isIconWidthProperty, isControlGeometryClass, isIconWidthClass } from './design-geometry.js';
import { designSystemDependency, isDesignSystemModule } from './design-system-boundary.js';
import { designSystemStylesheetScopeProblems } from './design-system-stylesheet-scope.js';
import { DESIGN_SYSTEM_CONTROLS, isDesignSystemOwner, ownsDesignSystemAppearance, designSystemOwnership, designSystemConsumerStylesheetProblems } from './design-system-ownership.js';
import { designSystemFilename, designSystemPackageRoot, resolveConsumerImport as resolveUiImport } from './package-location.js';

export function designSystemStylesheetProblems(css, filename, root = process.cwd()) {
  if (!isDesignSystemModule(filename)) return [];
  const problems = [];
  let sheet;
  try { sheet = postcss.parse(css, { from: filename }); }
  catch (error) {
    return [`${filename}:${error.line ?? 1}: Design-system CSS must be statically parseable to verify its dependency boundary.`];
  }
  const decode = value => value.replace(/\\([\da-f]{1,6})(?:\r\n|\s)?|\\([^\r\n\f])/gi,
    (_, hex, character) => hex ? String.fromCodePoint(parseInt(hex, 16) || 0xfffd) : character);
  const check = (node, value) => {
    const specifier = typeof value === 'string' ? decode(value) : value;
    if (typeof specifier === 'string' && /^(?:data:image\/|data:font\/|#)/i.test(specifier)) return;
    if (designSystemDependency(path.resolve(root, filename), specifier, root)) {
      problems.push(`${filename}:${node.source.start.line}: Design-system styles and assets must stay inside the reusable dependency boundary.`);
    }
  };
  const resource = node => {
    if (node?.type === 'string' || node?.type === 'word') return node.value;
    if (node?.type === 'function' && decode(node.value).toLowerCase() === 'url') {
      const values = node.nodes.filter(entry => !['space', 'comment'].includes(entry.type));
      return values.length === 1 && ['word', 'string'].includes(values[0].type) ? values[0].value : undefined;
    }
    return undefined;
  };
  sheet.walkAtRules(rule => {
    // PostCSS splits an escaped keyword into name and params, so decoding
    // name alone can miss a browser-recognized import. Keep keywords literal.
    if (rule.name.includes('\\') || (!rule.raws.afterName && rule.params.startsWith('\\'))) {
      problems.push(`${filename}:${rule.source.start.line}: Design-system at-rule names must use literal CSS keywords so their dependency boundary can be verified.`);
      return;
    }
    if (decode(rule.name).toLowerCase() !== 'import') return;
    const first = valueParser(rule.params).nodes.find(node => !['space', 'comment'].includes(node.type));
    check(rule, resource(first));
  });
  sheet.walkDecls(declaration => {
    valueParser(declaration.value).walk(node => {
      if (node.type !== 'function') return;
      const name = decode(node.value).toLowerCase();
      if (name === 'url' || name === 'src') { check(declaration, resource({ ...node, value: 'url' })); return false; }
      if (name === 'image-set' || name === '-webkit-image-set') {
        for (const entry of node.nodes) if (entry.type === 'string') check(declaration, entry.value);
      }
      if (name === 'type') return false;
    });
  });
  return problems;
}

// Geometry belongs to these implementations, not to every design-system file.
const OWNERS = new Set([
  'packages/design-system/src/control-tokens.css',
  'packages/design-system/src/solid/button-geometry.css',
  'packages/design-system/src/solid/choice-group.css',
  'packages/design-system/src/solid/tabs.css',
  // The pinned, scoped vendor theme owns defaults; control recipes override them.
  'packages/design-system/src/vendor/web-awesome/theme.css',
  'packages/design-system/src/vendor/web-awesome/controls.css',
  'packages/design-system/src/vendor/web-awesome/tabs.css',
]);
const FIELD_SIZE_OWNERS = new Set([
  'packages/design-system/src/vendor/web-awesome/text-field.css',
]);

export function stylesheetFrameworkProblems(css, filename) {
  const problems = [];
  const sheet = postcss.parse(css, { from: filename });
  sheet.walkAtRules(rule => {
    if (/^(?:tailwind|apply|screen|config)$/i.test(rule.name)) {
      problems.push(`${filename}:${rule.source.start.line}: Stylesheets must be ordinary CSS; framework directives are not part of the element contract.`);
    }
  });
  sheet.walkDecls(declaration => {
    valueParser(declaration.value).walk(node => {
      if (node.type === 'function' && node.value === 'theme') {
        problems.push(`${filename}:${declaration.source.start.line}: Use an owned CSS custom property instead of a build-time theme function.`);
      }
    });
  });
  return problems;
}

function subjects(selector) {
  const result = [];
  let subject = '', depth = 0, quote;
  for (const character of selector) {
    if (quote) { subject += character; if (character === quote) quote = undefined; continue; }
    if (character === '"' || character === "'") quote = character;
    if (character === '(' || character === '[') depth++;
    if (character === ')' || character === ']') depth--;
    if (depth === 0 && character === ',') { result.push(subject.trim()); subject = ''; }
    else if (depth === 0 && /[\s>+~]/.test(character)) {
      // Whitespace after a comma/combinator adds nothing; preserve the subject
      // until another compound actually starts so trailing whitespace is safe.
      if (subject && !subject.endsWith(' ')) subject += ' ';
    } else { if (subject.endsWith(' ')) subject = ''; subject += character; }
  }
  result.push(subject.trim());
  return result;
}

export function controlStylesheetProblems(css, filename, classes = new Set(), iconClasses = new Set()) {
  if (OWNERS.has(filename.replaceAll('\\', '/'))) return [];
  const problems = [];
  const root = postcss.parse(css, { from: filename });
  const targetsControl = selector => subjects(selector).some(subject => {
    // Inspect the subject, not a descendant label/icon inside a button.
    return /(?:^|[(:])(?:wa-)?button(?=[.#[:)]|$)|\[data-haku-(?:button|tab|choice)|\[(?:role|type)=['"]?button|::part\((?:button|tab|control)\)/.test(subject)
      || [...subject.matchAll(/\.([\w-]+)/g)].some(match => classes.has(match[1]) || /^haku-(?:button|standard-button)/.test(match[1]));
  });
  const targetsIcon = selector => subjects(selector).some(subject => /\[data-haku-shape=['"]?icon|\.haku-button-icon\b/.test(subject)
    || [...subject.matchAll(/\.([\w-]+)/g)].some(match => iconClasses.has(match[1])));
  root.walkDecls(declaration => {
    const rule = declaration.parent;
    if (CONTROL_VARIABLE.test(declaration.prop)
      || (VENDOR_SIZE_VARIABLE.test(declaration.prop) && !FIELD_SIZE_OWNERS.has(filename.replaceAll('\\', '/')))
      || (rule.type === 'rule' && targetsIcon(rule.selector) && isIconWidthProperty(declaration.prop))
      || (rule.type === 'rule' && targetsControl(rule.selector) && declaration.prop !== 'font-weight' && isControlGeometryProperty(declaration.prop))) {
      problems.push(`${filename}:${declaration.source.start.line}: Shared controls own ${declaration.prop}; choose a size/recipe at construction.`);
    }
  });
  root.walkAtRules('apply', rule => {
    if (rule.parent.type === 'rule' && ((targetsControl(rule.parent.selector)
      && rule.params.split(/\s+/).some(isControlGeometryClass))
      || (targetsIcon(rule.parent.selector) && rule.params.split(/\s+/).some(isIconWidthClass)))) {
      problems.push(`${filename}:${rule.source.start.line}: Shared controls own their geometry; do not resize them with @apply.`);
    }
  });
  return problems;
}

/** Collect only classes applied to an imported complete control's own host. */
export function collectDesignSystemControlClasses(text, filename, root = process.cwd(), program) {
  const classes = new Set();
  const iconClasses = new Set();
  const classControlTypes = new Map();
  const ids = new Set();
  const idControlTypes = new Map();
  const modules = new Map();
  const checker = program?.getTypeChecker();
  const unwrap = node => node && (ts.isParenthesizedExpression(node) || ts.isAsExpression(node) || ts.isSatisfiesExpression(node) || ts.isNonNullExpression(node)) ? unwrap(node.expression)
    : node && ts.isJsxExpression(node) ? unwrap(node.expression) : node;
  const key = (node, scope) => node && (ts.isIdentifier(node) || ts.isStringLiteralLike(node) || ts.isNumericLiteral(node)) ? node.text
    : node && ts.isComputedPropertyName(node) ? strings(node.expression, scope)?.[0] : undefined;
  const programNode = node => checker && node?.getSourceFile() === program.getSourceFile(node.getSourceFile().fileName);
  const actualType = node => programNode(node) ? checker.getTypeAtLocation(node) : undefined;
  const constant = (node, scope) => {
    if (programNode(node)) {
      const symbol = checker.getSymbolAtLocation(node);
      const declaration = symbol?.declarations?.find(ts.isVariableDeclaration);
      return declaration?.initializer;
    }
    return scope.constants.get(node.text);
  };
  const literalStrings = type => {
    if (!type) return undefined;
    const values = [];
    for (const member of type.types ?? [type]) {
      if (typeof member.value === 'string') values.push(member.value);
      else if (!(member.flags & (ts.TypeFlags.Undefined | ts.TypeFlags.Null | ts.TypeFlags.BooleanLiteral | ts.TypeFlags.Never))) return undefined;
    }
    return values;
  };
  const constraint = (condition, truth, scope) => {
    const node = unwrap(condition);
    return ts.isPrefixUnaryExpression(node) && node.operator === ts.SyntaxKind.ExclamationToken
      ? constraint(node.operand, !truth, scope) : [node.getText(scope.source).replace(/\s+/g, ''), truth];
  };
  const combine = (first = new Map(), second = new Map()) => {
    if ([...first].some(([key, value]) => second.has(key) && second.get(key) !== value)) return undefined;
    return new Map([...first,...second]);
  };
  const conditionedValues = (value, scope, conditions = new Map(), seen = new Set()) => {
    const node = unwrap(value);
    if (!node || seen.has(node)) return [{ text:undefined,unknown:!!node,conditions }];
    seen.add(node);
    if (ts.isIdentifier(node) && node.text === 'undefined') return [{ text:undefined,conditions }];
    if (ts.isIdentifier(node) && constant(node,scope)) return conditionedValues(constant(node,scope),scope,conditions,seen);
    if (ts.isConditionalExpression(node)) return [[node.whenTrue,true],[node.whenFalse,false]].flatMap(([branch,truth]) => {
      const next = combine(conditions,new Map([constraint(node.condition,truth,scope)]));
      return next ? conditionedValues(branch,scope,next,new Set(seen)) : [];
    });
    const values = strings(node,scope);
    return values ? values.map(text => ({ text,conditions })) : [{ text:undefined,unknown:true,conditions }];
  };
  const typedEntries = (type, node) => (type.types ?? [type]).flatMap(member => member.getProperties().map(property => {
    const value = checker.getTypeOfSymbolAtLocation(property, node);
    return { name: property.name, values: literalStrings(value), unknown:literalStrings(value) === undefined,
      entries: ['attributes', 'classList'].includes(property.name) ? typedEntries(value, node) : undefined };
  }));
  const moduleScope = (code, file) => {
    if (modules.has(file)) return modules.get(file);
    const scope = { source: program?.getSourceFile(path.resolve(root, file)) ?? ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true), filename: file, constants: new Map(), imports: new Map(), bindings: new Map() };
    modules.set(file, scope);
    const collect = node => {
      if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name)) scope.constants.set(node.name.text, node.initializer);
      if (ts.isVariableDeclaration(node) && ts.isObjectBindingPattern(node.name)) for (const entry of node.name.elements) {
        if (ts.isIdentifier(entry.name)) scope.bindings.set(entry.name.text, { object: node.initializer, member: entry.propertyName?.text ?? entry.name.text });
      }
      if (ts.isImportDeclaration(node) && ts.isStringLiteralLike(node.moduleSpecifier)) {
        const imported = node.importClause?.namedBindings;
        if (imported && ts.isNamedImports(imported)) for (const specifier of imported.elements) scope.imports.set(specifier.name.text, { source: node.moduleSpecifier.text, name: specifier.propertyName?.text ?? specifier.name.text });
        if (imported && ts.isNamespaceImport(imported)) scope.imports.set(imported.name.text, { source: node.moduleSpecifier.text, namespace: true });
      }
      ts.forEachChild(node, collect);
    };
    collect(scope.source);
    return scope;
  };
  const load = (specifier, scope) => {
    const resolved = resolveUiImport(path.resolve(root, scope.filename), specifier, root);
    const file = [resolved, `${resolved}.ts`, `${resolved}.tsx`, `${resolved}.js`, path.join(resolved, 'index.ts'), path.join(resolved, 'index.tsx')].find(file => existsSync(file) && /\.[cm]?[jt]sx?$/.test(file));
    return file ? moduleScope(readFileSync(file, 'utf8'), file) : undefined;
  };
  const exported = (specifier, name, scope, control, seen) => {
    if (/^@ui-kit\/core(?:\/|$)/.test(specifier) && control) return DESIGN_SYSTEM_CONTROLS.has(name) ? name : undefined;
    const target = load(specifier, scope);
    if (!target) return undefined;
    const identity = `${target.filename}:${name}:${control}`;
    if (seen.has(identity)) return undefined;
    seen.add(identity);
    for (const statement of target.source.statements) if (ts.isExportDeclaration(statement)) {
      const from = statement.moduleSpecifier?.text;
      if (!statement.exportClause && from) {
        const found = exported(from, name, target, control, new Set(seen));
        if (found) return found;
      }
      if (statement.exportClause && ts.isNamedExports(statement.exportClause)) {
        const entry = statement.exportClause.elements.find(entry => entry.name.text === name);
        if (entry) return from ? exported(from, entry.propertyName?.text ?? name, target, control, seen)
          : control ? component(entry.propertyName ?? entry.name, target, seen) : strings(entry.propertyName ?? entry.name, target, seen);
      }
    }
    const initializer = target.constants.get(name);
    return initializer && (control ? component(initializer, target, seen) : strings(initializer, target, seen));
  };
  const component = (value, scope, seen = new Set()) => {
    const node = unwrap(value);
    if (!node || seen.has(node)) return undefined;
    seen.add(node);
    if (ts.isIdentifier(node)) {
      const imported = scope.imports.get(node.text);
      if (imported) {
        const found = imported.namespace ? { namespace: imported.source }
          : !programNode(node) || /^@ui-kit\/core(?:\/|$)/.test(imported.source) ? exported(imported.source, imported.name, scope, true, seen) : undefined;
        if (found) return found;
      }
      const binding = scope.bindings.get(node.text);
      if (binding) {
        const owner = component(binding.object, scope, new Set(seen));
        if (owner?.namespace) return exported(owner.namespace, binding.member, scope, true, seen);
      }
      const found = component(constant(node, scope), scope, seen);
      if (found) return found;
    }
    if (ts.isPropertyAccessExpression(node) || ts.isElementAccessExpression(node)) {
      const member = ts.isPropertyAccessExpression(node) ? node.name.text : strings(node.argumentExpression, scope)?.[0];
      const owner = component(node.expression, scope, new Set(seen));
      if (member === 'View') return owner;
      if (owner?.namespace && (!programNode(node) || /^@ui-kit\/core(?:\/|$)/.test(owner.namespace))) return exported(owner.namespace, member, scope, true, seen);
      const object = ts.isIdentifier(node.expression) ? unwrap(constant(node.expression, scope)) : unwrap(node.expression);
      if (object && ts.isObjectLiteralExpression(object)) {
        const entry = object.properties.find(entry => ts.isPropertyAssignment(entry) && key(entry.name, scope) === member);
        if (entry) return component(entry.initializer, scope, seen);
      }
    }
    const type = ts.isCallExpression(node) || ts.isNewExpression(node) ? actualType(node) : undefined;
    let symbol = programNode(node) ? checker.getSymbolAtLocation(node) ?? type?.aliasSymbol ?? type?.symbol : undefined;
    if (symbol?.flags & ts.SymbolFlags.Alias) symbol = checker.getAliasedSymbol(symbol);
    return symbol?.declarations?.some(declaration => isDesignSystemOwner(declaration.getSourceFile().fileName, root)) && DESIGN_SYSTEM_CONTROLS.has(symbol.name) ? symbol.name : undefined;
  };
  const strings = (value, scope, seen = new Set()) => {
    const node = unwrap(value);
    if (!node || seen.has(node)) return undefined;
    seen.add(node);
    if (ts.isStringLiteralLike(node)) return [node.text];
    if (ts.isIdentifier(node)) {
      const imported = scope.imports.get(node.text);
      const found = imported && !imported.namespace ? literalStrings(actualType(node)) ?? exported(imported.source, imported.name, scope, false, seen) : strings(constant(node, scope), scope, seen);
      if (found) return found;
    }
    if (ts.isConditionalExpression(node)) return [...strings(node.whenTrue, scope, new Set(seen)) ?? [], ...strings(node.whenFalse, scope, new Set(seen)) ?? []];
    if (ts.isTemplateExpression(node)) {
      let values = [node.head.text];
      for (const part of node.templateSpans) {
        const expressions = strings(part.expression, scope, new Set(seen));
        if (!expressions) return values.concat(node.templateSpans.map(part => part.literal.text));
        values = values.flatMap(prefix => expressions.map(expression => prefix + expression + part.literal.text));
      }
      return values;
    }
    if (ts.isBinaryExpression(node)) {
      const first = strings(node.left, scope, new Set(seen));
      const second = strings(node.right, scope, new Set(seen));
      return node.operatorToken.kind === ts.SyntaxKind.PlusToken && first && second ? first.flatMap(a => second.map(b => a + b)) : [...first ?? [], ...second ?? []];
    }
    if (ts.isObjectLiteralExpression(node)) return node.properties.filter(ts.isPropertyAssignment).map(entry => key(entry.name, scope)).filter(Boolean);
    if (ts.isArrayLiteralExpression(node)) return node.elements.flatMap(entry => strings(entry, scope, new Set(seen)) ?? []);
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && ['cn', 'clsx', 'classNames'].includes(node.expression.text)) return node.arguments.flatMap(argument => strings(argument, scope, new Set(seen)) ?? []);
    return literalStrings(actualType(node));
  };
  const props = (value, scope, seen = new Set()) => {
    const node = unwrap(value);
    if (!node || seen.has(node)) return [];
    seen.add(node);
    if (ts.isIdentifier(node) && constant(node, scope)) return props(constant(node, scope), scope, seen);
    if (ts.isConditionalExpression(node)) return [[node.whenTrue,true],[node.whenFalse,false]].flatMap(([branch,truth]) => props(branch,scope,new Set(seen))
      .flatMap(entry => { const conditions=combine(entry.conditions,new Map([constraint(node.condition,truth,scope)])); return conditions ? [{...entry,conditions}] : []; }));
    if (!ts.isObjectLiteralExpression(node)) {
      const type = actualType(node);
      if (type) return typedEntries(type, node);
      return [];
    }
    return node.properties.flatMap(entry => ts.isSpreadAssignment(entry) ? props(entry.expression, scope, new Set(seen))
      : ts.isPropertyAssignment(entry) ? [{ name: key(entry.name, scope), value: entry.initializer }]
        : ts.isShorthandPropertyAssignment(entry) ? [{ name: entry.name.text, value: entry.name }] : []);
  };
  const record = (value, scope, icon, target, values, id = false) => {
    for (const text of values ?? strings(value, scope) ?? []) for (const token of id ? [text] : text.split(/\s+/)) if (id || /^[\w-]+$/.test(token)) {
      (id ? ids : classes).add(token);
      const controlTypes = id ? idControlTypes : classControlTypes;
      const types = controlTypes.get(token) ?? new Set();
      types.add(target); controlTypes.set(token, types);
      if (icon && !id) iconClasses.add(token);
    }
  };
  const entryValues = (entry,scope) => entry.values ? entry.values.map(text => ({text,conditions:entry.conditions ?? new Map()}))
    : entry.unknown ? [{text:undefined,unknown:true,conditions:entry.conditions ?? new Map()}] : conditionedValues(entry.value,scope,entry.conditions);
  const recordEntries = (entries, scope, target, inheritedShapes) => {
    if (!ownsDesignSystemAppearance(target)) return;
    const shapes = inheritedShapes ?? entries.filter(entry => entry.name === 'shape').flatMap(entry => entryValues(entry,scope));
    for (const entry of entries) {
      if (['class', 'className', 'classList','id'].includes(entry.name)) {
        const values = entry.name === 'classList' && entry.entries ? entry.entries.map(value => ({text:value.name,conditions:entry.conditions ?? new Map()})) : entryValues(entry,scope);
        for (const candidate of values) {
          if (typeof candidate.text !== 'string') continue;
          const icon = target === 'Button' && shapes.some(shape => (shape.text === 'icon' || shape.unknown) && combine(candidate.conditions,shape.conditions));
          record(undefined,scope,icon,target,[candidate.text],entry.name === 'id');
        }
      }
      if (entry.name === 'attributes') recordEntries(entry.entries ?? props(entry.value, scope), scope, target, shapes);
    }
  };
  const recordProps = (value, scope, target) => recordEntries(props(value, scope), scope, target);
  const currentScope = moduleScope(text, filename);
  const visit = node => {
    if (ts.isJsxOpeningElement(node) || ts.isJsxSelfClosingElement(node)) {
      let target = component(node.tagName, currentScope);
      if (!target) {
        const dynamic = node.attributes.properties.find(attribute => ts.isJsxAttribute(attribute) && attribute.name.getText(currentScope.source) === 'component');
        target = dynamic && component(dynamic.initializer, currentScope);
      }
      if (typeof target === 'string' && DESIGN_SYSTEM_CONTROLS.has(target)) {
        const entries = node.attributes.properties.flatMap(attribute => ts.isJsxAttribute(attribute)
          ? [{ name: attribute.name.getText(currentScope.source), value: attribute.initializer }]
          : props(attribute.expression, currentScope));
        recordEntries(entries, currentScope, target);
      }
    }
    if (ts.isNewExpression(node) && DESIGN_SYSTEM_CONTROLS.has(component(node.expression, currentScope))) recordProps(node.arguments?.[0], currentScope, component(node.expression, currentScope));
    if (ts.isCallExpression(node)) {
      const target = component(node.expression, currentScope);
      if (DESIGN_SYSTEM_CONTROLS.has(target)) recordProps(node.arguments[0], currentScope, target);
      if (ts.isIdentifier(node.expression) && ['createComponent', 'createElement', 'jsx', 'jsxs', 'jsxDEV'].includes(node.expression.text)
        && DESIGN_SYSTEM_CONTROLS.has(component(node.arguments[0], currentScope))) recordProps(node.arguments[1], currentScope, component(node.arguments[0], currentScope));
    }
    ts.forEachChild(node, visit);
  };
  visit(currentScope.source);
  return { classes, iconClasses, classControlTypes, ids, idControlTypes };
}

export function auditControlStylesheets(root = process.cwd()) {
  const files = directory => !existsSync(directory) ? [] : readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const file = path.join(directory, entry.name);
    return entry.isDirectory() ? entry.name === 'node_modules' ? [] : files(file) : [file];
  });
  const sources = [...files(path.join(root, 'src')), ...files(path.join(root, 'packages/ui')), ...files(path.join(designSystemPackageRoot(root), 'src'))];
  const classes = new Set();
  const iconClasses = new Set();
  const classControlTypes = new Map();
  const ids = new Set();
  const idControlTypes = new Map();
  const configFile = ts.findConfigFile(root, ts.sys.fileExists);
  const config = configFile ? ts.readConfigFile(configFile, ts.sys.readFile).config : {};
  const options = ts.parseJsonConfigFileContent(config, ts.sys, root).options;
  const program = ts.createProgram(sources.filter(file => /\.[cm]?[jt]sx?$/.test(file) && !/\.(?:test|spec)\./.test(file)), { ...options, allowJs:true, checkJs:false });
  for (const filename of sources.filter(file => /\.[cm]?[jt]sx?$/.test(file) && !/\.(?:test|spec)\./.test(file))) {
    const text = readFileSync(filename, 'utf8');
    const usage = collectDesignSystemControlClasses(text, filename, root, program);
    for (const value of usage.classes) classes.add(value);
    for (const value of usage.iconClasses) iconClasses.add(value);
    for (const value of usage.ids) ids.add(value);
    for (const [name, types] of usage.classControlTypes) {
      const existing = classControlTypes.get(name) ?? new Set();
      for (const type of types) existing.add(type);
      classControlTypes.set(name, existing);
    }
    for (const [name, types] of usage.idControlTypes) {
      const existing = idControlTypes.get(name) ?? new Set();
      for (const type of types) existing.add(type);
      idControlTypes.set(name, existing);
    }
  }
  const presentation = Object.fromEntries(['ScrollArea', 'ContentEditable'].map(type => [type,
    new Set([...classControlTypes].filter(([, types]) => [...types].every(name => name === type)).map(([name]) => name))]));
  presentation.ids = ids;
  for (const type of ['ScrollArea', 'ContentEditable']) presentation[`${type}Ids`] = new Set([...idControlTypes]
    .filter(([, types]) => [...types].every(name => name === type)).map(([name]) => name));
  const buttonClasses = new Set([...classControlTypes].filter(([, types]) => types.has('Button')).map(([name]) => name));
  const ownership = designSystemOwnership(root);
  return sources.filter(file => file.endsWith('.css')).flatMap(file => {
    const canonical = designSystemFilename(file);
    const filename = canonical.startsWith('packages/design-system/') ? canonical : path.relative(root, file).replaceAll('\\', '/');
    const css = readFileSync(file, 'utf8');
    return [...stylesheetFrameworkProblems(css, filename), ...controlStylesheetProblems(css, filename, buttonClasses, iconClasses), ...designSystemStylesheetProblems(css, filename, root), ...designSystemStylesheetScopeProblems(css, filename),
      ...designSystemConsumerStylesheetProblems(css, filename, classes, root, ownership, presentation)];
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const problems = auditControlStylesheets();
  if (problems.length) { process.stderr.write(`${problems.join('\n')}\n`); process.exitCode = 1; }
}
