import { Linter } from 'eslint';
import path from 'node:path';
import ts from 'typescript';
import tseslint from 'typescript-eslint';
import { describe, expect, it } from 'vitest';
// @ts-expect-error ESLint rules are JavaScript.
import { DESIGN_SYSTEM_CONSUMER } from './design-system-consumer.js';
// @ts-expect-error Ownership analysis is JavaScript.
import { designSystemConsumerStylesheetProblems, isDesignSystemPlacementProperty, ownedDesignSystemVariables } from './design-system-ownership.js';
// @ts-expect-error Ownership analysis is JavaScript.
import { collectDesignSystemControlClasses, designSystemStylesheetProblems, stylesheetFrameworkProblems } from './control-stylesheets.js';

const messages = (code: string, filename = 'src/features/example/Example.tsx') => new Linter().verify(code, [{
  files: ['**/*.{js,jsx,ts,tsx}'],
  languageOptions: { parser: tseslint.parser, ecmaVersion: 2022, sourceType: 'module', parserOptions: { ecmaFeatures: { jsx: true } } },
  plugins: { haku: { rules: { consumer: DESIGN_SYSTEM_CONSUMER } } },
  rules: { 'haku/consumer': 'error' },
}], { filename }).map(result => result.messageId ?? result.message);

const ownershipProgram = (code: string) => {
  const filename = path.resolve('src/features/example/OwnershipProbe.tsx');
  const alias = path.resolve('src/features/example/ownership-alias.ts');
  const propsFile = path.resolve('src/features/example/ownership-props.ts');
  const core = path.resolve('packages/design-system/src/ownership-probe.d.ts');
  const options: ts.CompilerOptions = { target: ts.ScriptTarget.ESNext, module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler, jsx: ts.JsxEmit.Preserve, strict: true,
    skipLibCheck: true, types: [], paths: { '@ui-kit/core': [core] } };
  const host = ts.createCompilerHost(options);
  const files = new Map([[filename, code], [alias, 'export {Button as Primary} from "@ui-kit/core";'],
    [propsFile, 'export const painted = {class:"placed", style:{width:"100%"}} as const; export const placement = {placement:{width:"100%"},title:"Save"} as const;'],
    [core,'export class Button { constructor(props:unknown); static View: (props:unknown)=>unknown; } export class Card { constructor(props:unknown); static View: (props:unknown)=>unknown; }']]);
  const originalRead = host.readFile.bind(host);
  const originalExists = host.fileExists.bind(host);
  const originalDirectoryExists = host.directoryExists?.bind(host);
  host.readFile = file => files.get(path.resolve(file)) ?? originalRead(file);
  host.fileExists = file => files.has(path.resolve(file)) || originalExists(file);
  host.directoryExists = directory => [...files.keys()].some(file => file.startsWith(path.resolve(directory) + path.sep)) || Boolean(originalDirectoryExists?.(directory));
  host.getSourceFile = (file, languageVersion) => {
    const text = host.readFile(file);
    return text === undefined ? undefined : ts.createSourceFile(file, text, languageVersion, true);
  };
  const program = ts.createProgram([filename, alias, propsFile], options, host);
  return { filename,program };
};
const typedMessages = (code: string) => {
  const {filename,program} = ownershipProgram(code);
  return new Linter().verify(code, [{
    files: ['**/*.tsx'],
    languageOptions: { parser: tseslint.parser, parserOptions: { programs: [program], ecmaFeatures: { jsx: true } } },
    plugins: { haku: { rules: { consumer: DESIGN_SYSTEM_CONSUMER } } }, rules: { 'haku/consumer': 'error' },
  }], { filename }).map(result => result.messageId ?? result.message);
};

const control = (attributes: string) => `import { Button } from '@ui-kit/core'; const Example=()=> <Button.View ${attributes}/>;`;
const ownership = { classes: new Set(['ui-button']), attributes: new Set(['data-ui-ready']), variables: new Set(['--primary']), publicImports: new Set(['@ui-kit/core']) };
const styles = (css: string, filename = 'packages/ui/src/views/example/example.css', classes = new Set(['action-placement'])) =>
  designSystemConsumerStylesheetProblems(css, filename, classes, process.cwd(), ownership);

describe('consumer control ownership', () => {
  it('protects the owned font registry through global and aliased constructors', () => {
    for (const code of [
      'new FontFace("ui-inter", source);',
      'new window.FontFace("UI-INTER", source);',
      'const Face = globalThis.FontFace; new Face("ui-emoji", source);',
      'const {FontFace: Face} = self; new Face("ui-inter", source);',
      'const {FontFace: Face = FontFace} = window; new Face(name, source);',
      'const browser=globalThis; const Face=browser["Font"+"Face"]; new Face("ui-inter",source);',
      'const browser = document.defaultView; new browser.FontFace("ui-inter", source);',
      'new FontFace(name, source);',
      'const Face = FontFace; new Face(prefix + "inter", source);',
      'new FontFace(flag ? "Host Face" : "ui-inter", source);',
      'new FontFace("\\"ui-inter\\"", source);',
      'new FontFace("u\\\\69 -inter", source);',
    ]) expect(messages(code), code).toContain('font');
    for (const code of [
      'new FontFace("Host Face", source);',
      'const Face=FontFace; new Face(flag ? "Host Face" : "Other Face", source);',
      'class FontFace { constructor(name: string, source: unknown) {} } new FontFace("ui-inter", source);',
      'function load(FontFace: new (name: string, source: unknown) => unknown) { return new FontFace("ui-inter", source); }',
      'document.fonts.ready; document.fonts.load("16px ui-inter"); document.fonts.check("16px ui-inter");',
    ]) expect(messages(code), code).toEqual([]);
    expect(typedMessages('declare const family:"Host Face"|"Other Face"; new FontFace(family,source);')).toEqual([]);
    expect(typedMessages('declare const family:"Host Face"|"ui-inter"; new FontFace(family,source);')).toContain('font');
  });
  it('preserves explicit control options, accessibility and outer placement', () => {
    expect(messages(control('size="compact" variant="ghost" aria-label="Save" title="Save changes" placement={{width:"100%",marginInline:"auto",alignSelf:"start"}}'))).toEqual([]);
    expect(messages('const Example=()=> <div class="application-panel" style={{padding:"12px",color:"red"}}/>;')).toEqual([]);
    expect(messages('import { Card } from "@ui-kit/core"; const Example=()=> <Card.View attributes={{id:"details", "aria-label":"Details",title:"Details"}}/>;')).toEqual([]);
  });

  it('rejects paint, geometry and behavior escape hatches on complete controls', () => {
    for (const attribute of ['style={{height:"3px"}}', 'style={{backgroundColor:"red"}}', 'style={{opacity:0.5}}',
      'style={{transform:"scale(.5)"}}', 'style={{display:"none"}}', 'class="p-8 bg-red-500"', 'class="[&_.ui-button]:!p-0"',
      'ref={element=>element.style.height="1px"}', 'onElement={element=>element.remove()}', 'onClick={()=>{}}', 'on:keydown={()=>{}}', 'as="div"']) {
      const result = messages(control(attribute));
      expect(result, attribute).toEqual(expect.arrayContaining([expect.stringMatching(/override|placement|recipe/)]));
    }
    expect(messages('import { Card } from "@ui-kit/core"; const Example=()=> <Card.View recipe="content" attributes={{style:"height:1px",onClick:()=>{}}}/>;')).toContain('recipe');
  });

  it('preserves application composition hosts while closing every Card recipe', () => {
    for (const name of ['Form', 'Image', 'Media', 'EditorHost', 'InteractionRegion', 'LayerPortal']) {
      expect(messages(`import {${name}} from '@ui-kit/core'; const Example=()=> <${name}.View class="app-content" style={{padding:'12px',color:'red',height:'100px'}}/>;`), name).toEqual([]);
      expect(messages(`import {${name}} from '@ui-kit/core'; const Example=()=> <${name}.View onClick={()=>{}} ref={()=>{}}/>;`), name).toContain('override');
    }
    for (const props of ['', 'recipe="plain"', '{...{recipe:"plain"}}', 'recipe="content"', 'recipe="panel"', 'recipe="popover"', 'recipe="notice"', 'recipe={unknownRecipe}']) {
      expect(messages(`import {Card} from '@ui-kit/core'; const Example=()=> <Card.View ${props} style={{display:'grid',padding:'12px'}}/>;`)).toContain('recipe');
    }
    expect(messages(`import {Card} from '@ui-kit/core'; new Card({recipe:'plain',style:{padding:'12px'}});`)).toContain('recipe');
    expect(messages(`import {Card} from '@ui-kit/core';const Example=()=> <Card.View recipe="notice" tone="warning" placement={{width:'100%'}} attributes={{id:'notice',role:'status','aria-label':'Notice'}}/>;`)).toEqual([]);
    expect(messages(`import {Card} from '@ui-kit/core';const attributes={class:'application-card'};const Example=()=> <Card.View attributes={attributes}/>;`)).toContain('recipe');
    expect(messages(`import {InteractionRegion,ScrollArea,ContentEditable} from '@ui-kit/core'; const Example=()=> <>
      <InteractionRegion.View as="section"/><ScrollArea.View as="main" style={{height:'300px',maxHeight:'60vh'}}/>
      <ContentEditable.View as="span" style={{fontSize:'18px',color:'red',lineHeight:1.5,padding:'4px'}}/>
    </>;`)).toEqual([]);
    expect(messages(`import {ContentEditable} from '@ui-kit/core'; const Example=()=> <ContentEditable.View style={{opacity:0,cursor:'none'}}/>;`)).toContain('placement');
    expect(messages(`import {InteractionRegion} from '@ui-kit/core'; const Example=()=> <InteractionRegion.View class={props.class} style={props.style} onPointerUp={()=>{}}/>;`)).toEqual([]);
    expect(messages(`import {Card} from '@ui-kit/core'; const Example=()=> <Card.View class={cardPaint()}/>;`)).toContain('recipe');
  });

  it('follows renamed imports, namespace members, destructuring and local aliases', () => {
    for (const code of [
      'import {Button as Action} from "@ui-kit/core"; const Example=()=> <Action.View style={{height:"1px"}}/>;',
      'import * as UI from "@ui-kit/core"; const Example=()=> <UI.Button.View style={{height:"1px"}}/>;',
      'import * as UI from "@ui-kit/core"; const {Button:Action}=UI; const Example=()=> <Action.View style={{height:"1px"}}/>;',
      'import {Button} from "@ui-kit/core"; const Action=Button.View; const Example=()=> <Action style={{height:"1px"}}/>;',
      'import {Button} from "@ui-kit/core"; const controls={Action:Button}; const Example=()=> <controls.Action.View style={{height:"1px"}}/>;',
      'import {Button} from "@ui-kit/core"; new Button({style:{height:"1px"}});',
      'import {Button} from "@ui-kit/core"; createComponent(Button.View,{style:{height:"1px"}});',
      'import {Button} from "@ui-kit/core"; const Example=()=> <Dynamic component={Button.View} style={{height:"1px"}}/>;',
      'const UI=await import("@ui-kit/core"); const Example=()=> <UI.Button.View style={{height:"1px"}}/>;',
      'const {Button:Action}=await import("@ui-kit/core"); const Example=()=> <Action.View style={{height:"1px"}}/>;',
      'const UI=require("@ui-kit/core"); new UI.Button({style:{height:"1px"}});',
    ]) expect(messages(code), code).toContain('recipe');
    expect(messages('import {Button} from "another-library"; const Example=()=> <Button style={{height:"1px"}}/>;')).toEqual([]);
  });

  it('checks spread keys and rejects unresolved/computed override channels', () => {
    expect(messages('import {Button} from "@ui-kit/core"; const props={style:{height:"1px"}}; const Example=()=> <Button.View {...props}/>;')).toContain('recipe');
    expect(messages('import {Button} from "@ui-kit/core"; const key="sty"+"le"; const props={[key]:{height:"1px"}}; const Example=()=> <Button.View {...props}/>;')).toContain('recipe');
    expect(messages('import {Button} from "@ui-kit/core"; const props={placement:{width:"100%"}}; const Example=()=> <Button.View {...props}/>;')).toEqual([]);
    expect(messages('import {Button} from "@ui-kit/core"; const props={...unknown}; const Example=()=> <Button.View {...props}/>;')).toContain('unknown');
    expect(messages('import {Button} from "@ui-kit/core"; const props={[unknownKey]:"value"}; const Example=()=> <Button.View {...props}/>;')).toContain('unknown');
    expect(messages(control('class={unknownClass}'))).toContain('recipe');
    expect(messages(control('style={{...unknownStyle,width:"100%"}}'))).toContain('recipe');
  });

  it('uses compiler shapes for imported/re-exported controls and finite typed props', () => {
    expect(typedMessages(`
      import {Button} from '@ui-kit/core'; import {Primary} from './ownership-alias';
      declare const safe: {placement: {width: string}, title: string};
      declare const bad: {style: {height: string}};
      declare const unknown: Record<string, unknown>;
      const Good=()=> <Button.View {...safe}/>;
      const Bad=()=> <Button.View {...bad}/>;
      const Unknown=()=> <Button.View {...unknown}/>;
      const Alias=()=> <Primary.View style={{height:'1px'}}/>;
    `)).toEqual(['recipe', 'unknown', 'recipe']);
  });

  it('closes styling inputs on complete controls, including harmless-looking classes', () => {
    const shared = ['class="placement-only"', 'className="placement-only"', 'classList={{"placement-only":true}}',
      'style={{width:"100%"}}', 'style:width="100%"', 'class:placement={true}', 'attr:class="placement-only"',
      'attr:style="color:red"', 'prop:className="placement-only"', 'prop:style="color:red"'];
    for (const name of ['Button', 'TextField', 'SearchField', 'Textarea', 'Select', 'Dialog', 'Card', 'Popover']) {
      for (const attribute of shared) {
        expect(messages(`import {${name} as Control} from '@ui-kit/core';const Example=()=> <Control.View ${attribute}/>;`), `${name} ${attribute}`).toContain('recipe');
      }
    }
    for (const key of ['recipe', 'size', 'type']) expect(messages(`import {SearchField} from '@ui-kit/core';new SearchField({${key}:'form'});`), key).toContain('recipe');
    expect(messages(`import {Link} from '@ui-kit/core';const Example=()=> <Link.View class="app-placement" style={{width:'100%'}}/>;`)).toEqual([]);
  });

  it('preserves Popover placement and behavior while closing trigger and panel styling', () => {
    for (const recipe of ['popover', 'picker', 'content', 'form']) {
      expect(messages(`import {Popover} from '@ui-kit/core';const Example=()=> <Popover.View recipe="${recipe}" side="top" align="end" offset={4} margin={8} fitContentWidth role="dialog" aria-label="Details" closeOnOutsidePointerDown={false}/>;`), recipe).toEqual([]);
    }
    expect(messages(`import {Popover} from '@ui-kit/core';const props={anchorClass:'application-anchor'};const Example=()=> <Popover.View {...props}/>;`)).toContain('recipe');
    expect(messages(`import {Popover as Surface} from '@ui-kit/core/solid/popover';new Surface({anchorClass:'application-anchor'});`)).toContain('recipe');
  });

  it('protects styling ownership through imported objects and assertions without rejecting closed prop types', () => {
    expect(typedMessages(`import {Button} from '@ui-kit/core';import {painted} from './ownership-props';
      const Example=()=> <Button.View {...(painted as unknown as {title:string})}/>;`)).toEqual(['recipe', 'recipe']);
    expect(typedMessages(`import {Button} from '@ui-kit/core';import {placement} from './ownership-props';
      const Example=()=> <Button.View {...placement}/>;`)).toEqual([]);
    expect(typedMessages(`import {Button} from '@ui-kit/core';
      declare const closed:{class?:never;className?:never;classList?:never;style?:never;placement?:{width?:string;height?:never}};
      const Example=()=> <Button.View {...closed}/>;`)).toEqual([]);
    expect(messages(`import {Button} from '@ui-kit/core';const paint={style:{color:'red'}};const props={...paint};
      const Example=()=> <Button.View {...(props as unknown as {title:string})}/>;`)).toContain('recipe');
  });

  it('limits explicit placement to outer layout with finite imported shapes', () => {
    for (const attribute of ['placement={{padding:"4px"}}', 'placement={{height:"4px"}}', 'placement={{color:"red"}}',
      'placement={{"--ui-control-target":"4px"}}', 'placement={{transform:"scale(.5)"}}']) {
      expect(messages(control(attribute)), attribute).toContain('placement');
    }
    expect(messages(control('placement={{...unknownLayout}}'))).toContain('unknown');
    expect(typedMessages(`import {Button} from '@ui-kit/core';declare const bad:{width:string;padding:string};
      const Example=()=> <Button.View placement={bad}/>;`)).toContain('placement');
    expect(messages(control('placement={{width:"100%",gridColumn:"1 / -1",flexGrow:1}}'))).toEqual([]);
    expect(messages(`import {Dialog} from '@ui-kit/core';const Example=()=> <Dialog.View recipe="dialog" placement="center"/>;`)).toEqual([]);
    expect(messages(`import {Dialog} from '@ui-kit/core';const Example=()=> <Dialog.View recipe="dialog" placement={{top:'1px'}}/>;`)).toContain('unknown');
  });

  it('reserves presentation data markers even through namespaced attributes and dataset input', () => {
    for (const attribute of ['data-ui-recipe="inline"', 'data-ui-hit-target="content"', 'data-wa-size="s"',
      'attr:data-ui-recipe="inline"', 'prop:data-ui-recipe="inline"']) {
      expect(messages(control(attribute)), attribute).toContain('override');
    }
    for (const attribute of ['dataset={{uiRecipe:"inline"}}', 'prop:dataset={{uiRecipe:"inline"}}']) {
      expect(messages(control(attribute)), attribute).toContain('recipe');
    }
    expect(messages(control('data-testid="save" data-tip="Save" data-application-action="save"'))).toEqual([]);
  });

  it('permits public reading typography recipes on application content while protecting complete controls', () => {
    expect(typedMessages(`import {READING_TEXT} from '@ui-kit/core/typography';const Example=()=> <div class={READING_TEXT.default}/>;`)).toEqual([]);
    expect(typedMessages(`import {Button} from '@ui-kit/core';import {READING_TEXT} from '@ui-kit/core/typography';const Example=()=> <Button.View class={READING_TEXT.large}/>;`)).not.toEqual([]);
    expect(messages('const attrs={class:"ui-selection-outline"};const Example=()=> <div {...attrs}/>;')).toContain('selector');
  });

  it('rejects private imports and direct vendor usage through loading syntaxes', () => {
    for (const code of [
      'import {Button} from "@ui-kit/core/src/solid/button";',
      'export * from "@ui-kit/core/vendor/web-awesome/button.adapter";',
      'import("@ui-kit/core/vendor/web-awesome/registration");',
      'import type {PreparedImplementation} from "@ui-kit/core/src/infrastructure/implementation";',
      'import "@awesome.me/webawesome/dist/components/button/button.js";',
      'import {Button} from "#ui/internal/solid/button";',
      'import {Button} from "../../../packages/design-system/src/solid/button";',
      'import {TestSurfaceRegistry} from "../../../packages/design-system/tests/surface-host";',
    ]) expect(messages(code), code).toContain('privateImport');
    expect(messages('const Example=()=> <wa-button/>;')).toContain('selector');
    expect(messages('document.createElement("wa-button");')).toContain('selector');
  });

  it('protects variables on any ancestor and catches imperative styling paths', () => {
    for (const code of [
      'const Example=()=> <div style={{"--ui-control-height":"1px"}}/>;',
      'const key="--ui-control-height"; wrapper.style.setProperty(key,"1px");',
      'wrapper.style["--wa-form-control-height"]="1px";',
      'wrapper.style.cssText="--ui-control-height:1px";',
      'sheet.insertRule("@layer overrides { .ui-button { all:revert!important } }");',
      'document.querySelector(".ui-button").style.cssText="color:red";',
      'document.querySelector(`[data-ui-${name}]`).setAttribute("style","color:red");',
      'document.querySelector(\'[class~="ui-button"]\').style.cssText="all:revert";',
      'const Example=()=> <header data-ui-control-size="dense"/>;',
      'const Example=()=> <div class="ui-selection-outline"/>;',
      'const attributes={"data-ui-root":""};',
      'wrapper.setAttribute("data-ui-control-size","dense");',
      'wrapper.dataset.uiControlSize="dense";',
    ]) expect(messages(code), code).toEqual(expect.arrayContaining([expect.stringMatching(/variable|selector|mutation/)]));
    expect(messages('import {Button} from "@ui-kit/core"; const Example=()=> <Button.View class="action-placement" id="save"/>; const host=document.getElementById("save"); host.style.cssText="all:revert";')).toContain('mutation');
    expect(messages('import {Button} from "@ui-kit/core"; const Example=()=> <Button.View id="save"/>; const host=document.querySelector(\'[id="save"]\'); host.style.cssText="all:revert";')).toContain('mutation');
    expect(messages('import {Button} from "@ui-kit/core"; const Example=()=> <Button.View class="action-placement"/>; const host=document.querySelector(".action-placement"); Object.assign(host.style,{backgroundColor:"red"});')).toContain('mutation');
    expect(messages('import {Button} from "@ui-kit/core"; const Example=()=> <Button.View class="action-placement"/>; const host=document.querySelector(".action-placement"); const child=host.firstElementChild; const style=child.style; style.cssText="all:revert";')).toContain('mutation');
    expect(messages('import {Button} from "@ui-kit/core"; const Example=()=> <Button.View id="save"/>; const host=document.getElementById("save"); Reflect.set(host.style,"color","red");')).toContain('mutation');
    expect(messages('wrapper.style.setProperty("--application-sidebar-width","200px"); wrapper.style.cssText="width:100%;margin:auto";')).toEqual([]);
    expect(messages('wrapper.style.setProperty("--haku-application-size","200px");')).toEqual([]);
  });

  it('protects hosts exposed by native control-event callbacks without sweeping ordinary DOM handlers', () => {
    for (const code of [
      `import {Button} from '@ui-kit/core';const View=()=> <Button.View onFocus={event=>{event.currentTarget.style.backgroundColor='red';}}/>;`,
      `import {Button} from '@ui-kit/core';const focused=event=>{const host=event.currentTarget;Object.assign(host.style,{color:'red'});};const View=()=> <Button.View onFocus={focused}/>;`,
      `import {Button as Action} from '@ui-kit/core';function focused(event){event.currentTarget.setAttribute('style','color:red');}const props={onFocus:focused};const View=()=> <Action.View {...props}/>;`,
    ]) expect(messages(code), code).toContain('mutation');
    expect(messages(`const focused=event=>{event.currentTarget.style.color='red';};const View=()=> <button onFocus={focused}/>;`)).toEqual([]);
    expect(messages(`import {Button} from 'other';const View=()=> <Button onFocus={event=>{event.currentTarget.style.color='red';}}/>;`)).toEqual([]);
  });

  it('exempts the actual implementation owner, not similarly named consumer files', () => {
    expect(messages(control('style={{height:"1px"}}'), 'packages/design-system/src/solid/example.tsx')).toEqual([]);
    expect(messages(control('style={{height:"1px"}}'), 'packages/ui/src/views/design-system/example.tsx')).toContain('recipe');
    expect(messages(control('style={{height:"1px"}}'), 'src/packages/design-system/src/example.tsx')).toContain('recipe');
  });
});

describe('consumer stylesheet ownership', () => {
  it('permits host placement and named custom content', () => {
    expect(styles('.action-placement { width:100%; margin-inline:auto; flex:1; align-self:start; position:relative; }')).toEqual([]);
    expect(styles('.application-panel { padding:12px; color:red; } .action-placement .application-label { color:red; }')).toEqual([]);
    expect(styles('.action-placement { width:100%; & .application-label { color:red; } }')).toEqual([]);
    expect(styles('.application-panel:has(.action-placement) { padding:12px; } .application-panel:not(.action-placement) { color:red; }')).toEqual([]);
    expect(isDesignSystemPlacementProperty('marginInlineStart')).toBe(true);
    expect(isDesignSystemPlacementProperty('WIDTH')).toBe(true);
    expect(styles('.page > * { flex-shrink:0; margin-inline:4px; }')).toEqual([]);
    expect(styles('button.application-action {color:red} .page :is(.application-label,.application-value) {font-size:18px}')).toEqual([]);
    expect(styles('body {font-family:Application; color:red; background:white}')).toEqual([]);
    expect(styles('.application-panel h1 {font-size:var(--app-title);color:red} .application-panel code {padding:4px} .page > * {--haku-space-reverse:0}')).toEqual([]);
    expect(messages('const Example=()=> <div style={{"--haku-app-layout-offset":"4px"}}/>;')).toEqual([]);
  });

  it('blocks broad selectors and document rem metric overrides without blocking named content', () => {
    for (const selector of ['.page *', '#app > *', ':where(*)', '[class]', '[aria-label]', 'button', '.page :is(button,input)', ':is(.wrapper button,.application-label)', 'span', ':focus']) {
      expect(styles(`${selector} {font-size:48px;color:red}`), selector).not.toEqual([]);
    }
    expect(styles(':root {font-size:48px}')).not.toEqual([]);
    expect(styles('html {font:48px Application}')).not.toEqual([]);
  });

  it('permits only declared ScrollArea dimensions and ContentEditable text presentation', () => {
    const classes = new Set(['viewport','editable','action-placement']);
    const check = (css: string) => designSystemConsumerStylesheetProblems(css,'src/example.css',classes,process.cwd(),ownership,
      { ScrollArea:new Set(['viewport']),ContentEditable:new Set(['editable']), ids:new Set(['save','viewport']),ScrollAreaIds:new Set(['viewport']) });
    expect(check('.viewport {height:60vh;max-height:100%;scroll-padding-block-start:4rem;scroll-padding-top:4rem;timeline-scope:--app-story;} .editable {font-size:18px;color:red;padding:4px;white-space:pre-wrap;}')).toEqual([]);
    expect(check('.viewport {overflow:hidden} .editable {opacity:0;cursor:none;}')).not.toEqual([]);
    expect(check('.editable,.action-placement {font-size:18px}')).not.toEqual([]);
    expect(check(':is(.editable,.action-placement) {font-size:18px}')).not.toEqual([]);
    expect(check('#save {padding:48px}')).not.toEqual([]);
    expect(check('#viewport {height:60vh}')).toEqual([]);
  });

  it('rejects any paint, geometry or behavior declaration on known control host classes', () => {
    for (const declaration of ['height:1px', 'padding:0', 'background:red', 'color:red', 'opacity:.5', 'display:none', 'transform:scale(.1)', 'all:revert-layer!important', 'pointer-events:none']) {
      expect(styles(`@layer override { .action-placement { ${declaration}; } }`), declaration).not.toEqual([]);
    }
    expect(styles('.action-placement { @media (width>10px) { color:red } }')).not.toEqual([]);
    expect(styles('.action-placement { &:hover { color:red; } }')).not.toEqual([]);
    expect(styles(':is(:where(.action-placement),.other) { color:red; }')).not.toEqual([]);
    expect(styles('.action-placement > span { color:red; }')).not.toEqual([]);
    expect(styles('.action-placement { @apply w-full; }')).not.toEqual([]);
  });

  it('normalizes escaped selectors, nested pseudos, parts and vendor tags', () => {
    for (const selector of ['.ui-button', '.u\\69-button', '[data-ui-ready]', '[data-\\75i-ready]',
      ':is(.ui-button,.application-panel)', ':where(.ui-button)', ':not(.ui-button)', 'wa-button', 'wa-\\62utton',
      '.application-panel ::part(button)', '.application-panel::slotted(span)', '[class~="ui-button"]', '[class^="ui-"]', 'button']) {
      expect(styles(`${selector} { all:revert!important; }`), selector).not.toEqual([]);
    }
    expect(styles('@scope (.ui-button) { .application-label { color:red; } }')).not.toEqual([]);
  });

  it('protects inherited variables and @property registration in any cascade layer', () => {
    for (const css of ['.application-panel { --ui-control-height:1px; }', ':root { --wa-form-control-height:1px; }',
      '@layer override { body { --primary:red!important; } }', '.application-panel { --u\\69-control-height:1px; }',
      '@property --ui-control-height { syntax:"<length>"; initial-value:1px; inherits:true; }']) {
      expect(styles(css), css).not.toEqual([]);
    }
    expect(styles('.application-panel { --application-sidebar-width:200px; }')).toEqual([]);
    expect(styles('.application-panel { --haku-app-sidebar-width:200px; }')).toEqual([]);
  });

  it('reserves font-face registrations while allowing consumers to use owned families', () => {
    for (const css of [
      '@font-face { font-family: ui-inter; src: url("./other.woff2"); }',
      '@FONT-FACE { font-family: "UI-INTER"; src: url("./other.woff2"); }',
      '@font-face { font-family: u\\69 -inter; src: url("./other.woff2"); }',
      '@font-face { font-family: "\\75i-emoji"; src: url("./other.woff2"); }',
      '@layer app { @font-face { font-family: ui-emoji; src: url("./other.ttf"); } }',
    ]) expect(styles(css), css).not.toEqual([]);
    expect(styles('@font-face { font-family: "Host Face"; src: url("./host.woff2"); }')).toEqual([]);
    expect(styles('.application-label { font-family: "ui-inter", "ui-emoji", sans-serif; }')).toEqual([]);
  });

  it('allows owner stylesheets to define their complete implementation', () => {
    expect(styles('.ui-button { --ui-control-height:20px; padding:4px; color:red; }', 'packages/design-system/src/solid/button.css')).toEqual([]);
  });
});

describe('consumer host class collection', () => {
  it('reserves actual custom property definitions rather than other-vendor linter strings', () => {
    expect([...ownedDesignSystemVariables('.host {--owned-size:12px;width:var(--application-size)} @property --owned-tone {syntax:"*";initial-value:red;inherits:true}', 'owner.css')].sort()).toEqual(['--owned-size','--owned-tone']);
    expect([...ownedDesignSystemVariables('const value={"--owned-size":"12px"}; host.style.setProperty("--owned-tone","red"); if(property === "--ag-input-focus-border-color") return false;', 'owner.ts')].sort()).toEqual(['--owned-size','--owned-tone']);
  });

  it('uses compiler scopes and finite imported prop types for host class collection', () => {
    const code=`import {Button,Card} from '@ui-kit/core';
      declare const props:{class:'typed-host'|'typed-alternative';attributes:{class:'attribute-host'}};
      declare const surface:{recipe:string;class:'unknown-card-recipe'};
      const scoped={class:'outer-host'};
      function other(){const scoped={class:'inner-host'};return new Button(scoped);}
      new Button(scoped);new Card(surface);const Example=()=> <Button.View {...props}/>;`;
    const {filename,program}=ownershipProgram(code);
    const {classes}=collectDesignSystemControlClasses(code,filename,process.cwd(),program);
    expect([...classes].sort()).toEqual(['attribute-host','inner-host','outer-host','typed-alternative','typed-host','unknown-card-recipe']);
  });

  it('records actual host classes without sweeping children, constructors or unpainted hosts', () => {
    const {classes,ids} = collectDesignSystemControlClasses(`
      import {Button,Card,InteractionRegion,ScrollArea} from '@ui-kit/core';
      const host={class:'button-host',children:<span class="custom-label"/>,content:{class:'content-option'}};
      new Button({...host,id:'save'});
      new Card({class:'plain-card',children:<div class="card-content"/>});
      new Card({recipe:'content',class:'surface-card',attributes:{class:'surface-attribute'}});
      new InteractionRegion({class:'own-layout'});
      const Example=()=> <><Button.View class="jsx-host"><span class="jsx-label"/></Button.View>
        <Card.View recipe="plain" class="plain-jsx"/><Card.View {...{recipe:'content',class:'surface-jsx'}}/>
        <ScrollArea.View class="viewport"/></>;
      new ApplicationThing({class:'other-constructor'});
    `,'src/example.tsx');
    expect([...classes].sort()).toEqual(['button-host','jsx-host','plain-card','plain-jsx','surface-attribute','surface-card','surface-jsx','viewport']);
    expect([...ids]).toEqual(['save']);
  });

  it('follows core aliases but does not assume matching application names are controls', () => {
    const {classes} = collectDesignSystemControlClasses(`
      import * as UI from '@ui-kit/core'; const {Button:Action}=UI; const View=Action.View;
      const refs={Action:Action}; const props={class:'spread-host'};
      const Example=()=> <><View {...props}/><refs.Action.View class="member-host"/><Dynamic component={Action.View} class="dynamic-host"/></>;
    `,'src/example.tsx');
    expect([...classes].sort()).toEqual(['dynamic-host','member-host','spread-host']);
    expect([...collectDesignSystemControlClasses('class Button{}; new Button({class:"application"}); const Example=()=> <Button.View class="own"/>;','src/example.tsx').classes]).toEqual([]);
  });

  it('keeps conditional icon shapes correlated and protects every Card recipe', () => {
    const {classes,iconClasses}=collectDesignSystemControlClasses(`import {Button,Card} from '@ui-kit/core';
      const Example=()=> <><Button.View shape={props.names ? undefined : 'icon'} class={props.names ? 'full-row' : undefined}/>
      <Button.View shape={props.names ? undefined : 'icon'} class="both-shapes"/>
      <Card.View {...(props.panel ? {recipe:'panel',class:'surface-panel'} : {recipe:'plain',class:'plain-panel'})}/></>;`, 'src/example.tsx');
    expect([...classes].sort()).toEqual(['both-shapes','full-row','plain-panel','surface-panel']);
    expect([...iconClasses]).toEqual(['both-shapes']);
  });
});

describe('reusable stylesheet dependency boundary', () => {
  const owner='packages/design-system/src/solid/probe.css';

  it('permits self-contained local imports, fonts, images and fragment references', () => {
    for (const css of ['@import "../tokens.css";', '@IMPORT URL("../tokens.css") layer(core);',
      '.host {background:URL("../assets/example.svg");mask:url(#owned-mask)}',
      '@font-face {src:local("Inter"),url("data:font/woff2;base64,AA==")} ',
      '.host {background:image-set("../assets/one.png" 1x,url("../assets/two.png") 2x)}',
      '.host {background:url("data:image/svg+xml,%3Csvg/%3E")}']) {
      expect(designSystemStylesheetProblems(css,owner),css).toEqual([]);
    }
  });

  it('rejects application assets, undeclared URLs and dynamic resource paths in every form', () => {
    for (const css of ['@import "../../../../ui/src/app.css";', '@IMPORT URL("../../../../ui/src/app.css");',
      '@im\\70ort "../../../../ui/src/app.css";', '@import url(var(--app-styles));',
      '.host {background:URL("/application-logo.svg")}', '.host {background:u\\72l("https://example.com/logo.svg")}',
      '.host {background:image-set("../../../../ui/src/app.png" 1x)}',
      '.host {background:image-set(URL("../../../../ui/src/app.png") 1x)}',
      '@font-face {src:SRC("../../../../ui/src/app.woff2")}', '.host {background:url(var(--app-image))}']) {
      expect(designSystemStylesheetProblems(css,owner),css).not.toEqual([]);
    }
    expect(designSystemStylesheetProblems('.host {background:url("/app.png")}', 'packages/ui/src/example.css')).toEqual([]);
  });

  it('rejects build-framework directives and theme functions in ordinary CSS', () => {
    for (const css of ['@tailwind utilities;', '.host {@apply text-sm;}', '@screen md {.host {width:100%}}',
      '@config "../../tailwind.config.js";', '.host {font-size:theme("fontSize.body")}']) {
      expect(stylesheetFrameworkProblems(css,'src/example.css'),css).not.toEqual([]);
    }
    expect(stylesheetFrameworkProblems('.app {width:var(--app-width);@media (width>40rem) {margin:auto}}','src/example.css')).toEqual([]);
  });
});
