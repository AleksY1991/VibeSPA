import { expect, it } from 'vitest';
import ts from 'typescript';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
// @ts-expect-error The external migration tool is a JavaScript CLI.
import { migratePresentationSource } from '../../../tools/migrate-presentation.mjs';

const imports = 'import { Button, TextField, Textarea, Select, SearchField, Dialog } from "@ui-kit/core";\n';
const run = (code: string) => migratePresentationSource(imports + code, 'migration-fixture.tsx');
const parses = (source: string) => ts.createSourceFile('result.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX).parseDiagnostics;

it.each([
  ['outlined field', '<TextField.View appearance="outlined" />', 'recipe="form"'],
  ['plain field', '<TextField.View appearance="plain" />', 'recipe="inline"'],
  ['filled field', '<TextField.View appearance="filled" />', 'recipe="filled"'],
  ['monospace field', '<TextField.View font="mono" appearance="outlined" textSize="body" />', 'recipe="code"'],
  ['select default typography', '<Select.View textSize="body" />', '<Select.View'],
  ['search facade', '<SearchField.View appearance="plain" />', '<SearchField.View'],
  ['textarea code', '<Textarea.View appearance="outlined" font="mono" rows={4} />', 'recipe="code"'],
  ['textarea composer', '<Textarea.View appearance="outlined" paddingBlock="lg" lineHeight="tight" trailingAction paddingEnd="action" resize="auto" />', 'recipe="composer"'],
  ['ordinary Button defaults', '<Button.View textSize="body" contentAlign="center" multiline={false} selectionPaint />', '<Button.View'],
  ['content Button explicit paint', '<Button.View recipe="content" variant="outline" fillLabel={false} />', 'recipe="content"'],
  ['empty styling', '<Button.View class="" className={undefined} classList={{}} />', '<Button.View'],
  ['placement-only style', '<Button.View style={{ width: "100%", position: "absolute", left: offset }} />', 'placement={{ width: "100%", position: "absolute", left: offset }}'],
  ['logical placement', '<TextField.View style={{ "inline-size": "100%", "grid-column": "2" }} />', 'placement={{ "inline-size": "100%", "grid-column": "2" }}'],
  ['default dialog', '<Dialog.View variant="default" layout="grid" padding="md" gap="md" />', 'recipe="dialog"'],
  ['bounded editor', '<Dialog.View layout="column" padding="none" gap="none" height="viewport" overflow="hidden" size="md" />', 'recipe="editor"'],
  ['complete fullscreen', '<Dialog.View variant="fullscreen" layout="column" padding="none" gap="none" overflow="hidden" size="sm" placement="center" />', 'recipe="fullscreen"'],
  ['complete detached', '<Dialog.View variant="detached" backdrop="transparent" padding="md" gap="md" />', 'recipe="detached"'],
])('migrates a statically equivalent %s composition', (_label, input, expected) => {
  const result = run(input);
  expect(result.blocked, JSON.stringify(result.reports)).toBe(false);
  expect(result.changed).toBe(true);
  expect(result.output).toContain(expected);
  expect(parses(result.output)).toEqual([]);
  expect(run(result.output.slice(imports.length)).changed).toBe(false);
});

it.each([
  ['legacy action name collision', '<Button.View recipe="action" />'],
  ['legacy inline name collision', '<Button.View recipe="inline" />'],
  ['legacy menu geometry', '<Button.View recipe="menu" variant="ghost" />'],
  ['unknown old recipe', '<Button.View recipe="cell" />'],
  ['implicit primary icon paint', '<Button.View shape="icon" aria-label="Save" />'],
  ['unsupported icon paint', '<Button.View shape="icon" variant="default" aria-label="Save" />'],
  ['missing icon name', '<Button.View shape="icon" variant="ghost" />'],
  ['implicit content paint', '<Button.View recipe="content" />'],
  ['legacy custom appearance', '<Button.View visualStyle="standard" />'],
  ['custom class', '<Button.View class="resize-me" />'],
  ['class directive', '<Button.View class:active={true} />'],
  ['style directive', '<Button.View style:color="red" />'],
  ['property style alias', '<Button.View prop:style={{color:"red"}} textSize="body" />'],
  ['attribute class alias', '<Button.View attr:class="custom" textSize="body" />'],
  ['property className alias', '<TextField.View prop:className="custom" appearance="plain" />'],
  ['attribute classList alias', '<TextField.View attr:classList={{custom:true}} appearance="plain" />'],
  ['property style directive', 'new Textarea({"prop:style:color":"red", appearance:"plain"});'],
  ['raw dataset', '<Button.View dataset={{uiButton:""}} textSize="body" />'],
  ['property dataset', '<TextField.View prop:dataset={{uiField:""}} appearance="plain" />'],
  ['raw library marker', '<Button.View data-ui-button="" textSize="body" />'],
  ['raw vendor marker', '<TextField.View data-wa-size="small" appearance="plain" />'],
  ['attribute library marker', '<Button.View attr:data-ui-button="" textSize="body" />'],
  ['property vendor marker', '<TextField.View prop:data-wa-size="small" appearance="plain" />'],
  ['arbitrary CSS', '<Button.View style={{ height: "23px" }} />'],
  ['CSS variables', '<Button.View style={{ "--ui-button-height": "23px" }} />'],
  ['style string', '<Button.View style="width:100%" />'],
  ['computed style property', '<Button.View style={{ [property]: "100%" }} />'],
  ['style spread', '<Button.View style={{ ...layout }} />'],
  ['two placement sources', '<Button.View style={{ width: "100%" }} placement={{ width: "50%" }} />'],
  ['dynamic appearance', '<TextField.View appearance={appearance} />'],
  ['custom typography', '<TextField.View appearance="plain" textSize="heading" />'],
  ['mixed code/paint', '<TextField.View appearance="filled" font="mono" />'],
  ['select custom spacing', '<Select.View paddingInline="none" />'],
  ['search recipe override', '<SearchField.View recipe="inline" />'],
  ['dynamic density', '<TextField.View size={size} appearance="plain" />'],
  ['unknown constructor props', 'new TextField(props)'],
  ['unknown JSX spread', '<TextField.View {...props} appearance="plain" />'],
  ['duplicate props', '<TextField.View appearance="plain" appearance="filled" />'],
  ['viewport variant alone', '<Dialog.View variant="fullscreen" />'],
  ['legacy default detached scrim', '<Dialog.View variant="detached" />'],
  ['partial editor composition', '<Dialog.View layout="column" padding="none" />'],
  ['Dialog arbitrary geometry', '<Dialog.View style={{ width: "100%" }} />'],
  ['Dialog dynamic viewport', '<Dialog.View viewportInset={inset} />'],
])('reports %s without making partial edits', (_label, input) => {
  const source = imports + input;
  const result = migratePresentationSource(source, 'migration-fixture.tsx');
  expect(result.blocked).toBe(true);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(source);
  expect(result.reports.some((report: { status: string }) => report.status === 'manual')).toBe(true);
});

it('recognizes named/namespace/local aliases, View calls and constructors', () => {
  const source = 'import { TextField as Input } from "@ui-kit/core/solid/text-field";\n'
    + 'import * as ui from "@ui-kit/core";\n'
    + 'const Local = Input;\n'
    + '<Local.View appearance="plain" />;\n'
    + '<ui.Textarea.View font="mono" />;\n'
    + 'new Input({ appearance: "filled", onValueChange: save });\n'
    + 'Input.View({appearance:"outlined", font:"default"});\n';
  const result = migratePresentationSource(source, 'aliases.tsx');
  expect(result.blocked, JSON.stringify(result.reports)).toBe(false);
  expect(result.reports).toHaveLength(4);
  expect(result.output).toContain('recipe="inline"');
  expect(result.output).toContain('recipe="code"');
  expect(result.output).toContain("recipe: 'filled'");
  expect(result.output).toContain("recipe: 'form'");
  expect(parses(result.output)).toEqual([]);
});

it('does not modify unrelated or lexically shadowed components', () => {
  const source = 'import { TextField } from "@ui-kit/core";\n'
    + 'function Other(TextField: any) { return <TextField.View appearance="plain" />; }\n'
    + 'const LocalButton = () => null;\n<LocalButton class="app-owned" />;\n';
  const result = migratePresentationSource(source, 'shadowed.tsx');
  expect(result.reports).toEqual([]);
  expect(result.output).toBe(source);
});

it('blocks retired properties in local and imported spreads without flattening them', () => {
  for (const source of [
    imports + 'const props = {appearance:"plain"}; <TextField.View {...props} />;',
    imports + 'import { props } from "./options"; <TextField.View {...props} appearance="plain" />;',
  ]) {
    const result = migratePresentationSource(source, 'spreads.tsx');
    expect(result.blocked).toBe(true);
    expect(result.output).toBe(source);
  }
});

it.each([
  'const construction = {observable: binding, surface: {kind:"inherit"}, hotkeys: []}; <TextField.View {...construction} appearance="plain" />;',
  'const construction = {observable, surface, hotkeys:[]}; construction.class = "custom"; <TextField.View {...construction} appearance="plain" />;',
  'const construction = {observable, surface, hotkeys:[]}; addPresentation(construction); <TextField.View {...construction} appearance="plain" />;',
  'const construction = {observable, surface, hotkeys:[]}; const alias=construction; alias.style={color:"red"}; <TextField.View {...construction} appearance="plain" />;',
  '<TextField.View {...{observable, surface, hotkeys:[]}} appearance="plain" />;',
  'new TextField({...{observable, surface, hotkeys:[]}, appearance:"plain"});',
  'const props = {appearance:"plain", observable, surface, hotkeys:[]}; props.class="custom"; new TextField(props);',
  'const props = Object.freeze({appearance:"plain", observable, surface, hotkeys:[]}); new TextField(props);',
])('leaves all referenced/spread props for manual review: %s', code => {
  const source = imports + code;
  const result = migratePresentationSource(source, 'spread-mutation.tsx');
  expect(result.blocked).toBe(true);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(source);
});

it('still resolves immutable scalar aliases in direct props', () => {
  const result = run('const appearance = "plain"; <TextField.View appearance={appearance} />;');
  expect(result.blocked, JSON.stringify(result.reports)).toBe(false);
  expect(result.output).toContain('recipe="inline"');
});

it.each([
  '<Button.View recipe="action-row" variant="outline" />',
  '<Button.View recipe="cell-action" size="compact" />',
  '<Button.View recipe="property-row" />',
  '<Button.View recipe="selection-cell" shape="icon" aria-label="Select item" />',
  '<Button.View recipe="fill-action" />',
  '<Button.View recipe="overlay-action" aria-labelledby="preview-title" />',
  '<TextField.View recipe="entry" />',
  '<TextField.View recipe="title" />',
  '<TextField.View recipe="search-action" />',
  '<Textarea.View recipe="entry" />',
  '<Textarea.View recipe="reading" />',
  '<Textarea.View recipe="compact-composer" />',
  '<Select.View recipe="entry" />',
  '<Dialog.View recipe="form" size="md" placement="start" />',
  '<Dialog.View recipe="form" size="lg" />',
  '<Dialog.View recipe="media" />',
  '<Dialog.View recipe="drawer" drawer={panelModel} />',
])('recognizes current recipes from the generated public contract: %s', code => {
  const source = imports + code;
  const result = migratePresentationSource(source, 'current-recipes.tsx');
  expect(result.blocked, JSON.stringify(result.reports)).toBe(false);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(source);
});

it.each([
  '<Button.View recipe="action-row" />',
  '<Button.View recipe="cell-action" variant="ghost" />',
  '<Button.View recipe="selection-cell" shape="icon" variant="ghost" aria-label="Select" />',
  '<Button.View recipe="selection-cell" shape="icon" />',
  '<Button.View recipe="fill-action" size="standard" />',
  '<Button.View recipe="overlay-action" />',
  '<Button.View recipe="overlay-action" aria-label=" " />',
  '<Button.View shape="icon" variant="ghost" aria-label={dynamicLabel} textSize="body" />',
  '<Dialog.View recipe="media" size="lg" />',
  '<Dialog.View recipe="form" size="wide" />',
  '<Dialog.View recipe="confirmation" />',
  '<Dialog.View recipe="command" />',
  '<Dialog.View recipe="command" placement="center" />',
  '<Dialog.View recipe="drawer" />',
  '<Dialog.View recipe="drawer" drawer={undefined} />',
  '<Dialog.View recipe="drawer" drawer={null} className={undefined} />',
  '<Dialog.View recipe="drawer" drawer="model" className={undefined} />',
  '<Dialog.View recipe="drawer" drawer={12} className={undefined} />',
  '<Dialog.View recipe="drawer" drawer={{width:400}} className={undefined} />',
  '<Dialog.View recipe="drawer" drawer={panelModel} placement="corner" />',
  '<Dialog.View recipe="form" drawer={panelModel} />',
])('rejects unsupported cross-products from the generated contract: %s', code => {
  const result = run(code);
  expect(result.blocked).toBe(true);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(imports + code);
});

it.each(['TextField', 'Textarea', 'Select'])('requires manual review of legacy 16px %s typography', name => {
  const code = '<' + name + '.View appearance="outlined" textSize="field" />';
  const result = run(code);
  expect(result.blocked).toBe(true);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(imports + code);
  expect(result.reports[0].messages.join(' ')).toContain('16px desktop text; form uses 13px');
});

it.each([
  '<Button.View recipe="selection-cell" textSize="body" />',
  '<Button.View recipe="action-row" variant="outline" contentAlign="center" />',
  '<TextField.View recipe="title" textSize="body" />',
  '<Textarea.View recipe="reading" textSize="body" />',
  '<Dialog.View recipe="form" padding="md" />',
  '<Dialog.View recipe="editor" layout="grid" padding="md" />',
])('does not confuse current recipe validity with legacy equivalence: %s', code => {
  const result = run(code);
  expect(result.blocked).toBe(true);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(imports + code);
  expect(result.reports[0].messages.join(' ')).toContain('no proven equivalence');
});

it.each([
  '<Button.View recipe="selection-cell" style={{width:"100%"}} />',
  '<TextField.View recipe="title" style={{width:"100%"}} />',
  '<Textarea.View recipe="reading" style={{width:"100%"}} />',
])('still migrates outer placement on recognized current recipes: %s', code => {
  const result = run(code);
  expect(result.blocked, JSON.stringify(result.reports)).toBe(false);
  expect(result.changed).toBe(true);
  expect(result.output).toContain('placement={{width:"100%"}}');
});

it.each([
  '<TextField.View appearance="outlined" placement={{padding:"lg"}} />',
  '<Textarea.View appearance="plain" placement={{width:"100%", color:"red"}} />',
  '<Select.View textSize="body" placement={{...layout}} />',
  '<Button.View textSize="body" placement="100%" />',
  '<TextField.View appearance="plain" placement={null} />',
  '<Textarea.View appearance="plain" placement={false} />',
  '<Button.View textSize="body" placement={[]} />',
])('does not label a visibly invalid existing placement as safe: %s', code => {
  const result = run(code);
  expect(result.blocked).toBe(true);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(imports + code);
  expect(result.reports[0].messages.join(' ')).toContain('placement');
});

it('leaves getters, computed props and ambiguous imported helpers for manual review', () => {
  for (const source of [
    imports + 'new TextField({ get appearance() { return "plain"; } });',
    imports + 'new TextField({ ["appearance"]: "plain" });',
    'import {buttonVariants as paint} from "@ui-kit/core"; paint({variant:"ghost"});',
    'import * as ui from "@ui-kit/core"; ui.BUTTON_SIZE_CLASSES.compact;',
    'const ui = await import("@ui-kit/core"); ui.buttonVariants({variant:"ghost"});',
  ]) {
    const result = migratePresentationSource(source, 'manual.tsx');
    expect(result.blocked).toBe(true);
    expect(result.output).toBe(source);
  }
});

it('does not apply safe edits elsewhere in a file containing a manual issue', () => {
  const source = imports + '<TextField.View appearance="plain" />;\n<Button.View class="custom" />;';
  const result = migratePresentationSource(source, 'atomic.tsx');
  expect(result.reports.map((report: { status: string }) => report.status)).toEqual(['safe', 'manual']);
  expect(result.changed).toBe(false);
  expect(result.output).toBe(source);
});

it('retains behavioral expressions and comments while removing constructor prop commas safely', () => {
  const source = imports + 'new TextField({ /* keep */ font: "default", appearance: "plain", onValueChange: save, });';
  const result = migratePresentationSource(source, 'comments.tsx');
  expect(result.blocked).toBe(false);
  expect(result.output).toContain('/* keep */');
  expect(result.output).toContain('onValueChange: save');
  expect(parses(result.output)).toEqual([]);
});

it('reports source positions and refuses invalid source syntax', () => {
  const result = run('\n<Button.View class="custom" />');
  expect(result.reports[0]).toMatchObject({ line: 3, column: 1, component: 'Button', props: ['class'] });
  expect(run('<Button.View').blocked).toBe(true);
});

it('dry-runs by default, writes explicit safe files, and returns a nonzero manual-report status', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'ui-kit-migration-'));
  const safe = path.join(directory, 'safe.tsx');
  const manual = path.join(directory, 'manual.tsx');
  const tool = path.resolve('tools/migrate-presentation.mjs');
  const safeSource = imports + '<TextField.View appearance="plain" />';
  const manualSource = imports + '<Button.View class="custom" />';
  try {
    fs.writeFileSync(safe, safeSource);
    fs.writeFileSync(manual, manualSource);
    const dry = spawnSync(process.execPath, [tool, safe], { encoding: 'utf8' });
    expect(dry.status, dry.stderr).toBe(0);
    expect(JSON.parse(dry.stdout)).toMatchObject({ mode: 'dry-run', scanned: 1 });
    expect(fs.readFileSync(safe, 'utf8')).toBe(safeSource);
    const write = spawnSync(process.execPath, [tool, '--write', safe, manual], { encoding: 'utf8' });
    expect(write.status, write.stderr).toBe(2);
    const report = JSON.parse(write.stdout);
    expect(report.files[0].file).toBe(manual);
    expect(report.files[0].reports[0]).toMatchObject({ status: 'manual', line: 2, component: 'Button' });
    expect(fs.readFileSync(safe, 'utf8')).toContain('recipe="inline"');
    expect(fs.readFileSync(manual, 'utf8')).toBe(manualSource);
  } finally {
    // Remove only the exact files created above, then the now-empty directory.
    fs.unlinkSync(safe);
    fs.unlinkSync(manual);
    fs.rmdirSync(directory);
  }
}, 30_000);

it('skips tests, fixtures, declarations and generated/dependency directories during directory migration', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'ui-kit-migration-scan-'));
  const tests = path.join(directory, 'tests');
  const dependency = path.join(directory, 'node_modules');
  const safe = path.join(directory, 'screen.tsx');
  const ignoredTest = path.join(directory, 'negative.test.tsx');
  const ignoredFixture = path.join(tests, 'screen.tsx');
  const ignoredDependency = path.join(dependency, 'screen.tsx');
  const source = imports + '<TextField.View appearance="plain" />';
  try {
    fs.mkdirSync(tests); fs.mkdirSync(dependency);
    for (const file of [safe, ignoredTest, ignoredFixture, ignoredDependency]) fs.writeFileSync(file, source);
    const result = spawnSync(process.execPath, [path.resolve('tools/migrate-presentation.mjs'), '--write', directory], { encoding: 'utf8' });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout).scanned).toBe(1);
    expect(fs.readFileSync(safe, 'utf8')).toContain('recipe="inline"');
    for (const file of [ignoredTest, ignoredFixture, ignoredDependency]) expect(fs.readFileSync(file, 'utf8')).toBe(source);
  } finally {
    for (const file of [safe, ignoredTest, ignoredFixture, ignoredDependency]) fs.unlinkSync(file);
    fs.rmdirSync(tests); fs.rmdirSync(dependency); fs.rmdirSync(directory);
  }
}, 30_000);
