import postcss from 'postcss';
import selectorParser from 'postcss-selector-parser';
import valueParser from 'postcss-value-parser';
import { decodeCss, fontFamilyNames, isDesignSystemOwner } from './design-system-ownership.js';

const selectorFunctions = new Set([':is', ':where', ':not', ':has', ':nth-child', ':nth-last-child', ':host', ':host-context', '::slotted']);
const groupingRules = new Set(['media', 'supports', 'container', 'layer', 'scope', 'starting-style']);
const animationNames = new Set(['none', 'inherit', 'initial', 'unset', 'revert', 'revert-layer']);
const animationCategories = new Map([
  ...['ease', 'ease-in', 'ease-out', 'ease-in-out', 'linear', 'step-start', 'step-end'].map(name => [name, 'timing']),
  ['infinite', 'iterations'],
  ...['normal', 'reverse', 'alternate', 'alternate-reverse'].map(name => [name, 'direction']),
  ...['forwards', 'backwards', 'both'].map(name => [name, 'fill']),
  ...['running', 'paused'].map(name => [name, 'play']),
]);
const timingFunctions = new Set(['steps', 'cubic-bezier', 'linear']);
const namespaced = value => /^ui-[\w-]+$/.test(decodeCss(value));
const ownedLayer = value => /^ui-[\w-]+(?:\.[\w-]+)*$/.test(decodeCss(value));
const keyframes = value => /^(?:-webkit-)?keyframes$/.test(decodeCss(value).toLowerCase());
const pseudoName = node => decodeCss(node.value).toLowerCase();
const minimum = values => values.length && values.every(value => value !== null) ? Math.min(...values) : null;

/** A marker in a negation or a descendant test does not constrain the subject. */
function positiveDepth(selector, parentDepth = null, initialDepth = null) {
  let depth = initialDepth;
  for (const node of selector.nodes) {
    if (node.type === 'combinator') {
      const combinator = node.value.trim();
      if (combinator === '' || combinator === '>') depth = depth === null ? null : depth + 1;
      else if (combinator === '+' || combinator === '~') depth = depth === 0 ? null : depth;
      else depth = null;
      continue;
    }
    let ownDepth = null;
    if (node.type === 'attribute' && !node.namespace && decodeCss(node.attribute) === 'data-ui-root') ownDepth = 0;
    if (node.type === 'nesting') ownDepth = parentDepth;
    if (node.type === 'pseudo' && [':is', ':where'].includes(pseudoName(node))) {
      ownDepth = minimum((node.nodes ?? []).map(branch => positiveDepth(branch, parentDepth)));
    }
    if (ownDepth !== null) depth = depth === null ? ownDepth : Math.max(depth, ownDepth);
  }
  return depth;
}

function documentSelector(selector) {
  return selector.nodes.some(node => node.type === 'tag' && /^(?:html|body)$/i.test(decodeCss(node.value))
    || node.type === 'pseudo' && (pseudoName(node) === ':root'
      || selectorFunctions.has(pseudoName(node)) && (node.nodes ?? []).some(documentSelector)));
}

function nested(selector) {
  let found = false;
  selector.walkNesting(() => { found = true; });
  return found;
}

function frameRule(rule) {
  for (let parent = rule.parent; parent; parent = parent.parent) {
    if (parent.type === 'atrule' && keyframes(parent.name)) return true;
  }
  return false;
}

function layerProblems(rule) {
  const name = decodeCss(rule.name).toLowerCase();
  if (name !== 'layer' && name !== 'import') return false;
  const tokens = valueParser(rule.params).nodes.filter(node => !['space', 'comment'].includes(node.type));
  if (name === 'import') return tokens.some(node => node.type === 'function'
    && decodeCss(node.value).toLowerCase() === 'layer'
    && !ownedLayer(valueParser.stringify(node.nodes).trim()));
  // A nested name lives below its containing library (or anonymous) layer.
  // Only global names can join or reorder an application's existing layers.
  for (let parent = rule.parent; parent; parent = parent.parent) {
    if (parent.type === 'atrule' && decodeCss(parent.name).toLowerCase() === 'layer') return false;
  }
  if (tokens.length === 0) return false;
  return tokens.some((node, index) => index % 2 === 0
    ? node.type !== 'word' || !ownedLayer(node.value)
    : node.type !== 'div' || node.value !== ',') || tokens.length % 2 === 0;
}

function animationProblems(declaration) {
  const property = decodeCss(declaration.prop).toLowerCase();
  if (!/^(?:-webkit-)?animation(?:-name)?$/.test(property)) return false;
  const nameOnly = property.endsWith('-name');
  const groups = [[]];
  for (const node of valueParser(declaration.value).nodes) {
    if (node.type === 'space' || node.type === 'comment') continue;
    if (node.type === 'div' && node.value === ',') groups.push([]);
    else groups.at(-1).push(node);
  }
  return groups.some(tokens => {
    if (tokens.length === 0) return true;
    if (tokens.length === 1 && tokens[0].type === 'word' && animationNames.has(decodeCss(tokens[0].value).toLowerCase())) return false;
    const occupied = new Set();
    let times = 0;
    return tokens.some(node => {
      let category;
      if (node.type === 'string') {
        if (!namespaced(node.value)) return true;
        category = 'name';
      } else if (node.type === 'function') {
        if (nameOnly || !timingFunctions.has(decodeCss(node.value).toLowerCase())) return true;
        category = 'timing';
      } else if (node.type === 'word') {
        const value = decodeCss(node.value);
        if (namespaced(value)) category = 'name';
        else if (nameOnly) return !animationNames.has(value.toLowerCase());
        else if (value.toLowerCase() === 'none') return false;
        else if (/^[-+]?(?:\d*\.)?\d+(?:e[-+]?\d+)?m?s$/i.test(value)) return ++times > 2;
        else if (/^[-+]?(?:\d*\.)?\d+(?:e[-+]?\d+)?$/i.test(value)) category = 'iterations';
        else category = animationCategories.get(value.toLowerCase());
        if (!category) return true;
      } else return true;
      // A repeated keyword can be parsed as the animation name. Do not let
      // `linear linear 1s` select an application's unnamespaced keyframes.
      if (occupied.has(category)) return true;
      occupied.add(category);
      return false;
    });
  });
}

/** Keep library CSS inside a mounted root, including future selectors and nesting. */
export function designSystemStylesheetScopeProblems(css, filename) {
  if (!/\.css$/i.test(filename) || !isDesignSystemOwner(filename)) return [];
  const problems = [];
  const report = (node, message) => problems.push(`${filename}:${node.source?.start?.line ?? 1}: ${message}`);
  let sheet;
  try { sheet = postcss.parse(css, { from: filename }); }
  catch (error) { return [`${filename}:${error.line ?? 1}: Design-system CSS must be statically parseable to verify its root scope.`]; }
  const guarantees = new WeakMap();
  const ruleDepth = rule => {
    if (guarantees.has(rule)) return guarantees.get(rule);
    let parent = rule.parent;
    while (parent && parent.type !== 'rule') parent = parent.parent;
    const inherited = parent ? ruleDepth(parent) : null;
    try {
      const selectors = selectorParser().astSync(rule.selector).nodes;
      const depths = selectors.map(selector => {
        let initial = null;
        if (parent && !nested(selector)) {
          initial = selector.nodes[0]?.type === 'combinator' ? inherited : inherited === null ? null : inherited + 1;
        }
        return documentSelector(selector) ? null : positiveDepth(selector, inherited, initial);
      });
      const guarantee = minimum(depths);
      guarantees.set(rule, guarantee);
      return guarantee;
    } catch {
      guarantees.set(rule, null);
      return null;
    }
  };
  sheet.walkRules(rule => {
    if (frameRule(rule)) return;
    if (ruleDepth(rule) === null) report(rule,
      'Every design-system selector branch must positively stay inside [data-ui-root]. Negations, descendant tests, sibling escapes and document selectors cannot establish library scope.');
  });
  sheet.walkAtRules(rule => {
    const name = decodeCss(rule.name).toLowerCase();
    if (name === 'font-face') {
      const descriptors = (rule.nodes ?? []).filter(node => node.type === 'decl' && decodeCss(node.prop).toLowerCase() === 'font-family');
      if (descriptors.length === 0 || descriptors.some(declaration => {
        const families = fontFamilyNames(declaration.value);
        return families.length !== 1 || !/^ui-[\w-]+$/i.test(families[0] ?? '');
      })) report(rule, 'Design-system font faces register explicit ui- family names so the embedding application keeps its own font registry.');
    }
    if (layerProblems(rule)) report(rule,
      'Global design-system cascade layers use ui- names. Application layer names and ordering belong to the host.');
    if (keyframes(name)) {
      const tokens = valueParser(rule.params).nodes.filter(node => !['space', 'comment'].includes(node.type));
      if (tokens.length !== 1 || !['word', 'string'].includes(tokens[0].type) || !namespaced(tokens[0].value)) {
        report(rule, 'Design-system keyframes use ui- names so the embedding application keeps its own animation registry.');
      }
      return;
    }
    if (!groupingRules.has(name) && !['font-face', 'import', 'charset', 'namespace'].includes(name)) {
      report(rule, 'Global page and descriptor rules belong to the embedding application. Design-system styles scope their selectors to [data-ui-root].');
    }
  });
  sheet.walkDecls(declaration => {
    if (animationProblems(declaration)) report(declaration,
      'Design-system animations use explicit ui- names or none. Application and dynamically selected animation names are outside the library scope.');
  });
  return problems;
}
