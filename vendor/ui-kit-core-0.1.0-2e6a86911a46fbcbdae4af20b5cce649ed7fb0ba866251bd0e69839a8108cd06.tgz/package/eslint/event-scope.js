import ts from 'typescript';
import { designSystemFilename } from './package-location.js';

const normalize = path => '/' + designSystemFilename(path).replace(/^\//, '');
const activationSource = path => normalize(path).endsWith('/packages/design-system/src/infrastructure/activation.ts');
const elementSource = path => normalize(path).endsWith('/packages/design-system/src/infrastructure/element.ts');
const listenerSource = path => normalize(path).endsWith('/packages/design-system/src/solid/interaction-events.ts');
const gestureSource = path => /\/packages\/design-system\/src\/solid\/(?:button|interaction-region)\.tsx$/.test(normalize(path));
const vendorSource = path => normalize(path).endsWith('/packages/design-system/src/vendor/web-awesome/button.adapter.tsx');
const FACTORIES = new Set(['eventScope', 'surfaceEvent', 'surfaceCommand']);

/** The shared native/vendor dispatchers own the imperative scope. Checking the
 * entry callback also covers reactive getters and dynamically supplied handlers
 * which the strict-read call graph cannot resolve. Application event handlers
 * continue to read snapshots through these guarded boundaries. */
export const EVENT_SCOPE = {
  meta: {
    type: 'problem', schema: [],
    messages: {
      scope: 'EVENT SCOPE: Browser events can fire synchronously during an effect. Wrap the complete dispatch callback in eventScope, or put its entire body inside Solid untrack, including handler lookup and admission. Untracking callback construction does not isolate later delivery.',
    },
  },
  create(context) {
    const services = context.sourceCode.parserServices;
    const filename = context.filename;
    if (![activationSource, elementSource, listenerSource, gestureSource, vendorSource].some(owns => owns(filename))) return {};
    if (!services.program || !services.esTreeNodeToTSNodeMap) {
      throw new Error('haku/event-scope requires TypeScript parserOptions.project or projectService.');
    }
    const checker = services.program.getTypeChecker();
    const source = services.esTreeNodeToTSNodeMap.get(context.sourceCode.ast);
    const functions = node => ts.isArrowFunction(node) || ts.isFunctionExpression(node);
    const callbacks = node => functions(node) || ts.isFunctionDeclaration(node) || ts.isMethodDeclaration(node);

    function api(call, name) {
      if (!ts.isCallExpression(call)) return false;
      const declaration = checker.getResolvedSignature(call)?.declaration;
      if (!declaration || declaration.name?.getText() !== name) return false;
      const file = declaration.getSourceFile().fileName;
      return name === 'eventScope' ? activationSource(file) && ts.isFunctionDeclaration(declaration)
        && ts.isSourceFile(declaration.parent) && declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword)
        : /\/(?:solid-js|@solidjs\/signals)\//.test(normalize(file));
    }

    function untrackedBody(body) {
      const expression = ts.isBlock(body) && body.statements.length === 1
        ? body.statements[0].expression : body;
      return expression && api(expression, 'untrack');
    }

    function eventCallback(node) {
      if (!callbacks(node) || node.parameters.length === 0) return false;
      const type = checker.getTypeAtLocation(node.parameters[0]);
      const signature = checker.getSignatureFromDeclaration(node);
      const result = signature && checker.getReturnTypeOfSignature(signature);
      const returnsVoid = type => type && (type.isUnion() ? type.types.some(returnsVoid)
        : (type.flags & (ts.TypeFlags.Void | ts.TypeFlags.Undefined)) !== 0);
      const contextual = functions(node) && checker.getContextualType(node);
      const dispatchResult = contextual && checker.getSignaturesOfType(contextual, ts.SignatureKind.Call)
        .some(signature => returnsVoid(checker.getReturnTypeOfSignature(signature)));
      return (returnsVoid(result) || dispatchResult) && ['preventDefault', 'stopPropagation']
        .every(name => checker.getPropertyOfType(type, name));
    }

    function returnedDispatcher(node) {
      if (!functions(node) || !ts.isReturnStatement(node.parent)) return false;
      for (let parent = node.parent; parent; parent = parent.parent) {
        if (ts.isFunctionDeclaration(parent)) {
          return activationSource(source.fileName) && FACTORIES.has(parent.name?.text);
        }
        if (functions(parent)) return false;
      }
      return false;
    }

    function visit(node) {
      const delivery = activationSource(source.fileName)
        && ts.isFunctionDeclaration(node) && node.name?.text === 'deliverEvent';
      if (node.body && (delivery || eventCallback(node) || returnedDispatcher(node))) {
        const parent = node.parent;
        const wrapped = ts.isCallExpression(parent) && parent.arguments[0] === node && api(parent, 'eventScope');
        if (!wrapped && !untrackedBody(node.body)) {
          context.report({ node: services.tsNodeToESTreeNodeMap.get(node), messageId: 'scope' });
        }
      }
      ts.forEachChild(node, visit);
    }

    return { 'Program:exit'() { visit(source); } };
  },
};
