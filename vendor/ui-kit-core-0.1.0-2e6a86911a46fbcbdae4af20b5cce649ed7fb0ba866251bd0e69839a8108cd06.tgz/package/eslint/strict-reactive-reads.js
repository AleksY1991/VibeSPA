import ts from 'typescript';
import { designSystemFilename } from './package-location.js';

const normalize = path => '/' + designSystemFilename(path).replace(/^\//, '');
const solidSource = path => /\/(?:solid-js|@solidjs\/(?:signals|web))\//.test(normalize(path));
const constructionSource = path => normalize(path).endsWith('/packages/design-system/src/infrastructure/construction.ts');
const registeredObservableSource = path => normalize(path).endsWith('/packages/design-system/src/contracts/construction.ts');
const functions = node => ts.isArrowFunction(node) || ts.isFunctionExpression(node)
  || ts.isFunctionDeclaration(node) || ts.isMethodDeclaration(node) || ts.isConstructorDeclaration(node)
  || ts.isGetAccessorDeclaration(node);

/**
 * The generic Solid rule guesses from names such as `props` and cannot distinguish
 * Haku's stable construction handles from reads of those handles. Resolve the
 * actual Solid accessor signature instead, including registered private UI
 * observables and the accessors returned by narrow view-contract adapters.
 * A neutral Readable is explicit-subscription data, not itself a Solid accessor;
 * its consumeReadable adapter is what establishes the tracked UI read.
 * Follow project-local setup calls across modules. Constructors, field
 * initializers and roots are checked at their definition as well, so injected
 * lifecycle interfaces cannot hide their setup reads. Check project getters and
 * effect cleanup functions too: cleanup inherits the next effect's strict scope.
 * Runtime diagnostics cover dynamic dispatch and getters that static analysis
 * cannot resolve.
 */
export const STRICT_REACTIVE_READS = {
  meta: {
    type: 'problem',
    schema: [],
    messages: {
      setup: 'STRICT REACTIVE READ: {{name}} reads reactive state outside a tracking scope and will not update. Read it in JSX, a memo, or the compute function of an effect. Use untrack only for an intentional initial or imperative snapshot; passing the accessor itself is safe.',
    },
  },
  create(context) {
    const services = context.sourceCode.parserServices;
    if (!services.program || !services.esTreeNodeToTSNodeMap) {
      throw new Error('haku/strict-reactive-reads requires TypeScript parserOptions.project or projectService.');
    }
    const checker = services.program.getTypeChecker();
    const source = services.esTreeNodeToTSNodeMap.get(context.sourceCode.ast);
    const setup = new Set();
    const effectCallbacks = [];
    const deferred = new Set();
    const reports = new Set();
    const projectCode = node => !node.getSourceFile().isDeclarationFile
      && !normalize(node.getSourceFile().fileName).includes('/node_modules/');

    function isAccessor(type) {
      if (type.isUnionOrIntersection()) return type.types.some(isAccessor);
      return checker.getSignaturesOfType(type, ts.SignatureKind.Call).some(signature => {
        const declaration = signature.declaration;
        if (!declaration) return false;
        const file = normalize(declaration.getSourceFile().fileName);
        return (solidSource(file) && ts.isTypeAliasDeclaration(declaration.parent)
          && ['Accessor', 'SourceAccessor'].includes(declaration.parent.name.text))
          || (registeredObservableSource(file)
            && ts.isPropertySignature(declaration.parent) && declaration.parent.name.getText() === 'read'
            && ts.isInterfaceDeclaration(declaration.parent.parent) && declaration.parent.parent.name.text === 'Observable');
      });
    }

    function callable(node, seen = new Set()) {
      let symbol = checker.getSymbolAtLocation(node);
      if (symbol?.flags & ts.SymbolFlags.Alias) symbol = checker.getAliasedSymbol(symbol);
      if (!symbol || seen.has(symbol)) return undefined;
      seen.add(symbol);
      const declaration = symbol?.valueDeclaration;
      if (declaration && functions(declaration)) return declaration;
      if (declaration && ts.isClassDeclaration(declaration)) return declaration;
      if (declaration && (ts.isVariableDeclaration(declaration) || ts.isPropertyAssignment(declaration)) && declaration.initializer) {
        if (functions(declaration.initializer)) return declaration.initializer;
        return callable(declaration.initializer, seen);
      }
      return undefined;
    }

    function contract(call) {
      const signature = checker.getResolvedSignature(call);
      const declaration = signature?.declaration;
      if (!declaration) return undefined;
      const file = declaration.getSourceFile().fileName;
      let symbol = checker.getSymbolAtLocation(call.expression);
      if (symbol?.flags & ts.SymbolFlags.Alias) symbol = checker.getAliasedSymbol(symbol);
      const name = declaration.name?.getText() ?? symbol?.name;
      if (solidSource(file)) return { source: 'solid', name };
      if (constructionSource(file)) return {
        source: 'construction',
        name: ts.isConstructorDeclaration(declaration) ? declaration.parent.name?.text : name,
      };
      return undefined;
    }

    function hasJsx(node) {
      if (ts.isJsxElement(node) || ts.isJsxSelfClosingElement(node) || ts.isJsxFragment(node)) return true;
      if (functions(node)) return false;
      return !!ts.forEachChild(node, hasJsx);
    }

    function effectApply(node, seen = new Set()) {
      if (seen.has(node)) return node;
      seen.add(node);
      const type = checker.getTypeAtLocation(node);
      if (checker.getSignaturesOfType(type, ts.SignatureKind.Call).length) return node;
      // Solid 2 also accepts { effect, error }. Inspect the same strict apply
      // scope whether that bundle is inline, aliased, typed, or imported.
      const member = checker.getPropertyOfType(type, 'effect')?.valueDeclaration;
      if (member && ts.isPropertyAssignment(member)) return member.initializer;
      if (member && functions(member)) return member;
      if (member && ts.isShorthandPropertyAssignment(member)) {
        const value = checker.getShorthandAssignmentValueSymbol(member)?.valueDeclaration;
        if (value && functions(value)) return value;
        if (value && ts.isVariableDeclaration(value) && value.initializer) return value.initializer;
      }
      let symbol = checker.getSymbolAtLocation(node);
      if (symbol?.flags & ts.SymbolFlags.Alias) symbol = checker.getAliasedSymbol(symbol);
      const declaration = symbol?.valueDeclaration;
      if (declaration && (ts.isVariableDeclaration(declaration) || ts.isPropertyAssignment(declaration)) && declaration.initializer) {
        return effectApply(declaration.initializer, seen);
      }
      return node;
    }

    function collect(node) {
      const name = node.name?.getText() ?? (node.parent && ts.isVariableDeclaration(node.parent) ? node.parent.name.getText() : '');
      if (functions(node) && node.body && (hasJsx(node.body)
        || ts.isConstructorDeclaration(node)
        || (source.fileName.endsWith('.tsx') && /^[A-Z]/.test(name)))) setup.add(node);
      if (ts.isPropertyDeclaration(node) && node.initializer
        && !node.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.StaticKeyword)) setup.add(node);
      // Solid's control-flow render functions run once per item/branch, even
      // when they return plain text instead of an element.
      if (functions(node) && ts.isJsxExpression(node.parent) && ts.isJsxElement(node.parent.parent)) {
        const tag = node.parent.parent.openingElement.tagName;
        let symbol = checker.getSymbolAtLocation(tag);
        if (symbol?.flags & ts.SymbolFlags.Alias) symbol = checker.getAliasedSymbol(symbol);
        if (['For', 'Show', 'Match'].includes(symbol?.name)
          && symbol?.declarations?.some(declaration => solidSource(declaration.getSourceFile().fileName))) setup.add(node);
      }
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        const api = contract(node);
        // The compute function tracks inputs; the second callback only applies
        // its result. It remains strict even when createEffect is inside untrack.
        if (api?.source === 'solid' && api.name === 'createEffect' && node.arguments?.[1]) {
          effectCallbacks.push({ callback: effectApply(node.arguments[1]), callsite: node.arguments[1] });
        }
        const index = api?.source === 'construction'
          ? api.name === 'constructItem' ? 1 : api.name === 'ItemCollection' ? 2 : api.name === 'bind' ? 1 : -1
          : api?.source === 'solid' && api.name === 'createRoot' ? 0 : -1;
        const callback = node.arguments?.[index];
        const fn = callback && (functions(callback) ? callback : callable(callback));
        if (fn?.body && fn.getSourceFile() === source) setup.add(fn);
        // Returning JSX does not turn a memo, boundary fallback, or lifecycle
        // callback into component setup. These APIs own their callback scope.
        const scoped = api?.source === 'solid' && [
          'createMemo', 'createSignal', 'createEffect', 'createTrackedEffect',
          'createErrorBoundary', 'createLoadingBoundary', 'untrack', 'onSettled', 'onCleanup',
        ].includes(api.name);
        const observed = api?.source === 'construction' && api.name === 'observe';
        if (scoped || observed) {
          for (const argument of node.arguments ?? []) {
            if (functions(argument)) deferred.add(argument);
            else {
              const callback = callable(argument);
              // A named render computation is also valid; PascalCase remains
              // a component boundary because it can be used from another file.
              if (callback && !/^[A-Z]/.test(callback.name?.getText() ?? '')) deferred.add(callback);
            }
          }
        }
      }
      ts.forEachChild(node, collect);
    }

    function report(node, origin) {
      // Local violations have one definition; imported violations must be
      // reported at every unsafe call site, including a later effect callback.
      const location = node.getSourceFile() === source ? node : origin;
      if (!location || reports.has(location)) return;
      const original = services.tsNodeToESTreeNodeMap.get(location);
      if (!original) return;
      reports.add(location);
      context.report({ node: original, messageId: 'setup', data: { name: (location.expression ?? location).getText() } });
    }

    // Cleanup runs before the next effect callback under the same strict scope.
    // A returned function is deferred work, but it is not an event handler.
    function inspectCleanup(value, origin, visiting) {
      if (!value) return;
      if (ts.isParenthesizedExpression(value) || ts.isAsExpression(value)
        || ts.isNonNullExpression(value) || ts.isSatisfiesExpression(value)) {
        inspectCleanup(value.expression, origin, visiting);
      } else if (ts.isConditionalExpression(value)) {
        inspectCleanup(value.whenTrue, origin, visiting);
        inspectCleanup(value.whenFalse, origin, visiting);
      } else if (ts.isBinaryExpression(value) && [ts.SyntaxKind.AmpersandAmpersandToken,
        ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken].includes(value.operatorToken.kind)) {
        inspectCleanup(value.left, origin, visiting);
        inspectCleanup(value.right, origin, visiting);
      } else {
        if (isAccessor(checker.getTypeAtLocation(value))) { report(value, origin); return; }
        const fn = functions(value) ? value : callable(value);
        if (fn?.body && projectCode(fn) && !visiting.has(fn)) {
          inspect(fn.body, origin ?? value, new Set(visiting).add(fn));
        }
      }
    }

    function effectReturns(node, origin, visiting) {
      if (functions(node)) return;
      if (ts.isReturnStatement(node)) inspectCleanup(node.expression, origin, visiting);
      else ts.forEachChild(node, child => effectReturns(child, origin, visiting));
    }

    // Walk only work executed now. JSX establishes tracking; function values
    // defer work. Imported project helpers execute in the same caller scope.
    function inspect(node, origin, visiting = new Set()) {
      if (ts.isJsxElement(node) || ts.isJsxSelfClosingElement(node) || ts.isJsxFragment(node)) return;
      if (functions(node)) return;
      if (ts.isPropertyAccessExpression(node) || ts.isElementAccessExpression(node)) {
        // Project getters can hide a signal read without a call expression.
        // Merely returning an accessor still passes: its body is not executed.
        const getter = checker.getSymbolAtLocation(ts.isPropertyAccessExpression(node) ? node.name : node.argumentExpression)
          ?.declarations?.find(ts.isGetAccessorDeclaration);
        const assignment = ts.isBinaryExpression(node.parent) && node.parent.left === node
          && node.parent.operatorToken.kind === ts.SyntaxKind.EqualsToken;
        if (!assignment && getter?.body && projectCode(getter) && !visiting.has(getter)) {
          inspect(getter.body, origin ?? node, new Set(visiting).add(getter));
        }
      }
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        if (ts.isCallExpression(node) && isAccessor(checker.getTypeAtLocation(node.expression))) {
          report(node, origin);
          return;
        }
        let target = node.expression;
        while (ts.isParenthesizedExpression(target) || ts.isAsExpression(target)
          || ts.isNonNullExpression(target) || ts.isSatisfiesExpression(target)) target = target.expression;
        const fn = functions(target) ? target : callable(target);
        if (fn && ts.isClassDeclaration(fn) && projectCode(fn) && !visiting.has(fn)) {
          const next = new Set(visiting).add(fn);
          for (const member of fn.members) {
            if (ts.isConstructorDeclaration(member) && member.body) inspect(member.body, origin ?? node, next);
            if (ts.isPropertyDeclaration(member) && member.initializer
              && !member.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.StaticKeyword)) inspect(member.initializer, origin ?? node, next);
          }
        }
        if (fn?.body && projectCode(fn) && !visiting.has(fn)) {
          const next = new Set(visiting).add(fn);
          inspect(fn.body, origin ?? node, next);
        }
        // Array callbacks and flush run synchronously in the caller's scope.
        const api = contract(node);
        const arrayCallback = ts.isPropertyAccessExpression(target)
          && ['map', 'flatMap', 'filter', 'forEach', 'some', 'every', 'find', 'findIndex', 'reduce', 'reduceRight', 'sort'].includes(target.name.text)
          && (checker.isArrayType(checker.getTypeAtLocation(target.expression))
            || checker.isTupleType(checker.getTypeAtLocation(target.expression))
            || checker.getTypeAtLocation(target.expression).symbol?.name === 'ReadonlyArray');
        if (arrayCallback || (api?.source === 'solid' && api.name === 'flush')) {
          const callback = node.arguments?.[0];
          const callbackFn = callback && (functions(callback) ? callback : callable(callback));
          if (callbackFn?.body && !visiting.has(callbackFn)) inspect(callbackFn.body, origin, new Set(visiting).add(callbackFn));
        }
      }
      ts.forEachChild(node, child => inspect(child, origin, visiting));
    }

    return {
      'Program:exit'() {
        collect(source);
        for (const fn of setup) if (!deferred.has(fn)) inspect(fn.body ?? fn.initializer, undefined, new Set([fn]));
        for (const { callback, callsite } of effectCallbacks) {
          if (isAccessor(checker.getTypeAtLocation(callback))) report(callback, callsite);
          else {
            const fn = functions(callback) ? callback : callable(callback);
            if (fn?.body && projectCode(fn)) {
              const origin = fn.getSourceFile() === source ? undefined : callsite;
              const visiting = new Set([fn]);
              inspect(fn.body, origin, visiting);
              if (ts.isBlock(fn.body)) effectReturns(fn.body, origin, visiting);
              else inspectCleanup(fn.body, origin, visiting);
            }
          }
        }
      },
    };
  },
};
