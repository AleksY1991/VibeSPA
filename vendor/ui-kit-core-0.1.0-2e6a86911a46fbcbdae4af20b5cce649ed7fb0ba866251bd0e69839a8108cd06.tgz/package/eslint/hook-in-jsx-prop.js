/**
 * A hook called inline in JSX — `<X model={useModel()} />` or `{useModel()}`
 * as a child — compiles to a getter, so Solid re-runs the call on every read
 * of that prop. The first read from an event handler has no owner, and a
 * context hook throws NoOwnerError there. Call the hook in the component body
 * and pass its result.
 *
 * A hook inside a callback written in JSX (`onClick={() => useX()}`) is a
 * different mistake with its own runtime error and is not this rule's job.
 */

const HOOK = /^use[A-Z]/;

const FUNCTION_NODES = new Set([
  'FunctionDeclaration',
  'FunctionExpression',
  'ArrowFunctionExpression',
]);

function hookName(callee) {
  if (callee.type === 'Identifier') return callee.name;
  if (callee.type === 'MemberExpression' && callee.property.type === 'Identifier') {
    return callee.property.name;
  }
  return null;
}

export const HOOK_IN_JSX_PROP = {
  meta: {
    type: 'problem',
    docs: {
      description: 'Hooks are called in the component body, never inline in JSX',
    },
    schema: [],
    messages: {
      inline: 'HOOK IN JSX: `{{name}}()` becomes a getter that re-runs without a Solid owner '
        + 'on every read; the first read from an event handler throws NoOwnerError. '
        + 'Call it in the component body and pass the value.',
    },
  },
  create(context) {
    return {
      CallExpression(node) {
        const name = hookName(node.callee);
        if (!name || !HOOK.test(name)) return;
        for (let parent = node.parent; parent; parent = parent.parent) {
          if (FUNCTION_NODES.has(parent.type)) return;
          if (parent.type === 'JSXExpressionContainer') {
            context.report({ node, messageId: 'inline', data: { name } });
            return;
          }
        }
      },
    };
  },
};
