import { posix } from 'node:path';
import { designSystemFilename } from './package-location.js';

// `Renderer` is a semantic suffix: it means Hotkey owns this component's
// visibility and registry lease. Renaming a passive host keeps the rule exact;
// aliases are rejected because they are the easiest way to hide a naked
// component definition in another file.
const rendererName = (node) =>
  node?.type === "Identifier" && /^(?!Renderer$)[A-Z][A-Za-z0-9]*Renderer$/.test(node.name);

const isHotkeyRenderer = (node) =>
  node?.type === "CallExpression"
  && node.callee?.type === "MemberExpression"
  && node.callee.computed === false
  && node.callee.object?.type === "Identifier"
  && node.callee.object.name === "Hotkey"
  && node.callee.property?.type === "Identifier"
  && node.callee.property.name === "renderer";

const jsxAttribute = (node, name) => node.attributes.find((attribute) =>
  attribute.type === 'JSXAttribute'
  && attribute.name.type === 'JSXIdentifier'
  && attribute.name.name === name);

const keyboardHandlerName = (name) =>
  /^onkey(?:down|up|press)(?:capture)?$/i.test(String(name).replace(':', ''));

const findHotkeysCall = (node) => {
  if (!node) return null;
  if (node.type === 'JSXExpressionContainer') return findHotkeysCall(node.expression);
  if (node.type === 'CallExpression') {
    return node.callee.type === 'Identifier' && node.callee.name === 'hotkeys' ? node : null;
  }
  if (node.type === 'ArrayExpression') {
    for (const element of node.elements) {
      const call = findHotkeysCall(element);
      if (call) return call;
    }
  }
  return null;
};

const marksLayer = (call) => call?.arguments[0]?.type === 'ObjectExpression'
  && call.arguments[0].properties.some((property) =>
    property.type === 'Property'
    && (property.key.name ?? property.key.value) === 'layer'
    && property.value.type === 'Literal'
    && property.value.value === true);

export function createHotkeyRendererRule({ lifecycleOwners = [], contextOwners = [], keyboardOwners = [], privateContextModules = [], registryModule, registryAdapter, aliases = {}, applicationTestRoots = [] } = {}) { return {
  meta: {
    type: "problem",
    schema: [],
    messages: {
      naked: "A *Renderer is a keyboard layer and must be defined with Hotkey.renderer(...). Rename passive UI to *Host/*Panel/*View.",
      lifecycle: "Renderer registry lifecycle is private to Hotkey.renderer(...); never register or mount it manually.",
      keyboard: "Declare keyboard handlers in the element's hotkeys contract; the element owns registration and cleanup.",
      unmarked: "An open dialog/menu must own a configured design-system layer (or the low-level hotkeys layer for a custom native element).",
    },
  },
  create(context) {
    const report = (node) => context.report({ node, messageId: "naked" });
    const reportLifecycle = (node) => context.report({ node, messageId: "lifecycle" });
    const filename = designSystemFilename(context.filename);
    const isFile = target => typeof target === 'string' && (filename === target || filename.endsWith('/' + target));
    const isUiTest = (/packages\/design-system\/src\//.test(filename) || applicationTestRoots.some(root => filename.includes('/' + root) || filename.startsWith(root))) && /\.test\.tsx?$/.test(filename);
    const isLifecycleOwner = ['packages/design-system/src/runtime/hotkeys.ts', 'packages/design-system/tests/surface-host.ts', ...lifecycleOwners].some(isFile) || isUiTest;
    const canUseRegistry = isLifecycleOwner || isFile(registryAdapter);
    const isContextOwner = isLifecycleOwner || ['packages/design-system/src/runtime/context.ts', 'packages/design-system/src/infrastructure/element.ts', 'packages/design-system/src/infrastructure/renderUiRoot.tsx', ...contextOwners].some(isFile);
    const importedModule = source => {
      if (typeof source !== 'string') return '';
      if (source.startsWith('@ui-kit/core/')) return posix.normalize('packages/design-system/src/' + source.slice(13));
      const alias = Object.entries(aliases).find(([prefix]) => source.startsWith(prefix));
      if (alias) return posix.normalize(alias[1] + source.slice(alias[0].length));
      return source.startsWith('.') ? posix.normalize(posix.dirname(filename) + '/' + source) : source;
    };
    const moduleIs = (source, target) => typeof target === 'string' && (() => {
      const module = importedModule(source).replace(/\.[jt]sx?$/, '');
      return module === target || module.endsWith('/' + target);
    })();
    const isPrivateContext = source => ['packages/design-system/src/runtime/context', ...privateContextModules].some(target => moduleIs(source, target));
    const isRegistry = source => moduleIs(source, registryModule);
    const registryObjects = new Set(['surfaceRegistry']);
    const lifecycleImports = new Set(['mountSurface', 'mountRendererSurface', 'mountElementSurface', 'mountElementSurfaceLease', 'mountNonvisualSurfaceLease', 'registerRenderer']);
    const isKeyboardInfrastructure = isLifecycleOwner || ['packages/design-system/src/solid/field-lifecycle.ts', 'packages/design-system/src/solid/scroll-area.tsx', 'packages/design-system/src/solid/split-panel-interaction.ts', 'packages/design-system/src/solid/tabs.tsx', ...keyboardOwners].some(isFile);
    const insideHotkeys = (node) => {
      let current = node.parent;
      while (current) {
        if (
          current.type === 'CallExpression'
          && current.callee.type === 'Identifier'
          && current.callee.name === 'hotkeys'
        ) return true;
        if (current.type === 'Program' || current.type === 'JSXElement') return false;
        current = current.parent;
      }
      return false;
    };
    return {
      FunctionDeclaration(node) {
        if (rendererName(node.id)) report(node.id);
      },
      ClassDeclaration(node) {
        if (rendererName(node.id)) report(node.id);
      },
      VariableDeclarator(node) {
        if (rendererName(node.id) && !isHotkeyRenderer(node.init)) report(node.id);
      },
      ImportSpecifier(node) {
        if (rendererName(node.local) && !rendererName(node.imported)) report(node.local);
      },
      ImportDefaultSpecifier(node) {
        if (rendererName(node.local)) report(node.local);
      },
      ExportSpecifier(node) {
        if (rendererName(node.exported) && !rendererName(node.local)) report(node.exported);
      },
      ImportDeclaration(node) {
        if (!isContextOwner && isPrivateContext(node.source.value)
          && node.importKind !== 'type'
          && node.specifiers.some(specifier => specifier.importKind !== 'type')) {
          reportLifecycle(node);
        }
        if (canUseRegistry || !isRegistry(node.source.value)) return;
        for (const specifier of node.specifiers) {
          if (specifier.type === 'ImportNamespaceSpecifier') reportLifecycle(specifier);
          if (specifier.type === 'ImportSpecifier' && specifier.imported.name === 'surfaceRegistry') {
            registryObjects.add(specifier.local.name);
          }
          if (
            specifier.type === 'ImportSpecifier'
            && lifecycleImports.has(specifier.imported.name)
          ) reportLifecycle(specifier);
        }
      },
      ExportNamedDeclaration(node) {
        if (node.source && !isContextOwner && isPrivateContext(node.source.value)
          && node.exportKind !== 'type') reportLifecycle(node);
        if (node.source && !isLifecycleOwner && isRegistry(node.source.value)
          && node.specifiers.some(specifier => lifecycleImports.has(specifier.local?.name))) reportLifecycle(node);
      },
      ExportAllDeclaration(node) {
        if (!isContextOwner && isPrivateContext(node.source.value)
          && node.exportKind !== 'type') reportLifecycle(node);
        if (!isLifecycleOwner && isRegistry(node.source.value)) reportLifecycle(node);
      },
      ImportExpression(node) {
        if (!isContextOwner && isPrivateContext(node.source.value)) reportLifecycle(node);
      },
      CallExpression(node) {
        const memberName = node.callee.type === 'MemberExpression'
          ? node.callee.property.type === 'Identifier'
            ? node.callee.property.name
            : node.callee.property.value
          : null;
        if (
          !isKeyboardInfrastructure
          && node.callee.type === 'MemberExpression'
          && memberName === 'addEventListener'
          && node.arguments[0]?.type === 'Literal'
          && /^key(?:down|up|press)$/.test(node.arguments[0].value)
        ) context.report({ node, messageId: 'keyboard' });
        if (canUseRegistry || node.callee.type !== 'MemberExpression') return;
        if (
          node.callee.object.type === 'Identifier'
          && registryObjects.has(node.callee.object.name)
          && ['mount', 'mountRenderer', 'mountElement', 'mountElementLease', 'mountNonvisualLease', 'registerRenderer'].includes(memberName)
        ) reportLifecycle(node.callee);
      },
      JSXOpeningElement(node) {
        if (isKeyboardInfrastructure) return;
        if (
          node.name.type !== 'JSXIdentifier'
          || node.name.name[0] !== node.name.name[0].toLowerCase()
        ) return;
        const role = jsxAttribute(node, 'role');
        const state = jsxAttribute(node, 'data-state');
        const roleValue = role?.value?.type === 'Literal' ? role.value.value : null;
        const isLayerRole = ['dialog', 'alertdialog', 'menu'].includes(roleValue)
          || (roleValue === 'listbox' && state?.value?.type === 'Literal' && state.value.value === 'open');
        const hotkeysCall = findHotkeysCall(jsxAttribute(node, 'ref')?.value);
        // A semantic positioning wrapper may contain the configured surface.
        // Require that surface to be the sole substantive direct child, so a
        // random nested control cannot silently legitimize an unowned layer.
        const children = node.parent.children.filter(child => child.type !== 'JSXText' || child.value.trim());
        const child = children.length === 1 && children[0].type === 'JSXElement' ? children[0].openingElement : null;
        const policy = child && jsxAttribute(child, 'surface')?.value?.expression;
        const childName = child?.name.type === 'JSXMemberExpression' && child.name.property.name === 'View'
          ? child.name.object.name : child?.name.name;
        const configuredChild = child && ['Card', 'MenuSurface', 'Dialog', 'Popover'].includes(childName)
          && jsxAttribute(child, 'observable') && jsxAttribute(child, 'hotkeys')
          && policy?.type === 'ObjectExpression'
          && policy.properties.some(p => p.type === 'Property' && (p.key.name ?? p.key.value) === 'kind' && p.value.value === 'own')
          && policy.properties.some(p => p.type === 'Property' && (p.key.name ?? p.key.value) === 'layer' && p.value.value === true);
        if (
          !isLayerRole
          || marksLayer(hotkeysCall)
          || configuredChild
        ) return;
        context.report({ node, messageId: 'unmarked' });
      },
      JSXAttribute(node) {
        if (isKeyboardInfrastructure) return;
        const name = node.name.type === 'JSXIdentifier'
          ? node.name.name
          : `${node.name.namespace.name}:${node.name.name.name}`;
        if (keyboardHandlerName(name)) context.report({ node, messageId: 'keyboard' });
      },
      Property(node) {
        if (isKeyboardInfrastructure || insideHotkeys(node)) return;
        const name = node.key.type === 'Identifier' ? node.key.name : node.key.value;
        if (keyboardHandlerName(name)) {
          context.report({ node, messageId: 'keyboard' });
        }
      },
      AssignmentExpression(node) {
        if (isKeyboardInfrastructure || node.left.type !== 'MemberExpression') return;
        const name = node.left.property.type === 'Identifier'
          ? node.left.property.name
          : node.left.property.value;
        if (keyboardHandlerName(name)) context.report({ node, messageId: 'keyboard' });
      },
    };
  },
};



}
export const HOTKEY_RENDERER_RULE = createHotkeyRendererRule();
