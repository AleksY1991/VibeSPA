import { describe, expect, it } from 'vitest';
import { designSystemStylesheetProblems, stylesheetFrameworkProblems } from './control-stylesheets.js';

const file = 'packages/design-system/src/example.css';

describe('design-system stylesheet dependencies', () => {
  it.each([
    'url("/application.png")',
    'image-set("/application.png" 1x)',
    '-webkit-image-set("/application.png" 1x)',
    String.raw`u\72l("/application.png")`,
    'url(var(--application-asset))',
  ])('rejects external or unverifiable assets: %s', value => {
    expect(designSystemStylesheetProblems(`.example { background-image: ${value}; }`, file)).not.toEqual([]);
  });
  it.each([
    '@import "../../ui/src/view.css";',
    String.raw`@\69mport "../../ui/src/view.css";`,
    String.raw`@im\70ort "../../ui/src/view.css";`,
    String.raw`@im\70 ort "../../ui/src/view.css";`,
    String.raw`@i\mport "../../ui/src/view.css";`,
    '@IMPORT url("../../ui/src/view.css") layer(controls);',
  ])('rejects application imports: %s', css => {
    expect(designSystemStylesheetProblems(css, file)).not.toEqual([]);
  });
  it('accepts owned assets and format metadata without treating metadata as a URL', () => {
    expect(designSystemStylesheetProblems('.example { background: image-set("./assets/image.png" 1x type("image/png")); src: url("./assets/font.woff2") format("woff2"); }', file)).toEqual([]);
  });
  it('rejects compiler-dependent CSS in either package', () => {
    expect(stylesheetFrameworkProblems('@tailwind utilities; .example { @apply text-body; width: theme("spacing.2"); }', file)).toHaveLength(3);
    expect(stylesheetFrameworkProblems('.example { width: var(--ui-space); }', file)).toEqual([]);
  });
});
