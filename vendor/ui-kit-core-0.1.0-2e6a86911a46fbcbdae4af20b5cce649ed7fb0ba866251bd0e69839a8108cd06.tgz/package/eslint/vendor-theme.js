import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import postcss from 'postcss';
import { DESIGN_SYSTEM_PACKAGE_ROOT } from './package-location.js';

const require = createRequire(import.meta.url);
export const PINNED_VENDOR_THEME = resolve(DESIGN_SYSTEM_PACKAGE_ROOT, 'src/vendor/web-awesome/theme.css');

/** Numeric and focus defaults belong only to the unchanged, scoped vendor snapshot. */
export function upstreamVendorThemeDeclarations() {
  const vendor = JSON.parse(readFileSync(require.resolve('@awesome.me/webawesome/package.json'), 'utf8'));
  if (vendor.version !== '3.12.0') throw new Error('Review the scoped vendor theme policy when upgrading Web Awesome.');
  const visited = new Set();
  const flatten = (filename) => {
    if (visited.has(filename)) return [];
    visited.add(filename);
    return postcss.parse(readFileSync(filename, 'utf8')).nodes.flatMap(node => {
      if (node.type !== 'atrule' || node.name !== 'import') return [node];
      const target = node.params.match(/^url\(['"]([^'"]+)['"]\)$/)?.[1];
      if (!target) throw new Error(`Unrecognized pinned vendor theme dependency: ${node.params}`);
      return flatten(resolve(dirname(filename), target));
    });
  };
  const sheet = postcss.root();
  sheet.append(...flatten(require.resolve('@awesome.me/webawesome/dist/styles/themes/default.css')));
  const declarations = [];
  sheet.walkDecls(declaration => { declarations.push([declaration.prop, declaration.value, String(declaration.important)]); });
  return declarations;
}
