import { Linter } from 'eslint';
import { describe, expect, it } from 'vitest';
// @ts-expect-error ESLint rules are plain JavaScript.
import { ELEMENT_CONSTRUCTION } from './element-construction.js';

const messages = (code: string, filename = 'packages/ui/src/views/example/Control.jsx') => new Linter().verify(code, [{
  files:['**/*.jsx'],
  languageOptions:{ecmaVersion:2022,sourceType:'module',parserOptions:{ecmaFeatures:{jsx:true}}},
  plugins:{haku:{rules:{construction:ELEMENT_CONSTRUCTION}}},
  rules:{'haku/construction':'error'},
}],{filename});

describe('element construction gate', () => {
  it('rejects getter/event/derived factories including aliases and local wrappers', () => {
    expect(messages('const C=()=> <Button observable={constructItem("x", build)}/>')).toHaveLength(1);
    expect(messages('const C=()=> <Button onActivate={()=>constructItem("x", build)}/>')).toHaveLength(1);
    expect(messages('import {constructItem as bind} from "@ui-kit/core/solid"; const C=()=> <Button {...bind("x", build)}/>')).toHaveLength(1);
    expect(messages('function model(){return constructItem("x", build)} const C=()=> <Button observable={model()}/>')).toHaveLength(1);
    expect(messages('const C=()=>{const x=createMemo(()=>constructItem("x",build)); return x;}')).toHaveLength(1);
    expect(messages('import {Button} from "@ui-kit/core"; const C=()=>{const x=createMemo(()=>new Button(props));return x;}')).toHaveLength(1);
    expect(messages('import {Button} from "@ui-kit/core"; const C=()=> <div onClick={()=>Button.View(props)}/>')).toHaveLength(1);
    expect(messages('import {Button as Choice} from "../../../../design-system/src/solid/button"; const C=()=>{const x=createMemo(()=>new Choice(props));return x;}')).toHaveLength(1);
    expect(messages('import {Button as Choice} from "@ui-kit/core/solid/button"; const C=()=> <div onClick={()=>Choice.View(props)}/>')).toHaveLength(1);
  });
  it('allows construction in components and keyed item owner callbacks', () => {
    expect(messages('const C=()=>{const model=constructItem("x", build);return <Button observable={model}/>;}')).toEqual([]);
    expect(messages('const C=()=> <For each={ids()}>{id=>{const model=constructItem(id,build);return <Button observable={model}/>;}}</For>')).toEqual([]);
  });
  it('keeps subscription machinery private', () => {
    const construction = 'import {readObservable} from "@ui-kit/core/infrastructure/construction";';
    expect(messages(construction, 'src/features/example/Control.jsx')).toHaveLength(1);
    expect(messages(construction)).toEqual([]);
    expect(messages(construction, 'packages/design-system/src/solid/wrapper.jsx')).toEqual([]);
    expect(messages('import {ElementBinding} from "@ui-kit/core/composition";', 'src/features/example/Control.jsx')).toHaveLength(1);
  });

  it('tracks public core subpaths and app composition constructors after extraction', () => {
    for (const source of ['@ui-kit/core', '@ui-kit/core/solid/button', '#ui/compositions/solid/property-bar', '#ui/presentation/TaskDisplay']) {
      expect(messages(`import {Button as Control} from "${source}"; const C=()=> <div onClick={()=>Control.View(props)}/>;`), source).toHaveLength(1);
    }
    expect(messages('const C=()=> <Button.View aria-disabled={locked()}/>;', 'packages/design-system/src/solid/button.jsx')).toEqual([]);
    expect(messages('const C=()=> <Button.View aria-disabled={locked()}/>;', 'packages/ui/src/compositions/solid/wrapper.jsx')).toHaveLength(1);
  });
  it('rejects copied aria state that hyphenated JSX names evade type checking', () => {
    expect(messages('const C=()=> <Button observable={model} aria-disabled={locked()}/>')).toHaveLength(1);
    expect(messages('const C=()=> <Button.View observable={model} aria-disabled={locked()}/>')).toHaveLength(1);
    expect(messages('const C=()=> <button aria-pressed={selected()}/>')).toEqual([]);
  });
});
