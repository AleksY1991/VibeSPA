import { readdirSync } from 'node:fs';
import path from 'node:path';
import { ESLint } from 'eslint';
import { expect, it } from 'vitest';
import { CANONICAL_SELECTORS, COLOR_SELECTORS, DESIGN_SELECTORS } from './policies.js';

const root = path.resolve(import.meta.dirname, '../../..');
const eslint = new ESLint({ cwd: root });
const walk = (directory: string): string[] => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
  const file = path.join(directory, entry.name);
  return entry.isDirectory() ? walk(file) : /\.[cm]?[jt]sx?$/.test(entry.name) ? [file] : [];
});

it('retains complete design policy and isolation for every source file and future module format', async () => {
  const files = [...walk(path.join(root, 'packages/design-system/src')),
    ...['ts', 'tsx', 'js', 'jsx', 'mjs', 'cjs', 'mts', 'cts'].map(extension => path.join(root, `packages/design-system/src/future.${extension}`))];
  for (const filename of files) {
    const config = await eslint.calculateConfigForFile(filename);
    for (const rule of ['design-system-boundary', 'design-system-consumer', 'design-geometry', 'icon-boundary', 'element-construction', 'focus-highlight', 'icon-only-label', 'hook-in-jsx-prop', 'subscription-disposal', 'ui-state-persistence', 'hotkey-renderer']) {
      expect(config?.rules?.[`ui/${rule}`], `${filename}: ${rule}`).toEqual([2]);
    }
    expect(config?.rules?.['no-restricted-syntax'], filename).toEqual(['error', ...DESIGN_SELECTORS, ...COLOR_SELECTORS, ...CANONICAL_SELECTORS].map((value, index) => index === 0 ? 2 : value));
    if (/\.tsx?$/.test(filename) && !/\.(?:test|test-helpers?)\.tsx?$|\/(?:__tests__)\//.test(filename.replaceAll('\\', '/'))) {
      expect(config?.rules?.['ui/strict-reactive-reads'], filename).toEqual([2]);
      expect(config?.rules?.['ui/event-scope'], filename).toEqual([2]);
    }
  }
});
